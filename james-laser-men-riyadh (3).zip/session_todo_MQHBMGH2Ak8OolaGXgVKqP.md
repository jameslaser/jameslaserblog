# Session Todo — Saudi Healthcare Website Compliance

- [x] Inspect the public site, appointment intake, protected portal boundaries, active database schema, and policy publication state.
- [x] Verify current Saudi MOH, SDAIA/PDPL, and NCA applicability through official-source research.
- [x] Add an explicit, purpose-limited health-screening acknowledgement to the full appointment form.
- [x] Persist additive privacy-notice version and health-screening acknowledgement evidence without changing existing clinic records.
- [x] Add bilingual public Patient Rights & Privacy routes and make them discoverable from the homepage footer.
- [x] Add public policy update-date display and correct the appointment form’s policy-link behavior.
- [x] Document remaining required governance approvals, PIA/DPIA, vendor, retention, rights-request, breach, transfer, DPO, and NCA-scope work.
- [x] Verify the database columns, type check, test suite, production build, and public English/Arabic interfaces.
