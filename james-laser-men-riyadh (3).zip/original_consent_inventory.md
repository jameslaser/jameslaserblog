# Original Consent Document Inventory

## Preservation status

This inventory records source-document identification only. No supplied PDF has been edited, copied into application assets, merged, rewritten, text-replaced, or used to create a derived signed document. The original uploaded PDFs remain authoritative source files pending owner confirmation of the exact appointment-consent document or document set.

| Supplied file | Pages inspected | Source identity and observable fields | Signature requirement observed | Current implementation status |
|---|---:|---|---|---|
| `FILENO3(1).pdf` | 1 | Bilingual New Look Clinic waiver with date and file-number fields, laser-session exception checkboxes, and English/Arabic layout. SHA-256: `dc820722e64c2a857a41dd005ff8f561060318127f24febd9566a473113fbd36` | Name and Signature lines are present | Identified as an original waiver; not yet selected for appointment display |
| `NewLookDentalandDermatologyClinicsComplex3(1).pdf` | 1 | Bilingual New Look Dental and Dermatology Clinics Complex adoption/policy sheet. SHA-256: `ec0026052ad658dd01ef503b7ac9f825a4e8e3a4ebc5e27dffb4221d5c6d7c8c` | Name, Signature, and File No. lines are present | Identified as an original policy/adoption sheet; not yet selected for appointment display |
| `CLINICPOLICYAGREEMENT3(1).pdf` | 1 | Bilingual “Clinic Policy Agreement” for laser treatment. SHA-256: `6cc22bfd5b3075f59a66cdf3d45fb214acf7c71d9bb9fcbf712a0ce59981d071` | “I have read and agreed to these terms” appears with Name, Signature, File No., and Date lines | Identified as an original policy agreement; not yet selected for appointment display |

All three supplied source documents include observable signature fields. Any final appointment workflow must preserve every selected original document unchanged and must not treat an online acknowledgement as a replacement for those signature fields.
