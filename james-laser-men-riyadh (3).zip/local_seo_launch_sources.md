# Google Search and Local Business Launch Sources

## Search Console domain-property and sitemap requirements

Google documents that a Search Console **Domain property** covers protocols and subdomains, while ownership verification for that property is DNS-record only. Google supplies the verification record during the owner flow; it must not be invented or substituted. Google also states that sitemap URLs should be fully qualified canonical URLs, and sitemap submission is a hint rather than a guarantee of crawling or indexing. [1] [2]

## Google Business Profile representation

Google Business Profile guidance requires business information to reflect real-world branding and an accurate address or service area, recommends choosing the fewest categories that describe the core business, and warns against multiple profiles for the same business. This supports reviewing any existing New Look Clinic or approved service profile rather than automatically creating another listing. [3]

## Structured data constraints

Google permits LocalBusiness markup for a business page and requires a name and address for local-business rich-result eligibility. It also recommends a working location URL and customer contact telephone when applicable, but review/aggregate-rating markup is only recommended on sites that capture reviews about *other* businesses. The planned markup therefore uses only owner-provided name, address and telephone, with no ratings, coordinates, price range, or unverified day-by-day hours. [4]

## References

[1] [Google Search Console: Add a website or platform property](https://support.google.com/webmasters/answer/34592?hl=en)

[2] [Google Search Central: Build and submit a sitemap](https://developers.google.com/search/docs/crawling-indexing/sitemaps/build-sitemap)

[3] [Google Business Profile: Guidelines for representing your business on Google](https://support.google.com/business/answer/3038177?hl=en)

[4] [Google Search Central: LocalBusiness structured data](https://developers.google.com/search/docs/appearance/structured-data/local-business)
