# Public Homepage Media Selection

## Selected original assets

| Asset | Intended homepage use | Reason |
|---|---|---|
| `filtered-D585CDF4-5A25-49AD-862E-C50C6C74D313.mp4` | Hero procedure video | Shows a male facial laser procedure with practitioner and client protective eyewear. It is James Laser branded and does not display before-and-after comparisons. |
| `-qbzht2_Original.JPG` | Practitioner / clinical-approach section | James Laser branded banner showing Nurse James in clinical attire beside treatment equipment. |

## Assets intentionally excluded from the public home page

The before-and-after graphics are not included because they could be interpreted as individual treatment outcomes. The New Look facility video and materials are not selected because their baked-in New Look branding, phone number, and clinic identity would conflict with the James Laser public identity. The Nurse James circular badge is not selected because the wide James Laser banner is a clearer section visual.

## Pending review

An equipment image may be selected after visual confirmation if it is free from unsupported promotional claims and works with the homepage composition.
