# WhatsApp Appointment Automation Handoff

## Delivery status

The repository now contains a **provider-ready, but inactive**, WhatsApp appointment-automation layer. It uses the existing Cloud API integration, protected staff roles, appointment/patient records, and webhook ingestion. No provider credential, Meta account, phone number, template, customer message, delivery receipt, or scheduler was configured during this implementation.

The default state is deliberately safe: `automationEnabled` is `false`; all patients begin with **consent verification required**; and records may be `scheduled`, `queued`, `provider_not_connected`, `blocked_consent`, or `blocked_template`, but are never represented as sent, delivered, or read without provider evidence.

## Included workflow

| Area | Implemented behavior |
|---|---|
| Session reminders | A deterministic job is prepared for **one day before** each eligible confirmed session, using the configured Riyadh dispatch time. |
| Retouch invitation | A deterministic job is prepared for **seven days after** a completed session. The original session creates an eligibility window from day 10 through day 14. |
| Appointment changes | Creating, editing, or recording an attendance outcome reconciles the queue. Obsolete unsent jobs are cancelled with a reason. |
| Consent and opt-out | An administrator records a verified opt-in or opt-out together with source and optional version. Opt-out cancels active queue jobs and synchronizes to the linked patient file. |
| Provider response handling | Authenticated replies are correlated by Meta message ID and conversation. `YES_SESSION` / `NO_SESSION`, retouch interest, eligible dates, and time choices update only protected workflow state. |
| Retouch requests | A customer response creates a retouch **request**, not an appointment. Staff must verify day 10–14 timing, date, time, machine, availability, and double-booking before confirmation creates the appointment. |
| Audit and retry | Manual queue/retry and cancellation require a staff reason. Provider submission, failure, patient response, and staff decisions are auditable. |
| Provider evidence | The API accepts a `provider_accepted` state only after a Meta response returns a message ID. Message `sent`, `delivered`, `read`, and `failed` status updates remain webhook-driven. |
| Scheduler | An owner can configure one authenticated five-minute heartbeat worker. It is **dormant** until the later checklist-gated owner activation. |

## Required owner activation sequence

1. Apply `drizzle/migrations/0023_add_whatsapp_automation_ready.sql` using the established managed database migration process.
2. Store the real Meta app secret, server-only access token, phone number ID, business account ID, webhook verification token, and Graph API version through the protected deployment-secret process. Do not place secrets in source control or the portal.
3. Configure the public callback at `/api/webhooks/whatsapp`, subscribe the required WhatsApp message/status fields, and complete Meta challenge verification.
4. Synchronize real provider templates in **WhatsApp → Templates**, submit the displayed English and Arabic utility-template definitions to Meta, and map only entries Meta has actually approved. Confirm variable counts and interactive reply IDs match the approved provider templates.
5. Establish and document the clinic’s verified patient opt-in/opt-out process. Existing appointments are intentionally not treated as opted in.
6. In **WhatsApp → Provider setup**, set the Riyadh reminder dispatch time and retouch-preparation copy, then use **Configure dormant scheduler**. Observe the first authenticated callback before treating the scheduler check as complete.
7. Perform the real provider test sequence: inbound webhook receipt, provider template acceptance, sent/delivered/read webhook receipt, interactive session reply, interactive retouch selection, staff approval, and error/retry handling. Record only a completed real test with **Record verified provider-flow test**.
8. After every checklist item is truthfully complete, the owner may select **Enable verified automation**. The UI presents an explicit warning that eligible queued templates may be submitted; it also states that appointments are never automatically created, moved, cancelled, or edited.

## Operational safeguards

The scheduler endpoint is `/api/scheduled/whatsapp-automation`. It accepts only an authenticated WebDev heartbeat identity and additionally checks that its task UID matches the protected WhatsApp settings record. The endpoint does not accept a task ID from request input.

Arabic and English template definitions are local specifications only. They become sendable only after an exact approved Meta template mapping exists for the applicable language. The implementation does not fabricate provider identifiers, approvals, delivery receipts, consent, or contact status.

## Local validation completed

The feature passed `pnpm check`, the focused Vitest suite for the new automation guards, existing WhatsApp service behavior, and webhook validation, and one final `pnpm build`. The production build completed successfully; Vite reported only its existing large-chunk advisory. There is no active managed WebDev project attached in the present workspace, so deployment and database application remain intentionally unperformed.
