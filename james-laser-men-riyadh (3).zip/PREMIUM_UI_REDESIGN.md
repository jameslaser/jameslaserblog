# Premium Healthcare UI/UX Redesign

## Scope

This pass improves the shared protected clinic shell without changing routes, tRPC contracts, database schemas, authentication, role-based access, HMS source boundaries, appointment/request separation, or patient records.

## Design decisions

The existing James Laser visual language remains the source of truth: deep navy for secure navigation, warm ivory for the workspace canvas, terracotta for active and attention states, and restrained serif display typography paired with readable sans-serif body copy. New shared utilities provide consistent page headers, eyebrow labels, soft surfaces, accessible focus rings, safe touch targets, and restrained elevation without introducing a second design system.

## Protected shell changes

The desktop shell retains the collapsible role-filtered sidebar and adds a clearer active state, quieter borders, and more deliberate header hierarchy. Shared page headings now use the same eyebrow, title, description, and action alignment across operational and content workspaces. The loading shell uses neutral branded placeholders rather than attention-grabbing accent blocks.

On small screens, the sidebar remains available through the existing menu control and a new fixed bottom navigation provides fast access to Dashboard, Appointments, Patients, WhatsApp, and More. The bottom bar uses safe-area padding, touch-sized controls, active-page labeling, and extra main-content padding so it does not cover clinic records.

## Preservation and safety

All existing portal modules remain available through the sidebar and More menu. The mobile shortcuts are derived from the existing role-filtered navigation, so they do not grant access to routes the current role cannot see. No public page exposes protected navigation or clinic records. Arabic public pages retain their existing localized route, document direction, typography, and metadata behavior.

## Validation

TypeScript passed. The full Vitest suite passed with 57 test files and 190 tests. The production build passed. Desktop screenshots were reviewed at 1440×900 for Dashboard, Appointments, and Patients. Mobile screenshots were reviewed at 390×844 for the same routes, including the bottom navigation. A tablet review at 1024×768 covered the Arabic homepage, Dashboard, Waiting List, and HMS workspace. A single readiness integration test required a longer startup allowance and now passes at 1500 ms; this is test timing only and does not alter runtime behavior.

The build continues to report a non-blocking bundle-size advisory for the existing large client chunk. Code splitting can be considered as a separate performance task, but it was not mixed into this targeted UI redesign.
