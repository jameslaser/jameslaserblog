# Appointment Request → Appointment Transfer Workflow

> **Operational workflow record.** Public appointment submission is a request only; it does not confirm an appointment or create a patient record.

## Required sequence

| Stage | System area | Record state | Boundary |
|---|---|---|---|
| 1. Public collection | Public Home → `/appointment` or `/ar/appointment` | A persistent private request is created with status `pending` | The public result is availability-only; no appointment is created. |
| 2. Clinic review | Admin → Patient Requests | Staff sees the original public request, consent reference, signature status/reference, and private workflow controls | Original public values remain retained. |
| 3. Finalization | Admin → Patient Requests | Authorized staff can enter the protected final snapshot: corrected contact details, MRN, date, time, multi-area treatment selection, machine, visit type, notes, optional staff assignment, and optional duration | Finalized fields are stored separately from original public submission data. |
| 4. Explicit transfer | Admin → Patient Requests | `Approve & transfer to Appointments` performs the only transition to `transferred` | The server validates the active request, final details, 15-minute time, duplicate mobile/time conflict, machine/time conflict, MRN ownership, and one linked appointment. |
| 5. Finalized schedule | Admin → Appointments | A linked appointment is created with source request ID, final snapshot, and consent/signature continuity | Unreviewed public requests never appear in this view. |

## Consent and signature continuity

The transferred appointment carries the original consent-set reference, acknowledgement time and language, signature status, and signature reference from the patient request. The workflow does not generate another consent record, replace an original PDF, or confirm the appointment until the explicit staff transfer transaction succeeds.

## Safeguards

The ordinary request-status update path rejects `transferred`. This prevents a status-only UI or API call from making a request look scheduled without a linked appointment. The transfer transaction rejects an existing appointment for the same mobile number at the selected date and time, and rejects a selected machine already assigned at that time. It retains the original request after transfer and links it by ID.

The implementation does not create test requests, patient files, confirmed appointments, signatures, or signed derivatives. Staff should use the protected Patient Requests workspace for real clinic review and the Appointments workspace only for already finalized records.
