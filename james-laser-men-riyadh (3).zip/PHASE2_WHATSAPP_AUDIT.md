# Phase 2 WhatsApp Integration Audit

## Architecture decision

The existing application is an appropriate host for the WhatsApp module: it already runs a single Express service on Cloud Run, uses tRPC for protected staff actions, persists operational data in PostgreSQL through Drizzle, stores private assets through a server-side proxy, and has role-gated Admin Portal workspaces. No Firebase, browser automation, personal WhatsApp automation, or separate CRM is required.

| Approach | Trade-offs | Cost | Setup complexity |
| --- | --- | --- | --- |
| **Direct Meta WhatsApp Business Platform Cloud API in the existing Cloud Run service** | Preserves a single operational system, allows first-party webhook validation, ties messages directly to request/patient/appointment records, and requires owner Meta setup. This is the Phase 2 implementation route. | Meta platform and conversation charges apply under the owner’s account; no intermediary platform fee is introduced. | Moderate; requires a Meta app, business phone, webhook subscription, approved templates, and Secret Manager entries. |
| A later third-party messaging provider or CRM adapter | Could reduce some vendor setup work but would add another vendor, duplicate data boundaries, and violate the Phase 2 direct-Cloud-API requirement. | Additional platform cost. | Higher long-term integration and governance burden. |

> **Selected route:** direct Meta Cloud API calls from the existing Cloud Run application. Meta documents that the WhatsApp Business Platform uses JSON webhooks for incoming messages, outgoing-message status updates, and related account events. The `messages` webhook includes both inbound customer messages and outbound delivery status updates. [1]

## Existing components to reuse

| Existing component | Reuse in Phase 2 |
| --- | --- |
| `server/_core/index.ts` | Host `GET` and `POST` `/api/webhooks/whatsapp` before JSON parsing so the raw body can be verified; keep `/healthz` and `/readyz` independent of Meta availability. |
| `server/_core/trpc.ts` and `server/routers.ts` | Add protected WhatsApp procedures under the current `owner`, `admin`, and `reception` role boundaries. Content editors remain denied. |
| `server/db.ts` `normalizeMobileNumber` | Reuse as the sole normalized-phone representation for deterministic matching against patient requests, patient files, appointments, and WhatsApp contacts. |
| `consultationRequests`, `patients`, and `appointments` tables | Store nullable links from a WhatsApp conversation; retain the existing approval-and-transfer workflow rather than replacing it. |
| `notifications` and `activityLogs` | Reuse generic staff notifications for inbound messages and existing audit logs for send, assign, status, link, and archive events. |
| `server/storage.ts` and storage proxy | Use private random-key storage and protected downloads if inbound Meta media retention is enabled. No public media URL will be introduced. |
| `AdminPortal`, `AdminRequestsWorkspace`, and the existing `/admin/*` routes | Add a mobile-aware WhatsApp workspace and contextual open/link controls, without creating a separate CRM. |
| Existing consent-signature flow | Preserve it; a WhatsApp message cannot replace original consent acknowledgement or a required signature. |

## New components required

| Area | Required Phase 2 addition |
| --- | --- |
| Meta client | A small server-only `metaWhatsApp` client that sends text/templates, synchronizes template metadata, optionally retrieves supported media, and normalizes safe errors. |
| Webhook endpoint | `GET /api/webhooks/whatsapp` challenge verification and `POST /api/webhooks/whatsapp` signature verification, event persistence, fast acknowledgement, and idempotent processing. |
| PostgreSQL model | Contacts, conversations, messages, templates, webhook events, automation logs, and safe integration settings/health metadata. |
| Services | Deterministic phone linking, conversation assignment/status transitions, unread counting, service-window enforcement, template sending, retry safety, webhook processing, and protected media authorization. |
| tRPC surface | Staff inbox/conversation/contact/template/settings procedures with server-side RBAC and input validation. |
| Admin UI | `/admin/whatsapp` workspace with Inbox, Conversations, Contacts, Templates, Automations, Webhook Logs, and Settings views. |
| Tests | Mocked Meta send/webhook tests, idempotency, status update, service-window, RBAC, deterministic linking, and secret-boundary regressions. |

## Database changes

The Phase 2 schema will add PostgreSQL tables with non-cascading foreign keys into the existing records.

| Table | Core purpose | Key constraints and links |
| --- | --- | --- |
| `whatsappContacts` | One retained WhatsApp identity per normalized number/Meta `wa_id`. | Unique `waId`; unique normalized phone where known; nullable deterministic links to patient request and patient. |
| `whatsappConversations` | Operational conversation state. | One contact link; status, assignee, unread count, service-window timestamps, nullable request/patient/appointment links. |
| `whatsappMessages` | Immutable chronological inbound/outbound and system/status records. | Unique Meta message ID where supplied; direction, type, original body, safe error fields, status timestamps, optional private media reference. |
| `whatsappTemplates` | Meta template metadata cache. | Unique business-account/template/language combination; approved status is required for outside-window sends. |
| `whatsappWebhookEvents` | Auditable, idempotent inbound payload receipt. | Unique event fingerprint; processing state and safe error field; no secret data. |
| `whatsappAutomationLogs` | Records only simple approved operational automation decisions. | References conversation/message where available; no chatbot behavior. |
| `whatsappSettings` | Safe health and public account metadata. | Stores account/phone identifiers, API version, webhook health timestamps; never stores tokens, app secret, or verify token. |

A separate PostgreSQL migration history will be generated under `drizzle-pg`; the historical MySQL/TiDB migration record remains untouched.

## Server route and security changes

The public webhook endpoint will not use staff authentication. `GET` will validate Meta’s verification token and return the requested challenge only on a valid subscription attempt. `POST` will validate the request HMAC derived from the raw request body and the server-only Meta app secret before event persistence. Invalid signatures and malformed payloads will be rejected without logging secret values.

Meta retries webhook deliveries that do not receive HTTP 200, potentially for up to seven days. [1] The handler must therefore detect duplicate event fingerprints and duplicate Meta message IDs before creating messages, conversations, notifications, or audit records. It will return acknowledgement promptly after durable receipt and handle unknown event types safely.

Meta service messages are free-form only while the customer-service window is open; once it closes, the system must use a pre-approved template. [2] The server will calculate this from the last inbound customer message, reject free-form outbound sends outside that window, and preserve actual sent, delivered, read, and failed statuses from Meta webhooks.

## Admin UI changes

The new **WhatsApp** Admin Portal navigation entry will be available to owner, admin, and reception users. The first view will use a responsive inbox design: a desktop conversation list, selected chronology, and customer context panel; on mobile it will present the list and conversation as focused views. It will show only the minimum operational preview data and keep detailed patient data on existing protected patient screens.

The context panel will link to existing patient requests, patient records, and appointments. Linking will happen automatically only on a deterministic normalized-phone match; ambiguous matches will require an authorized staff choice. No inbound message will create a confirmed appointment, reschedule an appointment, cancel an appointment, or replace the consent flow.

## Secrets required

No Meta or WhatsApp secret is present in the repository or current integration configuration. Add the following values directly to Google Secret Manager, then configure Cloud Run only with Secret Manager references: `META_APP_ID`, `META_APP_SECRET`, `WHATSAPP_ACCESS_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_BUSINESS_ACCOUNT_ID`, `WHATSAPP_WEBHOOK_VERIFY_TOKEN`, and `META_GRAPH_API_VERSION`.

## Owner actions required

| Step | Where | Value type | Expected result |
| --- | --- | --- | --- |
| Create or select the Meta app and add WhatsApp | Meta for Developers / WhatsApp product | Owner account action | A production WhatsApp Business Platform app is available. |
| Connect the business portfolio and production phone | Meta Business / WhatsApp Manager | Owner account action | A verified business phone and WhatsApp Business Account are connected. |
| Create the Secret Manager values | Google Cloud Secret Manager | Secret values entered directly by owner | Cloud Run can reference secrets without exposing them to source control or the frontend. |
| Deploy the Cloud Run revision | Existing protected Cloud Build flow | Owner-approved deployment | A stable HTTPS callback URL is available. |
| Configure callback and subscriptions | Meta App Dashboard → WhatsApp Configuration | `https://<production-origin>/api/webhooks/whatsapp`; verify token entered directly in Meta | Meta successfully verifies the webhook and `messages` subscription is active. |
| Approve operational templates | WhatsApp Manager | Approved English/Arabic templates | The module can send compliant messages outside the customer-service window. |
| Authorize a production test number | Meta / WhatsApp | Owner-controlled test number | The inbound message → webhook → inbox and outbound send/status path can be verified. |

No password, two-factor code, Meta access token, app secret, or verification token is required in this conversation.

## References

[1]: https://developers.facebook.com/documentation/business-messaging/whatsapp/webhooks/overview "Meta WhatsApp Business Platform — Webhooks"
[2]: https://developers.facebook.com/documentation/business-messaging/whatsapp/messages/send-messages "Meta WhatsApp Business Platform — Service messages"
