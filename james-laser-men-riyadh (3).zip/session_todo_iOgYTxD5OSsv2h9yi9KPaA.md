# Session Todo — Real-HMS Publication Validation

- [x] Locate the existing authorized HMS worker and login flow.
- [x] Authenticate to the real HMS without exposing credentials.
- [x] Fetch one genuine appointment report without database writes.
- [x] Record privacy-safe immutable evidence with accepted and rejected record hashes.
- [x] Add a strict publication gate that rejects missing, empty, stale, tampered, or incomplete evidence.
- [x] Run the complete TypeScript, test, and production-build suite.
- [x] Re-run the mandatory publication gate.
- [ ] Save the verified checkpoint, publish, and verify the live admin boundary.
