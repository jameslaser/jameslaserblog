# Built-in Database Standard

## Active persistence layer

The managed Manus/WebDev application uses the built-in MySQL/TiDB-compatible database as its sole active persistence layer. Runtime database access is implemented through Drizzle ORM with `drizzle-orm/mysql2`, and the server resolves `MYSQL_URL` before any local-development fallback. The application does not load a PostgreSQL adapter, connect to Cloud SQL, or perform an external database migration.

All active clinic records remain in the existing database. This includes users and roles, appointment requests, patients, appointments, HMS import batches, consent-signature sessions, clinic settings, published and draft CMS content, media metadata, policies, notifications, enquiries, analytics events, redirect records, audit activity, and follow-up/reminder fields defined by the current schema. No reset, reseed, destructive migration, table deletion, or data cutover was performed during this cleanup.

## Cleanup performed

The following verified-unused executable PostgreSQL migration tooling was removed because it was not imported by the application runtime and existed only behind owner-controlled migration scripts:

| Removed item | Reason |
| --- | --- |
| `server/postgresMigration.ts` | Preflight helper used only by the removed PostgreSQL migration test. |
| `server/postgresMigration.test.ts` | Test for paused migration-only behavior; no active runtime dependency. |
| `scripts/postgres-migration-preflight.mjs` | Migration-only command removed from `package.json`. |
| `scripts/migrate-mysql-to-postgres.mjs` | Data-copy command removed from `package.json`; never executed during cleanup. |
| `pg` and `@types/pg` | Dependencies used only by the removed migration script and its type declarations. |
| `postgres:preflight` and `postgres:migrate` package scripts | Commands that exposed the paused external migration path. |

The dependency lockfile was regenerated after the package manifest change. Active MySQL/TiDB dependencies, Drizzle schema/runtime code, authentication, storage, notification, audit, policy, appointment, patient, and admin workflows were retained.

## Intentionally retained artifacts

Historical Cloud Run, Firebase, Cloud SQL, PostgreSQL, WhatsApp, deployment, audit, and pause documents were retained because they record prior decisions, owner boundaries, or deployment evidence. They are documentation, not active runtime adapters. `template.json` was retained because it is scaffold metadata; its embedded historical static template still mentions the original legacy server entrypoint but does not control this project’s active package scripts or build.

The legacy `server/index.ts` was retained rather than deleted because `template.json` contains it as part of the scaffold metadata. The active application instead builds and runs `server/_core/index.ts`. Removing the legacy file without also rewriting scaffold metadata would create an inconsistent template record, so it is listed as technical debt for a future deliberate scaffold-maintenance task.

## External infrastructure boundary

Cloud Run, Google Cloud billing, Firebase, Secret Manager, Cloud SQL, PostgreSQL, external hosting, custom domains, DNS, and related account actions remain paused. This cleanup changed no external resource and did not alter authentication callbacks, RBAC, policies, audit records, staff records, clinic data, media storage, or appointment records.

## Validation record

The cleanup must be accepted only after the following checks pass against the managed application: the active runtime resolves the built-in MySQL/TiDB contract through `MYSQL_URL`; no removed PostgreSQL module is imported; representative database-backed reads and updates remain covered by the existing tests; protected routes and role enforcement remain intact; TypeScript passes; Vitest passes; the production build passes; health/readiness endpoints respond successfully; and public, admin, and staff route smoke checks show no new runtime or mixed-data behavior.
