# Meta WhatsApp Business Activation Boundary

## Current audited status

The application currently provides **click-to-chat links only**. It has no Meta access token, no webhook route, no message sender, no inbound-message persistence, and no automated appointment reminder. No WhatsApp Business message, contact, or delivery record has been created by this project.

> Activation is intentionally blocked until an owner supplies Meta credentials and authorizes the target business account, phone number, and webhook callback URL.

## Verified integration model

Meta documents that the WhatsApp Business Platform uses webhooks for incoming messages and outbound message-status updates. It requires a configured HTTPS endpoint, field subscriptions, and the relevant messaging or management permissions.[1] The production connection must therefore use a server-side callback, signature validation, idempotent event handling, and role-protected operational views rather than browser-side API calls.

| Component | Planned safe behavior | Activation requirement |
|---|---|---|
| Outbound messages | Staff-triggered only at first; use approved Meta templates where required | Owner approval and live Cloud API credentials |
| Inbound webhooks | Verify the callback challenge and validate each signed event before persistence | HTTPS callback URL and Meta webhook subscription |
| Patient matching | Match only after explicit staff review; never create a patient, request, or appointment automatically | Approved matching policy and privacy review |
| Delivery state | Store provider message ID and delivery status separately from clinical records | Successful Meta test event |
| Failure handling | Idempotent retries with bounded attempts and visible staff status; no silent fallback or uncontrolled resend | Retry policy approved by owner |
| Automation | No unattended clinical decisions, no appointment confirmation, and no reminder activation by default | Separate owner authorization for each workflow |

## Required owner-provided configuration

The following values must be entered only through the protected deployment secret interface and never committed to the repository:

| Secret name | Purpose |
|---|---|
| `META_WA_ACCESS_TOKEN` | Server-side Cloud API authorization token |
| `META_WA_PHONE_NUMBER_ID` | Approved sending phone-number identifier |
| `META_WA_WABA_ID` | WhatsApp Business Account identifier for webhook and account scoping |
| `META_WA_VERIFY_TOKEN` | Random callback-challenge token chosen by the clinic owner |
| `META_WA_APP_SECRET` | Signature-validation secret for incoming webhook requests |

Before activation, the owner must also confirm the exact Saudi business number to use, approve the callback URL, configure the permitted webhook fields, and identify the approved templates and opt-in rules for any outbound message type. The webhook documentation describes the use of the Meta App Dashboard to subscribe to webhook fields after endpoint configuration.[1]

## Safe activation sequence

1. Add the five secrets through protected deployment configuration and confirm the target business account.
2. Register the production HTTPS callback in Meta and complete verification.
3. Send one Meta test webhook only; store no operational patient data unless the owner explicitly authorizes a controlled test policy.
4. Verify signature rejection, idempotency, provider-account scope, and non-creation of appointments or patient files.
5. Enable a single staff-initiated, template-approved action only after the above checks pass.
6. Add reminder automation later as a separate owner-authorized project, with consent and retention controls.

## References

[1] [Meta for Developers — WhatsApp Business Platform Webhooks](https://developers.facebook.com/documentation/business-messaging/whatsapp/webhooks/overview)
