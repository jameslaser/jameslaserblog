# Live Health HTTP Evidence

Read-only sweep date: 2026-09-07.

The managed host `jameslaser-elxrr9qk.manus.space` returned HTTP 200 for `/readyz`, `/sitemap.xml`, and `/robots.txt`. `/healthz` returned HTTP 404, so the deployed health endpoint is `/readyz`; this is a release-health issue to report, not a change made during this check.

The managed host returned HTTP 301 redirects to the canonical apex custom domain for `/`, `/en`, `/ar`, `/appointment`, `/policies/privacy-policy`, and `/ar/policies/privacy-policy`. The secondary managed hostname `jameslaserhairremovall.manus.space` redirected to the apex. `www.jameslaserhairremovall.com` redirected to the apex. The apex `https://jameslaserhairremovall.com/` returned HTTP 200 with the James Laser/New Look Clinic title.

Observed response security headers included HSTS, CSP, X-Content-Type-Options, Permissions-Policy, and Referrer-Policy. No DNS, hosting, routing, or application state was changed.
