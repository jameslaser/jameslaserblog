# WhatsApp Page Implementation Audit

**Project:** James Laser Hair Removal for Men Riyadh at New Look Clinic  
**Audit date:** 1 September 2026  
**Scope:** Public WhatsApp communication page and click-to-chat workflow only

## Baseline and project boundaries

The current application is a React, tRPC, Express, and Drizzle application using the built-in Manus MySQL-compatible database. The existing website, authenticated portal, appointment-request queue, clinic settings, treatment catalogue, anonymous analytics, staff notifications, and public-form security controls are active and should be reused. No PostgreSQL, Cloud SQL, Cloud Run migration, external CRM, WhatsApp bot, bulk sender, or automated marketing component is required for this feature.

The pre-change baseline is clean. TypeScript completed without errors, and the full automated suite reported **55 passed test files, 1 intentionally skipped integration file, 181 passed tests, and 1 skipped test**. The desktop preview was reviewed for the English homepage, Arabic public landing page, appointment request page, and protected appointment-request workspace.

| Area | Verified current implementation | Required WhatsApp-page action |
|---|---|---|
| Public routing | `/`, `/en`, `/ar`, localized content routes, `/appointment`, `/en/appointment`, and `/ar/appointment` | Add `/whatsapp`, `/en/whatsapp`, and `/ar/whatsapp` within the same route architecture |
| Branding | Ink navy, warm ivory, copper accent, serif display typography, and Noto Sans Arabic | Extend the existing design without converting the site to a green theme |
| Localization | English full homepage plus Arabic RTL landing and localized public routes | Reuse document `lang`, `dir`, localized metadata, and RTL patterns |
| Authentication | Admin and reception procedures are enforced server-side; the portal is noindexed | Keep the new page public and keep request management private |
| PWA | Public install metadata without service-worker caching of protected data | Make external WhatsApp navigation compatible with standalone mode and avoid the install prompt |

## Verified clinic identity and contact source

The authoritative clinic data is the single row in `clinicSettings`. The WhatsApp page must read this record through `trpc.publicContent.clinicSettings` rather than hardcoding a second contact configuration.

| Field | Verified active value |
|---|---|
| Clinic | New Look Clinic |
| Business identity | James Laser Hair Removal for Men Riyadh at New Look Clinic |
| Specialist | Nurse James, Laser Specialist |
| Location | Al Sahafah, Riyadh, Saudi Arabia |
| Official WhatsApp | `+966557401562` |
| Telephone | `+966920013676` |
| Working hours | 1:00 PM–10:00 PM |
| Map source | Existing `mapsUrl` / Google Business link in clinic settings |
| Active branches | One configured clinic location; no separate branch selector is required |

Only the last four WhatsApp digits should be included in the final user-facing release report. The complete number remains appropriate inside the public click-to-chat URL because it is already the clinic’s published contact number.

## Existing services and appointment workflow

The built-in database currently has **21 active treatment records**. The existing appointment page already exposes the same 21 clinic-approved treatment areas through a structured English and Arabic grouping. `clinicSettings.appointmentTreatmentOptions` is currently unset, so the established appointment fallback is the active source to reuse for the WhatsApp appointment and availability forms. A second service list or table is not required.

The existing `consultationRequests` table already contains all data required for WhatsApp-origin appointment requests, including the public request reference, preferred date and time, treatment areas, language, consent evidence, source, status, duplicate indicator, review fields, and timestamps. The public `appointmentRequest.create` procedure already validates clinic availability settings, performs server-side normalization, applies public-form rate limiting, persists the request as `pending`, creates a protected staff notification, links an exact existing WhatsApp conversation when possible, and records an anonymous appointment-submit event.

| Requested behavior | Existing capability | Minimal implementation |
|---|---|---|
| Save appointment request | `appointmentRequest.create` and `consultationRequests` | Reuse with source `whatsapp_page_en` or `whatsapp_page_ar` |
| Status = New Request | Database status `pending`, displayed as “New request” | Reuse unchanged |
| Admin visibility | `/admin/requests` uses the same request queue | Add visible source information; do not create a new admin page |
| Appointment confirmation boundary | Requests transfer to Appointments only after explicit staff approval | Preserve unchanged |
| Duplicate protection | Existing normalized-phone/date/time duplicate detection | Reuse unchanged |
| Staff notification | Existing protected in-portal appointment notification | Reuse unchanged |
| Rate limiting | Existing non-reversible request fingerprint guard | Reuse unchanged |
| Audit event | Activity log exists, but public request creation does not currently log the requested event | Add one non-sensitive `appointment_request_created` activity record linked only to the request ID |

## Public communication workflows

The public page should use the official `wa.me` click-to-chat format with correctly encoded messages. The primary CTA, service inquiry, price inquiry, availability inquiry, callback request, and general inquiry can remain deterministic client-side deep links. Only the appointment request needs database persistence because the project already has a defined public-to-private appointment queue.

The callback periods should reflect the configured 1:00 PM–10:00 PM working hours. The page should therefore offer an afternoon period and an evening period rather than promising morning availability. The public form should not request national ID, Iqama, passport data, payment information, medical reports, passwords, laboratory results, confidential staff information, or unnecessary clinical details.

## Analytics, SEO, and discoverability

The app already records anonymous analytics without a visitor identifier, IP address, or personal form content. The new page can use the existing event types: `page_view` for the page, `appointment_form_start` and `appointment_form_submit` for the appointment workflow, and `whatsapp_click` for click-to-chat actions. The selected communication action can be stored as a safe non-personal `contentSlug`, avoiding a database enum migration and ensuring form content is never sent to analytics.

The page should use the existing `publicUrl()` helper for canonical and alternate-language URLs, add Open Graph and Twitter metadata at route level, and add the canonical English and Arabic routes to `sitemap.xml`. Admin URLs must remain absent from the sitemap and blocked from indexing.

## Implementation decision

The minimal architecture is one reusable bilingual `WhatsAppPage` component, one reusable public floating launcher, existing clinic and treatment queries, the existing appointment mutation, and a small pure helper module for validated message generation and URL encoding. A local QR-code library may render the canonical click-to-chat URL in the browser; no external QR-generation service should receive the clinic link or visitor data.

This approach preserves the current system boundaries, avoids duplicate persistence, adds no external service, and keeps the protected appointment and WhatsApp administration workspaces separate from the new public page.

## Resumed implementation decision — synchronized baseline `ec36dc95`

The public conversion page will retain the existing secure appointment contract rather than introduce a parallel appointment table or endpoint. Appointment handoff will call `appointmentRequest.create` with a localized source value, which already applies the existing server-side validation, trusted request fingerprint, rate guard, normalized phone storage, consent evidence, protected staff notification, private request status, and optional exact conversation linking.

Click-to-chat actions for a service question, current offers, availability, a callback request, and a general inquiry will be generated locally and opened by the visitor in the real WhatsApp application. They do not submit personal data to the application database. The page will not simulate a chat, publish staff presence, claim response times, or activate the provider-side Meta Cloud API.

Source auditability needs no schema migration: `consultationRequests.source` already supports the localized page origins. The implementation will add a non-sensitive activity record on public appointment-request creation and expose an internal source label in the existing protected request workspace. This is additive and does not alter confirmed appointments, HMS records, patients, or the waiting list.
