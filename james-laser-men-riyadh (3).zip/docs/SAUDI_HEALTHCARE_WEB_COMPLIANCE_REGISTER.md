# Saudi Healthcare Web Compliance Register

**Scope.** This register records the privacy, patient-rights, and security controls relevant to the New Look Clinics public website and protected operational portal. It is an implementation and governance record, not a legal opinion. Current official Arabic texts and qualified Saudi legal, privacy, and Ministry of Health licensing advice remain necessary before a material launch or a change to health-data processing.

## Current implementation decision

The public appointment page collects treatment-history and skin-screening information. These data can reveal health status and must therefore be treated as **sensitive personal data**. The implementation now requires a separate, unticked acknowledgement limited to the clinic’s appointment-review purpose. It stores the acknowledgement timestamp and the version of the privacy notice with the private appointment request. The acknowledgement expressly states that it is **not treatment consent**.

The public site now has an indexed bilingual **Patient Rights & Privacy** page. It links to the official Ministry of Health patient-rights document, explains a minimal-data contact route for privacy and patient-rights requests, and warns against submitting IDs, passwords, medical reports, or payment details through public forms or WhatsApp. The public privacy policy display now shows its last-updated date when that metadata is available.

No clinic record, policy archive, patient, appointment, or audit record was deleted or reseeded. The database change is additive only. Existing records receive a neutral privacy-notice version default and a `false` health-screening-consent value, preserving historical evidence rather than rewriting it.

## Regulatory basis and applied control

| Requirement | Classification | Applied or required control |
|---|---|---|
| A controller must provide a privacy policy before collecting personal data, and direct collection must state the purpose, required versus optional fields, legal basis, rights, contact route, retention criteria, and consent withdrawal method where consent is used. | Legally required / regulatory detail | The appointment request links to the public privacy policy. Its health-screening acknowledgement is purpose-specific and separate from optional marketing. The policy content must still be completed with verified clinic-specific controller contact, recipients, retention criteria, lawful basis, and transfer facts before a production approval. [1] [2] |
| Health data are sensitive data. Sensitive-data processing requires a documented impact assessment, restricted health-data operations, and purpose limitation. | Regulatory requirement | The health-screening acknowledgement, version evidence, private persistence, existing role-protected review queue, and separate treatment-consent statement reduce collection and reuse risk. A formal PIA/DPIA remains required before approval of this health-data workflow. [1] [2] |
| Patients have rights to confidentiality, understandable treatment discussion, informed consent or refusal before a procedure, information/record access subject to controls, and a complaint route. | Regulatory requirement for clinics; website layout is an implementation choice | The public patient-rights page provides discoverability and an official MOH source. The appointment page makes clear that an online request and privacy acknowledgement are not clinical informed consent. A clinic-owned complaint and rights-request workflow with tracking remains a required operational control. [3] [4] |
| Personal-data requests require identity verification, logging, and response within 30 days, subject to the limited documented extension route. | Legally required / regulatory requirement | The public page directs people to an official clinic contact channel and warns against unsafe initial disclosure. The clinic must implement a verified identity, case owner, 30-day timer, response record, and extension-notice process. [1] [2] |
| Controllers must apply suitable organizational, administrative, and technical safeguards; health-data access must be limited to the necessary people and use. | Regulatory requirement | Preserve individual protected accounts, server-side authorization, least privilege, audit trails, protected private queues, secure sessions, and the existing security headers. Privileged and clinical access should use MFA as a risk-based, ECC-aligned best practice unless a more specific applicable rule makes it mandatory. [1] [2] [5] |
| A controller must maintain processing records, processor governance, incident readiness, and foreign-transfer assessments when data are processed outside the Kingdom. | Regulatory requirement; transfer duties are conditional | Complete and maintain a data-flow register, vendor/processor register and agreements, breach runbook, and data-residency/support-location assessment. Do not claim Saudi-only hosting or NCA ECC scope without a documented applicability assessment. [1] [2] [5] |

## Required governance gates before production approval

The following gates are not safely satisfied by code alone and remain open until the clinic provides its verified operational facts and approvals.

**Privacy notice completion.** The published privacy policy must be reviewed against the actual controller identity and privacy contact, data categories, mandatory versus optional fields, purpose and lawful basis for every field, retention criteria, recipient and processor categories, rights route, withdrawal mechanism where consent is used, and actual international-transfer position. The existing policy must not promise an unverified retention period, Saudi-only data residency, controller registration, DPO appointment, or technical product feature.

**PIA/DPIA and processing record.** The clinic must approve a written assessment covering the appointment form, clinical-screening fields, staff roles, database, backups, logs, analytics, storage, support access, vendors, data geography, risks, and mitigations. The processing record must be kept current during processing and for five years after the activity ends. [2]

**Controller, DPO, and National Register assessment.** The clinic must document whether the controller-registration and data-protection-officer triggers apply to its actual health-data processing. Where the trigger applies, the clinic must appoint and publish the appropriate privacy contact or DPO and keep the relevant national registration information current. [6] [7]

**Rights and complaint operations.** A named clinic owner must receive privacy and patient-rights requests. The clinic must use identity verification before releasing, changing, or deleting personal data, preserve a case log, control response deadlines, and create an escalation path for complaints. Public WhatsApp, telephone, and email can begin a request but should not be used to collect unnecessary sensitive details.

**Retention and deletion.** The clinic must define approved retention criteria for web leads, abandoned requests, documents, operational logs, backups, and clinical records. Clinical-record retention must be confirmed separately; it must not be invented from web-platform rules. Destruction must include processor copies and backups when the applicable retention or legal-hold exception ends. [1] [2]

**Vendors and transfers.** Before a third party processes clinic data, the clinic must verify safeguards and sign the required processor terms. The inventory must cover hosting, storage, backups, analytics, messaging, support access, and subcontractors. Any outside-Kingdom processing requires the applicable transfer assessment and safeguards before data flow begins. [1] [2]

**Breach readiness.** The clinic must test an incident process with a named owner, evidence preservation, processor escalation, impact assessment, a 72-hour authority-notification decision path, affected-person notices where required, and corrective-action records. [2]

**NCA and health-sector scope.** The clinic must record an NCA ECC/CCC and critical-national-infrastructure scope determination. ECC is binding for the entities within its stated scope; for other private entities it is an authoritative security baseline, not an automatic legal designation. A SeHE or current telehealth integration requires a separate current MOH onboarding, licensing, and governance review. [5]

## Change-control rule

Any addition of symptom fields, medical uploads, remote consultation, AI-assisted decision support, patient photographs, testimonials, marketing audiences, analytics/session replay, a new vendor, or an overseas support or hosting location is a **material change**. It requires a data-flow review, lawful-basis check, privacy-notice comparison, PIA/DPIA update, authorization review, vendor/transfer assessment, and security test before release.

## References

[1]: https://sdaia.gov.sa/en/SDAIA/about/Documents/PersonalDataProtectionLaw.pdf "Personal Data Protection Law — Saudi Data and AI Authority"
[2]: https://sdaia.gov.sa/en/SDAIA/about/Documents/ImplementingRegulationPersonalDataProtectionLaw.pdf "Implementing Regulation of the Personal Data Protection Law — Saudi Data and AI Authority"
[3]: https://www.moh.gov.sa/en/HealthAwareness/EducationalContent/HealthTips/Documents/Patient-Bill-of-Rights-and-Responsibilities.pdf "Patient Rights and Responsibilities Document — Saudi Ministry of Health"
[4]: https://www.moh.gov.sa/en/Ministry/Rules/Documents/Law-of-Practicing-Healthcare-Professions.pdf "Law of Practicing Healthcare Professions and Implementing Regulation — Saudi Ministry of Health"
[5]: https://nca.gov.sa/en/regulatory-documents/controls-list/ecc/ "Essential Cybersecurity Controls 2-2024 — National Cybersecurity Authority"
[6]: https://sdaia.gov.sa/Documents/TheRulesGoverningTheNationalRegisterOfControllersWithinTheKingdomPublicEN.pdf "Rules Governing the National Register of Controllers Within the Kingdom — Saudi Data and AI Authority"
[7]: https://sdaia.gov.sa/en/SDAIA/about/Documents/RulesforAppointingPersonalDataProtectionOfficer.pdf "Rules for Appointing a Personal Data Protection Officer — Saudi Data and AI Authority"
