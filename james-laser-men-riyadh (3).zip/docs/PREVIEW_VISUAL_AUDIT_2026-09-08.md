# Managed Preview Visual Audit — 8 September 2026

## Scope

The existing managed WebDev project `eLXrr9QKsAYaLdvTTBBjZX` was verified after the bilingual premium homepage, expanded request workflow, inline consent/signature experience, protected request-detail additions, and additive database migration were completed. The audited public routes were `/`, `/ar`, `/appointment`, and the protected boundary at `/admin`.

## Visual and responsive checks

| Check | Result | Evidence observed |
|---|---|---|
| English homepage desktop | PASS | Premium navy, copper, and cream visual system; large English hero; clinic-published treatment grid; skin-tone discussion aid with medical limitation; exact four machines; five-step journey; Nurse James section; clinic media; visible map; request CTA; and footer render in the intended order. |
| Arabic homepage desktop | PASS | Arabic content renders in RTL with mirrored composition, Arabic trust indicators, the same four machines, approved media, and equivalent CTA hierarchy. |
| Appointment form desktop | PASS | One grouped form renders with contact details, preferred date/time, session/retouch choice, treatment-area selection, conditional screening, notes, complete consent reader, electronic signature, acknowledgements, and one final request button. |
| English homepage mobile | PASS | Mobile navigation and every section stack cleanly without horizontal clipping. |
| Arabic homepage mobile | PASS | RTL mobile layout, approved media, map area, and footer stack cleanly without horizontal clipping. |
| Appointment form mobile | PASS | Fields, treatment-area choices, conditional questions, consent reader, signature panel, acknowledgements, and final button remain visible and usable in one column. |
| Horizontal overflow | PASS | Desktop document width matched the viewport width (`1265px`). Mobile screenshots showed no horizontal clipping. |

## Content and runtime checks

| Check | Result | Evidence observed |
|---|---|---|
| English document direction | PASS | `lang=en`, `dir=ltr`. |
| Arabic document direction | PASS | Arabic route rendered right-to-left in final desktop and mobile captures. |
| Appointment navigation | PASS | English homepage appointment CTAs resolve to `/appointment`; Arabic routing is covered by route/source tests. |
| Google Map | PASS | One visible iframe is titled `View New Look Clinic location` and uses the configured Riyadh clinic address through `https://www.google.com/maps?...&output=embed`. |
| Nurse James image | PASS | Existing allowlisted asset loaded with intrinsic size 851×284. |
| Treatment image | PASS | Existing allowlisted male back-treatment asset loaded with intrinsic size 2560×1707. |
| Treatment video | PASS | Existing allowlisted facial-treatment video reached ready state 4 at 720×1280 with a 3.73-second duration. |
| Retired broken media paths | PASS | The three 404 paths were removed and regression-tested so they cannot silently return. No new media was generated or uploaded. |
| Homepage console | PASS | No runtime/API error was reported after the page, images, video, and map loaded. Browser output contained only the deliberate diagnostic result. |
| Protected `/admin` boundary | PASS | Before authentication, the route exposes only the secure-access page and one `Sign in securely` action; no admin/request data is public. |
| Admin pre-auth console | PASS | No runtime error appeared after the secure-access page settled. |
| Authenticated owner-role session | NOT EXECUTED | The sandbox OAuth window closed to `about:blank`; no credentials were guessed or entered. This does not block the public preview/checkpoint, but owner-role verification should be performed in the user's authenticated browser before public publication. |

## Database safety

Before migration, five existing appointment-request records were counted. The migration added nine nullable intake/evidence columns and one unique idempotency index. After migration, all five records remained, none received a fabricated submission ID, all nine columns existed, and the unique index existed. No record was deleted, reset, reseeded, or overwritten.

## Final publication state

The custom domain, Arabic route, appointment route, and admin route all returned HTTP 200 after the canonical-domain redirect. Response headers included HSTS, `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, a restrictive permissions policy, and the reviewed CSP frame allowlist.

The custom domain was verified to remain on the previous production homepage rather than checkpoint `678166c1`. My Browser was enabled, but user-browser takeover was unavailable and the sandbox had no authenticated session. The live `/admin` route was therefore rechecked at its unauthenticated boundary: it displayed only the secure sign-in screen, exposed no protected records, and produced no console errors.

This audit covers the managed development preview and release checkpoint preparation. The new checkpoint was **not published to production**. Publication remains intentionally blocked until an authorized user can complete the authenticated Admin Portal session check in a connected browser.
