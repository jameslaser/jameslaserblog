# Appointment Page and HMS Form Validation

**Date:** 19 September 2026  
**Scope:** Protected Admin Portal appointment page and the attached HMS `Report.csv` structure.

## Implemented behavior

The protected **Appointments** page now queries only records for the current Riyadh date where the persisted source is `hms_csv` and the internal appointment status is `confirmed`. Results are ordered by appointment start time and a defensive client-side identity check prevents duplicate rendering. The page no longer exposes the former multi-day calendar, status filters, or manual appointment entry controls.

The visible appointment row is intentionally limited to **patient name, appointment time, confirmed status, and controlled machine name**. The permitted machine values remain `DEKA AGAIN`, `CLARITY 2`, `GENTLE PROMAX`, and `DUETTO MACHINE`; unrecognized remarks do not create a new machine value.

The upload flow verifies the exact provider-scoped HMS export, accepts only source provider `NR011` or `Mohamed Taha (JF)`, and normalizes both to **`NR011 JAMES FLORES`**. It reads the report's `NotAttended` section as the active schedule to be synchronized as internal confirmed appointments and excludes the `Attended` history section. Provider-less, unknown-provider, malformed, error, and duplicate records are blocked. Valid rows synchronize automatically after server validation and the appointment/dashboard queries are invalidated immediately; the live appointment query also refreshes every five seconds.

## Actual attached form validation

The owner-supplied CSV was parsed three consecutive times without modification or database writes. Every run produced the same privacy-safe result:

| Check | Result |
|---|---:|
| Fatal parser errors | 0 |
| Provider verified from source | Yes |
| Source provider | Mohamed Taha (JF) |
| Internal provider code | NR011 |
| Internal provider label | NR011 JAMES FLORES |
| Active schedule rows retained | 36 |
| Attended-history rows excluded | 47 |
| Rows dated 19 September 2026 | 3 |
| Current-day rows sorted by time | Yes |
| Same-file duplicate fingerprints | 0 |

A database-aware **read-only preview** found 5 records already protected by duplicate controls and 31 valid non-duplicate rows available for synchronization. The source file was not imported automatically during development, and no production appointment, patient, request, or audit record was changed.

## Verification summary

| Validation | Result |
|---|---|
| TypeScript | PASS |
| Focused HMS, appointment, RBAC, and UI suite | PASS — 104 tests |
| Full application suite | PASS — 362 tests; 15 intentional skips |
| Production client, SSR, and server build | PASS |
| Actual CSV parse consistency | PASS — 3 identical runs |
| Database-aware preview | PASS — read only |
| Desktop authenticated appointment page | PASS |
| Mobile authenticated appointment page | PASS |
| Protected pre-auth boundary | PASS — no appointment data exposed |

No clinic records were reset, deleted, reseeded, or overwritten. The database remains the built-in Manus/WebDev persistence layer.
