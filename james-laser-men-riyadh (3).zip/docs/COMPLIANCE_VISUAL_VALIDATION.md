# Public Compliance UI Validation

**Validated on 19 September 2026 in the WebDev preview.**

The English **Patient Rights & Privacy** page renders with the public navigation, an easy-to-find privacy-policy link, a Ministry of Health patient-rights link, a clear treatment-consent boundary, a minimal-data privacy-request explanation, and the configured clinic email, telephone, and WhatsApp contact actions. The desktop layout displays the rights, data-request, consent, and contact cards with readable hierarchy and no visible overlap.

The English **Appointment Request** page renders the health-screening acknowledgement as a separate unchecked control after the privacy-policy acknowledgement. Its text limits use to appointment review and contact, states that it is not treatment consent, and links to the Patient Rights & Privacy page. The form retains its existing original-consent review, electronic-signature, private-queue, and no-confirmed-appointment boundaries.

No form was submitted during visual validation, and no patient or appointment data was created, changed, or exposed.

The Arabic **Patient Rights & Privacy** route was also validated. It renders in right-to-left layout, presents the Arabic privacy and patient-rights content, preserves the Ministry of Health link and official clinic contact actions, and its English language switch leads to the English Patient Rights & Privacy counterpart rather than the homepage.
