import { httpBatchLink } from "@trpc/client";
import { dehydrate, QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { renderToString } from "react-dom/server";
import { Router } from "wouter";
import superjson from "superjson";
import App from "./App";
import { trpc } from "./lib/trpc";
import { prefetchForPath, type HeadMeta, type SsrPrefetch } from "./ssr/prefetch";

export type RenderResult = {
  html: string;
  dehydratedState: unknown;
  head: HeadMeta;
};

export async function render(url: string, prefetch: SsrPrefetch): Promise<RenderResult> {
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false, refetchOnWindowFocus: false } },
  });
  const questionIndex = url.indexOf("?");
  const ssrPath = questionIndex === -1 ? url : url.slice(0, questionIndex);
  const ssrSearch = questionIndex === -1 ? "" : url.slice(questionIndex + 1);
  const head = await prefetchForPath(url, queryClient, prefetch);

  // Protected routes deliberately remain client-rendered. This avoids embedding
  // user-specific or operational content in HTTP responses while preserving the
  // normal authenticated application behavior after the client app starts.
  if (head.noindex && !head.notFound) {
    return { html: "", dehydratedState: dehydrate(queryClient), head };
  }

  const trpcClient = trpc.createClient({
    links: [httpBatchLink({ url: "/api/trpc", transformer: superjson })],
  });
  const html = renderToString(
    <trpc.Provider client={trpcClient} queryClient={queryClient}>
      <QueryClientProvider client={queryClient}>
        <Router ssrPath={ssrPath} ssrSearch={ssrSearch}>
          <App />
        </Router>
      </QueryClientProvider>
    </trpc.Provider>,
  );

  return { html, dehydratedState: dehydrate(queryClient), head };
}
