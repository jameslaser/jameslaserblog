import { describe, expect, it, vi } from "vitest";
import { downloadCsv, recordsToCsv } from "./csv";

describe("recordsToCsv", () => {
  it("serializes authorized export records with escaped quotes and ISO timestamps", () => {
    expect(recordsToCsv([{ id: 7, note: "Nurse said \"review\"", createdAt: new Date("2026-08-25T12:00:00.000Z") }])).toBe('id,note,createdAt\n"7","Nurse said ""review""","2026-08-25T12:00:00.000Z"');
  });

  it("returns an empty value when no authorized rows are available", () => {
    expect(recordsToCsv([])).toBe("");
  });

  it("hands a protected CSV to the browser download action with a revocable object URL", () => {
    const link = { href: "", download: "", click: vi.fn() };
    const createObjectUrl = vi.fn(() => "blob:clinic-export");
    const revokeObjectUrl = vi.fn();
    downloadCsv('id\n"7"', "james-laser-enquiries.csv", { createObjectUrl, revokeObjectUrl, createAnchor: () => link });
    expect(link).toMatchObject({ href: "blob:clinic-export", download: "james-laser-enquiries.csv" });
    expect(link.click).toHaveBeenCalledOnce();
    expect(revokeObjectUrl).toHaveBeenCalledWith("blob:clinic-export");
  });
});
