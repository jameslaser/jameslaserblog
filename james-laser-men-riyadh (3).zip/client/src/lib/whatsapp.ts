export type WhatsAppLocale = "en" | "ar";

function safeText(value: string, maximumLength = 1000) {
  return value.normalize("NFKC").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "").replace(/\r\n/g, "\n").trim().slice(0, maximumLength);
}

export function whatsappDigits(value: string) {
  return value.replace(/\D/g, "");
}

export function whatsappUrl(number: string, message?: string) {
  const digits = whatsappDigits(number);
  const text = message ? safeText(message) : "";
  return `https://wa.me/${digits}${text ? `?text=${encodeURIComponent(text)}` : ""}`;
}

/**
 * Creates an explicit manual fallback link for an authenticated clinic user.
 * This intentionally sends no message text or patient information beyond the
 * number needed by WhatsApp Web to open the chat.
 */
export function whatsappBusinessWebUrl(number: string) {
  const rawDigits = whatsappDigits(number);
  if (!rawDigits) return null;

  const internationalDigits = rawDigits.startsWith("00") ? rawDigits.slice(2) : rawDigits;
  const digits = internationalDigits.startsWith("0") && internationalDigits.length === 10
    ? `966${internationalDigits.slice(1)}`
    : internationalDigits;

  if (!/^[1-9]\d{7,14}$/.test(digits)) return null;
  return `https://web.whatsapp.com/send?phone=${digits}`;
}

export function quickWhatsAppMessage(locale: WhatsAppLocale, kind: "service" | "prices") {
  if (locale === "ar") return kind === "service" ? "مرحبًا، أود الاستفسار عن خدمات إزالة الشعر بالليزر للرجال في الرياض." : "مرحبًا، أود الاستفسار عن الأسعار والعروض المنشورة حاليًا.";
  return kind === "service" ? "Hello, I would like to ask about men’s laser hair removal services in Riyadh." : "Hello, I would like to ask about current published prices and offers.";
}

export function availabilityWhatsAppMessage(locale: WhatsAppLocale, input: { date: string; time: string; treatment: string }) {
  if (locale === "ar") return `مرحبًا، أود التحقق من التوفر لخدمة ${safeText(input.treatment, 120)} بتاريخ ${safeText(input.date, 20)} في الوقت ${safeText(input.time, 20)}. أفهم أن التوفر يحتاج إلى تأكيد من العيادة.`;
  return `Hello, I would like to check availability for ${safeText(input.treatment, 120)} on ${safeText(input.date, 20)} at ${safeText(input.time, 20)}. I understand availability requires clinic confirmation.`;
}

export function callbackWhatsAppMessage(locale: WhatsAppLocale, input: { name: string; mobile: string; callbackPeriod: string }) {
  if (locale === "ar") return `مرحبًا، اسمي ${safeText(input.name, 120)}. يمكن التواصل معي على ${safeText(input.mobile, 32)}. أفضل التواصل خلال ${safeText(input.callbackPeriod, 80)} ضمن ساعات عمل العيادة.`;
  return `Hello, my name is ${safeText(input.name, 120)}. You can contact me on ${safeText(input.mobile, 32)}. I prefer a callback during ${safeText(input.callbackPeriod, 80)} within clinic working hours.`;
}

export function generalInquiryWhatsAppMessage(locale: WhatsAppLocale, input: { name: string; message: string }) {
  if (locale === "ar") return `مرحبًا، اسمي ${safeText(input.name, 120)}. لدي استفسار عام: ${safeText(input.message, 1000)}`;
  return `Hello, my name is ${safeText(input.name, 120)}. I have a general enquiry: ${safeText(input.message, 1000)}`;
}
