import { describe, expect, it } from "vitest";
import {
  applyQuickReplyToDraft,
  EMPTY_WHATSAPP_MESSAGE_FILTERS,
  filterQuickReplies,
  filterWhatsAppMessages,
  hasActiveWhatsAppMessageFilters,
  resolveQuickReplyLanguage,
  WHATSAPP_QUICK_REPLIES,
} from "./whatsappWorkspace";

const messages = [
  { id: 1, direction: "inbound", messageType: "text", status: "received", body: "Can I request Tuesday?", templateName: null },
  { id: 2, direction: "outbound", messageType: "text", status: "delivered", body: "The clinic team will review availability.", templateName: null },
  { id: 3, direction: "outbound", messageType: "template", status: "read", body: null, templateName: "session_reminder_en" },
  { id: 4, direction: "system", messageType: "status", status: "failed", body: "Provider rejected delivery", templateName: null },
];

describe("WhatsApp workspace quick replies", () => {
  it("selects the persisted conversation language and uses the interface language only for unknown contacts", () => {
    expect(resolveQuickReplyLanguage("ar", "en")).toBe("ar");
    expect(resolveQuickReplyLanguage("en", "ar")).toBe("en");
    expect(resolveQuickReplyLanguage("unknown", "ar")).toBe("ar");
  });

  it("provides reviewed English and Arabic copy for every operational reply", () => {
    expect(WHATSAPP_QUICK_REPLIES).toHaveLength(6);
    for (const reply of WHATSAPP_QUICK_REPLIES) {
      expect(reply.en.title.trim()).not.toBe("");
      expect(reply.en.body.trim()).not.toBe("");
      expect(reply.ar.title.trim()).not.toBe("");
      expect(reply.ar.body.trim()).not.toBe("");
    }
    expect(WHATSAPP_QUICK_REPLIES.find(reply => reply.id === "availability-received")?.en.body).toContain("not a confirmed appointment");
    expect(WHATSAPP_QUICK_REPLIES.find(reply => reply.id === "availability-received")?.ar.body).toContain("لا يُعد هذا موعداً مؤكداً");
  });

  it("searches localized title/body copy and filters by category", () => {
    expect(filterQuickReplies("clinic", "all", "en").map(reply => reply.id)).toContain("clinic-hours");
    expect(filterQuickReplies("مرجع", "all", "ar").map(reply => reply.id)).toEqual(["request-reference"]);
    expect(filterQuickReplies("", "closing", "en").map(reply => reply.id)).toEqual(["closing"]);
  });

  it("replaces or appends only the local draft", () => {
    expect(applyQuickReplyToDraft("Existing draft", "Quick reply", "replace")).toBe("Quick reply");
    expect(applyQuickReplyToDraft("Existing draft", "Quick reply", "append")).toBe("Existing draft\n\nQuick reply");
    expect(applyQuickReplyToDraft("", "Quick reply", "append")).toBe("Quick reply");
  });
});

describe("WhatsApp message history filters", () => {
  it("filters by real direction, type, status, and local text without mutating records", () => {
    expect(filterWhatsAppMessages(messages, { ...EMPTY_WHATSAPP_MESSAGE_FILTERS, direction: "inbound" }).map(message => message.id)).toEqual([1]);
    expect(filterWhatsAppMessages(messages, { ...EMPTY_WHATSAPP_MESSAGE_FILTERS, messageType: "template" }).map(message => message.id)).toEqual([3]);
    expect(filterWhatsAppMessages(messages, { ...EMPTY_WHATSAPP_MESSAGE_FILTERS, status: "failed" }).map(message => message.id)).toEqual([4]);
    expect(filterWhatsAppMessages(messages, { ...EMPTY_WHATSAPP_MESSAGE_FILTERS, query: "availability" }).map(message => message.id)).toEqual([2]);
    expect(filterWhatsAppMessages(messages, { ...EMPTY_WHATSAPP_MESSAGE_FILTERS, query: "session_reminder" }).map(message => message.id)).toEqual([3]);
    expect(messages).toHaveLength(4);
  });

  it("supports combined filters, clear state, and truthful zero matches", () => {
    const filters = { ...EMPTY_WHATSAPP_MESSAGE_FILTERS, direction: "outbound" as const, status: "read" as const };
    expect(hasActiveWhatsAppMessageFilters(filters)).toBe(true);
    expect(filterWhatsAppMessages(messages, filters).map(message => message.id)).toEqual([3]);
    expect(filterWhatsAppMessages(messages, { ...filters, query: "not present" })).toEqual([]);
    expect(hasActiveWhatsAppMessageFilters(EMPTY_WHATSAPP_MESSAGE_FILTERS)).toBe(false);
    expect(filterWhatsAppMessages(messages, EMPTY_WHATSAPP_MESSAGE_FILTERS)).toHaveLength(4);
  });
});
