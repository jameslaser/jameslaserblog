export function recordsToCsv(rows: Array<Record<string, unknown>>) {
  if (!rows.length) return "";
  const headers = Object.keys(rows[0]);
  const escape = (value: unknown) => `"${String(value instanceof Date ? value.toISOString() : value ?? "").replaceAll('"', '""')}"`;
  return [headers.join(","), ...rows.map(row => headers.map(header => escape(row[header])).join(","))].join("\n");
}

type CsvDownloadDependencies = {
  createObjectUrl: (blob: Blob) => string;
  revokeObjectUrl: (url: string) => void;
  createAnchor: () => { href: string; download: string; click: () => void };
};

export function downloadCsv(csv: string, filename: string, dependencies: CsvDownloadDependencies = {
  createObjectUrl: blob => URL.createObjectURL(blob),
  revokeObjectUrl: url => URL.revokeObjectURL(url),
  createAnchor: () => document.createElement("a"),
}) {
  const url = dependencies.createObjectUrl(new Blob([csv], { type: "text/csv;charset=utf-8" }));
  const link = dependencies.createAnchor();
  link.href = url;
  link.download = filename;
  link.click();
  dependencies.revokeObjectUrl(url);
}
