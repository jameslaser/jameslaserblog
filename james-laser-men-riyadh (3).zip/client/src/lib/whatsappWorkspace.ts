export type QuickReplyLanguage = "en" | "ar";
export type QuickReplyCategory = "welcome" | "reference" | "review" | "availability" | "hours" | "closing";
export type QuickReplyDraftMode = "replace" | "append";

export type QuickReply = {
  id: string;
  category: QuickReplyCategory;
  en: { title: string; body: string };
  ar: { title: string; body: string };
};

export const WHATSAPP_QUICK_REPLIES: QuickReply[] = [
  {
    id: "welcome",
    category: "welcome",
    en: { title: "Welcome", body: "Hello, thank you for contacting James Laser at New Look Clinic. How may we assist you today?" },
    ar: { title: "ترحيب", body: "مرحباً، شكراً لتواصلك مع جيمس ليزر في عيادة نيو لوك. كيف يمكننا مساعدتك اليوم؟" },
  },
  {
    id: "request-reference",
    category: "reference",
    en: { title: "Request reference", body: "Please share your appointment request reference so our clinic team can review the correct request." },
    ar: { title: "رقم مرجع الطلب", body: "يرجى مشاركة رقم مرجع طلب الموعد حتى يتمكن فريق العيادة من مراجعة الطلب الصحيح." },
  },
  {
    id: "under-review",
    category: "review",
    en: { title: "Under review", body: "Thank you. Our clinic team is reviewing your message and will continue with you through this official WhatsApp conversation." },
    ar: { title: "قيد المراجعة", body: "شكراً لك. يقوم فريق العيادة بمراجعة رسالتك وسيواصل التواصل معك من خلال محادثة واتساب الرسمية هذه." },
  },
  {
    id: "availability-received",
    category: "availability",
    en: { title: "Availability received", body: "We received your preferred date and time. The clinic team will review availability. This is not a confirmed appointment until staff confirm it." },
    ar: { title: "تم استلام التفضيل", body: "استلمنا التاريخ والوقت المفضلين لديك. سيقوم فريق العيادة بمراجعة التوفر. لا يُعد هذا موعداً مؤكداً حتى يؤكده الموظفون." },
  },
  {
    id: "clinic-hours",
    category: "hours",
    en: { title: "Clinic hours", body: "Our clinic communication hours are from 1:00 PM to 10:00 PM in Riyadh." },
    ar: { title: "ساعات العيادة", body: "ساعات التواصل مع العيادة من 1:00 مساءً إلى 10:00 مساءً بتوقيت الرياض." },
  },
  {
    id: "closing",
    category: "closing",
    en: { title: "Closing", body: "Thank you for contacting James Laser at New Look Clinic. Our clinic team will continue with you through this official channel if further information is needed." },
    ar: { title: "ختام", body: "شكراً لتواصلك مع جيمس ليزر في عيادة نيو لوك. سيواصل فريق العيادة التواصل معك عبر هذه القناة الرسمية إذا لزم الأمر." },
  },
];

export function resolveQuickReplyLanguage(conversationLanguage: string | null | undefined, interfaceLanguage: QuickReplyLanguage): QuickReplyLanguage {
  return conversationLanguage === "ar" || conversationLanguage === "en" ? conversationLanguage : interfaceLanguage;
}

export function filterQuickReplies(query: string, category: QuickReplyCategory | "all", language: QuickReplyLanguage) {
  const normalizedQuery = query.trim().toLocaleLowerCase();
  return WHATSAPP_QUICK_REPLIES.filter(reply => {
    if (category !== "all" && reply.category !== category) return false;
    if (!normalizedQuery) return true;
    const localized = reply[language];
    return [localized.title, localized.body, reply.category].some(value => value.toLocaleLowerCase().includes(normalizedQuery));
  });
}

export function applyQuickReplyToDraft(currentDraft: string, replyBody: string, mode: QuickReplyDraftMode) {
  if (mode === "replace" || !currentDraft.trim()) return replyBody;
  return `${currentDraft.trimEnd()}\n\n${replyBody}`;
}

export type WhatsAppMessageFilters = {
  query: string;
  direction: "all" | "inbound" | "outbound" | "system";
  messageType: "all" | "text" | "image" | "document" | "audio" | "template" | "interactive" | "status" | "unsupported";
  status: "all" | "received" | "sending" | "sent" | "delivered" | "read" | "failed";
};

export type FilterableWhatsAppMessage = {
  direction: string;
  messageType: string;
  status: string;
  body?: string | null;
  templateName?: string | null;
};

export const EMPTY_WHATSAPP_MESSAGE_FILTERS: WhatsAppMessageFilters = {
  query: "",
  direction: "all",
  messageType: "all",
  status: "all",
};

export function hasActiveWhatsAppMessageFilters(filters: WhatsAppMessageFilters) {
  return Boolean(filters.query.trim()) || filters.direction !== "all" || filters.messageType !== "all" || filters.status !== "all";
}

export function filterWhatsAppMessages<T extends FilterableWhatsAppMessage>(messages: T[], filters: WhatsAppMessageFilters): T[] {
  const query = filters.query.trim().toLocaleLowerCase();
  return messages.filter(message => {
    if (filters.direction !== "all" && message.direction !== filters.direction) return false;
    if (filters.messageType !== "all" && message.messageType !== filters.messageType) return false;
    if (filters.status !== "all" && message.status !== filters.status) return false;
    if (!query) return true;
    return [message.body, message.templateName, message.messageType, message.status]
      .some(value => value?.toLocaleLowerCase().includes(query));
  });
}
