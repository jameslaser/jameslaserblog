import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";
import {
  fillCalendarDraft,
  fillFaqDraft,
  fillGuideDraft,
  fillHomepageDraft,
  fillPromotionDraft,
  fillSeoDraft,
  fillTreatmentDraft,
  slugifyDraft,
} from "./instantDrafts";

const read = (file: string) =>
  fs.readFileSync(path.resolve(process.cwd(), file), "utf8");

describe("instant zero-credit content drafts", () => {
  it("creates stable slugs locally without an API request", () => {
    expect(slugifyDraft("Men’s Laser: Face & Neck")).toBe(
      "mens-laser-face-neck"
    );
  });

  it("fills homepage copy immediately while preserving entered values", () => {
    const result = fillHomepageDraft({
      sectionKey: "custom-section",
      titleEn: "Owner title",
      subtitleEn: "",
      descriptionEn: "",
      titleAr: "",
      subtitleAr: "",
      descriptionAr: "",
      ctaText: "",
      ctaLink: "",
      status: "draft",
    });

    expect(result.sectionKey).toBe("custom-section");
    expect(result.titleEn).toBe("Owner title");
    expect(result.subtitleEn).not.toBe("");
    expect(result.titleAr).not.toBe("");
    expect(result.descriptionAr).not.toBe("");
    expect(result.ctaLink).toBe("/appointment");
    expect(result.status).toBe("draft");
  });

  it("fills treatment content but preserves factual commercial fields", () => {
    const result = fillTreatmentDraft({
      slug: "",
      nameEn: "Chest laser hair removal",
      nameAr: "",
      shortDescriptionEn: "",
      shortDescriptionAr: "",
      descriptionEn: "",
      descriptionAr: "",
      preparationEn: "",
      preparationAr: "",
      aftercareEn: "",
      aftercareAr: "",
      seoTitle: "",
      seoDescription: "",
      startingPrice: "",
      regularPrice: "250",
      durationMinutes: "",
      isActive: false,
    });

    expect(result.slug).toBe("chest-laser-hair-removal");
    expect(result.descriptionEn).toContain("Results vary");
    expect(result.preparationAr).not.toBe("");
    expect(result.seoDescription).not.toBe("");
    expect(result.startingPrice).toBe("");
    expect(result.regularPrice).toBe("250");
    expect(result.durationMinutes).toBe("");
    expect(result.isActive).toBe(false);
  });

  it("fills promotion copy without inventing price, dates, or publication state", () => {
    const result = fillPromotionDraft({
      slug: "",
      name: "",
      titleEn: "September clinic offer",
      titleAr: "",
      descriptionEn: "",
      descriptionAr: "",
      includedTreatments: "",
      termsEn: "",
      termsAr: "",
      originalPrice: "",
      promotionalPrice: "",
      startsAt: "",
      endsAt: "",
      status: "draft",
    });

    expect(result.slug).toBe("september-clinic-offer");
    expect(result.descriptionEn).toContain("must be confirmed by the clinic");
    expect(result.originalPrice).toBe("");
    expect(result.promotionalPrice).toBe("");
    expect(result.startsAt).toBe("");
    expect(result.endsAt).toBe("");
    expect(result.status).toBe("draft");
  });

  it("fills a bilingual guide and SEO fields without changing draft status", () => {
    const result = fillGuideDraft({
      slug: "",
      titleEn: "",
      titleAr: "",
      summaryEn: "",
      summaryAr: "",
      contentEn: "",
      contentAr: "",
      category: "",
      tags: "",
      seoTitle: "",
      metaDescription: "",
      canonicalUrl: "",
      status: "draft",
    });

    expect(result.slug).toBe("how-to-prepare-for-mens-laser-hair-removal");
    expect(result.contentEn).toContain("## Assessment and settings");
    expect(result.contentAr).toContain("## التقييم والإعدادات");
    expect(result.canonicalUrl).toContain(`/en/blog/${result.slug}`);
    expect(result.status).toBe("draft");
  });

  it("fills FAQ and calendar fields without authorizing or publishing anything", () => {
    const faq = fillFaqDraft({
      questionEn: "",
      answerEn: "",
      questionAr: "",
      answerAr: "",
      category: "",
      active: false,
    });
    const calendar = fillCalendarDraft(
      {
        planKey: "",
        plannedFor: "",
        topic: "",
        targetPage: "",
        searchIntent: "",
        cta: "",
        contentBrief: "",
        internalLinks: "",
        repurposingBrief: "",
        requiresOwnerAuthorization: false,
        externalPublication: false,
        status: "idea",
      },
      "2026-09-07"
    );

    expect(faq.questionAr).not.toBe("");
    expect(faq.answerEn).toContain("clinic");
    expect(faq.active).toBe(false);
    expect(calendar.plannedFor).toBe("2026-09-07");
    expect(calendar.contentBrief).toContain("Avoid guarantees");
    expect(calendar.requiresOwnerAuthorization).toBe(false);
    expect(calendar.externalPublication).toBe(false);
    expect(calendar.status).toBe("idea");
  });

  it("creates locale-specific SEO drafts", () => {
    const english = fillSeoDraft({
      locale: "en",
      title: "",
      metaDescription: "",
      robotsIndex: true,
    });
    const arabic = fillSeoDraft({
      locale: "ar-SA",
      title: "",
      metaDescription: "",
      robotsIndex: true,
    });

    expect(english.title).toContain("Riyadh");
    expect(arabic.title).toContain("الرياض");
    expect(english.robotsIndex).toBe(true);
    expect(arabic.robotsIndex).toBe(true);
  });
});

describe("instant draft control wiring", () => {
  const component = read("client/src/components/InstantDraftButton.tsx");
  const manager = read("client/src/pages/CmsManager.tsx");
  const catalogues = read("client/src/pages/CmsCatalogues.tsx");
  const promotions = read("client/src/pages/PromotionCatalogueUpload.tsx");
  const education = read("client/src/pages/CmsEducation.tsx");
  const calendar = read("client/src/pages/ContentCalendar.tsx");

  it("uses synchronous local handlers with no LLM or network integration", () => {
    const source = [
      component,
      manager,
      catalogues,
      promotions,
      education,
      calendar,
    ].join("\n");
    expect(source).toContain("data-instant-draft-control");
    expect(source).not.toContain("invokeLLM");
    expect(source).not.toMatch(/\bfetch\(/);
    expect(source).not.toContain("axios");
  });

  it("wires every applicable content form", () => {
    expect(manager).toContain("fillHomepageDraft");
    expect(manager).toContain("fillSeoDraft");
    expect(catalogues).toContain("fillTreatmentDraft");
    expect(promotions).toContain("fillPromotionDraft");
    expect(education).toContain("generateGuideDraft");
    expect(education).toContain("AI never publishes or posts externally on its own");
    expect(education).toContain("id: editingId ?? undefined");
    expect(education).toContain("clinicalReviewConfirmed: false");
    expect(education).toContain("fillFaqDraft");
    expect(calendar).toContain("fillCalendarDraft");

    const controls = [manager, catalogues, promotions, education, calendar]
      .map(source => source.match(/<InstantDraftButton/g)?.length ?? 0)
      .reduce((total, count) => total + count, 0);
    expect(controls).toBe(5);
  });
});
