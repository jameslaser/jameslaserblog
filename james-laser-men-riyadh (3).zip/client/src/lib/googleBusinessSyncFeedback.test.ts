import { describe, expect, it } from "vitest";
import { getGoogleBusinessSyncFeedback } from "./googleBusinessSyncFeedback";

describe("Google Business review sync feedback", () => {
  it("gives a specific next step for denied Google access", () => {
    const feedback = getGoogleBusinessSyncFeedback(
      "Google Business access was denied. Reconnect an account that manages the clinic profile."
    );

    expect(feedback.title).toBe("Google has not granted review access yet");
    expect(feedback.description).toContain("verified clinic Business Profile");
    expect(feedback.description).toContain("no review was published automatically");
  });

  it("gives a specific next step for expired authorization", () => {
    const feedback = getGoogleBusinessSyncFeedback(
      "Google Business authorization expired or was revoked. Reconnect the clinic profile."
    );

    expect(feedback.title).toBe("Google authorization needs to be renewed");
    expect(feedback.retryLabel).toBe("Reconnect Google Business");
  });

  it("uses a safe generic message instead of exposing unknown provider errors", () => {
    const feedback = getGoogleBusinessSyncFeedback(
      "Unexpected upstream payload diagnostic: token=not-for-display"
    );

    expect(feedback.title).toBe("The review sync did not finish");
    expect(feedback.description).not.toContain("token=not-for-display");
  });
});
