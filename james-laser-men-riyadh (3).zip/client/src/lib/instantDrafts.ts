const keep = (value: string, fallback: string) =>
  value.trim() ? value : fallback;

export function slugifyDraft(value: string) {
  return value
    .trim()
    .toLowerCase()
    .replace(/[’']/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 90);
}

export type HomepageDraft = {
  sectionKey: string;
  titleEn: string;
  subtitleEn: string;
  descriptionEn: string;
  titleAr: string;
  subtitleAr: string;
  descriptionAr: string;
  ctaText: string;
  ctaLink: string;
};

export function fillHomepageDraft<T extends HomepageDraft>(current: T): T {
  return {
    ...current,
    sectionKey: keep(current.sectionKey, "precision-and-timing"),
    titleEn: keep(current.titleEn, "Precision and timing for safer laser care"),
    subtitleEn: keep(
      current.subtitleEn,
      "Assessment-led treatment planning in Riyadh"
    ),
    descriptionEn: keep(
      current.descriptionEn,
      "Every plan begins with a review of skin type, hair characteristics, treatment area, and timing. The clinic confirms suitability and settings before treatment."
    ),
    titleAr: keep(current.titleAr, "الدقة والتوقيت لعلاج ليزر أكثر أمانًا"),
    subtitleAr: keep(
      current.subtitleAr,
      "تخطيط علاجي قائم على التقييم في الرياض"
    ),
    descriptionAr: keep(
      current.descriptionAr,
      "تبدأ كل خطة بمراجعة نوع البشرة وخصائص الشعر ومنطقة العلاج والتوقيت المناسب. تؤكد العيادة الملاءمة والإعدادات قبل العلاج."
    ),
    ctaText: keep(current.ctaText, "Request an appointment"),
    ctaLink: keep(current.ctaLink, "/appointment"),
  };
}

export type TreatmentDraft = {
  slug: string;
  nameEn: string;
  nameAr: string;
  shortDescriptionEn: string;
  shortDescriptionAr: string;
  descriptionEn: string;
  descriptionAr: string;
  preparationEn: string;
  preparationAr: string;
  aftercareEn: string;
  aftercareAr: string;
  seoTitle: string;
  seoDescription: string;
};

export function fillTreatmentDraft<T extends TreatmentDraft>(current: T): T {
  const subject = keep(current.nameEn, "Men’s laser hair removal treatment");
  const slug = keep(
    current.slug,
    slugifyDraft(subject) || "mens-laser-treatment"
  );
  return {
    ...current,
    slug,
    nameEn: subject,
    nameAr: keep(current.nameAr, "علاج إزالة الشعر بالليزر للرجال"),
    shortDescriptionEn: keep(
      current.shortDescriptionEn,
      `${subject} with assessment-led settings and a treatment schedule tailored to the hair-growth cycle.`
    ),
    shortDescriptionAr: keep(
      current.shortDescriptionAr,
      "علاج إزالة الشعر بالليزر للرجال بإعدادات قائمة على التقييم وجدول يراعي دورة نمو الشعر."
    ),
    descriptionEn: keep(
      current.descriptionEn,
      `${subject} is planned after reviewing skin type, hair colour, hair thickness, and the selected area. Results vary, and the clinic confirms suitability, settings, and treatment intervals before proceeding.`
    ),
    descriptionAr: keep(
      current.descriptionAr,
      "يتم التخطيط للعلاج بعد مراجعة نوع البشرة ولون الشعر وسماكته والمنطقة المحددة. تختلف النتائج، وتؤكد العيادة الملاءمة والإعدادات والفواصل العلاجية قبل البدء."
    ),
    preparationEn: keep(
      current.preparationEn,
      "Follow the clinic’s preparation instructions, avoid unnecessary irritation to the area, and report relevant skin or medication changes before the appointment."
    ),
    preparationAr: keep(
      current.preparationAr,
      "اتبع تعليمات التحضير المقدمة من العيادة، وتجنب تهيج المنطقة، وأبلغ عن أي تغيرات مهمة في البشرة أو الأدوية قبل الموعد."
    ),
    aftercareEn: keep(
      current.aftercareEn,
      "Follow the clinic’s cooling and skincare instructions, avoid heat and friction as advised, and contact the clinic if an unexpected reaction occurs."
    ),
    aftercareAr: keep(
      current.aftercareAr,
      "اتبع تعليمات التبريد والعناية بالبشرة، وتجنب الحرارة والاحتكاك حسب الإرشادات، وتواصل مع العيادة عند حدوث تفاعل غير متوقع."
    ),
    seoTitle: keep(current.seoTitle, `${subject} in Riyadh | Nurse James`),
    seoDescription: keep(
      current.seoDescription,
      `Learn about assessment-led ${subject.toLowerCase()} in Riyadh, including preparation, timing, aftercare, and realistic expectations.`
    ),
  };
}

export type PromotionDraft = {
  slug: string;
  name: string;
  titleEn: string;
  titleAr: string;
  descriptionEn: string;
  descriptionAr: string;
  includedTreatments: string;
  termsEn: string;
  termsAr: string;
};

export function fillPromotionDraft<T extends PromotionDraft>(current: T): T {
  const title = keep(current.titleEn, "Men’s laser care offer");
  return {
    ...current,
    slug: keep(current.slug, slugifyDraft(title) || "mens-laser-care-offer"),
    name: keep(current.name, `${title} — internal draft`),
    titleEn: title,
    titleAr: keep(current.titleAr, "عرض العناية بالليزر للرجال"),
    descriptionEn: keep(
      current.descriptionEn,
      "A clinic-reviewed offer for eligible men’s laser hair removal services. Suitability, included areas, price, and appointment availability must be confirmed by the clinic."
    ),
    descriptionAr: keep(
      current.descriptionAr,
      "عرض تراجعه العيادة لخدمات إزالة الشعر بالليزر للرجال المؤهلين. يجب تأكيد الملاءمة والمناطق المشمولة والسعر وتوفر المواعيد من العيادة."
    ),
    includedTreatments: keep(
      current.includedTreatments,
      "Clinic-confirmed treatment areas only"
    ),
    termsEn: keep(
      current.termsEn,
      "Subject to clinical assessment, clinic confirmation, stated validity dates, and appointment availability. No result is guaranteed."
    ),
    termsAr: keep(
      current.termsAr,
      "يخضع العرض للتقييم السريري وتأكيد العيادة وتواريخ الصلاحية المعلنة وتوفر المواعيد. لا توجد ضمانات للنتائج."
    ),
  };
}

export type GuideDraft = {
  slug: string;
  titleEn: string;
  titleAr: string;
  summaryEn: string;
  summaryAr: string;
  contentEn: string;
  contentAr: string;
  category: string;
  tags: string;
  seoTitle: string;
  metaDescription: string;
  canonicalUrl: string;
};

export function fillGuideDraft<T extends GuideDraft>(current: T): T {
  const title = keep(
    current.titleEn,
    "How to Prepare for Men’s Laser Hair Removal"
  );
  const slug = keep(
    current.slug,
    slugifyDraft(title) || "mens-laser-preparation"
  );
  return {
    ...current,
    slug,
    titleEn: title,
    titleAr: keep(
      current.titleAr,
      "كيفية الاستعداد لإزالة الشعر بالليزر للرجال"
    ),
    summaryEn: keep(
      current.summaryEn,
      "A practical preparation guide covering assessment, skin care, timing, and what to confirm with the clinic before a men’s laser hair removal appointment."
    ),
    summaryAr: keep(
      current.summaryAr,
      "دليل عملي للتحضير يشمل التقييم والعناية بالبشرة والتوقيت وما يجب تأكيده مع العيادة قبل موعد إزالة الشعر بالليزر للرجال."
    ),
    contentEn: keep(
      current.contentEn,
      "## Before your appointment\n\nFollow the clinic’s preparation instructions and avoid unnecessary irritation to the treatment area. Tell the clinic about relevant skin changes, medicines, or recent procedures.\n\n## Assessment and settings\n\nSkin type, hair colour, hair thickness, and treatment area affect the selected wavelength and settings. The clinic confirms suitability before treatment.\n\n## Timing and expectations\n\nLaser targets actively growing hair, so sessions are scheduled around the hair-growth cycle. Results vary, and multiple sessions may be needed.\n\n## Aftercare\n\nFollow the clinic’s cooling and skincare advice and contact the clinic if an unexpected reaction occurs."
    ),
    contentAr: keep(
      current.contentAr,
      "## قبل الموعد\n\nاتبع تعليمات التحضير المقدمة من العيادة وتجنب تهيج منطقة العلاج. أخبر العيادة عن أي تغيرات مهمة في البشرة أو الأدوية أو الإجراءات الحديثة.\n\n## التقييم والإعدادات\n\nيؤثر نوع البشرة ولون الشعر وسماكته ومنطقة العلاج في اختيار الطول الموجي والإعدادات. تؤكد العيادة الملاءمة قبل العلاج.\n\n## التوقيت والتوقعات\n\nيستهدف الليزر الشعر في مرحلة النمو النشط، لذلك تُحدد الجلسات وفق دورة نمو الشعر. تختلف النتائج وقد تكون هناك حاجة إلى عدة جلسات.\n\n## العناية بعد الجلسة\n\nاتبع نصائح التبريد والعناية بالبشرة وتواصل مع العيادة عند حدوث تفاعل غير متوقع."
    ),
    category: keep(current.category, "Patient education"),
    tags: keep(current.tags, "laser preparation, men, Riyadh, aftercare"),
    seoTitle: keep(current.seoTitle, `${title} | Nurse James Riyadh`),
    metaDescription: keep(
      current.metaDescription,
      "Prepare for men’s laser hair removal in Riyadh with clear guidance on assessment, skin care, treatment timing, aftercare, and realistic expectations."
    ),
    canonicalUrl: keep(
      current.canonicalUrl,
      `https://www.jameslaserformen.com/en/blog/${slug}`
    ),
  };
}

export type FaqDraft = {
  questionEn: string;
  answerEn: string;
  questionAr: string;
  answerAr: string;
  category: string;
};

export function fillFaqDraft<T extends FaqDraft>(current: T): T {
  return {
    ...current,
    questionEn: keep(
      current.questionEn,
      "How should I prepare for my laser appointment?"
    ),
    answerEn: keep(
      current.answerEn,
      "Follow the preparation instructions from the clinic, avoid unnecessary irritation to the area, and report relevant skin, medication, or health changes before treatment. The clinic will confirm the final instructions for your selected area."
    ),
    questionAr: keep(current.questionAr, "كيف أستعد لموعد الليزر؟"),
    answerAr: keep(
      current.answerAr,
      "اتبع تعليمات التحضير المقدمة من العيادة، وتجنب تهيج المنطقة، وأبلغ عن أي تغيرات مهمة في البشرة أو الأدوية أو الحالة الصحية قبل العلاج. ستؤكد العيادة التعليمات النهائية للمنطقة المحددة."
    ),
    category: keep(current.category, "Preparation"),
  };
}

export type CalendarDraft = {
  planKey: string;
  plannedFor: string;
  topic: string;
  targetPage: string;
  searchIntent: string;
  cta: string;
  contentBrief: string;
  internalLinks: string;
  repurposingBrief: string;
};

export function fillCalendarDraft<T extends CalendarDraft>(
  current: T,
  today = new Date().toISOString().slice(0, 10)
): T {
  const topic = keep(
    current.topic,
    "Men’s laser preparation and treatment timing in Riyadh"
  );
  return {
    ...current,
    planKey: keep(
      current.planKey,
      slugifyDraft(`week-${topic}`) || "weekly-laser-education"
    ),
    plannedFor: keep(current.plannedFor, today),
    topic,
    targetPage: keep(current.targetPage, "/en/blog"),
    searchIntent: keep(
      current.searchIntent,
      "Educational guidance for men considering laser hair removal in Riyadh"
    ),
    cta: keep(current.cta, "Request a clinic-reviewed appointment"),
    contentBrief: keep(
      current.contentBrief,
      "Explain assessment, preparation, treatment timing, the hair-growth cycle, realistic expectations, and aftercare. Avoid guarantees, diagnosis, invented prices, or unverified claims. Keep the item private until owner review."
    ),
    internalLinks: keep(
      current.internalLinks,
      "/en/treatments\n/en/faq\n/appointment"
    ),
    repurposingBrief: keep(
      current.repurposingBrief,
      "Create one educational carousel outline and one short bilingual caption draft. Keep all publication actions pending owner authorization."
    ),
  };
}

export type SeoDraft = {
  locale: "en" | "ar-SA";
  title: string;
  metaDescription: string;
};

export function fillSeoDraft<T extends SeoDraft>(current: T): T {
  const arabic = current.locale === "ar-SA";
  return {
    ...current,
    title: keep(
      current.title,
      arabic
        ? "إزالة الشعر بالليزر للرجال في الرياض | نيرس جيمس"
        : "Men’s Laser Hair Removal in Riyadh | Nurse James"
    ),
    metaDescription: keep(
      current.metaDescription,
      arabic
        ? "تعرف على إزالة الشعر بالليزر للرجال في الرياض مع تقييم دقيق وإرشادات للتحضير والتوقيت والعناية بعد الجلسة وطلب موعد تراجعه العيادة."
        : "Explore assessment-led men’s laser hair removal in Riyadh with preparation, timing, aftercare guidance, and clinic-reviewed appointment requests."
    ),
  };
}
