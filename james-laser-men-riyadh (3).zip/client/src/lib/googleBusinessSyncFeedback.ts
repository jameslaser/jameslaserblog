export type GoogleBusinessSyncFeedback = {
  title: string;
  description: string;
  retryLabel: string;
};

const PRIVATE_MODERATION_NOTE =
  "No Google listing was changed, and no review was published automatically. Any review record already received remains private and pending moderation.";

/**
 * Converts safe, server-generated Google Business sync errors into concise
 * owner-facing recovery instructions. The raw provider message is never
 * rendered in the admin UI.
 */
export function getGoogleBusinessSyncFeedback(
  message: string | null | undefined
): GoogleBusinessSyncFeedback {
  const normalized = (message ?? "").trim().toLowerCase();

  if (
    normalized.includes("authorization expired") ||
    normalized.includes("authorization") && normalized.includes("revoked")
  ) {
    return {
      title: "Google authorization needs to be renewed",
      description:
        "Google no longer accepts the stored authorization. Reconnect the clinic profile, then select the clinic location again before retrying. " +
        PRIVATE_MODERATION_NOTE,
      retryLabel: "Reconnect Google Business",
    };
  }

  if (
    normalized.includes("access was denied") ||
    normalized.includes("access denied") ||
    normalized.includes("403") ||
    normalized.includes("allowlist")
  ) {
    return {
      title: "Google has not granted review access yet",
      description:
        "Confirm that the connected Google account manages the verified clinic Business Profile. If Google API access approval is still pending, wait for Google to approve it before reconnecting and retrying. " +
        PRIVATE_MODERATION_NOTE,
      retryLabel: "Retry review sync",
    };
  }

  if (normalized.includes("location")) {
    return {
      title: "The clinic location needs attention",
      description:
        "Confirm the selected location still belongs to the connected Google account. Reconnect the clinic profile if its access or location changed. " +
        PRIVATE_MODERATION_NOTE,
      retryLabel: "Retry review sync",
    };
  }

  if (normalized.includes("temporarily unavailable")) {
    return {
      title: "The secure review service is temporarily unavailable",
      description:
        "Wait a moment, then retry the sync. If it continues, check the Google Business connection before reconnecting. " +
        PRIVATE_MODERATION_NOTE,
      retryLabel: "Retry review sync",
    };
  }

  return {
    title: "The review sync did not finish",
    description:
      "Retry the secure sync. If the issue continues, reconnect the clinic profile and confirm its Google Business access. " +
      PRIVATE_MODERATION_NOTE,
    retryLabel: "Retry review sync",
  };
}
