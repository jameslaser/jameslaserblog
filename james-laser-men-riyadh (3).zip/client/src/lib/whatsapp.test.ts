import { describe, expect, it } from "vitest";
import { availabilityWhatsAppMessage, callbackWhatsAppMessage, generalInquiryWhatsAppMessage, quickWhatsAppMessage, whatsappBusinessWebUrl, whatsappUrl } from "./whatsapp";

describe("public WhatsApp link helpers", () => {
  it("normalizes the clinic number and URL-encodes user-facing text", () => {
    const url = whatsappUrl("+966 55 740 1562", "Hello & welcome\nLine two");

    expect(url).toContain("https://wa.me/966557401562?text=");
    expect(url).toContain("Hello%20%26%20welcome%0ALine%20two");
    expect(url).not.toContain("Hello & welcome");
  });

  it("generates localized deterministic messages without hidden form fields", () => {
    expect(quickWhatsAppMessage("en", "service")).toContain("men’s laser hair removal");
    expect(quickWhatsAppMessage("ar", "prices")).toContain("الأسعار");
    expect(availabilityWhatsAppMessage("en", { date: "2026-09-08", time: "18:00", treatment: "Full Face" })).toContain("requires clinic confirmation");
    expect(callbackWhatsAppMessage("ar", { name: "أحمد", mobile: "+966501234567", callbackPeriod: "من 5:00 مساءً إلى 10:00 مساءً" })).toContain("ضمن ساعات عمل العيادة");
    expect(generalInquiryWhatsAppMessage("en", { name: "Hassan", message: "Can I ask about preparation?" })).toContain("general enquiry");
  });

  it("removes control characters from messages before opening WhatsApp", () => {
    const url = whatsappUrl("+966557401562", "Hello\u0000 clinic\u0007");
    expect(decodeURIComponent(url)).toContain("Hello clinic");
    expect(decodeURIComponent(url)).not.toContain("\u0000");
  });

  it("creates a manual WhatsApp Business Web fallback without message content", () => {
    expect(whatsappBusinessWebUrl("055 740 1562")).toBe("https://web.whatsapp.com/send?phone=966557401562");
    expect(whatsappBusinessWebUrl("00971 50 123 4567")).toBe("https://web.whatsapp.com/send?phone=971501234567");
    expect(whatsappBusinessWebUrl("not a number")).toBeNull();
  });
});
