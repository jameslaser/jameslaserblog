import { Button } from "@/components/ui/button";
import { Download, Smartphone, X } from "lucide-react";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

const isStandalone = () => typeof window !== "undefined" && (window.matchMedia?.("(display-mode: standalone)").matches || (window.navigator as Navigator & { standalone?: boolean }).standalone === true);

export function PwaInstallPrompt() {
  const [path] = useLocation();
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  // Render the same safe initial value on the server and first browser render.
  // Session state is then restored after hydration to avoid a React mismatch.
  const [dismissed, setDismissed] = useState(false);
  const [installed, setInstalled] = useState(false);
  const [isIos, setIsIos] = useState(false);
  const isPublicRoute = !path.startsWith("/admin") && !path.startsWith("/sign-consent");

  useEffect(() => {
    try {
      setDismissed(sessionStorage.getItem("pwa-install-dismissed") === "true");
      setInstalled(isStandalone());
      setIsIos(/iPad|iPhone|iPod/.test(navigator.userAgent));
    } catch {
      // Session storage can be unavailable in privacy-focused browser contexts.
    }
    const onBeforeInstall = (event: Event) => {
      event.preventDefault();
      setDeferredPrompt(event as BeforeInstallPromptEvent);
    };
    const onInstalled = () => {
      setInstalled(true);
      setDeferredPrompt(null);
    };
    window.addEventListener("beforeinstallprompt", onBeforeInstall);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onBeforeInstall);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  if (!isPublicRoute || installed || dismissed || (!deferredPrompt && !isIos)) return null;

  const dismiss = () => {
    sessionStorage.setItem("pwa-install-dismissed", "true");
    setDismissed(true);
  };
  const install = async () => {
    if (!deferredPrompt) return;
    await deferredPrompt.prompt();
    const choice = await deferredPrompt.userChoice;
    if (choice.outcome === "accepted") setInstalled(true);
    setDeferredPrompt(null);
  };

  return <aside className="fixed inset-x-3 bottom-3 z-50 mx-auto max-w-md border border-[#d8c6a6] bg-[#fffdf8] p-3 shadow-[0_18px_50px_rgba(16,32,50,0.22)]" aria-label="Install James Laser web app"><div className="flex items-start gap-3"><div className="grid size-9 shrink-0 place-items-center rounded-full bg-[#102032] text-white"><Smartphone className="size-4" /></div><div className="min-w-0 flex-1"><p className="text-sm font-bold text-[#102032]">Install James Laser</p><p className="mt-0.5 text-xs leading-5 text-[#52606B]">{isIos ? "On iPhone or iPad, use Share then Add to Home Screen for quick access." : "Add the public site to your home screen for quick access. Private clinic data is not cached for offline use."}</p></div><Button type="button" aria-label="Dismiss install prompt" variant="ghost" size="icon" className="size-8" onClick={dismiss}><X className="size-4" /></Button></div>{deferredPrompt ? <Button type="button" size="sm" className="mt-3 w-full" onClick={() => void install()}><Download className="mr-2 size-4" />Install app</Button> : null}</aside>;
}
