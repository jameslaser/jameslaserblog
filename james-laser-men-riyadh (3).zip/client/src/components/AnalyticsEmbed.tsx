import { useEffect } from "react";

const endpoint = import.meta.env.VITE_ANALYTICS_ENDPOINT?.trim();
const websiteId = import.meta.env.VITE_ANALYTICS_WEBSITE_ID?.trim();
const analyticsEnabled =
  import.meta.env.VITE_ENABLE_OPTIONAL_ANALYTICS?.trim().toLowerCase() === "true";
const SCRIPT_ID = "james-laser-optional-analytics";

function analyticsScriptUrl(value: string) {
  const url = new URL(value);
  if (url.protocol !== "https:") throw new Error("Analytics endpoint must use HTTPS.");
  return `${url.toString().replace(/\/$/, "")}/umami`;
}

/**
 * Loads the optional public analytics client only when explicitly enabled.
 * Browser privacy extensions commonly block analytics scripts; analytics must
 * never produce a visible browser error or affect clinic workflows by default.
 */
export function AnalyticsEmbed() {
  useEffect(() => {
    if (
      !analyticsEnabled ||
      !endpoint ||
      !websiteId ||
      document.getElementById(SCRIPT_ID)
    )
      return;

    try {
      const script = document.createElement("script");
      script.id = SCRIPT_ID;
      script.defer = true;
      script.src = analyticsScriptUrl(endpoint);
      script.dataset.websiteId = websiteId;
      document.head.appendChild(script);
    } catch {
      // Analytics is optional and must never affect public booking, consent, or
      // administrative workflows when its endpoint is misconfigured.
    }
  }, []);

  return null;
}
