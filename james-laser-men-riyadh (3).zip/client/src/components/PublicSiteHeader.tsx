import { ArrowUpRight, Menu, X } from "lucide-react";
import { useState } from "react";

type Locale = "en" | "ar";
export type PublicSection = "home" | "treatments" | "offers" | "results" | "faq" | "blog" | "whatsapp" | "privacyRights";

const sections: Array<{ key: Exclude<PublicSection, "home" | "whatsapp">; en: string; ar: string }> = [
  { key: "treatments", en: "Treatments", ar: "العلاجات" },
  { key: "offers", en: "Offers", ar: "العروض" },
  { key: "results", en: "Results", ar: "النتائج" },
  { key: "faq", en: "FAQ", ar: "الأسئلة" },
  { key: "blog", en: "Blog", ar: "المدونة" },
];

function pathFor(section: PublicSection, locale: Locale) {
  if (section === "home") return locale === "ar" ? "/ar" : "/en";
  if (section === "whatsapp") return locale === "ar" ? "/ar/whatsapp" : "/whatsapp";
  if (section === "privacyRights") return locale === "ar" ? "/ar/privacy-rights" : "/privacy-rights";
  return `/${locale}/${section}`;
}

export function PublicSiteHeader({ locale = "en", active = "home" }: { locale?: Locale; active?: PublicSection }) {
  const [open, setOpen] = useState(false);
  const arabic = locale === "ar";
  const alternateLocale: Locale = arabic ? "en" : "ar";
  const navigationLabel = arabic ? "التنقل العام" : "Public navigation";
  const requestPath = arabic ? "/ar/appointment" : "/appointment";

  return (
    <header className="public-site-header" dir={arabic ? "rtl" : "ltr"}>
      <div className="public-site-header__inner">
        <a href={pathFor("home", locale)} className="public-site-brand" aria-label={arabic ? "جيمس ليزر - الرئيسية" : "James Laser home"}>
          <span className="public-site-mark" aria-hidden="true">JL</span>
          <span className="min-w-0 leading-none">
            <span className="public-site-brand__name">{arabic ? "جيمس ليزر" : "James Laser"}</span>
            <span className="public-site-brand__meta">{arabic ? "للرجال · الرياض" : "For men · Riyadh"}</span>
          </span>
        </a>

        <nav aria-label={navigationLabel} className="public-site-nav">
          {sections.map(section => (
            <a key={section.key} href={pathFor(section.key, locale)} aria-current={active === section.key ? "page" : undefined}>
              {arabic ? section.ar : section.en}
            </a>
          ))}
          <a href={pathFor("whatsapp", locale)} aria-current={active === "whatsapp" ? "page" : undefined}>WhatsApp</a>
        </nav>

        <div className="public-site-actions">
          <nav aria-label={arabic ? "اختيار اللغة" : "Choose language"}>
            <a href={pathFor(active, alternateLocale)} lang={alternateLocale} className="public-site-language">
              {arabic ? "EN" : "العربية"}
            </a>
          </nav>
          <a href={requestPath} className="public-site-request">
            {arabic ? "طلب موعد" : "Request appointment"}
            <ArrowUpRight className={arabic ? "size-3.5 -scale-x-100" : "size-3.5"} />
          </a>
          <button type="button" className="public-site-menu-button" aria-expanded={open} aria-controls="public-mobile-navigation" aria-label={open ? (arabic ? "إغلاق القائمة" : "Close menu") : (arabic ? "فتح القائمة" : "Open menu")} onClick={() => setOpen(value => !value)}>
            {open ? <X className="size-4" /> : <Menu className="size-4" />}
          </button>
        </div>
      </div>

      {open ? (
        <nav id="public-mobile-navigation" aria-label={navigationLabel} className="public-site-mobile-nav">
          <div className="public-site-mobile-nav__grid">
            {sections.map(section => (
              <a key={section.key} href={pathFor(section.key, locale)} aria-current={active === section.key ? "page" : undefined} onClick={() => setOpen(false)}>
                <span>{arabic ? section.ar : section.en}</span>
                <ArrowUpRight className={arabic ? "size-4 -scale-x-100" : "size-4"} />
              </a>
            ))}
            <a href={pathFor("whatsapp", locale)} aria-current={active === "whatsapp" ? "page" : undefined} onClick={() => setOpen(false)}>
              <span>WhatsApp</span>
              <ArrowUpRight className={arabic ? "size-4 -scale-x-100" : "size-4"} />
            </a>
            <a href={requestPath} onClick={() => setOpen(false)}>
              <span>{arabic ? "طلب موعد خاص" : "Private appointment request"}</span>
              <ArrowUpRight className={arabic ? "size-4 -scale-x-100" : "size-4"} />
            </a>
          </div>
        </nav>
      ) : null}
    </header>
  );
}
