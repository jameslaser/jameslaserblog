import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

const read = (file: string) => fs.readFileSync(path.resolve(process.cwd(), file), "utf8");
const controlCenter = read("client/src/components/SettingsControlCenter.tsx");
const router = read("server/routers.ts");
const cms = read("server/cms.ts");

describe("Settings control centre", () => {
  it("uses the existing Settings route as a searchable control surface", () => {
    for (const label of ["Website", "Content & CMS", "SEO & Google", "Appointments", "Machines", "Patients", "WhatsApp", "Revenue", "Staff & RBAC", "Notifications", "Security & system"]) expect(controlCenter).toContain(`label: \"${label}\"`);
    expect(controlCenter).toContain("Search Settings");
    expect(controlCenter).toContain("SettingsControlCenter");
    expect(controlCenter).toContain('dir={isArabic ? "rtl" : "ltr"}');
    expect(controlCenter).toContain("xl:grid-cols-[260px_minmax(0,1fr)]");
  });

  it("keeps the public booking and WhatsApp safeguards visible and guarded", () => {
    expect(controlCenter).toContain("Enable public appointment requests");
    expect(controlCenter).toContain("window.confirm");
    expect(controlCenter).toContain("beforeunload");
    expect(controlCenter).toContain("Automation remains OFF");
    expect(controlCenter).toContain("cannot bypass the authoritative verification gate");
    expect(controlCenter).toContain("Total Income × 75% × 3%");
  });

  it("uses protected procedures and stores only safe settings history", () => {
    expect(router).toContain("settingsControl: contentProcedure");
    expect(router).toContain("updateSettingsControl: contentProcedure");
    expect(router).toContain("settingsChangeAudit: adminProcedure");
    expect(cms).toContain("settingsChangeAudits");
    expect(cms).toContain("safeValueFields");
    expect(cms).toContain("Updated clinic settings:");
  });
});
