import React from "react";
import { MessageCircle } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { whatsappBusinessWebUrl } from "@/lib/whatsapp";
import { trpc } from "@/lib/trpc";

type WhatsAppBusinessWebActionProps = {
  phone: string | null | undefined;
  patientName: string;
  subjectType: "patient" | "appointment" | "follow_up";
  subjectId: number;
  className?: string;
};

/**
 * An intentional, manual route to the clinic user's signed-in WhatsApp Business
 * Web session. The content-free audit record is server-authorized and includes
 * only the acting user plus the protected record type and ID.
 */
export function WhatsAppBusinessWebAction({ phone, patientName, subjectType, subjectId, className = "" }: WhatsAppBusinessWebActionProps) {
  const href = phone ? whatsappBusinessWebUrl(phone) : null;
  const recordLaunch = trpc.admin.recordManualWhatsAppLaunch.useMutation({
    onError: () => toast.warning("WhatsApp Web opened, but the activity event could not be recorded."),
  });
  const actionClassName = `min-h-10 min-w-10 shrink-0 border-emerald-700/25 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 hover:text-emerald-900 ${className}`;

  if (!href) {
    return <Button type="button" size="icon" variant="outline" disabled className={actionClassName} aria-label={`A valid WhatsApp number is required for ${patientName}`} title="A valid WhatsApp number is required"><MessageCircle className="size-4" aria-hidden="true" /></Button>;
  }

  return <Button asChild size="icon" variant="outline" className={actionClassName}><a href={href} target="_blank" rel="noopener noreferrer" onClick={() => recordLaunch.mutate({ subjectType, subjectId })} aria-label={`Open WhatsApp Business Web for ${patientName}`} title="Open WhatsApp Business Web"><MessageCircle className="size-4" aria-hidden="true" /></a></Button>;
}
