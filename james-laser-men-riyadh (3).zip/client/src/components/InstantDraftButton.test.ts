import { Button } from "@/components/ui/button";
import React, { isValidElement } from "react";
import { describe, expect, it, vi } from "vitest";

const { success } = vi.hoisted(() => ({ success: vi.fn() }));
vi.mock("sonner", () => ({ toast: { success } }));

import { InstantDraftButton } from "./InstantDraftButton";

describe("InstantDraftButton", () => {
  it("runs its fill handler synchronously on click and confirms review is required", () => {
    const onGenerate = vi.fn();
    const control = InstantDraftButton({ onGenerate });
    const button = React.Children.toArray(control.props.children).find(
      child => isValidElement(child) && child.type === Button
    );

    expect(isValidElement(button)).toBe(true);
    const result = (
      button as React.ReactElement<{ onClick: () => void }>
    ).props.onClick();

    expect(result).toBeUndefined();
    expect(onGenerate).toHaveBeenCalledOnce();
    expect(success).toHaveBeenCalledWith(
      "Draft fields filled instantly. Review before saving or publishing."
    );
  });
});
