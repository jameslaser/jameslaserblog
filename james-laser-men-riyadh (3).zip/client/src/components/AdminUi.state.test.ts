import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it, vi } from "vitest";

vi.mock("@/contexts/AdminLocaleContext", () => ({
  useAdminLocale: () => ({ locale: "en" }),
  translateAdminText: (value: string) => value,
}));

import { AdminEmptyState, AdminErrorState, AdminLoadingState, AdminMetricCard, AdminPageHeader } from "./AdminUi";

describe("shared authenticated management states", () => {
  it("renders a loaded management heading and real metric surface", () => {
    const html = renderToStaticMarkup(React.createElement(React.Fragment, null,
      React.createElement(AdminPageHeader, { eyebrow: "CMS oversight", title: "Activity log", description: "Protected records" }),
      React.createElement(AdminMetricCard, { label: "Configured locales", value: 2, note: "Reviewed settings" }),
    ));
    expect(html).toContain("Activity log");
    expect(html).toContain("Configured locales");
    expect(html).toContain("admin-metric-card");
  });

  it("renders an accessible loading state", () => {
    const html = renderToStaticMarkup(React.createElement(AdminLoadingState, { label: "Loading staff notifications…" }));
    expect(html).toContain('role="status"');
    expect(html).toContain("Loading staff notifications…");
  });

  it("renders an explicit empty state", () => {
    const html = renderToStaticMarkup(React.createElement(AdminEmptyState, { title: "No staff accounts available", description: "No authenticated staff accounts are available to manage in this portal session." }));
    expect(html).toContain("admin-empty-state");
    expect(html).toContain("No staff accounts available");
  });

  it("renders an accessible error and retry state", () => {
    const html = renderToStaticMarkup(React.createElement(AdminErrorState, { title: "Notifications unavailable", description: "Notifications could not be loaded from the secure CMS.", onRetry: () => undefined }));
    expect(html).toContain('role="alert"');
    expect(html).toContain("Notifications unavailable");
    expect(html).toContain("Try again");
  });
});
