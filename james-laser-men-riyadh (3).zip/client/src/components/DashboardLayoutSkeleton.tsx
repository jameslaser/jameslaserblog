import { Skeleton } from './ui/skeleton';

export function DashboardLayoutSkeleton() {
  return (
    <div className="flex min-h-screen bg-[#f5f1e9]">
      {/* Sidebar skeleton */}
      <div className="w-[248px] border-r border-[#0e2130] bg-[#102032] p-4 space-y-6">
        {/* Logo area */}
        <div className="flex items-center gap-3 px-2">
          <Skeleton className="h-9 w-9 rounded-md bg-white/15" />
          <Skeleton className="h-4 w-28 bg-white/15" />
        </div>

        {/* Menu items */}
        <div className="space-y-2 px-2">
          <Skeleton className="h-10 w-full rounded-md bg-white/10" />
          <Skeleton className="h-10 w-full rounded-md bg-white/10" />
          <Skeleton className="h-10 w-full rounded-md bg-white/10" />
        </div>

        {/* User profile area at bottom */}
        <div className="absolute bottom-4 left-4 right-4">
          <div className="flex items-center gap-3 px-1">
            <Skeleton className="h-9 w-9 rounded-full bg-white/15" />
            <div className="flex-1 space-y-2">
              <Skeleton className="h-3 w-20 bg-white/15" />
              <Skeleton className="h-2 w-32 bg-white/10" />
            </div>
          </div>
        </div>
      </div>

      {/* Main content skeleton */}
      <div className="flex-1 space-y-4 p-4 sm:p-6">
        {/* Content blocks */}
        <Skeleton className="h-12 w-48 rounded-md" />
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Skeleton className="h-32 rounded-md" />
          <Skeleton className="h-32 rounded-md" />
          <Skeleton className="h-32 rounded-md" />
        </div>
        <Skeleton className="h-64 rounded-md" />
      </div>
    </div>
  );
}
