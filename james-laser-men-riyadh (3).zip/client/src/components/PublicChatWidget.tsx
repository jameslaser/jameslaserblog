import { useEffect, useMemo, useRef, useState } from "react";
import { AlertTriangle, CheckCheck, MessageCircle, Send, ShieldCheck, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";

const sessionStorageKey = "new-look-web-chat-session-v1";

function getSessionToken() {
  const existing = window.localStorage.getItem(sessionStorageKey);
  if (existing && /^[0-9a-f-]{36}$/i.test(existing)) return existing;
  const token = crypto.randomUUID();
  window.localStorage.setItem(sessionStorageKey, token);
  return token;
}

function formatTime(value: Date | string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "" : date.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}

export function PublicChatWidget({ locale }: { locale: "en" | "ar" }) {
  const arabic = locale === "ar";
  const [open, setOpen] = useState(false);
  const [sessionToken, setSessionToken] = useState("");
  const [message, setMessage] = useState("");
  const lastReadStaffMessage = useRef<number | null>(null);
  const lastTypingSentAt = useRef(0);
  const utils = trpc.useUtils();
  const sessionInput = useMemo(() => ({ sessionToken }), [sessionToken]);
  const conversation = trpc.webChat.publicConversation.useQuery(sessionInput, {
    enabled: Boolean(sessionToken) && open,
    refetchInterval: open ? 8_000 : false,
  });
  const markRead = trpc.webChat.publicMarkRead.useMutation();
  const markTyping = trpc.webChat.publicTyping.useMutation();
  const sendMessage = trpc.webChat.sendVisitor.useMutation({
    onSuccess: async () => {
      setMessage("");
      await utils.webChat.publicConversation.invalidate(sessionInput);
    },
    onError: error => toast.error(error.message),
  });

  useEffect(() => {
    setSessionToken(getSessionToken());
  }, []);

  useEffect(() => {
    if (!open || !sessionToken || !conversation.data) return;
    const latestStaffMessage = [...conversation.data.messages].reverse().find(item => item.direction === "staff");
    if (!latestStaffMessage || latestStaffMessage.id === lastReadStaffMessage.current) return;
    lastReadStaffMessage.current = latestStaffMessage.id;
    markRead.mutate({ sessionToken });
  }, [conversation.data, open, sessionToken, markRead]);

  const copy = arabic
    ? {
      title: "محادثة الموقع",
      kicker: "نيو لوك كلينك · الرياض",
      opening: "مرحبًا. يمكن لفريق العيادة مساعدتك بمعلومات عامة. لا تشارك معلومات شخصية أو طبية هنا.",
      privacy: "لا ترسل الاسم الكامل أو رقم الجوال أو البريد أو تفاصيل الموعد أو المعلومات الطبية. استخدم نموذج طلب الموعد الآمن لهذه المعلومات.",
      prompt: "اكتب رسالة عامة…",
      send: "إرسال",
      notEmergency: "هذه المحادثة ليست للطوارئ ولا تقدم نصيحة طبية.",
      staff: "فريق العيادة",
      you: "أنت",
      waiting: "جاري تحميل المحادثة…",
      resolved: "تم إنهاء هذه المحادثة. يمكنك إرسال رسالة جديدة لفتحها مرة أخرى.",
      staffTyping: "فريق العيادة يكتب…",
      readByTeam: "اطّلع عليها الفريق",
      openLabel: "فتح محادثة الموقع",
      closeLabel: "إغلاق المحادثة",
    }
    : {
      title: "Website chat",
      kicker: "New Look Clinic · Riyadh",
      opening: "Hello. The clinic team can help with general information. Please do not share personal or medical information here.",
      privacy: "Do not send your full name, phone, email, appointment details, or medical information. Use the secure appointment form for those details.",
      prompt: "Write a general question…",
      send: "Send",
      notEmergency: "This chat is not for emergencies and does not provide medical advice.",
      staff: "Clinic team",
      you: "You",
      waiting: "Loading conversation…",
      resolved: "This conversation is resolved. Send a new message to reopen it.",
      staffTyping: "Clinic team is typing…",
      readByTeam: "Seen by clinic team",
      openLabel: "Open website chat",
      closeLabel: "Close chat",
    };

  const submit = () => {
    const body = message.trim();
    if (!body || !sessionToken || sendMessage.isPending) return;
    sendMessage.mutate({ sessionToken, language: locale, body, website: "" });
  };

  const updateMessage = (value: string) => {
    setMessage(value);
    if (!value.trim() || !sessionToken || Date.now() - lastTypingSentAt.current < 3_000) return;
    lastTypingSentAt.current = Date.now();
    markTyping.mutate({ sessionToken });
  };

  const lastVisitorMessageId = [...(conversation.data?.messages ?? [])].reverse().find(item => item.direction === "visitor")?.id;
  return (
    <div className="fixed bottom-5 end-5 z-[70] flex flex-col items-end gap-3" dir={arabic ? "rtl" : "ltr"}>
      {open ? <section className="w-[min(94vw,390px)] overflow-hidden rounded-2xl border border-[#102032]/15 bg-[#fcfaf6] shadow-[0_22px_60px_rgba(16,32,50,0.24)]" aria-label={copy.title}>
        <header className="flex items-start justify-between gap-4 bg-[#102032] px-5 py-4 text-white"><div><p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#eab394]">{copy.kicker}</p><h2 className="mt-1 font-display text-2xl tracking-[-0.035em]">{copy.title}</h2></div><Button variant="ghost" size="icon" className="size-8 text-white hover:bg-white/10 hover:text-white" onClick={() => setOpen(false)} aria-label={copy.closeLabel}><X className="size-4" /></Button></header>
        <div className="max-h-[45vh] min-h-56 space-y-3 overflow-y-auto bg-[#f7f3ec] p-4">
          <div className="max-w-[90%] rounded-2xl rounded-tl-sm border border-[#102032]/10 bg-white px-3.5 py-3 text-sm leading-6 text-[#43515d]"><p>{copy.opening}</p></div>
          {conversation.isLoading ? <p className="px-1 text-xs text-[#66727A]">{copy.waiting}</p> : conversation.data?.messages.map(item => {
            const visitor = item.direction === "visitor";
            const readReceipt = visitor && item.id === lastVisitorMessageId && Boolean(conversation.data?.staffReadLatestVisitor);
            return <div key={item.id} className={`flex ${visitor ? "justify-end" : "justify-start"}`}><div className={`max-w-[90%] rounded-2xl px-3.5 py-3 text-sm leading-6 ${visitor ? "rounded-tr-sm bg-[#b85e3c] text-white" : "rounded-tl-sm border border-[#102032]/10 bg-white text-[#263746]"}`}><p className={`mb-1 text-[10px] font-extrabold uppercase tracking-[0.14em] ${visitor ? "text-white/70" : "text-[#a85438]"}`}>{visitor ? copy.you : copy.staff}</p><p className="whitespace-pre-wrap">{item.body}</p><div className={`mt-1 flex items-center gap-1 text-[10px] ${visitor ? "text-white/70" : "text-[#83909a]"}`}><span>{formatTime(item.createdAt)}</span>{readReceipt ? <><CheckCheck className="size-3" /><span>{copy.readByTeam}</span></> : null}</div></div></div>;
          })}
          {conversation.data?.staffIsTyping ? <div className="flex justify-start"><div className="rounded-2xl rounded-tl-sm border border-[#102032]/10 bg-white px-3.5 py-2.5 text-xs font-medium text-[#52606B]"><span className="inline-flex items-center gap-1.5"><span>{copy.staffTyping}</span><span className="flex gap-1"><i className="size-1 rounded-full bg-[#a85438] animate-bounce" /><i className="size-1 rounded-full bg-[#a85438] animate-bounce [animation-delay:120ms]" /><i className="size-1 rounded-full bg-[#a85438] animate-bounce [animation-delay:240ms]" /></span></span></div></div> : null}
          {conversation.data?.status === "resolved" ? <p className="rounded-xl border border-[#b85e3c]/20 bg-[#fff6f1] px-3 py-2 text-xs leading-5 text-[#7d3d27]">{copy.resolved}</p> : null}
        </div>
        <div className="border-t border-[#102032]/10 bg-white p-4"><div className="mb-3 flex gap-2 rounded-xl border border-amber-700/20 bg-amber-50 px-3 py-2 text-xs leading-5 text-amber-950"><ShieldCheck className="mt-0.5 size-4 shrink-0 text-[#a85438]" /><p>{copy.privacy}</p></div><div className="flex items-end gap-2"><Textarea value={message} onChange={event => updateMessage(event.target.value)} maxLength={1500} className="min-h-20 resize-none border-[#102032]/20 bg-[#fcfaf6] text-sm" placeholder={copy.prompt} onKeyDown={event => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); submit(); } }} /><Button onClick={submit} disabled={!message.trim() || sendMessage.isPending} className="h-10 shrink-0 bg-[#102032] px-3 text-white hover:bg-[#1c3b51]"><Send className="size-4" /><span className="sr-only">{copy.send}</span></Button></div><p className="mt-2 flex items-start gap-1.5 text-[11px] leading-4 text-[#66727A]"><AlertTriangle className="mt-0.5 size-3.5 shrink-0 text-[#a85438]" />{copy.notEmergency}</p></div>
      </section> : null}
      <Button onClick={() => setOpen(current => !current)} className="h-12 rounded-full bg-[#102032] px-5 text-sm font-semibold text-white shadow-lg transition hover:bg-[#1c3b51] active:scale-[0.97]" aria-label={copy.openLabel} aria-expanded={open}><MessageCircle className="me-2 size-4" />{arabic ? "تواصل معنا" : "Chat with us"}</Button>
    </div>
  );
}
