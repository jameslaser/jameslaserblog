import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const source = readFileSync(resolve(process.cwd(), "client/src/components/PublicHomepage.tsx"), "utf8");

describe("public homepage privacy-policy link", () => {
  it("exposes the English and Arabic published privacy-policy routes in the footer", () => {
    expect(source).toContain('href={arabic ? "/ar/policies/privacy-policy" : "/policies/privacy-policy"}');
    expect(source).toContain('privacyPolicy: "Privacy Policy"');
    expect(source).toContain('privacyPolicy: "سياسة الخصوصية"');
    expect(source).toContain('href={arabic ? "/ar/privacy-rights" : "/privacy-rights"}');
    expect(source).toContain('patientRights: "Patient Rights & Privacy"');
    expect(source).toContain('patientRights: "حقوق المريض والخصوصية"');
  });
});
