import { Button } from "@/components/ui/button";
import {
  CheckCircle2,
  ExternalLink,
  FileSignature,
  FileText,
  RotateCcw,
  ScrollText,
} from "lucide-react";
import React, { useEffect, useRef, useState } from "react";
import { ORIGINAL_CONSENT_DOCUMENTS } from "@shared/originalConsent";

type Locale = "en" | "ar";

type AppointmentConsentWorkflowProps = {
  locale: Locale;
  signerName: string;
  readComplete: boolean;
  acknowledgement: boolean;
  signatureDataUrl: string;
  onReadComplete: () => void;
  onAcknowledgementChange: (checked: boolean) => void;
  onSignatureChange: (dataUrl: string) => void;
};

const copy = {
  en: {
    intro:
      "Review the three original clinic forms below. Scroll to the end, confirm the acknowledgement, then sign to continue with your appointment request.",
    originals: "Complete original clinic forms",
    sourceNote:
      "These unchanged clinic source files remain authoritative. You can also open each original in a separate tab.",
    open: "Open original",
    openAgain: "Open again",
    opened: "Opened",
    notOpened: "Not opened",
    openedProgress: (count: number, total: number) => `Opened ${count} of ${total} original forms.`,
    fallback: "If the preview is not visible on your device, open the original form.",
    continue: "Continue scrolling through the complete consent area.",
    complete: "Consent review completed. You may now acknowledge and sign.",
    acknowledgement:
      "I confirm that I have read and understood the complete consent information and the unchanged original clinic forms.",
    signature: "Electronic signature",
    signatureHint: "Use your finger, stylus, or mouse inside the signature panel.",
    signerMissing: "Enter your full name above before signing.",
    locked: "Complete the consent review and acknowledgement to unlock signing.",
    clear: "Clear",
    canvas: "Appointment request electronic signature panel",
    recorded: "Signature accepted and ready to be securely linked to this request.",
    signed: "Signature accepted",
    signatureConfirmed: "Signature captured",
    signatureConfirmedDetail: "Your electronic signature is ready to be included with this appointment request. Complete the form and select Request Appointment to continue.",
    end: "End of complete consent",
  },
  ar: {
    intro:
      "راجع نماذج العيادة الأصلية الثلاثة أدناه. مرّر حتى النهاية، ثم أكّد الإقرار ووقّع للمتابعة في طلب الموعد.",
    originals: "نماذج العيادة الأصلية كاملة",
    sourceNote:
      "تظل ملفات العيادة الأصلية غير المعدلة المرجع المعتمد. ويمكنك أيضًا فتح كل نموذج أصلي في علامة تبويب منفصلة.",
    open: "فتح النموذج الأصلي",
    openAgain: "فتح النموذج مجددًا",
    opened: "تم الفتح",
    notOpened: "لم يتم الفتح",
    openedProgress: (count: number, total: number) => `تم فتح ${count} من ${total} نماذج أصلية.`,
    fallback: "إذا لم تظهر المعاينة على جهازك، افتح النموذج الأصلي.",
    continue: "تابع التمرير خلال منطقة الموافقة كاملة.",
    complete: "اكتملت مراجعة الموافقة. يمكنك الآن الإقرار والتوقيع.",
    acknowledgement:
      "أؤكد أنني قرأت وفهمت معلومات الموافقة كاملة ونماذج العيادة الأصلية غير المعدلة.",
    signature: "التوقيع الإلكتروني",
    signatureHint: "استخدم إصبعك أو القلم أو الفأرة داخل لوحة التوقيع.",
    signerMissing: "أدخل اسمك الكامل أعلاه قبل التوقيع.",
    locked: "أكمل مراجعة الموافقة والإقرار لفتح التوقيع.",
    clear: "مسح",
    canvas: "لوحة التوقيع الإلكتروني لطلب الموعد",
    recorded: "تم قبول التوقيع وهو جاهز للربط الآمن بهذا الطلب.",
    signed: "تم قبول التوقيع",
    signatureConfirmed: "تم التقاط التوقيع",
    signatureConfirmedDetail: "أصبح توقيعك الإلكتروني جاهزًا ليُدرج مع طلب الموعد. أكمل النموذج ثم اختر إرسال طلب الموعد للمتابعة.",
    end: "نهاية الموافقة الكاملة",
  },
} as const;

export default function AppointmentConsentWorkflow({
  locale,
  signerName,
  readComplete,
  acknowledgement,
  signatureDataUrl,
  onReadComplete,
  onAcknowledgementChange,
  onSignatureChange,
}: AppointmentConsentWorkflowProps) {
  const t = copy[locale];
  const rtl = locale === "ar";
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const drawingRef = useRef(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [openedDocumentIds, setOpenedDocumentIds] = useState<string[]>([]);
  const signingUnlocked = readComplete && acknowledgement && Boolean(signerName.trim());
  const openedDocumentCount = openedDocumentIds.length;

  useEffect(() => {
    if (!showSuccess) return;
    const timer = window.setTimeout(() => setShowSuccess(false), 1400);
    return () => window.clearTimeout(timer);
  }, [showSuccess]);

  const handleConsentScroll = (event: React.UIEvent<HTMLDivElement>) => {
    const reader = event.currentTarget;
    if (reader.scrollHeight - reader.scrollTop - reader.clientHeight <= 16) onReadComplete();
  };

  const recordDocumentOpen = (documentId: string) => {
    setOpenedDocumentIds(current => current.includes(documentId) ? current : [...current, documentId]);
  };

  const point = (event: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return {
      x: (event.clientX - rect.left) * (canvas.width / rect.width),
      y: (event.clientY - rect.top) * (canvas.height / rect.height),
    };
  };

  const beginSignature = (event: React.PointerEvent<HTMLCanvasElement>) => {
    if (!signingUnlocked) return;
    const canvas = canvasRef.current;
    const context = canvas?.getContext("2d");
    if (!canvas || !context) return;
    event.currentTarget.setPointerCapture(event.pointerId);
    const position = point(event);
    context.beginPath();
    context.moveTo(position.x, position.y);
    context.lineCap = "round";
    context.lineJoin = "round";
    context.strokeStyle = "#102032";
    context.lineWidth = 3;
    drawingRef.current = true;
  };

  const drawSignature = (event: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawingRef.current || !signingUnlocked) return;
    const context = canvasRef.current?.getContext("2d");
    if (!context) return;
    const position = point(event);
    context.lineTo(position.x, position.y);
    context.stroke();
  };

  const endSignature = () => {
    if (!drawingRef.current) return;
    drawingRef.current = false;
    const canvas = canvasRef.current;
    if (!canvas) return;
    onSignatureChange(canvas.toDataURL("image/png"));
    setShowSuccess(true);
  };

  const clearSignature = () => {
    const canvas = canvasRef.current;
    const context = canvas?.getContext("2d");
    if (canvas && context) context.clearRect(0, 0, canvas.width, canvas.height);
    setShowSuccess(false);
    onSignatureChange("");
  };

  return (
    <div className="sm:col-span-2">
      <div className="mb-4 grid grid-cols-3 gap-2 text-center text-[10px] font-extrabold uppercase tracking-[0.12em]">
        <div className={readComplete ? "border border-emerald-200 bg-emerald-50 px-2 py-3 text-emerald-800" : "border border-[#a85438] bg-[#fff8f2] px-2 py-3 text-[#a85438]"}>
          1 · {rtl ? "اقرأ" : "Read"}
        </div>
        <div className={signatureDataUrl ? "border border-emerald-200 bg-emerald-50 px-2 py-3 text-emerald-800" : "border border-[#102032]/10 bg-[#f5f1e9] px-2 py-3 text-[#66727A]"}>
          2 · {rtl ? "وقّع" : "Sign"}
        </div>
        <div className="border border-[#102032]/10 bg-[#f5f1e9] px-2 py-3 text-[#66727A]">
          3 · {rtl ? "أرسل" : "Send"}
        </div>
      </div>

      <p className="text-sm leading-6 text-[#52606B]">{t.intro}</p>
      <div
        data-testid="appointment-consent-reader"
        tabIndex={0}
        onScroll={handleConsentScroll}
        className="mt-4 max-h-[34rem] overflow-y-auto overscroll-contain border border-[#102032]/15 bg-[#fdfbf7] outline-none focus-visible:ring-2 focus-visible:ring-[#a85438]"
        aria-label={rtl ? "قارئ الموافقة القابل للتمرير" : "Scrollable appointment consent reader"}
      >
        <div className="p-4 sm:p-5">
          <div className="flex items-center gap-2 text-[#a85438]">
            <ScrollText className="size-5" />
            <h3 className="font-display text-2xl text-[#102032]">{t.originals}</h3>
          </div>
          <p className="mt-2 text-xs leading-5 text-[#66727A]">{t.sourceNote}</p>
          <p data-testid="opened-consent-progress" aria-live="polite" className="mt-3 flex items-center gap-2 text-xs font-semibold text-[#52606B]">
            <FileText className="size-4 shrink-0 text-[#a85438]" />
            {t.openedProgress(openedDocumentCount, ORIGINAL_CONSENT_DOCUMENTS.length)}
          </p>
          <div className="mt-5 space-y-8">
            {ORIGINAL_CONSENT_DOCUMENTS.map((document, index) => {
              const opened = openedDocumentIds.includes(document.id);
              return <article key={document.id} className="border border-[#102032]/10 bg-white p-3 sm:p-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <p className="flex items-center gap-2 text-sm font-semibold text-[#102032]">
                      <FileText className="size-4 text-[#a85438]" />
                      {String(index + 1).padStart(2, "0")} · {rtl ? document.titleAr : document.titleEn}
                    </p>
                    <p data-testid={`consent-document-${document.id}-status`} aria-live="polite" className={`mt-2 flex items-center gap-1.5 text-xs font-semibold ${opened ? "text-emerald-700" : "text-[#66727A]"}`}>
                      {opened ? <CheckCircle2 className="size-3.5 shrink-0" /> : <ScrollText className="size-3.5 shrink-0" />}
                      {opened ? t.opened : t.notOpened}
                    </p>
                  </div>
                  <Button type="button" size="sm" variant="outline" asChild>
                    <a href={document.url} target="_blank" rel="noreferrer" onClick={() => recordDocumentOpen(document.id)}>
                      {opened ? t.openAgain : t.open}
                      <ExternalLink className="ms-1 size-3.5" />
                    </a>
                  </Button>
                </div>
                <iframe
                  src={`${document.url}#toolbar=0&navpanes=0&view=FitH`}
                  title={rtl ? document.titleAr : document.titleEn}
                  className="mt-3 h-[28rem] w-full border border-[#102032]/10 bg-[#f5f1e9]"
                />
                <p className="mt-2 text-xs text-[#66727A]">{t.fallback}</p>
                <p className="mt-2 break-all font-mono text-[9px] text-[#80909B]">SHA-256 · {document.sha256}</p>
              </article>
            })}
          </div>
          <div data-testid="appointment-consent-end" className="mt-7 border border-emerald-200 bg-emerald-50 p-4 text-center">
            <CheckCircle2 className="mx-auto size-6 text-emerald-700" />
            <p className="mt-2 text-xs font-extrabold uppercase tracking-[0.14em] text-emerald-800">{t.end}</p>
          </div>
        </div>
      </div>

      <p aria-live="polite" className={`mt-3 flex items-center gap-2 text-xs font-semibold ${readComplete ? "text-emerald-700" : "text-[#a85438]"}`}>
        {readComplete ? <CheckCircle2 className="size-4 shrink-0" /> : <ScrollText className="size-4 shrink-0" />}
        {readComplete ? t.complete : t.continue}
      </p>

      <label className="mt-5 flex gap-3 text-sm leading-6">
        <input
          required
          disabled={!readComplete}
          type="checkbox"
          checked={acknowledgement}
          onChange={event => onAcknowledgementChange(event.target.checked)}
          className="mt-1 size-4 shrink-0 accent-[#a85438] disabled:cursor-not-allowed"
        />
        <span>{t.acknowledgement}</span>
      </label>

      <div className={`mt-6 border p-4 ${signingUnlocked ? "border-[#a85438]/40 bg-[#fff8f2]" : "border-[#102032]/10 bg-[#f5f1e9]"}`}>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h3 className="flex items-center gap-2 font-display text-2xl text-[#102032]">
              <FileSignature className="size-5 text-[#a85438]" />
              {t.signature}
            </h3>
            <p className="mt-1 text-xs leading-5 text-[#66727A]">{signerName.trim() ? t.signatureHint : t.signerMissing}</p>
          </div>
          <Button type="button" size="sm" variant="outline" disabled={!signatureDataUrl} onClick={clearSignature} data-testid="clear-appointment-signature">
            <RotateCcw className="me-1 size-4" />
            {t.clear}
          </Button>
        </div>
        <div className="relative mt-4">
          <canvas
            ref={canvasRef}
            width={900}
            height={240}
            onPointerDown={beginSignature}
            onPointerMove={drawSignature}
            onPointerUp={endSignature}
            onPointerCancel={endSignature}
            className={`h-44 w-full touch-none border border-dashed bg-white ${signingUnlocked ? "cursor-crosshair border-[#102032]/35" : "cursor-not-allowed border-[#102032]/15 opacity-60"}`}
            aria-label={t.canvas}
            aria-disabled={!signingUnlocked}
          />
          {showSuccess && signatureDataUrl ? (
            <div role="status" data-testid="signature-success-animation" className="pointer-events-none absolute inset-0 grid place-items-center bg-emerald-50/90 animate-in fade-in zoom-in-95 duration-200 motion-reduce:animate-none">
              <div className="flex items-center gap-3 border border-emerald-200 bg-white px-5 py-4 text-emerald-800 shadow-lg">
                <span className="grid size-10 place-items-center rounded-full bg-emerald-100"><CheckCircle2 className="size-6" /></span>
                <span className="font-display text-2xl">{t.signed}</span>
              </div>
            </div>
          ) : null}
        </div>
        <p aria-live="polite" className={`mt-3 text-xs font-semibold ${signatureDataUrl ? "text-emerald-700" : "text-[#66727A]"}`}>
          {signatureDataUrl ? t.recorded : signingUnlocked ? t.signatureHint : t.locked}
        </p>
        {signatureDataUrl ? (
          <div role="status" data-testid="appointment-signature-confirmation" className="mt-4 flex gap-3 border border-emerald-200 bg-emerald-50 p-4 text-emerald-900">
            <span className="grid size-8 shrink-0 place-items-center rounded-full bg-emerald-100 text-emerald-700"><CheckCircle2 className="size-5" /></span>
            <div>
              <p className="text-sm font-extrabold">{t.signatureConfirmed}</p>
              <p className="mt-1 text-xs leading-5 text-emerald-800">{t.signatureConfirmedDetail}</p>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
