import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

const read = (file: string) => fs.readFileSync(path.resolve(process.cwd(), file), "utf8");
const css = read("client/src/index.css");
const header = read("client/src/components/PublicSiteHeader.tsx");
const publicContent = read("client/src/pages/PublicContent.tsx");
const publicLanding = read("client/src/pages/PublicLanding.tsx");
const whatsapp = read("client/src/pages/WhatsAppPage.tsx");
const button = read("client/src/components/ui/button.tsx");
const input = read("client/src/components/ui/input.tsx");

 describe("premium clinical design system", () => {
  it("defines the shared admin hierarchy that existing workspaces already consume", () => {
    for (const className of [".admin-page-header", ".admin-page-title", ".admin-surface", ".admin-filter-bar", ".admin-metric-card", ".admin-empty-state", ".admin-loading-state", ".admin-error-state"]) {
      expect(css).toContain(className);
    }
  });

  it("provides a predictable bilingual public navigation with a mobile menu", () => {
    expect(header).toContain('aria-controls="public-mobile-navigation"');
    expect(header).toContain("public-site-mobile-nav");
    expect(header).toContain('active?: PublicSection');
    expect(publicContent).toContain("<PublicSiteHeader");
    expect(publicLanding).toContain("<PublicSiteHeader");
    expect(whatsapp).toContain("<PublicSiteHeader");
  });

  it("keeps strong focus, reduced-motion, touch-target, and RTL treatment", () => {
    expect(css).toContain('outline: 2px solid #c99667');
    expect(css).toContain("prefers-reduced-motion: reduce");
    expect(css).toContain("min-height: 2.75rem");
    expect(css).toContain('.admin-portal[dir="rtl"]');
    expect(css).toContain("unicode-bidi: isolate");
  });

  it("uses readable shared controls instead of decorative component defaults", () => {
    expect(button).toContain('rounded-lg text-sm font-semibold');
    expect(button).toContain('default: "h-11');
    expect(input).toContain('h-11 w-full');
    expect(input).toContain('bg-white');
  });
});
