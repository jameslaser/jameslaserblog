import { describe, expect, it } from "vitest";
import fs from "node:fs";
import path from "node:path";

const shellPath = path.resolve(process.cwd(), "client/src/components/DashboardLayout.tsx");
const cssPath = path.resolve(process.cwd(), "client/src/index.css");
const shell = fs.readFileSync(shellPath, "utf8");
const css = fs.readFileSync(cssPath, "utf8");

describe("shared clinic shell redesign", () => {
  it("keeps authenticated navigation and role-filtered nav items intact", () => {
    expect(shell).toContain("useAuth");
    expect(shell).toContain("DashboardNavItem[]");
    expect(shell).toContain("navItems = defaultMenuItems");
    expect(shell).toContain("setLocation");
    expect(shell).toContain("/admin/appointments");
    expect(shell).toContain("/admin/patients");
  });

  it("provides a mobile-first bottom navigation without replacing the desktop sidebar", () => {
    expect(shell).toContain('className="mobile-bottom-nav md:hidden"');
    expect(shell).toContain('aria-label="Primary mobile navigation"');
    expect(shell).toContain('aria-label="Open all admin sections"');
    expect(shell).toContain("SidebarProvider");
    expect(shell).toContain("Sidebar collapsible=\"icon\"");
  });

  it("uses safe-area spacing and accessible touch targets for mobile clinic work", () => {
    expect(css).toContain("env(safe-area-inset-bottom)");
    expect(css).toContain("min-height: 3.1rem");
    expect(css).toContain("outline: 2px solid #c99667");
  });

  it("preserves the existing healthcare design tokens and restrained motion rules", () => {
    expect(css).toContain("--background: oklch");
    expect(css).toContain("--primary: oklch");
    expect(css).toContain("--shadow-soft");
    expect(css).toContain("prefers-reduced-motion: no-preference");
    expect(css).toContain(".arabic-public-page");
  });
});
