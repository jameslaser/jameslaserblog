// @vitest-environment jsdom
import { cleanup, render } from "@testing-library/react";
import { createElement } from "react";
import { afterEach, describe, expect, it } from "vitest";
import { AnalyticsEmbed } from "./AnalyticsEmbed";

afterEach(() => {
  cleanup();
  document.getElementById("james-laser-optional-analytics")?.remove();
});

describe("AnalyticsEmbed", () => {
  it("does not inject the optional analytics script without an explicit opt-in", () => {
    render(createElement(AnalyticsEmbed));

    expect(
      document.getElementById("james-laser-optional-analytics")
    ).toBeNull();
  });
});
