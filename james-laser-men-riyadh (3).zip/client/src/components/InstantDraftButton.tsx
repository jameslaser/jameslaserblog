import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Sparkles } from "lucide-react";
import React from "react";
import { toast } from "sonner";

type InstantDraftButtonProps = {
  onGenerate: () => void;
  className?: string;
  label?: string;
};

export function InstantDraftButton({
  onGenerate,
  className,
  label = "Generate instant draft",
}: InstantDraftButtonProps) {
  const generate = () => {
    onGenerate();
    toast.success(
      "Draft fields filled instantly. Review before saving or publishing."
    );
  };

  return (
    <div
      className={cn(
        "flex flex-col gap-2 border border-[#a85438]/25 bg-[#fff8f2] p-3 sm:flex-row sm:items-center sm:justify-between",
        className
      )}
      data-instant-draft-control
    >
      <div>
        <p className="text-xs font-bold text-[#102032]">
          Instant zero-credit draft
        </p>
        <p className="mt-0.5 text-xs leading-5 text-[#66727A]">
          Fills blank content fields immediately with a local clinic-safe
          template. Existing entries stay unchanged.
        </p>
      </div>
      <Button
        type="button"
        variant="outline"
        className="shrink-0 bg-white"
        onClick={generate}
      >
        <Sparkles className="mr-2 size-4 text-[#a85438]" />
        {label}
      </Button>
    </div>
  );
}
