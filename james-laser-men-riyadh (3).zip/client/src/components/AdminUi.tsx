import { AlertCircle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import React from "react";
import { cn } from "@/lib/utils";
import { translateAdminText, useAdminLocale } from "@/contexts/AdminLocaleContext";

export function AdminPageHeader({ eyebrow, title, description, action, className }: { eyebrow: string; title: string; description: string; action?: React.ReactNode; className?: string }) {
  const { locale } = useAdminLocale();
  return <header className={cn("admin-page-header", className)}><div className="min-w-0"><p className="admin-eyebrow">{translateAdminText(eyebrow, locale)}</p><h1 className="admin-page-title">{translateAdminText(title, locale)}</h1><p className="admin-page-description">{translateAdminText(description, locale)}</p></div>{action ? <div className="admin-page-actions">{action}</div> : null}</header>;
}

export function AdminSurface({ children, className, as: Component = "section" }: { children: React.ReactNode; className?: string; as?: "section" | "article" | "div" }) {
  return <Component className={cn("admin-surface", className)}>{children}</Component>;
}

export function AdminMetricCard({ label, value, note, icon: Icon, tone = "default", onClick }: { label: string; value: React.ReactNode; note: string; icon?: React.ElementType; tone?: "default" | "accent" | "success" | "warning" | "danger"; onClick?: () => void }) {
  const { locale } = useAdminLocale();
  const Component = onClick ? "button" : "article";
  return <Component type={onClick ? "button" : undefined} onClick={onClick} className={cn("admin-metric-card", `admin-metric-card--${tone}`, onClick && "admin-metric-card--interactive")}>{Icon ? <span className="admin-metric-icon"><Icon className="size-4" /></span> : null}<p className="admin-metric-value">{value}</p><p className="admin-metric-label">{translateAdminText(label, locale)}</p><p className="admin-metric-note">{translateAdminText(note, locale)}</p></Component>;
}

export function AdminFilterBar({ children, className }: { children: React.ReactNode; className?: string }) {
  return <section className={cn("admin-filter-bar", className)}>{children}</section>;
}

export function AdminEmptyState({ title, description, icon: Icon, action }: { title: string; description: string; icon?: React.ElementType; action?: React.ReactNode }) {
  const { locale } = useAdminLocale();
  return <section className="admin-empty-state">{Icon ? <span className="admin-empty-icon"><Icon className="size-5" /></span> : null}<h2>{translateAdminText(title, locale)}</h2><p>{translateAdminText(description, locale)}</p>{action ? <div className="mt-5">{action}</div> : null}</section>;
}

export function AdminLoadingState({ label = "Loading protected workspace…" }: { label?: string }) {
  const { locale } = useAdminLocale();
  return <div className="admin-loading-state" role="status"><Loader2 className="size-5 animate-spin" /><span>{translateAdminText(label, locale)}</span></div>;
}

export function AdminErrorState({ title, description, onRetry }: { title: string; description: string; onRetry?: () => void }) {
  const { locale } = useAdminLocale();
  const [reportCopied, setReportCopied] = React.useState(false);
  const copyReport = async () => {
    const path = typeof window === "undefined" ? "not available" : window.location.pathname;
    const report = `Context:\nPage: ${path}\nError: ${title}\nDetails: ${description}\nTime: ${new Date().toLocaleString("en-SA", { timeZone: "Asia/Riyadh" })}`;
    try {
      await navigator.clipboard.writeText(report);
      setReportCopied(true);
    } catch {
      setReportCopied(false);
    }
  };
  return <section className="admin-error-state" role="alert"><span className="admin-error-icon"><AlertCircle className="size-5" /></span><div><h2>{translateAdminText(title, locale)}</h2><p>{translateAdminText(description, locale)}</p><div className="mt-4 flex flex-wrap gap-2">{onRetry ? <Button type="button" variant="outline" size="sm" onClick={onRetry}>{translateAdminText("Try again", locale)}</Button> : null}<Button type="button" variant="outline" size="sm" onClick={copyReport}>{reportCopied ? "REPORT COPIED" : "REPORT"}</Button></div></div></section>;
}
