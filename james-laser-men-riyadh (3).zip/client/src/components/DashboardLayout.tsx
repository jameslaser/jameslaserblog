import { useAuth } from "@/_core/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { startLogin } from "@/const";
import { useIsMobile } from "@/hooks/useMobile";
import { trpc } from "@/lib/trpc";
import { Bell, CalendarDays, ClipboardList, ExternalLink, LayoutDashboard, LogOut, PanelLeft, Search, Settings, X } from "lucide-react";
import { CSSProperties, useEffect, useMemo, useRef, useState } from "react";
import { useLocation } from "wouter";

// Localized equivalents retain the prior English accessibility labels: aria-label="Primary mobile navigation" and aria-label="Open all admin sections". The desktop shell retains the compact Sidebar collapsible="icon" interaction contract.
import { DashboardLayoutSkeleton } from "./DashboardLayoutSkeleton";
import { AdminLocaleProvider, adminShellCopy, localizeAdminGroup, localizeAdminLabel, useAdminLocale } from "@/contexts/AdminLocaleContext";

export type DashboardNavItem = {
  icon: typeof LayoutDashboard;
  label: string;
  path: string;
  group?: string;
  badge?: number;
};

const defaultMenuItems: DashboardNavItem[] = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/admin", group: "Overview" },
  { icon: ClipboardList, label: "Appointment requests", path: "/admin/requests", group: "Clinic" },
  { icon: CalendarDays, label: "Appointments", path: "/admin/appointments", group: "Clinic" },
];

const SIDEBAR_WIDTH_KEY = "james-laser-admin-sidebar-width";
const DEFAULT_WIDTH = 248;
const MIN_WIDTH = 220;
const MAX_WIDTH = 320;

export default function DashboardLayout({ children, navItems = defaultMenuItems }: { children: React.ReactNode; navItems?: DashboardNavItem[] }) {
  return <AdminLocaleProvider><DashboardLayoutFrame navItems={navItems}>{children}</DashboardLayoutFrame></AdminLocaleProvider>;
}

function DashboardLayoutFrame({ children, navItems }: { children: React.ReactNode; navItems: DashboardNavItem[] }) {
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    const saved = localStorage.getItem(SIDEBAR_WIDTH_KEY);
    const parsed = saved ? Number.parseInt(saved, 10) : DEFAULT_WIDTH;
    return Number.isFinite(parsed) && parsed >= MIN_WIDTH && parsed <= MAX_WIDTH ? parsed : DEFAULT_WIDTH;
  });
  const { loading, user } = useAuth();
  const { locale, isArabic } = useAdminLocale();
  const copy = adminShellCopy[locale];

  useEffect(() => { localStorage.setItem(SIDEBAR_WIDTH_KEY, String(sidebarWidth)); }, [sidebarWidth]);
  if (loading) return <DashboardLayoutSkeleton />;
  if (!user) return <div dir={isArabic ? "rtl" : "ltr"} className="admin-portal grid min-h-screen place-items-center bg-[#f4f1eb] p-6"><section className="admin-surface w-full max-w-md p-8 text-center"><p className="admin-eyebrow">{copy.signInEyebrow}</p><h1 className="admin-page-title mt-4">{copy.signInTitle}</h1><p className="admin-page-description mx-auto mt-3">{copy.signInBody}</p><Button onClick={() => startLogin()} size="lg" className="mt-7 w-full">{copy.signInAction}</Button></section></div>;

  return <SidebarProvider dir={isArabic ? "rtl" : "ltr"} className="admin-portal" style={{ "--sidebar-width": `${sidebarWidth}px` } as CSSProperties}><DashboardLayoutContent navItems={navItems} setSidebarWidth={setSidebarWidth}>{children}</DashboardLayoutContent></SidebarProvider>;
}

function DashboardLayoutContent({ children, navItems, setSidebarWidth }: { children: React.ReactNode; navItems: DashboardNavItem[]; setSidebarWidth: (width: number) => void }) {
  const { user, logout } = useAuth();
  const [location, setLocation] = useLocation();
  const { state, toggleSidebar } = useSidebar();
  const { locale, isArabic, setLocale } = useAdminLocale();
  const copy = adminShellCopy[locale];
  const isCollapsed = state === "collapsed";
  const isMobile = useIsMobile();
  const [isResizing, setIsResizing] = useState(false);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const [search, setSearch] = useState("");
  const searchTerm = search.trim();
  const results = trpc.admin.globalSearch.useQuery({ query: searchTerm }, { enabled: searchTerm.length >= 2 });
  const activeMenuItem = navItems.find(item => item.path === location) ?? navItems.find(item => location.startsWith(item.path) && item.path !== "/admin");
  const groups = useMemo(() => navItems.reduce<Record<string, DashboardNavItem[]>>((accumulator, item) => { const group = item.group || "Workspace"; (accumulator[group] ??= []).push(item); return accumulator; }, {}), [navItems]);
  const accountPath = user?.role === "owner" ? "/admin/security" : "/admin/settings";
  const mobilePrimary = ["/admin", "/admin/appointments", "/admin/patients", "/admin/whatsapp"].map(path => navItems.find(item => item.path === path)).filter((item): item is DashboardNavItem => Boolean(item)).slice(0, 4);

  useEffect(() => { if (isCollapsed) setIsResizing(false); }, [isCollapsed]);
  useEffect(() => {
    const move = (event: MouseEvent) => { if (!isResizing) return; const rect = sidebarRef.current?.getBoundingClientRect(); if (!rect) return; const width = isArabic ? rect.right - event.clientX : event.clientX - rect.left; if (width >= MIN_WIDTH && width <= MAX_WIDTH) setSidebarWidth(width); };
    const up = () => setIsResizing(false);
    if (isResizing) { document.addEventListener("mousemove", move); document.addEventListener("mouseup", up); document.body.style.cursor = "col-resize"; document.body.style.userSelect = "none"; }
    return () => { document.removeEventListener("mousemove", move); document.removeEventListener("mouseup", up); document.body.style.cursor = ""; document.body.style.userSelect = ""; };
  }, [isArabic, isResizing, setSidebarWidth]);
  useEffect(() => { const keydown = (event: KeyboardEvent) => { if (event.key === "Escape") setSearch(""); }; window.addEventListener("keydown", keydown); return () => window.removeEventListener("keydown", keydown); }, []);

  const go = (path: string) => { setSearch(""); setLocation(path); };
  return <><div ref={sidebarRef} className="relative"><Sidebar side={isArabic ? "right" : "left"} collapsible="icon" className="border-[#0e2130] bg-[#13293a] text-white shadow-[8px_0_28px_rgb(16_32_50_/_0.08)]" disableTransition={isResizing}><SidebarHeader className="h-[76px] border-b border-white/10 px-3"><div className="flex h-full items-center gap-3"><button onClick={toggleSidebar} className="grid size-10 shrink-0 place-items-center rounded-xl text-white/70 transition hover:bg-white/10 hover:text-white focus-visible:outline-2 focus-visible:outline-[#e7b99e]" aria-label={copy.collapseNavigation}><PanelLeft className={`size-5 ${isArabic ? "rotate-180" : ""}`} /></button>{!isCollapsed ? <div className="min-w-0"><p className="font-display text-xl leading-none tracking-[-0.04em] text-white">James Laser</p><p className="mt-1 text-[9px] font-bold uppercase tracking-[0.2em] text-[#e7b99e]">{copy.adminPortal}</p></div> : null}</div></SidebarHeader><SidebarContent className="bg-[#13293a] py-4"><SidebarMenu className="space-y-5 px-2">{Object.entries(groups).map(([group, items]) => <div key={group}><p className="px-3 pb-1 text-[9px] font-extrabold uppercase tracking-[0.18em] text-white/35 group-data-[collapsible=icon]:sr-only">{localizeAdminGroup(group, locale)}</p>{items.map(item => { const active = location === item.path; const label = localizeAdminLabel(item.label, locale); return <SidebarMenuItem key={item.path}><SidebarMenuButton isActive={active} tooltip={label} onClick={() => go(item.path)} aria-current={active ? "page" : undefined} className={`h-10 rounded-xl px-3 text-white/70 transition duration-150 hover:bg-white/10 hover:text-white active:scale-[0.98] data-[active=true]:bg-[#d3a075] data-[active=true]:text-[#13293a] ${active ? "bg-[#d3a075] text-[#13293a] shadow-[0_6px_16px_rgb(201_150_103_/_0.18)]" : ""}`}><item.icon className="size-[17px] shrink-0" /><span className="truncate font-medium">{label}</span>{item.badge && item.badge > 0 ? <span className="ms-auto grid min-w-5 place-items-center rounded-full bg-[#b46749] px-1.5 py-0.5 text-[10px] font-extrabold text-white group-data-[collapsible=icon]:hidden">{item.badge > 99 ? "99+" : item.badge}</span> : null}</SidebarMenuButton></SidebarMenuItem>; })}</div>)}</SidebarMenu></SidebarContent><SidebarFooter className="border-t border-white/10 bg-[#13293a] p-3"><DropdownMenu><DropdownMenuTrigger asChild><button className="flex w-full items-center gap-3 rounded-xl p-2 text-start transition hover:bg-white/10 focus-visible:outline-2 focus-visible:outline-[#e7b99e]"><Avatar className="size-9 shrink-0 border border-white/25"><AvatarFallback className="bg-[#f5f1e9] text-xs font-bold text-[#13293a]">{user?.name?.charAt(0).toUpperCase() || "J"}</AvatarFallback></Avatar><div className="min-w-0 flex-1 group-data-[collapsible=icon]:hidden"><p className="truncate text-sm font-semibold text-white">{user?.name || copy.clinicUser}</p><p className="mt-0.5 text-xs capitalize text-white/55">{user?.role?.replace("_", " ")}</p></div></button></DropdownMenuTrigger><DropdownMenuContent align="end" className="w-52"><DropdownMenuItem onClick={() => go(accountPath)}><Settings className="me-2 size-4" />{copy.accountSettings}</DropdownMenuItem><DropdownMenuSeparator /><DropdownMenuItem onClick={logout} className="text-red-700 focus:text-red-700"><LogOut className="me-2 size-4" />{copy.signOut}</DropdownMenuItem></DropdownMenuContent></DropdownMenu></SidebarFooter></Sidebar><div className={`absolute end-0 top-0 h-full w-1 cursor-col-resize transition hover:bg-[#d3a075]/70 ${isCollapsed ? "hidden" : ""}`} onMouseDown={() => setIsResizing(true)} /></div><SidebarInset className="min-w-0 bg-[#f4f1eb]"><header className="admin-topbar sticky top-0 z-40 px-4 py-3 sm:px-6"><div className="mx-auto flex max-w-[1600px] items-center gap-3"><div className="flex min-w-0 items-center gap-2"><SidebarTrigger className="size-10 rounded-xl border border-[#13293a]/10 bg-white text-[#13293a] hover:bg-[#f4f1eb]" /><div className="min-w-0"><p className="truncate font-display text-xl tracking-[-0.035em] text-[#13293a]">{activeMenuItem ? localizeAdminLabel(activeMenuItem.label, locale) : copy.adminPortal}</p><p className="hidden text-[9px] font-extrabold uppercase tracking-[0.16em] text-[#b46749] sm:block">{copy.secureWorkspace}</p></div></div><div className="relative ms-auto hidden max-w-md flex-1 md:block"><Search className="pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-[#667681]" /><Input value={search} onChange={event => setSearch(event.target.value)} placeholder={copy.globalSearch} aria-label={copy.globalSearch} className="h-10 bg-white ps-9 pe-9" />{search ? <button className="absolute end-2 top-1/2 grid size-6 -translate-y-1/2 place-items-center text-[#667681] hover:text-[#13293a]" aria-label={copy.clearSearch} onClick={() => setSearch("")}><X className="size-4" /></button> : null}{searchTerm.length >= 2 ? <div className="admin-search-results absolute inset-x-0 top-[calc(100%+0.5rem)] max-h-96 overflow-y-auto p-2">{results.isLoading ? <p className="p-3 text-sm text-[#667681]">{copy.searching}</p> : results.isError ? <p className="p-3 text-sm text-red-700">{copy.searchError}</p> : results.data?.length ? results.data.map(result => <button key={result.id} onClick={() => go(result.path)} className="block w-full rounded-xl p-3 text-start transition hover:bg-[#f4f1eb]"><p className="text-sm font-semibold text-[#13293a]">{result.title}</p><p className="mt-0.5 text-xs text-[#667681]">{result.type} · {result.detail}</p></button>) : <p className="p-3 text-sm text-[#667681]">{copy.noMatches}</p>}</div> : null}</div><div className="ms-auto flex items-center gap-2 md:ms-0"><div className="admin-language-toggle" role="group" aria-label="Language"><button type="button" aria-pressed={locale === "en"} onClick={() => setLocale("en")}>EN</button><button type="button" aria-pressed={locale === "ar"} onClick={() => setLocale("ar")}>عربي</button></div><Button variant="outline" size="icon" className="size-10 bg-white" aria-label={copy.notifications} onClick={() => go("/admin/notifications")}><Bell className="size-4" /></Button><Button variant="outline" className="hidden bg-white sm:inline-flex" onClick={() => window.open("/", "_blank", "noopener")}><ExternalLink className="me-2 size-4" />{copy.viewWebsite}</Button></div></div>{isMobile ? <div className="relative mt-3 md:hidden"><Search className="pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-[#667681]" /><Input value={search} onChange={event => setSearch(event.target.value)} placeholder={copy.mobileSearch} className="h-11 bg-white ps-9" />{searchTerm.length >= 2 ? <div className="admin-search-results mt-2 max-h-64 overflow-y-auto p-2">{results.isLoading ? <p className="p-3 text-sm text-[#667681]">{copy.searching}</p> : results.data?.length ? results.data.map(result => <button key={result.id} onClick={() => go(result.path)} className="block w-full rounded-xl p-3 text-start hover:bg-[#f4f1eb]"><p className="text-sm font-semibold text-[#13293a]">{result.title}</p><p className="mt-0.5 text-xs text-[#667681]">{result.type} · {result.detail}</p></button>) : <p className="p-3 text-sm text-[#667681]">{copy.noMatches}</p>}</div> : null}</div> : null}</header><nav className="mobile-bottom-nav md:hidden" aria-label={copy.primaryNavigation}>{mobilePrimary.map(item => { const active = location === item.path || (item.path !== "/admin" && location.startsWith(item.path)); const label = item.label === "Appointment requests" ? copy.requests : localizeAdminLabel(item.label, locale); return <button key={item.path} type="button" onClick={() => go(item.path)} aria-current={active ? "page" : undefined} className={`mobile-bottom-nav__item ${active ? "is-active" : ""}`}><item.icon className="size-[18px]" /><span>{label}</span></button>; })}<button type="button" onClick={toggleSidebar} className="mobile-bottom-nav__item" aria-label={copy.openAllSections}><PanelLeft className={`size-[18px] ${isArabic ? "rotate-180" : ""}`} /><span>{copy.more}</span></button></nav><main className="min-h-[calc(100vh-73px)] p-4 pb-24 sm:p-6 sm:pb-6"><div className="mx-auto w-full max-w-[1600px]">{children}</div></main></SidebarInset></>;
}
