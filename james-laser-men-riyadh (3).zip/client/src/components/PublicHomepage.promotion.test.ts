import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const source = readFileSync(resolve(process.cwd(), "client/src/components/PublicHomepage.tsx"), "utf8");

describe("featured promotion homepage placement", () => {
  it("renders only published public-feed promotions selected for the homepage", () => {
    expect(source).toContain("const promotions = trpc.publicContent.promotions.useQuery()");
    expect(source).toContain(".filter(promotion => promotion.isFeatured)");
    expect(source).toContain('aria-labelledby="premium-home-offers"');
    expect(source).toContain("const featuredPromotions");
  });

  it("keeps price and terms conditional and routes requests through the private appointment flow", () => {
    expect(source).toContain("money(promotion.promotionalPrice) ?");
    expect(source).toContain("promotion.terms ?");
    expect(source).toContain("href={requestPath}");
    expect(source).toContain("View all prices & offers");
  });
});
