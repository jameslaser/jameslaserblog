import React, { useMemo, useState } from "react";
import { MessageCircle, MessageSquareQuote, RotateCcw, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAdminLocale } from "@/contexts/AdminLocaleContext";
import {
  applyQuickReplyToDraft,
  EMPTY_WHATSAPP_MESSAGE_FILTERS,
  filterQuickReplies,
  filterWhatsAppMessages,
  hasActiveWhatsAppMessageFilters,
  resolveQuickReplyLanguage,
  type QuickReplyCategory,
  type QuickReplyDraftMode,
  type WhatsAppMessageFilters,
} from "@/lib/whatsappWorkspace";

type ConversationMessage = {
  id: number;
  direction: string;
  messageType: string;
  body?: string | null;
  templateName?: string | null;
  status: string;
  createdAt: Date | string;
};

const directionOptions = ["all", "inbound", "outbound", "system"] as const;
const messageTypeOptions = ["all", "text", "image", "document", "audio", "template", "interactive", "status", "unsupported"] as const;
const statusOptions = ["all", "received", "sending", "sent", "delivered", "read", "failed"] as const;
const categoryOptions = ["all", "welcome", "reference", "review", "availability", "hours", "closing"] as const;

function formatTime(value: Date | string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  const sameDay = date.toDateString() === new Date().toDateString();
  return sameDay ? date.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }) : date.toLocaleDateString([], { month: "short", day: "numeric" });
}

function messageStyle(direction: string) {
  if (direction === "outbound") return "justify-end border-[#a85438]/30 bg-[#fff4ed] text-[#102032]";
  if (direction === "system") return "justify-start border-[#102032]/10 bg-white text-[#66727A]";
  return "justify-start border-[#102032]/10 bg-white text-[#102032]";
}

export function WhatsAppMessageHistory({ messages, initialFilters = EMPTY_WHATSAPP_MESSAGE_FILTERS }: { messages: ConversationMessage[]; initialFilters?: WhatsAppMessageFilters }) {
  const { locale } = useAdminLocale();
  const ar = locale === "ar";
  const [filters, setFilters] = useState<WhatsAppMessageFilters>(initialFilters);
  const filteredMessages = useMemo(() => filterWhatsAppMessages(messages, filters), [messages, filters]);
  const hasFilters = hasActiveWhatsAppMessageFilters(filters);
  const setFilter = <K extends keyof WhatsAppMessageFilters>(key: K, value: WhatsAppMessageFilters[K]) => setFilters(current => ({ ...current, [key]: value }));
  const labels = ar ? {
    heading: "تصفية سجل الرسائل",
    detail: "تتم التصفية محلياً داخل المحادثة المصرح بها ولا يتم تغيير أي سجل.",
    search: "ابحث في نص الرسالة أو الحالة",
    direction: "الاتجاه",
    type: "نوع الرسالة",
    status: "حالة التسليم",
    allDirections: "كل الاتجاهات",
    allTypes: "كل الأنواع",
    allStatuses: "كل الحالات",
    clear: "مسح عوامل التصفية",
    showing: "معروض",
    of: "من",
    noMatch: "لا توجد رسائل محفوظة تطابق عوامل التصفية الحالية.",
    noMessages: "لم يتم حفظ رسائل لهذه المحادثة بعد.",
  } : {
    heading: "Filter message history",
    detail: "Filtering happens locally inside this authorized conversation and does not change any record.",
    search: "Search message text or status",
    direction: "Direction",
    type: "Message type",
    status: "Delivery status",
    allDirections: "All directions",
    allTypes: "All types",
    allStatuses: "All statuses",
    clear: "Clear filters",
    showing: "Showing",
    of: "of",
    noMatch: "No persisted messages match the current filters.",
    noMessages: "No messages have been persisted for this conversation.",
  };
  const optionLabel = (value: string) => value === "all" ? "" : value.replaceAll("_", " ");

  return <section className="bg-[#f8f5ef]" aria-labelledby="message-history-filter-title">
    <div className="border-b border-[#102032]/10 bg-white p-4">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <h3 id="message-history-filter-title" className="text-sm font-semibold text-[#102032]">{labels.heading}</h3>
          <p className="mt-1 text-xs leading-5 text-[#66727A]">{labels.detail}</p>
        </div>
        <p className="shrink-0 text-xs font-semibold text-[#52606B]" aria-live="polite">{labels.showing} {filteredMessages.length} {labels.of} {messages.length}</p>
      </div>
      <div className="mt-3 grid gap-2 sm:grid-cols-2 xl:grid-cols-[minmax(180px,1fr)_150px_150px_150px_auto]">
        <div className="relative"><Search className="pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-[#66727A]" /><Input value={filters.query} onChange={event => setFilter("query", event.target.value)} placeholder={labels.search} aria-label={labels.search} className="ps-9" /></div>
        <Select value={filters.direction} onValueChange={value => setFilter("direction", value as WhatsAppMessageFilters["direction"])}><SelectTrigger aria-label={labels.direction}><SelectValue /></SelectTrigger><SelectContent>{directionOptions.map(value => <SelectItem key={value} value={value}>{value === "all" ? labels.allDirections : optionLabel(value)}</SelectItem>)}</SelectContent></Select>
        <Select value={filters.messageType} onValueChange={value => setFilter("messageType", value as WhatsAppMessageFilters["messageType"])}><SelectTrigger aria-label={labels.type}><SelectValue /></SelectTrigger><SelectContent>{messageTypeOptions.map(value => <SelectItem key={value} value={value}>{value === "all" ? labels.allTypes : optionLabel(value)}</SelectItem>)}</SelectContent></Select>
        <Select value={filters.status} onValueChange={value => setFilter("status", value as WhatsAppMessageFilters["status"])}><SelectTrigger aria-label={labels.status}><SelectValue /></SelectTrigger><SelectContent>{statusOptions.map(value => <SelectItem key={value} value={value}>{value === "all" ? labels.allStatuses : optionLabel(value)}</SelectItem>)}</SelectContent></Select>
        <Button type="button" variant="outline" disabled={!hasFilters} onClick={() => setFilters(EMPTY_WHATSAPP_MESSAGE_FILTERS)}><RotateCcw className="me-2 size-4" />{labels.clear}</Button>
      </div>
    </div>
    <div className="min-h-[420px] space-y-3 p-4">
      {filteredMessages.map(message => <div key={message.id} className={`flex ${message.direction === "outbound" ? "justify-end" : "justify-start"}`}><div className={`max-w-[86%] border px-3 py-2 text-sm shadow-sm ${messageStyle(message.direction).replace(/^justify-(end|start)\s/, "")}`}><p data-admin-no-translate dir={/[\u0600-\u06FF]/.test(message.body || "") ? "rtl" : "ltr"} className="whitespace-pre-wrap break-words">{message.body || message.templateName || `[${message.messageType}]`}</p><div className="mt-2 flex items-center justify-end gap-1 text-[10px] text-[#66727A]"><span data-admin-no-translate>{formatTime(message.createdAt)}</span>{message.direction === "outbound" && <span className="capitalize">· {message.status}</span>}</div></div></div>)}
      {filteredMessages.length === 0 ? <div className="py-16 text-center"><MessageCircle className="mx-auto size-6 text-[#a85438]" /><p className="mt-3 text-sm text-[#66727A]">{hasFilters ? labels.noMatch : labels.noMessages}</p></div> : null}
    </div>
  </section>;
}

export function WhatsAppQuickReplies({ conversationLanguage, serviceWindowOpen, draft, onDraftChange }: { conversationLanguage: string | null | undefined; serviceWindowOpen: boolean; draft: string; onDraftChange: (value: string) => void }) {
  const { locale } = useAdminLocale();
  const ar = locale === "ar";
  const language = resolveQuickReplyLanguage(conversationLanguage, locale);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<QuickReplyCategory | "all">("all");
  const [mode, setMode] = useState<QuickReplyDraftMode>("replace");
  const [notice, setNotice] = useState("");
  const replies = useMemo(() => filterQuickReplies(query, category, language), [query, category, language]);
  const labels = ar ? {
    heading: "ردود سريعة للموظفين",
    detail: "اختيار الرد يضيفه إلى المسودة فقط. راجع النص ثم استخدم زر الإرسال الحالي.",
    search: "ابحث في الردود السريعة",
    category: "فئة الرد",
    all: "كل الفئات",
    replace: "استبدال المسودة",
    append: "إضافة إلى المسودة",
    unavailable: "الردود الحرة غير متاحة خارج نافذة خدمة العملاء. استخدم قالب Meta معتمداً.",
    noMatch: "لا توجد ردود سريعة مطابقة.",
    prepared: "تم إعداد المسودة فقط ولم يتم إرسال أي رسالة:",
  } : {
    heading: "Staff quick replies",
    detail: "Selecting a reply changes the draft only. Review it, then use the existing send button.",
    search: "Search quick replies",
    category: "Reply category",
    all: "All categories",
    replace: "Replace draft",
    append: "Add to draft",
    unavailable: "Free-form replies are unavailable outside the customer-service window. Use an approved Meta template.",
    noMatch: "No quick replies match this search.",
    prepared: "Draft prepared only; no message was sent:",
  };
  const categoryLabel: Record<typeof categoryOptions[number], { en: string; ar: string }> = {
    all: { en: "All categories", ar: "كل الفئات" },
    welcome: { en: "Welcome", ar: "ترحيب" },
    reference: { en: "Request reference", ar: "مرجع الطلب" },
    review: { en: "Under review", ar: "قيد المراجعة" },
    availability: { en: "Availability", ar: "التوفر" },
    hours: { en: "Clinic hours", ar: "ساعات العيادة" },
    closing: { en: "Closing", ar: "ختام" },
  };
  const chooseReply = (title: string, body: string) => {
    onDraftChange(applyQuickReplyToDraft(draft, body, mode));
    setNotice(`${labels.prepared} ${title}`);
  };

  return <section className="mb-3 rounded-2xl border border-[#102032]/10 bg-[#f8f5ef] p-3" aria-labelledby="quick-reply-title">
    <div className="flex items-start gap-2"><MessageSquareQuote className="mt-0.5 size-4 shrink-0 text-[#a85438]" /><div><h3 id="quick-reply-title" className="text-sm font-semibold text-[#102032]">{labels.heading}</h3><p className="mt-1 text-xs leading-5 text-[#66727A]">{labels.detail}</p></div></div>
    {!serviceWindowOpen ? <p className="mt-3 rounded-xl border border-amber-700/20 bg-amber-50 px-3 py-2 text-xs leading-5 text-amber-900">{labels.unavailable}</p> : null}
    <div className="mt-3 grid gap-2 sm:grid-cols-[minmax(160px,1fr)_170px_170px]">
      <div className="relative"><Search className="pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-[#66727A]" /><Input value={query} onChange={event => setQuery(event.target.value)} disabled={!serviceWindowOpen} placeholder={labels.search} aria-label={labels.search} className="ps-9" /></div>
      <Select value={category} disabled={!serviceWindowOpen} onValueChange={value => setCategory(value as QuickReplyCategory | "all")}><SelectTrigger aria-label={labels.category}><SelectValue /></SelectTrigger><SelectContent>{categoryOptions.map(value => <SelectItem key={value} value={value}>{categoryLabel[value][ar ? "ar" : "en"]}</SelectItem>)}</SelectContent></Select>
      <Select value={mode} disabled={!serviceWindowOpen} onValueChange={value => setMode(value as QuickReplyDraftMode)}><SelectTrigger aria-label={ar ? "طريقة إدراج الرد" : "Quick reply insertion mode"}><SelectValue /></SelectTrigger><SelectContent><SelectItem value="replace">{labels.replace}</SelectItem><SelectItem value="append">{labels.append}</SelectItem></SelectContent></Select>
    </div>
    <div className="mt-3 grid gap-2 sm:grid-cols-2">
      {replies.map(reply => { const content = reply[language]; return <button key={reply.id} type="button" disabled={!serviceWindowOpen} onClick={() => chooseReply(content.title, content.body)} className="min-h-11 rounded-xl border border-[#102032]/10 bg-white p-3 text-start transition hover:border-[#a85438]/50 hover:bg-[#fffaf5] disabled:cursor-not-allowed disabled:opacity-50"><span className="text-xs font-semibold text-[#102032]" data-admin-no-translate>{content.title}</span><span className="mt-1 line-clamp-2 block text-xs leading-5 text-[#66727A]" data-admin-no-translate>{content.body}</span></button>; })}
      {replies.length === 0 ? <p className="rounded-xl border border-dashed border-[#102032]/20 bg-white p-4 text-center text-xs text-[#66727A] sm:col-span-2">{labels.noMatch}</p> : null}
    </div>
    <p className="sr-only" aria-live="polite">{notice}</p>
  </section>;
}
