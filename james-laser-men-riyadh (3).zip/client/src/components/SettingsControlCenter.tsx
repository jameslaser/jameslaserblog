import { AdminErrorState, AdminLoadingState, AdminPageHeader } from "@/components/AdminUi";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useAdminLocale } from "@/contexts/AdminLocaleContext";
import { AlertTriangle, ArrowUpRight, Bot, CalendarDays, CheckCircle2, ChevronRight, FileText, Globe2, Loader2, LockKeyhole, MessageCircle, Search, Settings2, ShieldCheck, SlidersHorizontal, UsersRound, Wrench } from "lucide-react";
import React, { FormEvent, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";

type SettingsForm = {
  availableDays: string;
  preferredTimes: string;
  appointmentTreatmentOptions: string;
  visitTypeOptions: string;
  defaultLanguage: "en" | "ar";
  maintenanceMode: boolean;
  appointmentFormEnabled: boolean;
};

type Category = {
  id: string;
  label: string;
  description: string;
  icon: typeof Globe2;
  routes: Array<{ label: string; detail: string; path: string; keywords: string[] }>;
};

const weekdayNames = new Set(["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]);

const categories: Category[] = [
  {
    id: "website",
    label: "Website",
    description: "Public identity, contact details, location, hours, social profiles, and brand assets.",
    icon: Globe2,
    routes: [
      { label: "General, contact & location", detail: "Business name, contact details, maps, business hours, social profiles, and Google Business link.", path: "/admin/clinic", keywords: ["website", "general", "contact", "location", "hours", "footer", "social", "maps", "google"] },
      { label: "Homepage", detail: "Draft, publish, order, visibility, bilingual copy, CTA, and media for actual homepage sections.", path: "/admin/content", keywords: ["homepage", "hero", "trust", "assessment", "nurse james", "services", "promotions", "faq", "footer", "cta"] },
      { label: "Homepage appearance", detail: "Vetted theme presets and protected upload controls for the public hero, specialist, and clinic images.", path: "/admin/appearance", keywords: ["homepage", "theme", "appearance", "brand", "hero image", "specialist image", "clinic image", "upload"] },
    ],
  },
  {
    id: "content",
    label: "Content & CMS",
    description: "Reviewed public content, media, policies, education, promotions, and publishing workflow.",
    icon: FileText,
    routes: [
      { label: "Treatments & services", detail: "Bilingual service copy, duration, visibility, active state, and service SEO.", path: "/admin/treatments", keywords: ["services", "treatment", "duration", "visibility"] },
      { label: "Promotions & reviews", detail: "Approved offers, reviews, consent-controlled results, and public visibility.", path: "/admin/promotions", keywords: ["promotion", "reviews", "results", "approval"] },
      { label: "Blog, FAQ & media", detail: "AI-assisted drafts, approved educational content, FAQs, and authorised media metadata.", path: "/admin/guide", keywords: ["guide", "blog", "ai", "vlog", "faq", "media", "cms"] },
      { label: "Policies & publishing calendar", detail: "Bilingual policy pages and owner-authorised content planning. Calendar planning never publishes externally.", path: "/admin/policies", keywords: ["policy", "publishing", "approval", "calendar"] },
    ],
  },
  {
    id: "seo",
    label: "SEO & Google",
    description: "Public-only search configuration, canonical guidance, indexing, redirects, and Google readiness.",
    icon: Search,
    routes: [
      { label: "SEO controls", detail: "Locale title, description, canonical, indexability, structured data, sitemap, and robots readiness for public pages.", path: "/admin/seo", keywords: ["seo", "canonical", "sitemap", "robots", "structured data", "index"] },
      { label: "Redirects", detail: "Server-enforced redirects for public routes. Protected portal routes cannot be made public here.", path: "/admin/redirects", keywords: ["redirect", "navigation", "url", "private routes"] },
      { label: "Google profile readiness", detail: "The public Google Business URL is maintained in Clinic information. OAuth credentials and verification are never shown or submitted here.", path: "/admin/clinic", keywords: ["google", "business profile", "search console", "oauth", "maps"] },
    ],
  },
  {
    id: "appointments",
    label: "Appointments",
    description: "Request preferences only. The clinic remains responsible for confirming every appointment.",
    icon: CalendarDays,
    routes: [],
  },
  {
    id: "machines",
    label: "Machines",
    description: "Existing protected machine inventory and appointment synchronization.",
    icon: Wrench,
    routes: [
      { label: "Machine records", detail: "Maintain internal identifiers for DEKA AGAIN, CLARITY 2, GENTLE PROMAX, and DUETTO MACHINE without changing manufacturer serial numbers.", path: "/admin/machines", keywords: ["machine", "deka", "clarity", "gentle promax", "duetto", "availability", "blocking"] },
    ],
  },
  {
    id: "patients",
    label: "Patients",
    description: "Protected patient operations; patient records never appear in Settings.",
    icon: UsersRound,
    routes: [
      { label: "Patient records", detail: "Open the protected patient workspace for authorised clinical and administrative records.", path: "/admin/patients", keywords: ["patient", "consent", "language", "required fields", "records"] },
    ],
  },
  {
    id: "whatsapp",
    label: "WhatsApp",
    description: "Provider status, templates, consent, webhooks, and the authoritative activation gate.",
    icon: MessageCircle,
    routes: [
      { label: "WhatsApp automation centre", detail: "Provider status, template mappings, consent, webhook metadata, queue controls, and activation safeguards.", path: "/admin/whatsapp", keywords: ["whatsapp", "provider", "template", "automation", "webhook", "consent", "reminder"] },
    ],
  },
  {
    id: "revenue",
    label: "Revenue",
    description: "Read-only commission reporting based on HMS source records.",
    icon: SlidersHorizontal,
    routes: [
      { label: "Revenue workspace", detail: "HMS remains the source of truth. The commission formula is fixed: Total Income × 75% × 3%.", path: "/admin/revenue", keywords: ["revenue", "commission", "income", "hms", "75", "3"] },
    ],
  },
  {
    id: "staff",
    label: "Staff & RBAC",
    description: "Owner-only role administration with server-side enforcement.",
    icon: ShieldCheck,
    routes: [
      { label: "Users & roles", detail: "Owner-only assignment of existing admin, content editor, reception, and user roles. Interface visibility never replaces backend authorization.", path: "/admin/security", keywords: ["staff", "roles", "rbac", "permissions", "security"] },
    ],
  },
  {
    id: "notifications",
    label: "Notifications",
    description: "Private staff notifications and governed public announcements.",
    icon: CheckCircle2,
    routes: [
      { label: "Notification centre", detail: "Review in-app staff notifications and approved public announcements. WhatsApp delivery remains controlled in its protected workspace.", path: "/admin/notifications", keywords: ["notification", "in-app", "email", "whatsapp", "recipients", "timing"] },
    ],
  },
  {
    id: "security",
    label: "Security & system",
    description: "Safe system status, access controls, data safeguards, and recoverable operations.",
    icon: LockKeyhole,
    routes: [
      { label: "Data & backup", detail: "Protected export and backup verification tools. No production reset or destructive data action is available from this Settings surface.", path: "/admin/data", keywords: ["system", "backup", "health", "environment", "feature flags", "data"] },
      { label: "Activity log", detail: "Review privileged operational events without exposing secrets, credentials, patient records, or raw integration payloads.", path: "/admin/activity", keywords: ["audit", "activity", "security events", "history"] },
    ],
  },
];

function blankToNull(value: string) {
  return value.trim() || null;
}

function toForm(settings: { availableDays?: string | null; preferredTimes?: string | null; appointmentTreatmentOptions?: string | null; visitTypeOptions?: string | null; defaultLanguage?: "en" | "ar"; maintenanceMode?: boolean; appointmentFormEnabled?: boolean } | undefined): SettingsForm {
  return {
    availableDays: settings?.availableDays ?? "",
    preferredTimes: settings?.preferredTimes ?? "",
    appointmentTreatmentOptions: settings?.appointmentTreatmentOptions ?? "",
    visitTypeOptions: settings?.visitTypeOptions ?? "session, retouch",
    defaultLanguage: settings?.defaultLanguage ?? "en",
    maintenanceMode: settings?.maintenanceMode ?? false,
    appointmentFormEnabled: settings?.appointmentFormEnabled ?? true,
  };
}

function splitValues(value: string) {
  return value.split(/[\n,]/).map(item => item.trim()).filter(Boolean);
}

function formatDate(value: Date | string | null | undefined) {
  if (!value) return "Not recorded";
  return new Intl.DateTimeFormat("en-SA", { dateStyle: "medium", timeStyle: "short", timeZone: "Asia/Riyadh" }).format(new Date(value));
}

function statusBadge(connected: boolean, ready?: boolean) {
  if (!connected) return <Badge variant="outline" className="border-amber-300 bg-amber-50 text-amber-900">Needs configuration</Badge>;
  if (ready) return <Badge variant="outline" className="border-emerald-300 bg-emerald-50 text-emerald-800">Connected</Badge>;
  return <Badge variant="outline" className="border-sky-300 bg-sky-50 text-sky-800">Configured</Badge>;
}

export function SettingsControlCenter() {
  const [, setLocation] = useLocation();
  const { isArabic } = useAdminLocale();
  const settings = trpc.cms.settingsControl.useQuery();
  const audit = trpc.cms.settingsChangeAudit.useQuery();
  const whatsapp = trpc.whatsapp.settings.useQuery();
  const utils = trpc.useUtils();
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("appointments");
  const [form, setForm] = useState<SettingsForm>(() => toForm(undefined));

  useEffect(() => {
    if (settings.data) setForm(toForm(settings.data));
  }, [settings.data]);

  const dirty = useMemo(() => JSON.stringify(form) !== JSON.stringify(toForm(settings.data)), [form, settings.data]);

  useEffect(() => {
    const onBeforeUnload = (event: BeforeUnloadEvent) => {
      if (!dirty) return;
      event.preventDefault();
      event.returnValue = "";
    };
    window.addEventListener("beforeunload", onBeforeUnload);
    return () => window.removeEventListener("beforeunload", onBeforeUnload);
  }, [dirty]);

  const save = trpc.cms.updateSettingsControl.useMutation({
    onSuccess: async () => {
      toast.success("Settings saved and recorded in change history.");
      await Promise.all([
        utils.cms.settingsControl.invalidate(),
        utils.cms.settingsChangeAudit.invalidate(),
        utils.cms.clinicSettings.invalidate(),
        utils.publicContent.clinicSettings.invalidate(),
      ]);
    },
    onError: error => toast.error(error.message),
  });

  const query = search.trim().toLowerCase();
  const visibleCategories = categories.filter(category => !query || `${category.label} ${category.description} ${category.routes.flatMap(route => [route.label, route.detail, ...route.keywords]).join(" ")}`.toLowerCase().includes(query));
  const current = categories.find(category => category.id === activeCategory) ?? categories[0];
  const socialLinks = [settings.data?.instagramUrl, settings.data?.tiktokUrl, settings.data?.snapchatUrl, settings.data?.facebookUrl, settings.data?.youtubeUrl, settings.data?.xUrl].filter(Boolean).length;
  const lastAudit = audit.data?.[0];

  const selectCategory = (id: string) => {
    if (dirty && !window.confirm("You have unsaved appointment configuration changes. Continue without saving them?")) return;
    if (dirty) setForm(toForm(settings.data));
    setActiveCategory(id);
  };

  const openRoute = (path: string) => {
    if (dirty && !window.confirm("You have unsaved appointment configuration changes. Continue without saving them?")) return;
    setLocation(path);
  };

  const validateForm = () => {
    const times = splitValues(form.preferredTimes);
    const invalidTime = times.find(value => {
      const match = /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(value);
      if (!match) return true;
      const [hour, minute] = value.split(":").map(Number);
      return hour < 13 || hour > 22 || minute % 15 !== 0;
    });
    if (invalidTime) return "Preferred times must use 24-hour 15-minute slots between 13:00 and 22:45, for example 13:00, 13:15.";
    const invalidDay = splitValues(form.availableDays).find(value => !weekdayNames.has(value.toLowerCase()));
    if (invalidDay) return "Available request days must use full English weekday names, separated by commas or lines.";
    const invalidVisitType = splitValues(form.visitTypeOptions).find(value => !["session", "retouch"].includes(value.toLowerCase()));
    if (invalidVisitType) return "Visit-type choices support only session and retouch in the existing request workflow.";
    return null;
  };

  const submitAppointmentSettings = (event: FormEvent) => {
    event.preventDefault();
    const validationError = validateForm();
    if (validationError) {
      toast.error(validationError);
      return;
    }
    const currentSettings = toForm(settings.data);
    const impactChanged = currentSettings.appointmentFormEnabled !== form.appointmentFormEnabled || currentSettings.maintenanceMode !== form.maintenanceMode;
    if (impactChanged && !window.confirm("You are changing public appointment availability. This may affect appointment requests. Confirm only after reviewing clinic operations.")) return;
    save.mutate({
      availableDays: blankToNull(form.availableDays),
      preferredTimes: blankToNull(form.preferredTimes),
      appointmentTreatmentOptions: blankToNull(form.appointmentTreatmentOptions),
      visitTypeOptions: blankToNull(form.visitTypeOptions),
      defaultLanguage: form.defaultLanguage,
      maintenanceMode: form.maintenanceMode,
      appointmentFormEnabled: form.appointmentFormEnabled,
    });
  };

  if (settings.isLoading) return <div className="mx-auto max-w-7xl"><AdminPageHeader eyebrow="Master control centre" title="Settings" description="Loading the existing protected settings configuration." /><AdminLoadingState label="Loading settings control centre…" /></div>;
  if (settings.isError) return <div className="mx-auto max-w-7xl"><AdminPageHeader eyebrow="Master control centre" title="Settings" description="Configuration remains protected while the settings service is unavailable." /><AdminErrorState title="Settings unavailable" description="The existing settings configuration could not be loaded." onRetry={() => settings.refetch()} /></div>;
  const clinic = settings.data;
  if (!clinic) return <div className="mx-auto max-w-7xl"><AdminPageHeader eyebrow="Master control centre" title="Settings" description="Configuration remains protected while the settings service is unavailable." /><AdminErrorState title="Settings unavailable" description="No clinic configuration was returned. No setting has been changed." onRetry={() => settings.refetch()} /></div>;

  return <div dir={isArabic ? "rtl" : "ltr"} className="mx-auto max-w-7xl space-y-6">
    <AdminPageHeader
      eyebrow="Master control centre"
      title="Settings"
      description="One protected control surface for existing website, CMS, appointment, communication, security, and system workflows. Settings links open the authoritative workspace; they never duplicate sensitive records or bypass approvals."
      action={<Badge variant="outline" className="w-fit border-[#a85438]/30 bg-[#fff4ed] text-[#8d4027]"><ShieldCheck className="mr-1.5 size-3.5" />Server-authorized</Badge>}
    />

    <section className="grid gap-3 border border-[#102032]/10 bg-white p-4 sm:grid-cols-2 lg:grid-cols-4">
      <div><p className="text-xs font-semibold text-[#66727A]">Clinic timezone</p><p className="mt-1 font-semibold text-[#102032]">Asia/Riyadh</p></div>
      <div><p className="text-xs font-semibold text-[#66727A]">Default website language</p><p className="mt-1 font-semibold text-[#102032]">{clinic.defaultLanguage === "ar" ? "Arabic" : "English"}</p></div>
      <div><p className="text-xs font-semibold text-[#66727A]">Public appointment requests</p><p className="mt-1 font-semibold text-[#102032]">{clinic.appointmentFormEnabled && !clinic.maintenanceMode ? "Available for review" : "Paused"}</p></div>
      <div><p className="text-xs font-semibold text-[#66727A]">Last clinic setting change</p><p className="mt-1 font-semibold text-[#102032]">{formatDate(clinic.updatedAt)}</p></div>
    </section>

    <section className="border border-[#102032]/10 bg-white p-4 sm:p-5">
      <label className="relative block"><Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-[#66727A]" /><Input value={search} onChange={event => setSearch(event.target.value)} placeholder="Search Settings: WhatsApp, appointment, SEO, machine, audit…" className="h-11 pl-10" aria-label="Search Settings" /></label>
      <p className="mt-2 text-xs leading-5 text-[#66727A]">Search finds the existing authoritative module for each setting. Protected portal routes and private APIs are never offered as public navigation controls.</p>
    </section>

    <div className="grid gap-6 xl:grid-cols-[260px_minmax(0,1fr)]">
      <nav aria-label="Settings categories" className="h-fit space-y-1 border border-[#102032]/10 bg-white p-2">
        {visibleCategories.length ? visibleCategories.map(category => {
          const Icon = category.icon;
          const active = current.id === category.id;
          return <button key={category.id} type="button" onClick={() => selectCategory(category.id)} className={`flex w-full items-center gap-3 rounded-md px-3 py-3 text-left text-sm transition focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#a85438] ${active ? "bg-[#102032] text-white" : "text-[#102032] hover:bg-[#f5f1e9]"}`}><Icon className="size-4 shrink-0" /><span className="font-semibold">{category.label}</span><ChevronRight className="ml-auto size-4" /></button>;
        }) : <p className="p-3 text-sm text-[#66727A]">No matching settings area.</p>}
      </nav>

      <main className="min-w-0 space-y-5">
        <section className="border border-[#102032]/10 bg-white p-5 sm:p-6">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between"><div><div className="flex items-center gap-2"><current.icon className="size-5 text-[#a85438]" /><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">Existing configuration</p></div><h2 className="mt-2 font-display text-3xl text-[#102032]">{current.label}</h2><p className="mt-2 max-w-3xl text-sm leading-6 text-[#52606B]">{current.description}</p></div>{current.id === "whatsapp" ? statusBadge(Boolean(whatsapp.data), Boolean(whatsapp.data?.webhookConfigured)) : null}</div>

          {current.id === "appointments" ? <form onSubmit={submitAppointmentSettings} className="mt-6 space-y-5">
            <div className="grid gap-4 lg:grid-cols-2">
              <label className="grid gap-1.5 text-xs font-bold text-[#102032]"><span>Clinic request hours</span><Input disabled value="1:00 PM – 10:00 PM · 15-minute intervals" aria-label="Clinic request hours" /><span className="font-normal leading-5 text-[#66727A]">The existing request engine accepts configured preferences only; it does not promise real-time availability or change treatment duration rules.</span></label>
              <label className="grid gap-1.5 text-xs font-bold text-[#102032]"><span>Default public language</span><select value={form.defaultLanguage} onChange={event => setForm(previous => ({ ...previous, defaultLanguage: event.target.value as "en" | "ar" }))} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm"><option value="en">English</option><option value="ar">Arabic</option></select></label>
              <label className="grid gap-1.5 text-xs font-bold text-[#102032]"><span>Available request days</span><textarea value={form.availableDays} onChange={event => setForm(previous => ({ ...previous, availableDays: event.target.value }))} placeholder="Monday, Tuesday, Wednesday" className="min-h-24 resize-y border border-[#102032]/20 bg-white px-3 py-2 text-sm" /></label>
              <label className="grid gap-1.5 text-xs font-bold text-[#102032]"><span>Preferred time choices</span><textarea value={form.preferredTimes} onChange={event => setForm(previous => ({ ...previous, preferredTimes: event.target.value }))} placeholder="13:00, 13:15, 13:30" className="min-h-24 resize-y border border-[#102032]/20 bg-white px-3 py-2 text-sm" /></label>
              <label className="grid gap-1.5 text-xs font-bold text-[#102032]"><span>Request treatment choices</span><textarea value={form.appointmentTreatmentOptions} onChange={event => setForm(previous => ({ ...previous, appointmentTreatmentOptions: event.target.value }))} placeholder="Full Face, Chest, Full Body" className="min-h-24 resize-y border border-[#102032]/20 bg-white px-3 py-2 text-sm" /></label>
              <label className="grid gap-1.5 text-xs font-bold text-[#102032]"><span>Visit-type choices</span><Input value={form.visitTypeOptions} onChange={event => setForm(previous => ({ ...previous, visitTypeOptions: event.target.value }))} placeholder="session, retouch" /></label>
            </div>
            <div className="grid gap-3 border-y border-[#102032]/10 py-4 text-sm"><label className="flex items-center gap-3 font-semibold text-[#102032]"><input type="checkbox" checked={form.appointmentFormEnabled} onChange={event => setForm(previous => ({ ...previous, appointmentFormEnabled: event.target.checked }))} />Enable public appointment requests</label><label className="flex items-center gap-3 font-semibold text-[#102032]"><input type="checkbox" checked={form.maintenanceMode} onChange={event => setForm(previous => ({ ...previous, maintenanceMode: event.target.checked }))} />Maintenance mode (pauses public appointment requests)</label></div>
            <div className="flex flex-wrap items-center gap-3"><Button type="submit" disabled={!dirty || save.isPending}>{save.isPending ? <Loader2 className="mr-2 size-4 animate-spin" /> : <Settings2 className="mr-2 size-4" />}Save appointment settings</Button><Button type="button" variant="outline" disabled={!dirty || save.isPending} onClick={() => { setForm(toForm(settings.data)); toast.message("Unsaved changes cancelled."); }}>Cancel</Button>{dirty ? <span className="text-xs font-semibold text-amber-800">Unsaved changes</span> : <span className="text-xs text-[#66727A]">All changes saved</span>}</div>
          </form> : <div className="mt-6 grid gap-3">
            {current.routes.map(route => <button type="button" key={route.label} onClick={() => openRoute(route.path)} className="group flex w-full items-start gap-4 border border-[#102032]/10 bg-[#fdfbf7] p-4 text-left transition hover:border-[#a85438]/50 hover:bg-[#fff8f2]"><ArrowUpRight className="mt-0.5 size-4 shrink-0 text-[#a85438]" /><span className="min-w-0 flex-1"><span className="block font-semibold text-[#102032]">{route.label}</span><span className="mt-1 block text-sm leading-6 text-[#52606B]">{route.detail}</span></span><ChevronRight className="mt-1 size-4 text-[#66727A]" /></button>)}
          </div>}
        </section>

        <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          <article className="border border-[#102032]/10 bg-white p-4"><p className="text-xs font-semibold text-[#66727A]">Website integrations</p><div className="mt-3 flex items-center justify-between gap-3"><span className="font-semibold text-[#102032]">Maps & Google Business</span>{statusBadge(Boolean(clinic.mapsUrl || clinic.googleBusinessUrl))}</div><p className="mt-2 text-xs leading-5 text-[#52606B]">Public links only; OAuth credentials, verification tokens, and secrets are not stored or displayed here.</p></article>
          <article className="border border-[#102032]/10 bg-white p-4"><p className="text-xs font-semibold text-[#66727A]">Social profiles</p><p className="mt-2 text-2xl font-bold text-[#102032]">{socialLinks}/6</p><p className="mt-1 text-xs leading-5 text-[#52606B]">Official configured profile links. Manage them in Clinic information.</p></article>
          <article className="border border-[#102032]/10 bg-white p-4"><p className="text-xs font-semibold text-[#66727A]">WhatsApp activation</p><div className="mt-3 flex items-center gap-2"><Bot className="size-4 text-[#a85438]" /><span className="font-semibold text-[#102032]">{whatsapp.data?.automationEnabled ? "Enabled through verified gate" : "Automation remains OFF"}</span></div><p className="mt-2 text-xs leading-5 text-[#52606B]">This page has no activation control and cannot bypass the authoritative verification gate.</p></article>
        </section>

        <section className="border border-[#102032]/10 bg-white p-5 sm:p-6">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">Audit & compliance</p><h2 className="mt-2 font-display text-2xl text-[#102032]">Settings change history</h2><p className="mt-2 max-w-3xl text-sm leading-6 text-[#52606B]">Changes record the actor, setting area, safe field names, and timestamp. Values for secrets, credentials, and private patient information are never kept here.</p></div><Button type="button" variant="outline" onClick={() => openRoute("/admin/activity")}>Open full activity log</Button></div>
          {audit.isLoading ? <div className="mt-5"><AdminLoadingState label="Loading settings change history…" /></div> : audit.isError ? <div className="mt-5"><AdminErrorState title="Settings history unavailable" description="No configuration values were changed while this history was unavailable." onRetry={() => audit.refetch()} /></div> : audit.data?.length ? <div className="mt-5 overflow-x-auto"><table className="w-full min-w-[680px] text-left text-sm"><thead className="bg-[#f7f3ec] text-[10px] font-extrabold uppercase tracking-[0.12em] text-[#66727A]"><tr><th className="p-3">When</th><th className="p-3">Changed by</th><th className="p-3">Area</th><th className="p-3">Safe change summary</th></tr></thead><tbody>{audit.data.map(item => <tr key={item.id} className="border-t border-[#102032]/10"><td className="p-3 text-[#52606B]">{formatDate(item.createdAt)}</td><td className="p-3 font-medium text-[#102032]">{item.actorName || "System"}</td><td className="p-3 text-[#52606B]">{item.settingArea}</td><td className="p-3 text-[#52606B]">{item.changedFields.join(", ")}</td></tr>)}</tbody></table></div> : <div className="mt-5 border border-dashed border-[#102032]/20 bg-[#fdfbf7] p-5 text-sm text-[#52606B]">No settings changes have been recorded in the dedicated history yet. Existing activity remains available in the full audit log.</div>}
          <p className="mt-4 text-xs text-[#66727A]">Last recorded setting update: {lastAudit ? `${lastAudit.actorName || "System"} · ${formatDate(lastAudit.createdAt)}` : "not recorded in dedicated history"}.</p>
        </section>

        <section className="border border-amber-300 bg-amber-50 p-5 sm:p-6"><div className="flex items-start gap-3"><AlertTriangle className="mt-0.5 size-5 shrink-0 text-amber-800" /><div><p className="font-semibold text-amber-950">Protected actions only</p><p className="mt-1 text-sm leading-6 text-amber-900">This Settings control centre deliberately has no destructive production controls. It cannot reset data, change DNS, hosting, billing, infrastructure, HMS revenue records, commission rates, or WhatsApp activation. Revenue remains locked to <strong>Total Income × 75% × 3%</strong>.</p></div></div></section>
      </main>
    </div>
  </div>;
}
