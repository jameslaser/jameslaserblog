import {
  ArrowUpRight,
  Building2,
  CalendarDays,
  Check,
  Clock3,
  ExternalLink,
  Facebook,
  Ghost,
  Instagram,
  MapPin,
  MessageCircle,
  Music2,
  Phone,
  ShieldCheck,
  Twitter,
  Youtube,
  type LucideIcon,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import type { CSSProperties } from "react";

type Locale = "en" | "ar";

type PublicHomepageProps = {
  locale: Locale;
  onAppointmentClick?: () => void;
  onWhatsappClick?: () => void;
  onSocialClick?: (platform: string) => void;
  clinicNameHint?: string;
  fallbackAddressEn?: string;
  fallbackMapUrl?: string;
  locationActionLabel?: string;
};

const CONTROLLED_MACHINE_NAMES = ["DEKA AGAIN", "CLARITY 2", "GENTLE PROMAX", "DUETTO MACHINE"] as const;
const COPYRIGHT_YEAR = "2026";
const RIYADH_OFFSET_MS = 3 * 60 * 60 * 1000;
const ENGLISH_MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"] as const;
const ARABIC_MONTHS = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"] as const;

/**
 * Uses fixed Riyadh calendar math instead of host Intl output so SSR and the
 * first browser hydration render generate exactly the same blog-date text.
 */
export function formatRiyadhPublishedDate(value: Date | string, arabic: boolean) {
  const source = new Date(value);
  if (Number.isNaN(source.getTime())) return "";
  const riyadh = new Date(source.getTime() + RIYADH_OFFSET_MS);
  const day = riyadh.getUTCDate();
  const month = riyadh.getUTCMonth();
  const year = riyadh.getUTCFullYear();
  return arabic
    ? `${day} ${ARABIC_MONTHS[month]} ${year}`
    : `${ENGLISH_MONTHS[month]} ${day}, ${year}`;
}

export function toStableIsoTimestamp(value: Date | string) {
  const source = new Date(value);
  return Number.isNaN(source.getTime()) ? "" : source.toISOString();
}

const MACHINE_PRESENTATION: Record<(typeof CONTROLLED_MACHINE_NAMES)[number], {
  imageUrl?: string;
  descriptionEn: string;
  descriptionAr: string;
}> = {
  "DEKA AGAIN": {
    imageUrl: "/manus-storage/deka-again-riyadh-photo_ac4f0d6e.jpeg",
    descriptionEn: "A clinic laser platform with integrated cooling support for specialist-led treatment planning.",
    descriptionAr: "منصة ليزر في العيادة مع دعم تبريد مدمج ضمن خطة علاجية يشرف عليها المختص.",
  },
  "CLARITY 2": {
    descriptionEn: "An available clinic laser option selected only after the specialist reviews your treatment area and details.",
    descriptionAr: "خيار ليزر متاح في العيادة، ويُختار فقط بعد مراجعة المختص لمنطقة العلاج وتفاصيلك.",
  },
  "GENTLE PROMAX": {
    imageUrl: "/manus-storage/gentle-promax-riyadh-photo_30349ffb.jpeg",
    descriptionEn: "An advanced clinic laser platform with cooling support for a specialist-guided session.",
    descriptionAr: "منصة ليزر متقدمة في العيادة مع دعم تبريد لجلسة يشرف عليها المختص.",
  },
  "DUETTO MACHINE": {
    imageUrl: "/manus-storage/duetto-machine-riyadh-photo_03e9b4c8.jpeg",
    descriptionEn: "A versatile clinic laser platform considered for different hair patterns and skin tones after consultation.",
    descriptionAr: "منصة ليزر متعددة الاستخدامات تُؤخذ في الاعتبار لأنماط شعر ودرجات بشرة مختلفة بعد الاستشارة.",
  },
};

const fallbackAreas = [
  { key: "face-neck", en: "Face & neck", ar: "الوجه والرقبة", descriptionEn: "A focused discussion for the areas you would like to treat.", descriptionAr: "مناقشة مركزة للمناطق التي ترغب في علاجها." },
  { key: "chest-abdomen", en: "Chest & abdomen", ar: "الصدر والبطن", descriptionEn: "Plan the areas together around your preferences and timing.", descriptionAr: "نرتب المناطق معاً وفق تفضيلاتك وتوقيتك." },
  { key: "back-shoulders", en: "Back & shoulders", ar: "الظهر والأكتاف", descriptionEn: "Private, clinic-led planning for broader treatment areas.", descriptionAr: "تخطيط خاص بإشراف العيادة للمناطق الأوسع." },
  { key: "arms-hands", en: "Arms & hands", ar: "الذراعان واليدان", descriptionEn: "Clear information before you decide on your request.", descriptionAr: "معلومات واضحة قبل أن تقرر ما تطلبه." },
  { key: "legs", en: "Legs", ar: "الساقان", descriptionEn: "Include one area or several in the same private request.", descriptionAr: "أضف منطقة واحدة أو عدة مناطق في الطلب الخاص نفسه." },
  { key: "full-body", en: "Full body", ar: "الجسم الكامل", descriptionEn: "A consultation helps organise the conversation before treatment.", descriptionAr: "تساعد الاستشارة على تنظيم الحديث قبل العلاج." },
] as const;

function localized(en: string | null | undefined, ar: string | null | undefined, arabic: boolean) {
  return arabic ? ar || en || "" : en || ar || "";
}

function money(value: unknown) {
  return value === null || value === undefined || value === "" ? null : `SAR ${value}`;
}

function SectionKicker({ children, inverse = false }: { children: string; inverse?: boolean }) {
  return <p className={`premium-home__kicker${inverse ? " premium-home__kicker--inverse" : ""}`}><span aria-hidden="true" />{children}</p>;
}

export function PublicHomepage({
  locale,
  onAppointmentClick,
  onWhatsappClick,
  onSocialClick,
  clinicNameHint,
  fallbackAddressEn = "New Look Clinic, Al Sahafah, Riyadh, Saudi Arabia",
  fallbackMapUrl = "https://maps.app.goo.gl/LYx98uWLW8kHdsMv7?g_st=ic",
  locationActionLabel,
}: PublicHomepageProps) {
  const arabic = locale === "ar";
  const clinic = trpc.publicContent.clinicSettings.useQuery();
  const treatments = trpc.publicContent.treatments.useQuery();
  const machines = trpc.publicContent.machines.useQuery();
  const homepageSections = trpc.publicContent.homepageSections.useQuery();
  const guidePosts = trpc.publicContent.guidePosts.useQuery();
  const promotions = trpc.publicContent.promotions.useQuery();

  const heroContent = homepageSections.data?.find(section => section.sectionKey.toLowerCase() === "hero");
  const approachContent = homepageSections.data?.find(section => section.sectionKey.toLowerCase() === "approach");
  const prefix = arabic ? "/ar" : "/en";
  const requestPath = arabic ? "/ar/appointment" : "/appointment";
  const whatsappDigits = (clinic.data?.whatsapp || "+966557401562").replace(/\D/g, "");
  const whatsappLink = `https://wa.me/${whatsappDigits}`;
  const mapLink = clinic.data?.mapsUrl || fallbackMapUrl;
  const clinicName = clinic.data?.clinicName || clinicNameHint || "New Look Clinic";
  const address = localized(clinic.data?.addressEn || fallbackAddressEn, clinic.data?.addressAr, arabic);
  const professionalTitle = clinic.data?.professionalTitle || (arabic ? "أخصائي ليزر" : "Laser Specialist");
  const homepageTheme = clinic.data?.homepageTheme || "signature";
  const heroImageUrl = clinic.data?.homepageHeroImageUrl || null;
  const specialistImageUrl = clinic.data?.homepageSpecialistImageUrl || "/manus-storage/nurse-james-laser-hair-removal-specialist-riyadh_f79913ca.jpg";
  const clinicImageUrl = clinic.data?.homepageClinicImageUrl || "/manus-storage/male-laser-back-treatment_3bb98402.jpg";
  const exteriorImages = arabic ? [
    { src: "/manus-storage/public-home/exterior/IMG_6504_a7062d4c.jpeg", alt: "منظر واسع لواجهة مدخل العيادة في الرياض" },
    { src: "/manus-storage/public-home/exterior/IMG_6505_cd5a4964.jpeg", alt: "تفاصيل الواجهة الخارجية ومدخل العيادة" },
    { src: "/manus-storage/public-home/exterior/IMG_6506_674ddd0c.jpeg", alt: "تفاصيل أقرب لواجهة ومدخل العيادة" },
  ] : [
    { src: "/manus-storage/public-home/exterior/IMG_6504_a7062d4c.jpeg", alt: "Wide view of the clinic entrance exterior in Riyadh" },
    { src: "/manus-storage/public-home/exterior/IMG_6505_cd5a4964.jpeg", alt: "Clinic exterior and entrance detail" },
    { src: "/manus-storage/public-home/exterior/IMG_6506_674ddd0c.jpeg", alt: "Closer exterior detail of the clinic entrance" },
  ];

  const copy = arabic ? {
    heroKicker: "جيمس ليزر · الرياض",
    heroTitle: "إزالة الشعر بالليزر للرجال في الرياض",
    heroDescription: "عناية مهنية وخطة مدروسة تبدأ بمحادثة خاصة وواضحة حول المناطق التي تهمك.",
    request: "طلب موعد",
    whatsapp: "واتساب",
    trust: ["عناية احترافية", "تجربة خاصة", "تقنية ليزر حديثة"],
    introKicker: "نهج هادئ ومدروس",
    introTitle: "محادثة واضحة قبل كل خطوة.",
    introDescription: "نبدأ بما تريد مناقشته، ثم نراجع التفاصيل العملية معك قبل تأكيد أي موعد.",
    areasKicker: "مناطق العلاج",
    areasTitle: "اختر المناطق التي تريد مناقشتها.",
    areasDescription: "هذه الخدمات المنشورة من العيادة تساعدك على بدء طلب موعدك بصورة أوضح.",
    exploreAreas: "استكشف جميع مناطق العلاج",
    offersKicker: "عروض مختارة",
    offersTitle: "عروض منشورة ومعتمدة من العيادة.",
    offersDescription: "تظهر هنا العروض التي اختارت العيادة عرضها على الصفحة الرئيسية. تُراجع الملاءمة والتوفر بشكل منفصل.",
    viewOffers: "عرض جميع الأسعار والعروض",
    requestOffer: "اطلب موعداً",
    skinKicker: "البشرة والشعر",
    skinTitle: "تفاصيلك جزء من المحادثة.",
    skinDescription: "نناقش لون البشرة ونمط الشعر وسجل العلاج وتوقيت الجلسات أثناء الاستشارة. لا يمكن للصفحة أن تقرر الملاءمة أو الخطة العلاجية.",
    scaleLabel: "سُلّم توضيحي لألوان البشرة — ليس تشخيصاً أو توصية علاجية.",
    scaleStart: "درجات فاتحة",
    scaleEnd: "درجات داكنة",
    scaleExplanation: "وسيلة بصرية عامة للحوار فقط؛ يقدم فريق العيادة الإرشاد بعد الحديث معك.",
    technologyKicker: "التقنية المتاحة",
    technologyTitle: "الأجهزة التي نعرضها بشفافية.",
    technologyDescription: "توضح العيادة خيارات الأجهزة المتاحة. يراجع المختص المنطقة والتفاصيل المناسبة معك بدلاً من افتراض إعداد عبر الإنترنت.",
    technologyNote: "تختلف التقنية والإعدادات حسب الجهاز وخطة العيادة. لا تعيّن هذه الصفحة طولاً موجياً أو إعداداً علاجياً.",
    processKicker: "مسار الجلسة",
    processTitle: "خمس خطوات واضحة، من الطلب إلى المتابعة.",
    processSteps: [
      ["01", "اختر ما تريد مناقشته", "ابدأ بالمنطقة أو المناطق التي تهمك."],
      ["02", "أرسل طلباً خاصاً", "اختر الوقت المفضل وأدخل بيانات التواصل."],
      ["03", "تراجع العيادة الطلب", "يطلع الفريق على التفاصيل قبل تأكيد التوفر."],
      ["04", "نتواصل معك", "نؤكد الخطوة التالية أو نناقش وقتاً آخر."],
      ["05", "يُؤكد الموعد بشكل منفصل", "لا يصبح الموعد مؤكداً تلقائياً عند إرسال الطلب."],
    ],
    nurseKicker: "Nurse James",
    nurseTitle: "رعاية مهنية، ووقت كافٍ للأسئلة.",
    nurseDescription: "يوفر لك Nurse James مساحة لمناقشة المنطقة التي تهمك وتاريخ العلاج والتوقيت بصورة خاصة وواضحة.",
    blogKicker: "من المدونة",
    blogTitle: "إرشادات واضحة قبل أن تتخذ الخطوة التالية.",
    blogDescription: "مقالات مراجعة من العيادة حول التحضير والعناية اللاحقة ومناطق العلاج والتوقعات الواقعية.",
    readArticle: "اقرأ المقال",
    viewBlog: "عرض جميع المقالات",
    clinicKicker: "داخل العيادة",
    clinicTitle: "مساحة هادئة لمحادثة خاصة.",
    clinicDescription: "من الاستقبال إلى جلسة العلاج، صُممت الزيارة لتكون واضحة ومحترمة للخصوصية. الصور توضح بيئة العيادة وتفاصيل العلاج فقط.",
    exteriorKicker: "الوصول إلى العيادة",
    exteriorTitle: "صورة واضحة للموقع قبل زيارتك.",
    exteriorDescription: "اعرف واجهة المدخل قبل الوصول إلى العيادة في الرياض.",
    locationKicker: "الموقع والتواصل",
    locationTitle: "في الرياض، وبسيط الوصول إليه.",
    locationDescription: "افتح موقع العيادة أو تواصل مع الفريق بالطريقة التي تناسبك.",
    openMap: "فتح الخريطة",
    viewLocation: "عرض موقع عيادة نيو لوك",
    directions: "الاتجاهات",
    call: "اتصال بالعيادة",
    appointmentKicker: "طلب الموعد",
    appointmentTitle: "ثلاث خطوات لبدء طلبك الخاص.",
    appointmentSteps: [
      ["01", "أرسل تفضيلك", "اختر المنطقة والتاريخ والوقت المفضل."],
      ["02", "مراجعة خاصة", "يراجع فريق العيادة طلبك وتفاصيل التواصل."],
      ["03", "تأكيد منفصل", "نتصل بك لتأكيد التوفر والخطوة التالية."],
    ],
    finalKicker: "خذ الخطوة الأولى",
    finalTitle: "اطلب موعداً يناسبك.",
    finalDescription: "إرسال الطلب لا يعني أن الموعد أصبح مؤكداً. تؤكد العيادة التوفر معك بشكل منفصل.",
    footerNote: "عناية مهنية. تخطيط خاص. معلومات واضحة.",
    privacyPolicy: "سياسة الخصوصية",
    patientRights: "حقوق المريض والخصوصية",
    social: "تابع العيادة",
  } : {
    heroKicker: "James Laser · Riyadh",
    heroTitle: "Laser Hair Removal for Men in Riyadh",
    heroDescription: "Professional care and a considered plan, beginning with a private, straightforward conversation about the areas that matter to you.",
    request: "Request appointment",
    whatsapp: "WhatsApp",
    trust: ["Professional care", "Private experience", "Modern laser technology"],
    introKicker: "A considered approach",
    introTitle: "A clear conversation before every next step.",
    introDescription: "We begin with what you would like to discuss, then review the practical details with you before any appointment is confirmed.",
    areasKicker: "Treatment areas",
    areasTitle: "Choose the areas you would like to discuss.",
    areasDescription: "These clinic-published services help you start your appointment request with greater clarity.",
    exploreAreas: "Explore all treatment areas",
    offersKicker: "Selected offers",
    offersTitle: "Published, clinic-approved offers.",
    offersDescription: "Only offers selected by the clinic for the homepage appear here. Suitability and availability are reviewed separately.",
    viewOffers: "View all prices & offers",
    requestOffer: "Request appointment",
    skinKicker: "Skin & hair",
    skinTitle: "Your details are part of the conversation.",
    skinDescription: "Skin tone, hair pattern, treatment history and session timing can be discussed during a consultation. This page cannot determine suitability or a treatment plan.",
    scaleLabel: "Illustrative skin-tone scale — not a diagnosis or treatment recommendation.",
    scaleStart: "Lighter tones",
    scaleEnd: "Deeper tones",
    scaleExplanation: "A general visual discussion aid only; the clinic team provides guidance after speaking with you.",
    technologyKicker: "Available technology",
    technologyTitle: "The machines we present with clarity.",
    technologyDescription: "The clinic shows the available machine options. A specialist reviews the area and relevant details with you rather than assuming an online setting.",
    technologyNote: "Technology and settings vary by device and clinic plan. This page does not assign a wavelength or treatment setting.",
    processKicker: "Your treatment journey",
    processTitle: "Five clear steps, from request to follow-up.",
    processSteps: [
      ["01", "Choose what to discuss", "Start with the treatment area or areas that matter to you."],
      ["02", "Send a private request", "Choose a preferred time and share your contact details."],
      ["03", "The clinic reviews it", "The team reviews the request before confirming availability."],
      ["04", "We contact you", "We confirm the next step or discuss another time."],
      ["05", "Confirmation happens separately", "A request does not automatically confirm an appointment."],
    ],
    nurseKicker: "Nurse James",
    nurseTitle: "Professional care, with time for your questions.",
    nurseDescription: "Nurse James gives you space to discuss the area that matters to you, treatment history and timing in a private, straightforward way.",
    blogKicker: "From the blog",
    blogTitle: "Clear guidance before your next step.",
    blogDescription: "Clinic-reviewed articles covering preparation, aftercare, treatment areas, and realistic expectations.",
    readArticle: "Read article",
    viewBlog: "View all articles",
    clinicKicker: "Inside the clinic",
    clinicTitle: "A calm setting for a private conversation.",
    clinicDescription: "From reception to treatment, the visit is designed to feel clear and respectful of privacy. The photographs show the clinic environment and treatment detail only.",
    exteriorKicker: "Arriving at the clinic",
    exteriorTitle: "A clear view before your visit.",
    exteriorDescription: "Recognise the entrance before arriving at the clinic in Riyadh.",
    locationKicker: "Location & contact",
    locationTitle: "In Riyadh, straightforward to reach.",
    locationDescription: "Open the clinic location or contact the team in the way that works for you.",
    openMap: "Open map",
    viewLocation: "View New Look Clinic location",
    directions: "Directions",
    call: "Call the clinic",
    appointmentKicker: "Appointment request",
    appointmentTitle: "Three steps to start your private request.",
    appointmentSteps: [
      ["01", "Send your preference", "Choose the area, preferred date and time."],
      ["02", "Private review", "The clinic team reviews your request and contact details."],
      ["03", "Separate confirmation", "We contact you to confirm availability and the next step."],
    ],
    finalKicker: "Take the first step",
    finalTitle: "Request an appointment that works for you.",
    finalDescription: "Sending a request does not confirm an appointment. The clinic confirms availability with you separately.",
    footerNote: "Professional care. Private planning. Clear information.",
    privacyPolicy: "Privacy Policy",
    patientRights: "Patient Rights & Privacy",
    social: "Follow the clinic",
  };

  const areas = treatments.data?.length
    ? treatments.data.slice(0, 6).map(treatment => ({
        key: treatment.slug || String(treatment.id),
        title: localized(treatment.nameEn, treatment.nameAr, arabic),
        description: localized(treatment.shortDescriptionEn || treatment.descriptionEn, treatment.shortDescriptionAr || treatment.descriptionAr, arabic),
      }))
    : fallbackAreas.map(area => ({ key: area.key, title: arabic ? area.ar : area.en, description: arabic ? area.descriptionAr : area.descriptionEn }));

  const machineCards = CONTROLLED_MACHINE_NAMES.map(fallbackName => {
    const presentation = MACHINE_PRESENTATION[fallbackName];
    return {
      name: machines.data?.find(machine => machine.name === fallbackName)?.name || fallbackName,
      imageUrl: presentation.imageUrl,
      description: arabic ? presentation.descriptionAr : presentation.descriptionEn,
    };
  });
  const latestArticles = [...(guidePosts.data ?? [])]
    .sort((first, second) => Number(Boolean(second.isFeatured)) - Number(Boolean(first.isFeatured)))
    .map(article => ({
      ...article,
      title: localized(article.titleEn, article.titleAr, arabic),
      excerpt: localized(article.summaryEn, article.summaryAr, arabic),
      path: `${prefix}/blog/${encodeURIComponent(article.slug)}`,
      date: article.publishedAt ? formatRiyadhPublishedDate(article.publishedAt, arabic) : null,
      publishedAtIso: article.publishedAt ? toStableIsoTimestamp(article.publishedAt) : "",
    }))
    .filter(article => article.title && article.excerpt)
    .slice(0, 3);
  const featuredPromotions = (promotions.data ?? [])
    .filter(promotion => promotion.isFeatured)
    .slice(0, 2)
    .map(promotion => ({
      ...promotion,
      title: localized(promotion.titleEn, promotion.titleAr, arabic),
      description: localized(promotion.descriptionEn, promotion.descriptionAr, arabic),
      terms: localized(promotion.termsEn, promotion.termsAr, arabic),
    }));
  const socialLinks = [
    { label: "Instagram", href: clinic.data?.instagramUrl, Icon: Instagram },
    { label: "TikTok", href: clinic.data?.tiktokUrl, Icon: Music2 },
    { label: "Snapchat", href: clinic.data?.snapchatUrl, Icon: Ghost },
    { label: "Facebook", href: clinic.data?.facebookUrl, Icon: Facebook },
    { label: "YouTube", href: clinic.data?.youtubeUrl, Icon: Youtube },
    { label: "X", href: clinic.data?.xUrl, Icon: Twitter },
    { label: "Google Business", href: clinic.data?.googleBusinessUrl, Icon: Building2 },
  ].filter((link): link is { label: string; href: string; Icon: LucideIcon } => typeof link.href === "string" && link.href.trim().length > 0);

  // Keep the public search-facing headline stable; CMS hero copy continues to drive its supporting description.
  const heroTitle = copy.heroTitle;
  const heroDescription = localized(heroContent?.descriptionEn, heroContent?.descriptionAr, arabic) || copy.heroDescription;
  const introTitle = localized(approachContent?.titleEn, approachContent?.titleAr, arabic) || copy.introTitle;
  const introDescription = localized(approachContent?.descriptionEn, approachContent?.descriptionAr, arabic) || copy.introDescription;
  const mapEmbedUrl = `https://www.google.com/maps?q=${encodeURIComponent(address)}&output=embed`;

  return (
    <div className={`premium-home__appearance premium-home--theme-${homepageTheme}`}>
      <section id="top" className={`premium-home__hero${heroImageUrl ? " premium-home__hero--image" : ""}`} style={heroImageUrl ? ({ "--ph-hero-image": `url("${heroImageUrl}")` } as CSSProperties) : undefined} aria-labelledby="premium-home-title">
        <div className="premium-home__frame premium-home__hero-grid">
          <div className="premium-home__hero-copy">
            <SectionKicker inverse>{copy.heroKicker}</SectionKicker>
            <h1 id="premium-home-title">{heroTitle}</h1>
            <p className="premium-home__lede premium-home__lede--inverse">{heroDescription}</p>
            <div className="premium-home__actions">
              <a href={requestPath} onClick={onAppointmentClick} className="premium-home__button premium-home__button--copper">
                {copy.request}<ArrowUpRight aria-hidden="true" />
              </a>
              <a href={whatsappLink} target="_blank" rel="noreferrer" onClick={onWhatsappClick} className="premium-home__text-action premium-home__text-action--inverse">
                <MessageCircle aria-hidden="true" />{copy.whatsapp}<ArrowUpRight aria-hidden="true" />
              </a>
            </div>
          </div>
          <div className="premium-home__hero-aside" aria-label={arabic ? "معلومات عن نهج العيادة" : "Clinic approach information"}>
            <p>{arabic ? "طلب خاص" : "Private request"}</p>
            <strong>{arabic ? "تُراجع العيادة كل طلب قبل تأكيد التوفر." : "Every request is reviewed by the clinic before availability is confirmed."}</strong>
          </div>
        </div>
        <div className="premium-home__trust" aria-label={arabic ? "مزايا العيادة" : "Clinic qualities"}>
          <div className="premium-home__frame premium-home__trust-grid">
            {copy.trust.map(item => <p key={item}><Check aria-hidden="true" />{item}</p>)}
          </div>
        </div>
      </section>

      <section className="premium-home__section premium-home__section--paper" aria-labelledby="premium-home-introduction">
        <div className="premium-home__frame premium-home__intro-grid">
          <div><SectionKicker>{copy.introKicker}</SectionKicker></div>
          <div>
            <h2 id="premium-home-introduction">{introTitle}</h2>
            <p className="premium-home__lede">{introDescription}</p>
          </div>
        </div>
      </section>

      <section className="premium-home__section premium-home__section--warm" aria-labelledby="premium-home-areas">
        <div className="premium-home__frame">
          <div className="premium-home__section-heading">
            <div><SectionKicker>{copy.areasKicker}</SectionKicker><h2 id="premium-home-areas">{copy.areasTitle}</h2></div>
            <p>{copy.areasDescription}</p>
          </div>
          <div className="premium-home__areas-grid">
            {areas.map((area, index) => <article key={area.key} className="premium-home__area">
              <span>{String(index + 1).padStart(2, "0")}</span>
              <h3>{area.title}</h3>
              {area.description ? <p>{area.description}</p> : null}
            </article>)}
          </div>
          <a href={`${prefix}/treatments`} className="premium-home__text-action">{copy.exploreAreas}<ArrowUpRight aria-hidden="true" /></a>
        </div>
      </section>

      {featuredPromotions.length ? <section className="premium-home__section premium-home__section--paper" aria-labelledby="premium-home-offers">
        <div className="premium-home__frame">
          <div className="premium-home__section-heading">
            <div><SectionKicker>{copy.offersKicker}</SectionKicker><h2 id="premium-home-offers">{copy.offersTitle}</h2></div>
            <p>{copy.offersDescription}</p>
          </div>
          <div className="premium-home__offer-grid">
            {featuredPromotions.map(promotion => <article key={promotion.id} className="premium-home__offer-card">
              {promotion.imageUrl ? <img src={promotion.imageUrl} alt={promotion.title} loading="lazy" /> : null}
              <div className="premium-home__offer-copy"><p>{arabic ? "عرض منشور" : "Published offer"}</p><h3>{promotion.title}</h3>{promotion.description ? <p className="premium-home__offer-description">{promotion.description}</p> : null}<div className="premium-home__offer-details">{money(promotion.promotionalPrice) ? <strong>{money(promotion.promotionalPrice)}</strong> : null}{promotion.sessionCount ? <span>{promotion.sessionCount} {arabic ? "جلسات" : "sessions"}</span> : null}{promotion.retouchIncluded ? <span>{arabic ? "يشمل رتوش" : "Retouch included"}</span> : null}</div>{promotion.terms ? <p className="premium-home__offer-terms">{promotion.terms}</p> : null}<a href={requestPath} onClick={onAppointmentClick} className="premium-home__text-action">{copy.requestOffer}<ArrowUpRight aria-hidden="true" /></a></div>
            </article>)}
          </div>
          <a href={`${prefix}/offers`} className="premium-home__text-action premium-home__offers-link">{copy.viewOffers}<ArrowUpRight aria-hidden="true" /></a>
        </div>
      </section> : null}

      <section className="premium-home__section premium-home__section--paper" aria-labelledby="premium-home-skin">
        <div className="premium-home__frame premium-home__skin-grid">
          <div>
            <SectionKicker>{copy.skinKicker}</SectionKicker>
            <h2 id="premium-home-skin">{copy.skinTitle}</h2>
            <p className="premium-home__lede">{copy.skinDescription}</p>
          </div>
          <figure className="premium-home__skin-scale" aria-labelledby="skin-scale-label">
            <figcaption id="skin-scale-label">{copy.scaleLabel}</figcaption>
            <div className="premium-home__tone-bars" aria-hidden="true">
              <span /><span /><span /><span /><span /><span />
            </div>
            <div className="premium-home__scale-ends"><span>{copy.scaleStart}</span><span>{copy.scaleEnd}</span></div>
            <p>{copy.scaleExplanation}</p>
          </figure>
        </div>
      </section>

      <section className="premium-home__section premium-home__section--navy" aria-labelledby="premium-home-technology">
        <div className="premium-home__frame premium-home__technology-grid">
          <div>
            <SectionKicker inverse>{copy.technologyKicker}</SectionKicker>
            <h2 id="premium-home-technology">{copy.technologyTitle}</h2>
          </div>
          <p className="premium-home__lede premium-home__lede--inverse">{copy.technologyDescription}</p>
        </div>
        <div className="premium-home__frame premium-home__machine-grid" aria-label={arabic ? "أجهزة الليزر المتاحة" : "Available laser machines"}>
          {machineCards.map((machine, index) => <article key={machine.name} className={`premium-home__machine${machine.imageUrl ? " premium-home__machine--pictured" : ""}`}>
            <figure className={`premium-home__machine-media${machine.imageUrl ? "" : " premium-home__machine-media--placeholder"}`}>
              {machine.imageUrl ? <img src={machine.imageUrl} alt={arabic ? `جهاز ${machine.name} في العيادة` : `${machine.name} laser device at the clinic`} loading="lazy" /> : <span aria-hidden="true">C2</span>}
            </figure>
            <div className="premium-home__machine-copy"><span>{String(index + 1).padStart(2, "0")}</span><h3>{machine.name}</h3><p>{machine.description}</p></div>
          </article>)}
        </div>
        <p className="premium-home__frame premium-home__technology-note">{copy.technologyNote}</p>
      </section>

      <section className="premium-home__section premium-home__section--paper" aria-labelledby="premium-home-process">
        <div className="premium-home__frame">
          <div className="premium-home__section-heading premium-home__section-heading--stacked">
            <div><SectionKicker>{copy.processKicker}</SectionKicker><h2 id="premium-home-process">{copy.processTitle}</h2></div>
          </div>
          <ol className="premium-home__five-steps">
            {copy.processSteps.map(([number, title, description]) => <li key={number}><span>{number}</span><h3>{title}</h3><p>{description}</p></li>)}
          </ol>
        </div>
      </section>

      <section className="premium-home__section premium-home__section--warm" aria-labelledby="premium-home-nurse">
        <div className="premium-home__frame premium-home__image-feature">
          <figure><img src={specialistImageUrl} alt={arabic ? "Nurse James في بيئة العيادة" : "Nurse James in the clinic setting"} loading="lazy" /></figure>
          <div>
            <SectionKicker>{copy.nurseKicker}</SectionKicker>
            <p className="premium-home__role">{professionalTitle}</p>
            <h2 id="premium-home-nurse">{copy.nurseTitle}</h2>
            <p className="premium-home__lede">{copy.nurseDescription}</p>
            <a href={`${prefix}/blog`} className="premium-home__text-action">{arabic ? "اقرأ مدونة العيادة" : "Read the clinic blog"}<ArrowUpRight aria-hidden="true" /></a>
          </div>
        </div>
      </section>

      {latestArticles.length ? <section className="premium-home__section premium-home__section--paper" aria-labelledby="premium-home-blog">
        <div className="premium-home__frame">
          <div className="premium-home__section-heading">
            <div><SectionKicker>{copy.blogKicker}</SectionKicker><h2 id="premium-home-blog">{copy.blogTitle}</h2></div>
            <p>{copy.blogDescription}</p>
          </div>
          <div className="premium-home__blog-grid">
            {latestArticles.map((article, index) => <article key={article.id} className="premium-home__blog-card">
              <a href={article.path} className="premium-home__blog-media" aria-label={`${copy.readArticle}: ${article.title}`}>
                {article.featuredImageUrl ? <img src={article.featuredImageUrl} alt={localized(article.featuredImageAltEn, article.featuredImageAltAr, arabic) || article.title} loading="lazy" /> : <span aria-hidden="true">{String(index + 1).padStart(2, "0")}</span>}
              </a>
              <div className="premium-home__blog-copy">
                <div className="premium-home__blog-meta"><span>{article.category || (arabic ? "تثقيف المرضى" : "Patient education")}</span>{article.date && article.publishedAtIso ? <time dateTime={article.publishedAtIso}><CalendarDays aria-hidden="true" />{article.date}</time> : null}</div>
                <h3><a href={article.path}>{article.title}</a></h3>
                <p>{article.excerpt}</p>
                <a href={article.path} className="premium-home__text-action">{copy.readArticle}<ArrowUpRight aria-hidden="true" /></a>
              </div>
            </article>)}
          </div>
          <a href={`${prefix}/blog`} className="premium-home__button premium-home__button--copper premium-home__blog-all">{copy.viewBlog}<ArrowUpRight aria-hidden="true" /></a>
        </div>
      </section> : null}

      <section className="premium-home__section premium-home__section--paper" aria-labelledby="premium-home-clinic">
        <div className="premium-home__frame">
          <div className="premium-home__section-heading">
            <div><SectionKicker>{copy.clinicKicker}</SectionKicker><h2 id="premium-home-clinic">{copy.clinicTitle}</h2></div>
            <p>{copy.clinicDescription}</p>
          </div>
          <div className="premium-home__clinic-media">
            <figure className="premium-home__clinic-reception"><img src={clinicImageUrl} alt={arabic ? "تفاصيل من بيئة العيادة" : "Clinic environment detail"} loading="lazy" /></figure>
            <figure className="premium-home__clinic-treatment"><video controls playsInline preload="metadata" aria-label={arabic ? "فيديو جلسة ليزر للوجه للرجال" : "Men’s facial laser treatment video"} src="/manus-storage/james-laser-mens-facial-laser-hair-removal-riyadh_fb2a3e42.mp4" /></figure>
          </div>
        </div>
      </section>

      <section className="premium-home__section premium-home__section--warm" aria-labelledby="premium-home-exterior">
        <div className="premium-home__frame">
          <div className="premium-home__section-heading">
            <div><SectionKicker>{copy.exteriorKicker}</SectionKicker><h2 id="premium-home-exterior">{copy.exteriorTitle}</h2></div>
            <p>{copy.exteriorDescription}</p>
          </div>
          <div className="premium-home__exterior-grid">
            {exteriorImages.map(({ src, alt }) => <figure key={src}><img src={src} alt={alt} loading="lazy" /></figure>)}
          </div>
        </div>
      </section>

      <section className="premium-home__section premium-home__section--location" aria-labelledby="premium-home-location">
        <div className="premium-home__frame premium-home__location-grid">
          <div>
            <SectionKicker inverse>{copy.locationKicker}</SectionKicker>
            <h2 id="premium-home-location">{copy.locationTitle}</h2>
            <p className="premium-home__lede premium-home__lede--inverse">{copy.locationDescription}</p>
          </div>
          <div className="premium-home__location-panel">
            <p className="premium-home__map-label">{copy.viewLocation}</p>
            <iframe title={copy.viewLocation} src={mapEmbedUrl} loading="lazy" referrerPolicy="no-referrer-when-downgrade" className="premium-home__map-preview" />
          <address className="premium-home__location-details">
            <p><MapPin aria-hidden="true" />{clinicName}<br />{address}</p>
            <p><Clock3 aria-hidden="true" />{clinic.data?.workingHours || "1:00 PM – 10:00 PM"}</p>
            <div className="premium-home__actions">
              <a href={mapLink} target="_blank" rel="noreferrer" className="premium-home__button premium-home__button--light">{locationActionLabel || copy.openMap}<ExternalLink aria-hidden="true" /></a>
              <a href={mapLink} target="_blank" rel="noreferrer" className="premium-home__text-action premium-home__text-action--inverse"><MapPin aria-hidden="true" />{copy.directions}</a>
              <a href={whatsappLink} target="_blank" rel="noreferrer" onClick={onWhatsappClick} className="premium-home__text-action premium-home__text-action--inverse"><MessageCircle aria-hidden="true" />{copy.whatsapp}</a>
              {clinic.data?.telephone ? <a href={`tel:${clinic.data.telephone.replace(/\s/g, "")}`} className="premium-home__text-action premium-home__text-action--inverse"><Phone aria-hidden="true" />{copy.call}</a> : null}
            </div>
          </address>
          </div>
        </div>
      </section>

      <section className="premium-home__section premium-home__section--warm" aria-labelledby="premium-home-appointment">
        <div className="premium-home__frame">
          <div className="premium-home__section-heading premium-home__section-heading--stacked"><div><SectionKicker>{copy.appointmentKicker}</SectionKicker><h2 id="premium-home-appointment">{copy.appointmentTitle}</h2></div></div>
          <ol className="premium-home__appointment-steps">
            {copy.appointmentSteps.map(([number, title, description]) => <li key={number}><span>{number}</span><h3>{title}</h3><p>{description}</p></li>)}
          </ol>
        </div>
      </section>

      <section className="premium-home__final-cta" aria-labelledby="premium-home-final">
        <div className="premium-home__frame premium-home__final-grid">
          <div><SectionKicker inverse>{copy.finalKicker}</SectionKicker><h2 id="premium-home-final">{copy.finalTitle}</h2><p>{copy.finalDescription}</p></div>
          <div className="premium-home__actions">
            <a href={requestPath} onClick={onAppointmentClick} className="premium-home__button premium-home__button--copper">{copy.request}<ArrowUpRight aria-hidden="true" /></a>
            <a href={whatsappLink} target="_blank" rel="noreferrer" onClick={onWhatsappClick} className="premium-home__button premium-home__button--outline-light">{copy.whatsapp}<MessageCircle aria-hidden="true" /></a>
          </div>
        </div>
      </section>

      <footer className="premium-home__footer">
        <div className="premium-home__frame premium-home__footer-grid">
          <div><p className="premium-home__footer-brand"><span aria-hidden="true">JL</span>James Laser</p><p>{copy.footerNote}</p><div className="mt-3 flex flex-wrap gap-x-4 gap-y-2"><a href={arabic ? "/ar/policies/privacy-policy" : "/policies/privacy-policy"} className="premium-home__footer-policy">{copy.privacyPolicy}</a><a href={arabic ? "/ar/privacy-rights" : "/privacy-rights"} className="premium-home__footer-policy">{copy.patientRights}</a></div></div>
          <div><p>{clinicName}</p><p>{address}</p>{clinic.data?.email ? <a href={`mailto:${clinic.data.email}`}>{clinic.data.email}</a> : null}</div>
          {socialLinks.length ? <div><p>{copy.social}</p><nav aria-label={copy.social}>{socialLinks.map(({ label, href, Icon }) => <a key={label} href={href} target="_blank" rel="noopener noreferrer" aria-label={`${copy.social}: ${label}`} title={label} className="premium-home__social-link" onClick={() => onSocialClick?.(label)}><Icon aria-hidden="true" focusable="false" /><span>{label}</span></a>)}</nav></div> : null}
          <p className="premium-home__footer-copyright"><ShieldCheck aria-hidden="true" />© {COPYRIGHT_YEAR} James Laser</p>
        </div>
      </footer>
    </div>
  );
}

export default PublicHomepage;
