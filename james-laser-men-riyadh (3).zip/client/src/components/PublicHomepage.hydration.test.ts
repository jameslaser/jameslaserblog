import { describe, expect, it } from "vitest";
import {
  formatRiyadhPublishedDate,
  toStableIsoTimestamp,
} from "./PublicHomepage";

describe("PublicHomepage hydration-safe dates", () => {
  const crossingRiyadhMidnight = "2026-09-02T21:30:00.000Z";

  it("formats the same Riyadh calendar date without depending on host Intl output", () => {
    expect(formatRiyadhPublishedDate(crossingRiyadhMidnight, false)).toBe(
      "Sep 3, 2026"
    );
    expect(formatRiyadhPublishedDate(crossingRiyadhMidnight, true)).toBe(
      "3 سبتمبر 2026"
    );
  });

  it("renders stable ISO timestamps and safely ignores invalid values", () => {
    expect(toStableIsoTimestamp(crossingRiyadhMidnight)).toBe(
      crossingRiyadhMidnight
    );
    expect(formatRiyadhPublishedDate("not-a-date", false)).toBe("");
    expect(toStableIsoTimestamp("not-a-date")).toBe("");
  });
});
