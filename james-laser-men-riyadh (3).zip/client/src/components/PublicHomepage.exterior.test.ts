import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const source = readFileSync(resolve(process.cwd(), "client/src/components/PublicHomepage.tsx"), "utf8");

describe("public homepage clinic-exterior gallery", () => {
  it("uses all supplied exterior images with bilingual accessibility copy", () => {
    expect(source).toContain('/manus-storage/public-home/exterior/IMG_6504_a7062d4c.jpeg');
    expect(source).toContain('/manus-storage/public-home/exterior/IMG_6505_cd5a4964.jpeg');
    expect(source).toContain('/manus-storage/public-home/exterior/IMG_6506_674ddd0c.jpeg');
    expect(source).toContain('exteriorTitle: "A clear view before your visit."');
    expect(source).toContain('exteriorTitle: "صورة واضحة للموقع قبل زيارتك."');
    expect(source).toContain('className="premium-home__exterior-grid"');
  });
});
