import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ImagePlus, Loader2, Trash2 } from "lucide-react";
import { useRef } from "react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

const imageMimeTypes = ["image/jpeg", "image/png", "image/webp", "image/avif"] as const;
const maximumBytes = 10_000_000;

function toBase64(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("The image could not be read."));
    reader.onload = () => {
      const value = String(reader.result || "");
      const marker = value.indexOf(",");
      resolve(marker >= 0 ? value.slice(marker + 1) : value);
    };
    reader.readAsDataURL(file);
  });
}

export function CmsImageUploadField({ label, value, onChange, altEn, altAr }: { label: string; value: string; onChange: (url: string) => void; altEn?: string; altAr?: string }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const upload = trpc.cms.uploadMedia.useMutation({
    onSuccess: result => {
      onChange(result.url);
      toast.success(`${label} uploaded to the protected media library.`);
    },
    onError: error => toast.error(error.message),
  });

  const chooseFile = async (file: File | undefined) => {
    if (!file) return;
    if (!imageMimeTypes.includes(file.type as (typeof imageMimeTypes)[number])) {
      toast.error("Choose a JPEG, PNG, WebP, or AVIF image.");
      return;
    }
    if (file.size > maximumBytes) {
      toast.error("Images must be smaller than 10 MB.");
      return;
    }
    try {
      const dataBase64 = await toBase64(file);
      upload.mutate({ fileName: file.name, mimeType: file.type as (typeof imageMimeTypes)[number], dataBase64, altEn: altEn?.trim() || null, altAr: altAr?.trim() || null });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "The image could not be prepared.");
    } finally {
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  return <section className="grid gap-3 border border-dashed border-[#102032]/20 bg-[#fdfaf5] p-4 sm:col-span-2"><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="text-xs font-bold text-[#102032]">{label}</p><p className="mt-1 text-xs leading-5 text-[#66727A]">Upload JPEG, PNG, WebP, or AVIF up to 10 MB. A media-library reference is saved; no image URL needs to be entered.</p></div>{value ? <Button type="button" size="sm" variant="outline" className="text-red-700" onClick={() => onChange("")}><Trash2 className="mr-1 size-4" />Remove</Button> : null}</div><Input ref={inputRef} type="file" accept="image/jpeg,image/png,image/webp,image/avif" className="sr-only" aria-label={label} onChange={event => void chooseFile(event.target.files?.[0])} />{value ? <img src={value} alt="" className="max-h-64 w-full border border-[#102032]/10 bg-white object-contain" /> : <div className="grid min-h-28 place-items-center border border-[#102032]/10 bg-white text-sm text-[#66727A]">No image uploaded</div>}<div className="flex flex-wrap items-center gap-3"><Button type="button" variant="outline" disabled={upload.isPending} onClick={() => inputRef.current?.click()}>{upload.isPending ? <Loader2 className="mr-2 size-4 animate-spin" /> : <ImagePlus className="mr-2 size-4" />}{value ? "Replace image" : "Upload image"}</Button>{upload.isPending ? <span className="text-xs font-semibold text-[#66727A]">Uploading securely…</span> : null}</div></section>;
}
