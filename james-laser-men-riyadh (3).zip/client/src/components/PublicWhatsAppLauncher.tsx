import { MessageCircle } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { whatsappUrl } from "@/lib/whatsapp";

export function PublicWhatsAppLauncher() {
  const [path] = useLocation();
  const clinic = trpc.publicContent.clinicSettings.useQuery();
  const privateOrDedicatedRoute = path.startsWith("/admin") || path.startsWith("/sign-consent") || /(^|\/)whatsapp$/.test(path);
  if (privateOrDedicatedRoute) return null;

  return <a href={whatsappUrl(clinic.data?.whatsapp || "+966557401562")} target="_blank" rel="noreferrer" aria-label="Open WhatsApp with James Laser" className="fixed bottom-24 right-4 z-40 inline-flex min-h-12 items-center gap-2 rounded-full bg-[#25D366] px-4 text-sm font-extrabold text-[#092A16] shadow-[0_14px_32px_rgba(16,32,50,0.24)] transition duration-200 ease-out hover:-translate-y-0.5 hover:bg-[#35e576] active:scale-[0.97] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#102032] sm:bottom-6 sm:right-6">
    <MessageCircle className="size-5" aria-hidden="true" />
    <span>WhatsApp</span>
  </a>;
}
