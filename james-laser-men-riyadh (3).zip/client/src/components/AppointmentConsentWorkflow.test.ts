// @vitest-environment jsdom
import { createElement } from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import AppointmentConsentWorkflow from "./AppointmentConsentWorkflow";

const baseProps = {
  locale: "en" as const,
  signerName: "Test Client",
  readComplete: false,
  acknowledgement: false,
  signatureDataUrl: "",
  onReadComplete: vi.fn(),
  onAcknowledgementChange: vi.fn(),
  onSignatureChange: vi.fn(),
};

describe("AppointmentConsentWorkflow", () => {
  it("tracks each original form when it is opened without changing the review gate", () => {
    render(createElement(AppointmentConsentWorkflow, baseProps));

    expect(screen.getByTestId("opened-consent-progress").textContent).toContain("Opened 0 of 3 original forms.");
    expect(screen.getByTestId("consent-document-waiver-status").textContent).toContain("Not opened");

    fireEvent.click(screen.getAllByRole("link", { name: "Open original" })[0]!);

    expect(screen.getByTestId("opened-consent-progress").textContent).toContain("Opened 1 of 3 original forms.");
    expect(screen.getByTestId("consent-document-waiver-status").textContent).toContain("Opened");
    expect(screen.getByRole("link", { name: "Open again" })).toBeTruthy();
    expect((screen.getByLabelText(/I confirm that I have read and understood/) as HTMLInputElement).disabled).toBe(true);
  });

  it("shows a persistent next-step confirmation when a signature is present", () => {
    render(createElement(AppointmentConsentWorkflow, {
      ...baseProps,
      readComplete: true,
      acknowledgement: true,
      signatureDataUrl: "data:image/png;base64,AA==",
    }));

    expect(screen.getByTestId("appointment-signature-confirmation").textContent).toContain("Signature captured");
    expect(screen.getByTestId("appointment-signature-confirmation").textContent).toContain("select Request Appointment to continue");
  });
});
