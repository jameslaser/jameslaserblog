import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { translateAdminText } from "@/contexts/AdminLocaleContext";

const read = (file: string) => fs.readFileSync(path.resolve(process.cwd(), file), "utf8");
const shell = read("client/src/components/DashboardLayout.tsx");
const css = read("client/src/index.css");
const portal = read("client/src/pages/AdminPortal.tsx");
const cms = read("client/src/pages/CmsManager.tsx");
const whatsapp = read("client/src/pages/WhatsAppWorkspace.tsx");

describe("authenticated bilingual responsive evidence", () => {
  it("preserves English UI text and returns exact approved Arabic presentation copy", () => {
    expect(translateAdminText("Last sign-in", "en")).toBe("Last sign-in");
    expect(translateAdminText("Last sign-in", "ar")).toBe("آخر تسجيل دخول");
    expect(translateAdminText("Available request days", "ar")).toBe("أيام الطلب المتاحة");
    expect(translateAdminText("Waiting list unavailable", "ar")).toBe("قائمة الانتظار غير متاحة");
    expect(translateAdminText("Automation workspace unavailable", "ar")).toBe("مساحة عمل الأتمتة غير متاحة");
    expect(translateAdminText("Owner", "ar")).toBe("المالك");
  });

  it("provides a role-filtered mobile shell with safe-area and touch-target rules", () => {
    expect(shell).toContain('className="mobile-bottom-nav md:hidden"');
    expect(shell).toContain("mobilePrimary");
    expect(shell).toContain("aria-label={copy.primaryNavigation}");
    expect(shell).toContain("aria-label={copy.openAllSections}");
    expect(css).toContain("env(safe-area-inset-bottom)");
    expect(css).toContain("min-height: 2.75rem");
    expect(css).toContain("overflow-x: clip");
  });

  it("mirrors the authenticated shell and isolates directional record fields in Arabic", () => {
    expect(shell).toContain('side={isArabic ? "right" : "left"}');
    expect(shell).toContain('dir={isArabic ? "rtl" : "ltr"}');
    expect(css).toContain('.admin-portal[dir="rtl"]');
    expect(css).toContain('input[type="tel"]');
    expect(css).toContain("unicode-bidi: isolate");
    expect(css).toContain("text-align: right");
  });

  it("localizes static interface text without translating protected record values", () => {
    expect(cms).toContain("translateAdminText(\"Last sign-in\", locale)");
    expect(cms).toContain("data-admin-no-translate>{user.name");
    expect(cms).toContain("data-admin-no-translate>{user.email");
    expect(portal).toContain("data-admin-no-translate>{machine.name}");
    expect(whatsapp).toContain("data-admin-no-translate");
  });

  it("keeps responsive tables, tabs, dialogs, statuses, and form errors inspectable", () => {
    expect(css).toContain("scroll-snap-type: x proximity");
    expect(css).toContain('[role="dialog"]');
    expect(css).toContain('[aria-invalid="true"]');
    expect(css).toContain('[data-slot="badge"]');
    expect(css).toContain(".overflow-x-auto");
  });
});
