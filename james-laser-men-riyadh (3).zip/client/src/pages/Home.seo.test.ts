import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const home = readFileSync(resolve(process.cwd(), "client/src/pages/Home.tsx"), "utf8");
const app = readFileSync(resolve(process.cwd(), "client/src/App.tsx"), "utf8");
const registry = readFileSync(resolve(process.cwd(), "client/src/ssr/prefetch.ts"), "utf8");
const server = readFileSync(resolve(process.cwd(), "server/_core/vite.ts"), "utf8");

describe("Home public SEO metadata", () => {
  it("server-renders a focused homepage title and description instead of a shared SPA shell", () => {
    expect(registry).toContain('title: "Men’s Laser Hair Removal in Riyadh | New Look Clinic"');
    expect(registry).toContain("Professional men’s laser hair removal in Al Sahafah, Riyadh");
    expect(server).toContain('<!--app-head-->');
    expect(server).toContain('<!--app-html-->');
  });

  it("keeps browser-rendered language alternatives aligned to the canonical public origin", () => {
    expect(home).toContain('import { publicUrl } from "@/seo";');
    expect(home).toContain('setAlternate(`${origin}/`, "en");');
    expect(home).toContain('setAlternate(`${origin}/ar`, "ar-SA");');
    expect(home).toContain('setAlternate(`${origin}/`, "x-default");');
  });

  it("restores indexability only for known public routes after client navigation", () => {
    expect(app).toContain("function PublicCrawlDirective()");
    expect(app).toContain("index, follow, max-image-preview:large");
    expect(app).toContain('path === "/appointment"');
    expect(app).not.toContain('/^(en|ar)\\/guide\\/[^/]+$/.test(path)');
  });
});
