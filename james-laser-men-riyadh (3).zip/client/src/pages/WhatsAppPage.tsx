import { QRCodeSVG } from "qrcode.react";
import { type FormEvent, useEffect, useMemo, useRef, useState } from "react";
import { ArrowLeft, ArrowRight, ArrowUpRight, CalendarDays, CheckCircle2, Clock3, ExternalLink, MapPin, MessageCircle, Phone, ShieldCheck, TriangleAlert } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { availabilityWhatsAppMessage, callbackWhatsAppMessage, generalInquiryWhatsAppMessage, quickWhatsAppMessage, whatsappUrl, type WhatsAppLocale } from "@/lib/whatsapp";
import { publicUrl } from "@/seo";
import { ORIGINAL_CONSENT_DOCUMENTS } from "@shared/originalConsent";
import { allAppointmentAreas } from "./AppointmentRequest";
import { PublicSiteHeader } from "@/components/PublicSiteHeader";

const timeOptions = Array.from({ length: 37 }, (_, index) => {
  const totalMinutes = 13 * 60 + index * 15;
  const hour = Math.floor(totalMinutes / 60);
  const minute = totalMinutes % 60;
  const value = `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
  const displayHour = hour > 12 ? hour - 12 : hour;
  return { value, en: `${displayHour}:${String(minute).padStart(2, "0")} PM`, ar: `${displayHour}:${String(minute).padStart(2, "0")} م` };
});

type ActionKind = "service" | "prices" | "availability" | "callback" | "general" | "appointment";
type AppointmentSuccess = { requestId: string } | null;
type AppointmentTreatment = (typeof allAppointmentAreas)[number];

function riyadhToday() {
  return new Intl.DateTimeFormat("sv-SE", { timeZone: "Asia/Riyadh", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
}

function createSubmissionId() {
  if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID();
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, character => {
    const random = Math.floor(Math.random() * 16);
    return (character === "x" ? random : (random & 0x3) | 0x8).toString(16);
  });
}

function Copy({ locale }: { locale: WhatsAppLocale }) {
  const arabic = locale === "ar";
  return {
    arabic,
    prefix: arabic ? "/ar" : "/en",
    languagePath: arabic ? "/en/whatsapp" : "/ar/whatsapp",
    title: arabic ? "واتساب جيمس ليزر | تواصل مع العيادة في الرياض" : "WhatsApp James Laser | Contact the Clinic in Riyadh",
    description: arabic ? "تواصل مع جيمس ليزر في الرياض عبر واتساب للاستفسار عن الخدمات وطلب موعدك المفضل بصورة خاصة." : "Contact James Laser in Riyadh by WhatsApp for services, availability, and a private appointment request.",
    eyebrow: arabic ? "تواصل مباشر · نيو لوك كلينيك · الرياض" : "Direct clinic communication · New Look Clinic · Riyadh",
    heading: arabic ? "ابدأ محادثتك مع العيادة بوضوح وخصوصية." : "Start a clear, private conversation with the clinic.",
    body: arabic ? "اختر سبب التواصل، ثم افتح واتساب بالرسالة المناسبة. لا يتم تأكيد أي موعد تلقائيًا؛ تؤكد العيادة التوفر والخطوة التالية بشكل منفصل." : "Choose the reason for contact, then open WhatsApp with the right message. No appointment is confirmed automatically; the clinic confirms availability and next steps separately.",
    primary: arabic ? "فتح واتساب" : "Open WhatsApp",
    call: arabic ? "اتصال بالعيادة" : "Call the clinic",
    optionsTitle: arabic ? "كيف يمكننا مساعدتك؟" : "How can we help?",
    optionsBody: arabic ? "اختر مسارًا بسيطًا. لن يتم إنشاء سجل موعد أو مريض إلا عند إرسال طلب الموعد الخاص أدناه." : "Choose a simple route. No appointment or patient record is created unless you send the private appointment request below.",
    service: arabic ? "سؤال عن خدمة" : "Ask about a service",
    serviceBody: arabic ? "استفسر عن مناطق العلاج والخدمات المنشورة." : "Ask about treatment areas and published services.",
    prices: arabic ? "الأسعار والعروض" : "Prices & offers",
    pricesBody: arabic ? "استفسر عن الأسعار والعروض المنشورة حاليًا." : "Ask about current published prices and offers.",
    availability: arabic ? "التحقق من التوفر" : "Check availability",
    availabilityBody: arabic ? "شارك تفضيلك ليُراجع من قبل فريق العيادة." : "Share a preference for clinic review.",
    callback: arabic ? "طلب معاودة الاتصال" : "Request a callback",
    callbackBody: arabic ? "اختر فترة مناسبة ضمن ساعات العمل." : "Choose a suitable period within working hours.",
    general: arabic ? "استفسار عام" : "General enquiry",
    generalBody: arabic ? "أرسل سؤالك العام مباشرة عبر واتساب." : "Send a general question directly by WhatsApp.",
    appointment: arabic ? "طلب موعد خاص" : "Private appointment request",
    appointmentOptionBody: arabic ? "أرسل طلب موعد للمراجعة الخاصة من قبل العيادة." : "Send an appointment request for private clinic review.",
    serviceFormTitle: arabic ? "سؤال عن الخدمات" : "Service question",
    serviceFormBody: arabic ? "سيتم فتح واتساب برسالة استفسار عامة. يمكنك إضافة تفاصيلك داخل واتساب إذا رغبت." : "WhatsApp will open with a general service enquiry. You may add details there if you choose.",
    availabilityTitle: arabic ? "التحقق من التوفر" : "Check preferred availability",
    availabilityNotice: arabic ? "هذا ليس تأكيدًا للموعد. التوفر وتوقيت العلاج يراجعان من قبل العيادة." : "This does not confirm an appointment. Availability and treatment timing are reviewed by the clinic.",
    callbackTitle: arabic ? "طلب معاودة الاتصال" : "Request a callback",
    generalTitle: arabic ? "استفسار عام" : "General enquiry",
    appointmentTitle: arabic ? "إرسال طلب موعد" : "Send an appointment request",
    appointmentBody: arabic ? "يُرسل هذا النموذج إلى قائمة طلبات المواعيد الخاصة بالعيادة. لا يظهر في المواعيد المؤكدة إلا بعد مراجعة واعتماد صريح من الموظف المخول." : "This form is sent to the clinic’s private appointment-request queue. It never appears in confirmed appointments until an authorized staff member reviews and explicitly approves it.",
    appointmentPaused: arabic ? "طلبات المواعيد متوقفة مؤقتًا. يمكنك التواصل مع العيادة عبر واتساب." : "Appointment requests are temporarily paused. You can still contact the clinic via WhatsApp.",
    name: arabic ? "الاسم الكامل" : "Full name",
    mobile: arabic ? "رقم الجوال / واتساب" : "Mobile / WhatsApp number",
    date: arabic ? "التاريخ المفضل" : "Preferred date",
    time: arabic ? "الوقت المفضل" : "Preferred time",
    treatment: arabic ? "منطقة العلاج" : "Treatment area",
    visit: arabic ? "نوع الزيارة" : "Visit type",
    session: arabic ? "جلسة" : "Session",
    retouch: arabic ? "رتوش" : "Retouch",
    period: arabic ? "فترة الاتصال المفضلة" : "Preferred callback period",
    message: arabic ? "رسالتك" : "Your message",
    choose: arabic ? "اختر" : "Select",
    consent: arabic ? "أفهم أن الضغط على الزر يفتح تطبيق واتساب الحقيقي، وأنني أتحكم بالمعلومات التي أرسلها هناك." : "I understand that this button opens the real WhatsApp service and that I control the information I send there.",
    appointmentAcknowledgement: arabic ? "أفهم أن هذا طلب موعد فقط؛ لا يصبح التاريخ والوقت مؤكدين حتى تتواصل العيادة معي وتؤكد التوفر." : "I understand this is an appointment request only; the date and time are not confirmed until the clinic contacts me and confirms availability.",
    privacy: arabic ? "أوافق على استخدام تفاصيل هذا الطلب فقط لمراجعته والرد عليه وفق سياسة الخصوصية." : "I agree that these request details may be used only to review and respond to this request under the Privacy Policy.",
    originalConsent: arabic ? "نماذج الموافقة الأصلية" : "Original consent documents",
    consentHelp: arabic ? "افتح نماذج الموافقة الأصلية الثلاثة قبل تأكيد قراءتها. لا تغيّر هذه الصفحة النماذج أو تحل محل أي توقيع مطلوب." : "Open the three original consent forms before confirming you read them. This page does not change those forms or replace any required signature.",
    consentOpened: arabic ? "تم فتح جميع النماذج الأصلية" : "All original forms opened",
    consentRequired: arabic ? "افتح جميع النماذج الأصلية أولًا." : "Open all original forms first.",
    consentAcknowledgement: arabic ? "أؤكد أنني فتحت وقرأت نماذج الموافقة الأصلية." : "I confirm that I opened and read the original consent documents.",
    submit: arabic ? "إرسال طلب الموعد" : "Send appointment request",
    submitting: arabic ? "جارٍ إرسال الطلب…" : "Sending request…",
    successTitle: arabic ? "تم استلام طلبك" : "Your request was received",
    successBody: arabic ? "سيُراجع فريق العيادة طلبك بشكل خاص ويتواصل معك لتأكيد التوفر. لا يوجد موعد مؤكد حتى الآن." : "The clinic team will review your request privately and contact you to confirm availability. There is no confirmed appointment yet.",
    request: arabic ? "رقم الطلب" : "Request number",
    sendSummary: arabic ? "فتح واتساب مع رقم الطلب" : "Open WhatsApp with request number",
    formRequired: arabic ? "يرجى تعبئة الحقول والموافقات المطلوبة." : "Complete the required fields and acknowledgements.",
    workingHours: arabic ? "ساعات العمل" : "Working hours",
    location: arabic ? "الموقع" : "Location",
    emergency: arabic ? "هذه الصفحة ليست لخدمات الطوارئ أو المشكلات الطبية العاجلة. في حال الطوارئ، اتصل بخدمات الطوارئ المحلية أو توجه إلى أقرب قسم طوارئ." : "This page is not for emergencies or urgent medical concerns. In an emergency, contact local emergency services or go to the nearest emergency department.",
    privacyTitle: arabic ? "خصوصيتك" : "Your privacy",
    privacyBody: arabic ? "تُستخدم البيانات التي ترسلها عبر طلب الموعد فقط للتواصل والمراجعة. لا تضع أرقام الهوية أو معلومات الدفع أو التقارير الطبية أو كلمات المرور في واتساب أو في هذا النموذج." : "Details sent through the appointment request are used only for contact and review. Do not put ID numbers, payment details, medical reports, or passwords in WhatsApp or this form.",
    qrTitle: arabic ? "امسح رمز واتساب" : "Scan the WhatsApp code",
    qrBody: arabic ? "للاستخدام على جهاز آخر. يفتح الرمز رابط واتساب الرسمي للعيادة فقط." : "For use on another device. This code opens only the clinic’s official WhatsApp link.",
    fallback: arabic ? "إذا لم يفتح واتساب، استخدم الرقم المنشور أو اتصل بالعيادة خلال ساعات العمل." : "If WhatsApp does not open, use the published number or call the clinic during working hours.",
    openForm: arabic ? "فتح النموذج" : "Open form",
    backHome: arabic ? "العودة للرئيسية" : "Back to home",
  } as const;
}

function FormField({ label, children, required }: { label: string; children: React.ReactNode; required?: boolean }) {
  return <label className="grid gap-1.5 text-xs font-bold text-[#102032]"><span>{label}{required ? <span className="text-[#B85E3C]"> *</span> : null}</span>{children}</label>;
}

function ActionButton({ href, enabled, onClick, children, fallbackTelephone }: { href: string; enabled: boolean; onClick?: () => void; children: React.ReactNode; fallbackTelephone?: string | null }) {
  const arabic = typeof document !== "undefined" && document.documentElement.lang.startsWith("ar");
  const incompleteMessage = arabic ? "أكمل الحقول المطلوبة ووافق قبل فتح واتساب." : "Complete the required fields and acknowledgement before opening WhatsApp.";
  const reopenLabel = arabic ? "إعادة فتح واتساب" : "Open WhatsApp again";
  const callLabel = arabic ? "اتصال بالعيادة" : "Call the clinic";
  const telephoneHref = fallbackTelephone ? `tel:${fallbackTelephone.replace(/\s/g, "")}` : null;
  if (!enabled) return <div><p id="whatsapp-required-fields" role="status" className="mb-3 text-sm font-semibold text-[#B85E3C]">{incompleteMessage}</p><button type="button" disabled aria-describedby="whatsapp-required-fields" className="inline-flex min-h-11 w-full cursor-not-allowed items-center justify-center gap-2 bg-[#102032]/35 px-4 text-[11px] font-extrabold uppercase tracking-[0.12em] text-white">{children}</button></div>;
  return <div><a href={href} target="_blank" rel="noreferrer" onClick={onClick} className="inline-flex min-h-11 w-full items-center justify-center gap-2 bg-[#102032] px-4 text-[11px] font-extrabold uppercase tracking-[0.12em] text-white transition duration-200 ease-out hover:bg-[#B85E3C] active:scale-[0.97] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#102032]">{children}<ArrowUpRight className="size-4" /></a><div className="mt-3 flex flex-wrap gap-2 text-[11px] font-bold"><a href={href} target="_blank" rel="noreferrer" className="underline underline-offset-4">{reopenLabel}</a>{telephoneHref ? <a href={telephoneHref} className="underline underline-offset-4">{callLabel}</a> : null}</div></div>;
}

export default function WhatsAppPage({ locale = "en" }: { locale?: WhatsAppLocale }) {
  const t = Copy({ locale });
  const clinic = trpc.publicContent.clinicSettings.useQuery();
  const treatments = trpc.publicContent.treatments.useQuery();
  const analytics = trpc.analytics.record.useMutation();
  const [clientSubmissionId] = useState(createSubmissionId);
  const submissionLock = useRef(false);
  const [hasStartedAppointmentRequest, setHasStartedAppointmentRequest] = useState(false);
  const [active, setActive] = useState<ActionKind>("service");
  const [availability, setAvailability] = useState<{ date: string; time: string; treatment: AppointmentTreatment | "" }>({ date: riyadhToday(), time: "", treatment: "" });
  const [availabilityConsent, setAvailabilityConsent] = useState(false);
  const [callback, setCallback] = useState({ name: "", mobile: "+966 ", callbackPeriod: locale === "ar" ? "من 1:00 ظهرًا إلى 5:00 مساءً" : "1:00 PM–5:00 PM" });
  const [callbackConsent, setCallbackConsent] = useState(false);
  const [general, setGeneral] = useState({ name: "", message: "" });
  const [generalConsent, setGeneralConsent] = useState(false);
  const [appointment, setAppointment] = useState<{ name: string; mobile: string; date: string; time: string; treatment: AppointmentTreatment | ""; visitType: "session" | "retouch"; consentRead: boolean; appointmentAcknowledgement: boolean; privacy: boolean; website: string }>({ name: "", mobile: "+966 ", date: riyadhToday(), time: "", treatment: "", visitType: "session", consentRead: false, appointmentAcknowledgement: false, privacy: false, website: "" });
  const [openedConsentIds, setOpenedConsentIds] = useState<string[]>([]);
  const [appointmentError, setAppointmentError] = useState("");
  const [appointmentSuccess, setAppointmentSuccess] = useState<AppointmentSuccess>(null);
  const source = locale === "ar" ? "whatsapp_page_ar" : "whatsapp_page_en";
  const pagePath = locale === "ar" ? "/ar/whatsapp" : "/whatsapp";
  const clinicNumber = clinic.data?.whatsapp || "+966557401562";
  const primaryUrl = whatsappUrl(clinicNumber);
  const configuredTimes = useMemo(() => {
    const selected = clinic.data?.preferredTimes?.split(",").map(value => value.trim()).filter(Boolean) ?? [];
    return selected.length ? timeOptions.filter(time => selected.includes(time.value)) : timeOptions;
  }, [clinic.data?.preferredTimes]);
  const configuredAreas = useMemo(() => {
    const selected = clinic.data?.appointmentTreatmentOptions?.split(",").map(value => value.trim()).filter(Boolean) ?? [];
    return selected.length ? allAppointmentAreas.filter(area => selected.includes(area)) : allAppointmentAreas;
  }, [clinic.data?.appointmentTreatmentOptions]);
  const configuredVisitTypes = useMemo<Array<"session" | "retouch">>(() => {
    const selected = clinic.data?.visitTypeOptions?.split(",").map(value => value.trim()) ?? [];
    const valid = selected.filter((value): value is "session" | "retouch" => value === "session" || value === "retouch");
    return valid.length ? valid : ["session", "retouch"];
  }, [clinic.data?.visitTypeOptions]);
  const appointmentPaused = clinic.data?.appointmentFormEnabled === false || clinic.data?.maintenanceMode === true;
  const allConsentOpened = openedConsentIds.length === ORIGINAL_CONSENT_DOCUMENTS.length;
  const canTrack = !import.meta.env.DEV;
  const track = (eventType: "page_view" | "whatsapp_click" | "appointment_form_start" | "appointment_form_submit", action: string) => {
    if (!canTrack) return;
    analytics.mutate({ eventType, path: pagePath, locale: locale === "ar" ? "ar-SA" : "en", source: window.location.hostname, deviceType: window.matchMedia("(max-width: 767px)").matches ? "mobile" : "desktop", treatmentSlug: null, contentSlug: action });
  };
  const appointmentMutation = trpc.appointmentRequest.create.useMutation({
    onSuccess: data => { submissionLock.current = true; setAppointmentSuccess({ requestId: data.requestId }); setAppointmentError(""); track("appointment_form_submit", "private-appointment-request"); },
    onError: error => { submissionLock.current = false; setAppointmentError(error.message || t.formRequired); },
  });

  useEffect(() => {
    const html = document.documentElement;
    const priorLang = html.lang;
    const priorDir = html.dir;
    html.lang = locale === "ar" ? "ar" : "en";
    html.dir = t.arabic ? "rtl" : "ltr";
    document.title = t.title;
    const setMeta = (name: string, value: string) => { let node = document.querySelector(`meta[name="${name}"]`) as HTMLMetaElement | null; if (!node) { node = document.createElement("meta"); node.name = name; document.head.appendChild(node); } node.content = value; };
    const setProperty = (property: string, value: string) => { let node = document.querySelector(`meta[property="${property}"]`) as HTMLMetaElement | null; if (!node) { node = document.createElement("meta"); node.setAttribute("property", property); document.head.appendChild(node); } node.content = value; };
    const setLink = (hrefLang: string, href: string) => { let node = Array.from(document.querySelectorAll('link[rel="alternate"]')).find(link => link.getAttribute("hreflang") === hrefLang) as HTMLLinkElement | undefined; if (!node) { node = document.createElement("link"); node.rel = "alternate"; node.hreflang = hrefLang; document.head.appendChild(node); } node.href = href; };
    const canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null || document.head.appendChild(document.createElement("link"));
    canonical.rel = "canonical"; canonical.href = publicUrl(pagePath);
    setMeta("description", t.description); setMeta("twitter:title", t.title); setMeta("twitter:description", t.description); setProperty("og:title", t.title); setProperty("og:description", t.description); setProperty("og:url", publicUrl(pagePath));
    setLink("en", publicUrl("/whatsapp")); setLink("ar-SA", publicUrl("/ar/whatsapp")); setLink("x-default", publicUrl("/whatsapp"));
    track("page_view", "whatsapp-page");
    return () => { html.lang = priorLang || "en"; html.dir = priorDir; };
  }, [locale, pagePath, t.description, t.title]);

  useEffect(() => {
    if (!availability.treatment && configuredAreas[0]) setAvailability(previous => ({ ...previous, treatment: configuredAreas[0] }));
    if (!appointment.treatment && configuredAreas[0]) setAppointment(previous => ({ ...previous, treatment: configuredAreas[0] }));
  }, [appointment.treatment, availability.treatment, configuredAreas]);

  useEffect(() => {
    if (configuredVisitTypes.length && !configuredVisitTypes.includes(appointment.visitType)) {
      setAppointment(previous => ({ ...previous, visitType: configuredVisitTypes[0]! }));
    }
  }, [appointment.visitType, configuredVisitTypes]);

  const trackAppointmentStart = () => {
    if (hasStartedAppointmentRequest || appointmentPaused) return;
    setHasStartedAppointmentRequest(true);
    track("appointment_form_start", "private-appointment-request");
  };

  const submitAppointment = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (submissionLock.current || appointmentMutation.isPending || appointmentPaused) return;
    setAppointmentError("");
    if (!appointment.name.trim() || !appointment.mobile.replace(/\D/g, "") || !appointment.date || !appointment.time || !appointment.treatment || !allConsentOpened || !appointment.consentRead || !appointment.appointmentAcknowledgement || !appointment.privacy) { setAppointmentError(allConsentOpened ? t.formRequired : t.consentRequired); return; }
    submissionLock.current = true;
    appointmentMutation.mutate({ clientSubmissionId, fullName: appointment.name, whatsapp: appointment.mobile, nationality: null, preferredDate: appointment.date, preferredTime: appointment.time, visitType: appointment.visitType, treatmentAreas: [appointment.treatment], previousLaser: false, notes: null, appointmentAcknowledgement: true, originalConsentAcknowledgement: true, privacyConsent: true, marketingConsent: false, language: locale, source, website: appointment.website });
  };
  const summaryUrl = appointmentSuccess ? whatsappUrl(clinicNumber, locale === "ar" ? `مرحبًا، أرسلت طلب موعد عبر الموقع. رقم الطلب: ${appointmentSuccess.requestId}` : `Hello, I sent an appointment request through the website. My request number is: ${appointmentSuccess.requestId}`) : primaryUrl;
  const cards: Array<{ key: ActionKind; title: string; description: string }> = [
    { key: "service", title: t.service, description: t.serviceBody }, { key: "prices", title: t.prices, description: t.pricesBody }, { key: "availability", title: t.availability, description: t.availabilityBody }, { key: "callback", title: t.callback, description: t.callbackBody }, { key: "general", title: t.general, description: t.generalBody }, { key: "appointment", title: t.appointment, description: t.appointmentOptionBody },
  ];

  if (appointmentSuccess) return <main dir={t.arabic ? "rtl" : "ltr"} className="grid min-h-screen place-items-center bg-[#F7F3EC] px-4 py-10 text-[#102032]"><section className="w-full max-w-2xl border border-[#102032]/10 bg-white p-7 text-center shadow-xl shadow-[#102032]/5 sm:p-10"><CheckCircle2 className="mx-auto size-12 text-[#B85E3C]" /><p className="mt-6 text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#B85E3C]">{t.appointment}</p><h1 className="mt-2 font-display text-4xl tracking-[-0.05em]">{t.successTitle}</h1><p className="mx-auto mt-4 max-w-xl text-sm leading-7 text-[#52606B]">{t.successBody}</p><div className="mx-auto mt-7 max-w-sm border border-[#B85E3C]/30 bg-[#FFF8F2] p-4"><p className="text-xs font-bold text-[#B85E3C]">{t.request}</p><p className="mt-1 font-display text-3xl tracking-[0.06em]">{appointmentSuccess.requestId}</p></div><div className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-center"><a href={summaryUrl} target="_blank" rel="noreferrer" onClick={() => track("whatsapp_click", "appointment-request-reference")} className="inline-flex min-h-11 items-center justify-center gap-2 bg-[#102032] px-5 text-[11px] font-extrabold uppercase tracking-[0.12em] text-white transition hover:bg-[#B85E3C]"><MessageCircle className="size-4" />{t.sendSummary}</a><a href={t.prefix} className="inline-flex min-h-11 items-center justify-center border border-[#102032]/20 px-5 text-[11px] font-extrabold uppercase tracking-[0.12em]">{t.backHome}</a></div></section></main>;

  return <main lang={locale} dir={t.arabic ? "rtl" : "ltr"} className={`public-content-page min-h-screen bg-[#F7F3EC] text-[#102032] ${t.arabic ? "arabic-public-page" : ""}`}>
    <PublicSiteHeader locale={locale} active="whatsapp" />
    <section className="border-b border-[#102032]/10 bg-[#EDE5D8]"><div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[1.2fr_0.8fr] lg:px-8 lg:py-20"><div><p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#B85E3C]">{t.eyebrow}</p><h1 className={`mt-4 max-w-3xl text-5xl tracking-[-0.055em] sm:text-7xl ${t.arabic ? "font-sans font-extrabold leading-[1.2]" : "font-display leading-[0.94]"}`}>{t.heading}</h1><p className="mt-6 max-w-2xl text-base leading-8 text-[#52606B]">{t.body}</p><div className="mt-8 flex flex-wrap gap-3"><a href={primaryUrl} target="_blank" rel="noreferrer" onClick={() => track("whatsapp_click", "hero") } className="inline-flex min-h-12 items-center gap-2 bg-[#25D366] px-5 text-[11px] font-extrabold uppercase tracking-[0.12em] text-[#092A16] transition hover:bg-[#35E576] active:scale-[0.97]"><MessageCircle className="size-4" />{t.primary}<ArrowUpRight className="size-4" /></a>{clinic.data?.telephone ? <a href={`tel:${clinic.data.telephone.replace(/\s/g, "")}`} className="inline-flex min-h-12 items-center gap-2 border border-[#102032]/20 px-5 text-[11px] font-extrabold uppercase tracking-[0.12em]"><Phone className="size-4" />{t.call}</a> : null}</div><div className="mt-8 grid gap-3 border-t border-[#102032]/10 pt-5 text-sm text-[#52606B] sm:grid-cols-2"><p className="flex gap-2"><Clock3 className="mt-0.5 size-4 shrink-0 text-[#B85E3C]" /><span><strong className="block text-[#102032]">{t.workingHours}</strong><bdi dir="ltr">{clinic.data?.workingHours || "1:00 PM–10:00 PM"}</bdi></span></p><p className="flex gap-2"><MapPin className="mt-0.5 size-4 shrink-0 text-[#B85E3C]" /><span><strong className="block text-[#102032]">{t.location}</strong>{t.arabic ? clinic.data?.addressAr || "الرياض، المملكة العربية السعودية" : clinic.data?.addressEn || "Riyadh, Saudi Arabia"}</span></p></div></div><aside className="hidden self-center border border-[#102032]/10 bg-white p-6 text-center md:block"><QRCodeSVG value={primaryUrl} size={190} level="M" includeMargin /><h2 className={`mt-5 text-2xl ${t.arabic ? "font-sans font-extrabold" : "font-display"}`}>{t.qrTitle}</h2><p className="mt-2 text-sm leading-6 text-[#52606B]">{t.qrBody}</p></aside></div></section>
    <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8"><div className="max-w-2xl"><p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#B85E3C]">{t.arabic ? "خيارات التواصل" : "Contact options"}</p><h2 className={`mt-3 text-4xl tracking-[-0.045em] ${t.arabic ? "font-sans font-extrabold" : "font-display"}`}>{t.optionsTitle}</h2><p className="mt-3 text-sm leading-7 text-[#52606B]">{t.optionsBody}</p></div><div className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{cards.map(card => <button key={card.key} type="button" onClick={() => { setActive(card.key); document.getElementById("whatsapp-action-form")?.scrollIntoView({ behavior: "smooth", block: "start" }); }} className={`min-h-40 border p-5 text-start transition duration-200 ease-out hover:-translate-y-0.5 hover:border-[#B85E3C] focus-visible:outline-2 focus-visible:outline-[#B85E3C] ${active === card.key ? "border-[#B85E3C] bg-[#FFF8F2]" : "border-[#102032]/10 bg-white"}`}><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#B85E3C]">WhatsApp</p><h3 className={`mt-3 text-2xl ${t.arabic ? "font-sans font-extrabold" : "font-display"}`}>{card.title}</h3><p className="mt-2 text-sm leading-6 text-[#52606B]">{card.description}</p></button>)}</div></section>
    <section id="whatsapp-action-form" className="scroll-mt-5 bg-[#102032] px-4 py-14 text-white sm:px-6 lg:px-8"><div className="mx-auto max-w-4xl">{active === "service" || active === "prices" ? <section className="border border-white/15 bg-white/5 p-6 sm:p-8"><p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#EAB394]">{active === "service" ? t.service : t.prices}</p><h2 className={`mt-3 text-4xl ${t.arabic ? "font-sans font-extrabold" : "font-display"}`}>{active === "service" ? t.serviceFormTitle : t.prices}</h2><p className="mt-3 max-w-2xl text-sm leading-7 text-white/70">{active === "service" ? t.serviceFormBody : t.pricesBody}</p><div className="mt-6 max-w-sm"><ActionButton href={whatsappUrl(clinicNumber, quickWhatsAppMessage(locale, active === "service" ? "service" : "prices"))} enabled fallbackTelephone={clinic.data?.telephone} onClick={() => track("whatsapp_click", active)}><MessageCircle className="size-4" />{t.primary}</ActionButton></div></section> : null}
      {active === "availability" ? <section className="border border-white/15 bg-white p-6 text-[#102032] sm:p-8"><p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#B85E3C]">WhatsApp</p><h2 className={`mt-3 text-4xl ${t.arabic ? "font-sans font-extrabold" : "font-display"}`}>{t.availabilityTitle}</h2><p className="mt-3 text-sm leading-7 text-[#52606B]">{t.availabilityNotice}</p><div className="mt-6 grid gap-4 sm:grid-cols-3"><FormField label={t.date} required><input type="date" min={riyadhToday()} value={availability.date} onChange={event => setAvailability({ ...availability, date: event.target.value })} className="h-11 border border-[#102032]/20 bg-white px-3 text-sm" /></FormField><FormField label={t.time} required><select value={availability.time} onChange={event => setAvailability({ ...availability, time: event.target.value })} className="h-11 border border-[#102032]/20 bg-white px-3 text-sm"><option value="">{t.choose}</option>{configuredTimes.map(option => <option key={option.value} value={option.value}>{t.arabic ? option.ar : option.en}</option>)}</select></FormField><FormField label={t.treatment} required><select value={availability.treatment} onChange={event => setAvailability({ ...availability, treatment: event.target.value as AppointmentTreatment })} className="h-11 border border-[#102032]/20 bg-white px-3 text-sm">{configuredAreas.map(area => <option key={area} value={area}>{area}</option>)}</select></FormField></div><label className="mt-5 flex gap-3 text-sm leading-6 text-[#52606B]"><input type="checkbox" checked={availabilityConsent} onChange={event => setAvailabilityConsent(event.target.checked)} className="mt-1 size-4 accent-[#B85E3C]" /><span>{t.consent}</span></label><div className="mt-6 max-w-sm"><ActionButton href={whatsappUrl(clinicNumber, availabilityWhatsAppMessage(locale, availability))} enabled={Boolean(availability.date && availability.time && availability.treatment && availabilityConsent)} fallbackTelephone={clinic.data?.telephone} onClick={() => track("whatsapp_click", "availability")}><CalendarDays className="size-4" />{t.primary}</ActionButton></div></section> : null}
      {active === "callback" ? <section className="border border-white/15 bg-white p-6 text-[#102032] sm:p-8"><p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#B85E3C]">WhatsApp</p><h2 className={`mt-3 text-4xl ${t.arabic ? "font-sans font-extrabold" : "font-display"}`}>{t.callbackTitle}</h2><div className="mt-6 grid gap-4 sm:grid-cols-3"><FormField label={t.name} required><input value={callback.name} onChange={event => setCallback({ ...callback, name: event.target.value })} autoComplete="name" className="h-11 border border-[#102032]/20 px-3 text-sm" /></FormField><FormField label={t.mobile} required><input value={callback.mobile} onChange={event => setCallback({ ...callback, mobile: event.target.value })} inputMode="tel" autoComplete="tel" className="h-11 border border-[#102032]/20 px-3 text-sm" /></FormField><FormField label={t.period} required><select value={callback.callbackPeriod} onChange={event => setCallback({ ...callback, callbackPeriod: event.target.value })} className="h-11 border border-[#102032]/20 bg-white px-3 text-sm"><option>{t.arabic ? "من 1:00 ظهرًا إلى 5:00 مساءً" : "1:00 PM–5:00 PM"}</option><option>{t.arabic ? "من 5:00 مساءً إلى 10:00 مساءً" : "5:00 PM–10:00 PM"}</option></select></FormField></div><label className="mt-5 flex gap-3 text-sm leading-6 text-[#52606B]"><input type="checkbox" checked={callbackConsent} onChange={event => setCallbackConsent(event.target.checked)} className="mt-1 size-4 accent-[#B85E3C]" /><span>{t.consent}</span></label><div className="mt-6 max-w-sm"><ActionButton href={whatsappUrl(clinicNumber, callbackWhatsAppMessage(locale, callback))} enabled={Boolean(callback.name.trim() && callback.mobile.replace(/\D/g, "").length >= 8 && callbackConsent)} fallbackTelephone={clinic.data?.telephone} onClick={() => track("whatsapp_click", "callback")}><Phone className="size-4" />{t.primary}</ActionButton></div></section> : null}
      {active === "general" ? <section className="border border-white/15 bg-white p-6 text-[#102032] sm:p-8"><p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#B85E3C]">WhatsApp</p><h2 className={`mt-3 text-4xl ${t.arabic ? "font-sans font-extrabold" : "font-display"}`}>{t.generalTitle}</h2><div className="mt-6 grid gap-4"><FormField label={t.name} required><input value={general.name} onChange={event => setGeneral({ ...general, name: event.target.value })} autoComplete="name" className="h-11 border border-[#102032]/20 px-3 text-sm" /></FormField><FormField label={t.message} required><textarea value={general.message} onChange={event => setGeneral({ ...general, message: event.target.value })} maxLength={1000} rows={5} className="border border-[#102032]/20 p-3 text-sm" /><span className="text-end text-[11px] font-normal text-[#66727A]">{general.message.length}/1000</span></FormField></div><label className="mt-5 flex gap-3 text-sm leading-6 text-[#52606B]"><input type="checkbox" checked={generalConsent} onChange={event => setGeneralConsent(event.target.checked)} className="mt-1 size-4 accent-[#B85E3C]" /><span>{t.consent}</span></label><div className="mt-6 max-w-sm"><ActionButton href={whatsappUrl(clinicNumber, generalInquiryWhatsAppMessage(locale, general))} enabled={Boolean(general.name.trim() && general.message.trim().length >= 4 && generalConsent)} fallbackTelephone={clinic.data?.telephone} onClick={() => track("whatsapp_click", "general")}><MessageCircle className="size-4" />{t.primary}</ActionButton></div></section> : null}
      {active === "appointment" ? <form noValidate onFocus={trackAppointmentStart} onSubmit={submitAppointment} className="border border-white/15 bg-white p-6 text-[#102032] sm:p-8"><p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#B85E3C]">{t.appointment}</p><h2 className={`mt-3 text-4xl ${t.arabic ? "font-sans font-extrabold" : "font-display"}`}>{t.appointmentTitle}</h2><p className="mt-3 max-w-3xl text-sm leading-7 text-[#52606B]">{t.appointmentBody}</p><input aria-hidden tabIndex={-1} autoComplete="off" className="hidden" name="website" value={appointment.website} onChange={event => setAppointment({ ...appointment, website: event.target.value })} /><div className="mt-6 grid gap-4 sm:grid-cols-2"><FormField label={t.name} required><input value={appointment.name} onChange={event => setAppointment({ ...appointment, name: event.target.value })} autoComplete="name" className="h-11 border border-[#102032]/20 px-3 text-sm" /></FormField><FormField label={t.mobile} required><input value={appointment.mobile} onChange={event => setAppointment({ ...appointment, mobile: event.target.value })} inputMode="tel" autoComplete="tel" className="h-11 border border-[#102032]/20 px-3 text-sm" /></FormField><FormField label={t.date} required><input min={riyadhToday()} type="date" value={appointment.date} onChange={event => setAppointment({ ...appointment, date: event.target.value })} className="h-11 border border-[#102032]/20 px-3 text-sm" /></FormField><FormField label={t.time} required><select value={appointment.time} onChange={event => setAppointment({ ...appointment, time: event.target.value })} className="h-11 border border-[#102032]/20 bg-white px-3 text-sm"><option value="">{t.choose}</option>{configuredTimes.map(option => <option key={option.value} value={option.value}>{t.arabic ? option.ar : option.en}</option>)}</select></FormField><FormField label={t.treatment} required><select value={appointment.treatment} onChange={event => setAppointment({ ...appointment, treatment: event.target.value as AppointmentTreatment })} className="h-11 border border-[#102032]/20 bg-white px-3 text-sm">{configuredAreas.map(area => <option key={area} value={area}>{area}</option>)}</select></FormField><fieldset><legend className="mb-1.5 text-xs font-bold text-[#102032]">{t.visit} <span className="text-[#B85E3C]">*</span></legend><div className={`grid h-11 border border-[#102032]/20 text-sm ${configuredVisitTypes.length === 1 ? "grid-cols-1" : "grid-cols-2"}`}>{configuredVisitTypes.map(visitType => <button key={visitType} type="button" aria-pressed={appointment.visitType === visitType} onClick={() => setAppointment({ ...appointment, visitType })} className={appointment.visitType === visitType ? "bg-[#FFF8F2] font-bold text-[#102032]" : "text-[#52606B]"}>{visitType === "retouch" ? t.retouch : t.session}</button>)}</div></fieldset></div><section className="mt-7 border-t border-[#102032]/10 pt-6"><h3 className="text-lg font-bold text-[#102032]">{t.originalConsent}</h3><p className="mt-2 text-sm leading-6 text-[#52606B]">{t.consentHelp}</p><div className="mt-4 grid gap-2">{ORIGINAL_CONSENT_DOCUMENTS.map(document => <a key={document.id} href={document.url} target="_blank" rel="noreferrer" onClick={() => setOpenedConsentIds(current => current.includes(document.id) ? current : [...current, document.id])} className="inline-flex min-h-11 items-center justify-between border border-[#102032]/10 px-3 text-sm font-semibold transition hover:border-[#B85E3C]"><span>{t.arabic ? document.titleAr : document.titleEn}</span><ExternalLink className="size-4 text-[#B85E3C]" /></a>)}</div><p className={`mt-3 text-xs font-bold ${allConsentOpened ? "text-emerald-700" : "text-[#B85E3C]"}`}>{allConsentOpened ? t.consentOpened : t.consentRequired}</p></section><section className="mt-6 space-y-4 border-t border-[#102032]/10 pt-6"><label className="flex gap-3 text-sm leading-6"><input disabled={!allConsentOpened} type="checkbox" checked={appointment.consentRead} onChange={event => setAppointment({ ...appointment, consentRead: event.target.checked })} className="mt-1 size-4 accent-[#B85E3C]" /><span>{t.consentAcknowledgement}</span></label><label className="flex gap-3 text-sm leading-6"><input type="checkbox" checked={appointment.appointmentAcknowledgement} onChange={event => setAppointment({ ...appointment, appointmentAcknowledgement: event.target.checked })} className="mt-1 size-4 accent-[#B85E3C]" /><span>{t.appointmentAcknowledgement}</span></label><label className="flex gap-3 text-sm leading-6"><input type="checkbox" checked={appointment.privacy} onChange={event => setAppointment({ ...appointment, privacy: event.target.checked })} className="mt-1 size-4 accent-[#B85E3C]" /><span>{t.privacy} <a href={t.arabic ? "/ar/policies/privacy-policy" : "/policies/privacy-policy"} className="font-bold text-[#B85E3C] underline">{t.arabic ? "سياسة الخصوصية" : "Privacy Policy"}</a></span></label></section>{appointmentError ? <p role="alert" className="mt-5 border border-red-200 bg-red-50 p-3 text-sm text-red-800">{appointmentError}</p> : null}<button type="submit" disabled={appointmentMutation.isPending || appointmentPaused} className="mt-6 inline-flex min-h-12 w-full items-center justify-center gap-2 bg-[#B85E3C] px-5 text-[11px] font-extrabold uppercase tracking-[0.12em] text-white transition hover:bg-[#D37A55] disabled:cursor-not-allowed disabled:opacity-60">{appointmentMutation.isPending ? t.submitting : t.submit}<ArrowRight className={t.arabic ? "size-4 rotate-180" : "size-4"} /></button>{appointmentPaused ? <p role="status" className="mt-3 text-sm leading-6 text-[#52606B]">{t.appointmentPaused}</p> : null}</form> : null}</div></section>
    <section className="mx-auto grid max-w-7xl gap-5 px-4 py-12 sm:px-6 lg:grid-cols-2 lg:px-8"><article className="border border-[#102032]/10 bg-white p-6"><ShieldCheck className="size-6 text-[#B85E3C]" /><h2 className={`mt-4 text-2xl ${t.arabic ? "font-sans font-extrabold" : "font-display"}`}>{t.privacyTitle}</h2><p className="mt-3 text-sm leading-7 text-[#52606B]">{t.privacyBody}</p></article><article className="border border-[#E5B4A0] bg-[#FFF8F2] p-6"><TriangleAlert className="size-6 text-[#B85E3C]" /><h2 className={`mt-4 text-2xl ${t.arabic ? "font-sans font-extrabold" : "font-display"}`}>{t.arabic ? "ملاحظة مهمة" : "Important note"}</h2><p className="mt-3 text-sm leading-7 text-[#52606B]">{t.emergency}</p></article></section>
    <footer className="bg-[#102032] px-4 py-10 text-white sm:px-6 lg:px-8"><div className="mx-auto flex max-w-7xl flex-col justify-between gap-5 md:flex-row md:items-end"><div><p className={`text-2xl ${t.arabic ? "font-sans font-extrabold" : "font-display"}`}>{t.arabic ? "جيمس ليزر" : "James Laser"}</p><p className="mt-2 text-sm text-white/65">{t.fallback}</p></div><div className="flex flex-wrap gap-3"><a href={primaryUrl} target="_blank" rel="noreferrer" onClick={() => track("whatsapp_click", "footer")} className="inline-flex min-h-11 items-center gap-2 bg-[#25D366] px-4 text-[11px] font-extrabold uppercase tracking-[0.12em] text-[#092A16]"><MessageCircle className="size-4" />{t.primary}</a><a href={t.prefix} className="inline-flex min-h-11 items-center gap-2 border border-white/25 px-4 text-[11px] font-extrabold uppercase tracking-[0.12em]"><ArrowLeft className={t.arabic ? "size-4 rotate-180" : "size-4"} />{t.backHome}</a></div></div></footer>
  </main>;
}
