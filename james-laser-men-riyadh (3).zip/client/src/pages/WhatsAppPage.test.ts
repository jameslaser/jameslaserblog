import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const appSource = readFileSync(resolve(process.cwd(), "client/src/App.tsx"), "utf8");
const pageSource = readFileSync(resolve(process.cwd(), "client/src/pages/WhatsAppPage.tsx"), "utf8");
const launcherSource = readFileSync(resolve(process.cwd(), "client/src/components/PublicWhatsAppLauncher.tsx"), "utf8");
const sitemap = readFileSync(resolve(process.cwd(), "client/public/sitemap.xml"), "utf8");

describe("public WhatsApp conversion page", () => {
  it("registers English and Arabic public routes without exposing private portal paths", () => {
    expect(appSource).toContain('path={"/whatsapp"}');
    expect(appSource).toContain('path={"/en/whatsapp"}');
    expect(appSource).toContain('path={"/ar/whatsapp"}');
    expect(pageSource).not.toContain('href="/admin');
  });

  it("uses localized metadata, clinic settings, canonical links, and RTL handling", () => {
    expect(pageSource).toContain("trpc.publicContent.clinicSettings.useQuery()");
    expect(pageSource).toContain('html.dir = t.arabic ? "rtl" : "ltr"');
    expect(pageSource).toContain('setLink("ar-SA", publicUrl("/ar/whatsapp"))');
    expect(pageSource).toContain("document.title = t.title");
    expect(pageSource).toContain("New Look Clinic");
  });

  it("keeps real WhatsApp handoff, local QR rendering, privacy disclosures, and appointment confirmation boundaries", () => {
    expect(pageSource).toContain("QRCodeSVG");
    expect(pageSource).toContain("whatsappUrl(clinicNumber");
    expect(pageSource).toContain("opens the real WhatsApp service");
    expect(pageSource).toContain("No appointment is confirmed automatically");
    expect(pageSource).toContain("ID numbers, payment details, medical reports, or passwords");
    expect(pageSource).toContain("not for emergencies");
    expect(pageSource).toContain('aria-describedby="whatsapp-required-fields"');
    expect(pageSource).toContain("fallbackTelephone={clinic.data?.telephone}");
    expect(pageSource).toContain("Open WhatsApp again");
    expect(pageSource).not.toContain("typing indicator");
    expect(pageSource).not.toContain("online now");
  });

  it("reuses the secure appointment procedure with localized source values and mandatory consent evidence", () => {
    expect(pageSource).toContain("trpc.appointmentRequest.create.useMutation({");
    expect(pageSource).toContain('"whatsapp_page_ar"');
    expect(pageSource).toContain('"whatsapp_page_en"');
    expect(pageSource).toContain("ORIGINAL_CONSENT_DOCUMENTS");
    expect(pageSource).toContain("appointmentAcknowledgement: true");
    expect(pageSource).toContain("privacyConsent: true");
  });

  it("matches clinic availability controls and uses a stable submission id to prevent duplicate private requests", () => {
    expect(pageSource).toContain("clientSubmissionId");
    expect(pageSource).toContain("submissionLock.current");
    expect(pageSource).toContain("appointmentFormEnabled");
    expect(pageSource).toContain("maintenanceMode");
    expect(pageSource).toContain("configuredVisitTypes");
    expect(pageSource).toContain("disabled={appointmentMutation.isPending || appointmentPaused}");
  });

  it("provides a public launcher that avoids dedicated, consent-signature, and admin routes", () => {
    expect(launcherSource).toContain('path.startsWith("/admin")');
    expect(launcherSource).toContain('path.startsWith("/sign-consent")');
    expect(launcherSource).toContain("whatsappUrl");
  });

  it("adds the localized public routes to the sitemap while keeping administrative routes absent", () => {
    expect(sitemap).toContain("/whatsapp</loc>");
    expect(sitemap).toContain("/ar/whatsapp</loc>");
    expect(sitemap).not.toContain("/admin");
  });
});
