import { AdminEmptyState, AdminErrorState, AdminLoadingState, AdminMetricCard, AdminPageHeader } from "@/components/AdminUi";
import { WhatsAppBusinessWebAction } from "@/components/WhatsAppBusinessWebAction";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { CalendarCheck2, CalendarClock, CheckCircle2, ChevronLeft, ClipboardPlus, FileText, Loader2, Pencil, Printer, Search, UserRound, X } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";

type Machine = "DEKA AGAIN" | "CLARITY 2" | "GENTLE PROMAX" | "DUETTO MACHINE";
type VisitType = "session" | "retouch";
type SessionStatus = "draft" | "completed" | "cancelled";
type FollowUpStatus = "pending" | "contacted" | "completed" | "cancelled";
type FollowUpFilter = "open" | "due" | "upcoming" | "overdue" | "unscheduled" | "completed" | "cancelled";

type SessionDraft = {
  id?: number;
  appointmentId: number;
  sessionDate: string;
  sessionTime: string;
  visitType: VisitType;
  treatmentAreasText: string;
  machine: Machine;
  nurseName: string;
  outcome: string;
  notes: string;
  status: SessionStatus;
  nextFollowUpDate: string;
  nextFollowUpType: VisitType;
  followUpAssignedStaff: string;
  followUpNotes: string;
};

type SelectedPatient = { id: number; fullName: string; mrn: string | null; whatsapp: string };
type FollowUpDraft = { id: number; followUpType: VisitType; dueDate: string; status: FollowUpStatus; assignedStaff: string; outcome: string; notes: string };

const fieldClass = "h-10 w-full border border-[#102032]/20 bg-white px-3 text-sm text-[#102032] focus:outline-none focus:ring-2 focus:ring-[#a85438]";
const textAreaClass = "min-h-24 w-full border border-[#102032]/20 bg-white p-3 text-sm text-[#102032] focus:outline-none focus:ring-2 focus:ring-[#a85438]";
const labelClass = "grid gap-1.5 text-xs font-bold text-[#102032]";

function todayInRiyadh() {
  return new Intl.DateTimeFormat("sv-SE", { timeZone: "Asia/Riyadh", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
}

function escapeHtml(value: string) {
  return value.replace(/[&<>'"]/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#039;", '"': "&quot;" })[character] ?? character);
}

function printTable(title: string, headers: string[], rows: string[][]) {
  const popup = window.open("", "_blank", "width=1100,height=760");
  if (!popup) {
    toast.error("Allow pop-ups to print this protected report.");
    return;
  }
  popup.opener = null;
  const body = rows.map(row => `<tr>${row.map(cell => `<td>${escapeHtml(cell)}</td>`).join("")}</tr>`).join("");
  popup.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${escapeHtml(title)}</title><style>body{font-family:Arial,sans-serif;color:#102032;padding:28px}h1{font-family:Georgia,serif;margin:0 0 6px}.meta{color:#52606b;font-size:12px;margin-bottom:22px}table{width:100%;border-collapse:collapse;font-size:12px}th,td{border:1px solid #ccd2d5;padding:8px;text-align:left;vertical-align:top}th{background:#f2eee6;text-transform:uppercase;font-size:10px;letter-spacing:.08em}@media print{body{padding:0}}</style></head><body><h1>${escapeHtml(title)}</h1><p class="meta">Private clinic record · Printed ${escapeHtml(new Date().toLocaleString())}</p><table><thead><tr>${headers.map(header => `<th>${escapeHtml(header)}</th>`).join("")}</tr></thead><tbody>${body}</tbody></table></body></html>`);
  popup.document.close();
  popup.focus();
  popup.print();
}

function StatusBadge({ value }: { value: string }) {
  const styles: Record<string, string> = {
    completed: "border-emerald-200 bg-emerald-50 text-emerald-800",
    draft: "border-amber-200 bg-amber-50 text-amber-800",
    cancelled: "border-slate-200 bg-slate-100 text-slate-700",
    pending: "border-sky-200 bg-sky-50 text-sky-800",
    contacted: "border-violet-200 bg-violet-50 text-violet-800",
    due: "border-emerald-200 bg-emerald-50 text-emerald-800",
    upcoming: "border-sky-200 bg-sky-50 text-sky-800",
    overdue: "border-red-200 bg-red-50 text-red-800",
    unscheduled: "border-amber-200 bg-amber-50 text-amber-800",
  };
  return <Badge variant="outline" className={styles[value] ?? ""}>{value.replaceAll("_", " ")}</Badge>;
}

function SessionEditor({ draft, setDraft, machines, onSave, saving, onClose }: {
  draft: SessionDraft;
  setDraft: (value: SessionDraft) => void;
  machines: Machine[];
  onSave: () => void;
  saving: boolean;
  onClose: () => void;
}) {
  const update = (change: Partial<SessionDraft>) => setDraft({ ...draft, ...change });
  const areas = draft.treatmentAreasText.split(",").map(area => area.trim()).filter(Boolean);
  const canSave = Boolean(draft.appointmentId && draft.sessionDate && draft.sessionTime && draft.machine && areas.length && (draft.status !== "completed" || draft.outcome.trim()));
  return <section className="mt-5 border border-[#a85438]/25 bg-[#fffaf5] p-4 sm:p-6">
    <div className="flex flex-wrap items-start justify-between gap-3"><div><p className="admin-eyebrow">Protected treatment record</p><h2 className="mt-1 font-display text-2xl text-[#102032]">{draft.id ? "Edit session record" : "Complete session details"}</h2><p className="mt-1 text-sm text-[#52606B]">The linked appointment and patient identity cannot be replaced from this editor. Historical records remain available for authorized Nurse’s Notes corrections.</p></div><Button size="icon" variant="ghost" aria-label="Close session editor" onClick={onClose}><X className="size-4" /></Button></div>
    <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      <label className={labelClass}>Session date<Input type="date" value={draft.sessionDate} onChange={event => update({ sessionDate: event.target.value })} /></label>
      <label className={labelClass}>Session time<Input type="time" value={draft.sessionTime} onChange={event => update({ sessionTime: event.target.value })} /></label>
      <label className={labelClass}>Visit type<select className={fieldClass} value={draft.visitType} onChange={event => update({ visitType: event.target.value as VisitType })}><option value="session">Session</option><option value="retouch">Retouch</option></select></label>
      <label className={labelClass}>Machine<select className={fieldClass} value={draft.machine} onChange={event => update({ machine: event.target.value as Machine })}>{machines.map(machine => <option key={machine} value={machine}>{machine}</option>)}</select></label>
      <label className={labelClass}>Nurse / specialist<Input value={draft.nurseName} onChange={event => update({ nurseName: event.target.value })} placeholder="Staff name" /></label>
      <label className={labelClass}>Record status<select className={fieldClass} value={draft.status} onChange={event => update({ status: event.target.value as SessionStatus })}><option value="draft">Draft</option><option value="completed">Completed</option><option value="cancelled">Cancelled</option></select></label>
      <label className={`${labelClass} sm:col-span-2 lg:col-span-3`}>Treatment areas<Input value={draft.treatmentAreasText} onChange={event => update({ treatmentAreasText: event.target.value })} placeholder="Face, Neck, Underarm" /><span className="font-normal text-[#66727A]">Separate multiple areas with commas.</span></label>
      <label className={`${labelClass} sm:col-span-2 lg:col-span-3`}>Outcome<textarea className={textAreaClass} value={draft.outcome} onChange={event => update({ outcome: event.target.value })} placeholder="Required before marking the session completed" /></label>
      <label className={`${labelClass} sm:col-span-2 lg:col-span-3`}>Private Nurse’s Notes<textarea className={textAreaClass} value={draft.notes} onChange={event => update({ notes: event.target.value })} /></label>
    </div>
    <div className="mt-6 border-t border-[#102032]/10 pt-5"><p className="admin-eyebrow">Optional next follow-up</p><p className="mt-1 text-sm text-[#52606B]">Staff choose the date explicitly. The system does not infer clinical timing or send a message automatically.</p><div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4"><label className={labelClass}>Due date<Input type="date" value={draft.nextFollowUpDate} onChange={event => update({ nextFollowUpDate: event.target.value })} /></label><label className={labelClass}>Type<select className={fieldClass} value={draft.nextFollowUpType} onChange={event => update({ nextFollowUpType: event.target.value as VisitType })}><option value="session">Session</option><option value="retouch">Retouch</option></select></label><label className={`${labelClass} sm:col-span-2`}>Assigned staff<Input value={draft.followUpAssignedStaff} onChange={event => update({ followUpAssignedStaff: event.target.value })} /></label><label className={`${labelClass} sm:col-span-2 lg:col-span-4`}>Follow-up note<textarea className={textAreaClass} value={draft.followUpNotes} onChange={event => update({ followUpNotes: event.target.value })} /></label></div></div>
    <div className="mt-5 flex flex-wrap gap-2"><Button disabled={!canSave || saving} onClick={onSave}>{saving ? <Loader2 className="mr-2 size-4 animate-spin" /> : <CheckCircle2 className="mr-2 size-4" />}Save session record & Nurse’s Notes</Button><Button variant="outline" onClick={onClose}>Cancel</Button></div>
  </section>;
}

export function SessionsWorkspace() {
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<"all" | SessionStatus>("all");
  const [showCreate, setShowCreate] = useState(false);
  const [appointmentSearch, setAppointmentSearch] = useState("");
  const [draft, setDraft] = useState<SessionDraft | null>(null);
  const sessions = trpc.admin.sessionRecords.useQuery({ query: query || undefined, status: status === "all" ? undefined : status });
  const eligible = trpc.admin.eligibleSessionAppointments.useQuery({ query: appointmentSearch || undefined }, { enabled: showCreate });
  const machineQuery = trpc.admin.machines.useQuery();
  const machineOptions = (machineQuery.data?.map(item => item.name) ?? ["DEKA AGAIN", "CLARITY 2", "GENTLE PROMAX", "DUETTO MACHINE"]) as Machine[];
  const save = trpc.admin.saveSessionRecord.useMutation({
    onSuccess: async () => {
      toast.success("Session record saved.");
      setDraft(null); setShowCreate(false);
      await Promise.all([utils.admin.sessionRecords.invalidate(), utils.admin.eligibleSessionAppointments.invalidate(), utils.admin.followUps.invalidate(), utils.admin.reminders.invalidate()]);
    },
    onError: error => toast.error(error.message),
  });
  const rows = sessions.data ?? [];
  const metrics = { total: rows.length, completed: rows.filter(row => row.status === "completed").length, draft: rows.filter(row => row.status === "draft").length, cancelled: rows.filter(row => row.status === "cancelled").length };

  const selectAppointment = (appointment: NonNullable<typeof eligible.data>[number]) => {
    setDraft({ appointmentId: appointment.id, sessionDate: appointment.appointmentDate, sessionTime: appointment.appointmentTime.slice(0, 5), visitType: appointment.visitType, treatmentAreasText: appointment.treatmentAreas.join(", "), machine: (appointment.machine ?? machineOptions[0]) as Machine, nurseName: appointment.assignedStaff ?? "", outcome: "", notes: "", status: appointment.status === "completed" ? "completed" : "draft", nextFollowUpDate: "", nextFollowUpType: appointment.visitType, followUpAssignedStaff: appointment.assignedStaff ?? "", followUpNotes: "" });
  };
  const editRecord = (row: NonNullable<typeof sessions.data>[number]) => setDraft({ id: row.id, appointmentId: row.appointmentId, sessionDate: row.sessionDate, sessionTime: row.sessionTime.slice(0, 5), visitType: row.visitType, treatmentAreasText: row.treatmentAreas.join(", "), machine: row.machine, nurseName: row.nurseName ?? "", outcome: row.outcome ?? "", notes: row.notes ?? "", status: row.status, nextFollowUpDate: "", nextFollowUpType: row.visitType, followUpAssignedStaff: "", followUpNotes: "" });
  const submit = () => draft && save.mutate({ id: draft.id, appointmentId: draft.appointmentId, sessionDate: draft.sessionDate, sessionTime: draft.sessionTime, visitType: draft.visitType, treatmentAreas: draft.treatmentAreasText.split(",").map(area => area.trim()).filter(Boolean), machine: draft.machine, nurseName: draft.nurseName, outcome: draft.outcome, notes: draft.notes, status: draft.status, nextFollowUpDate: draft.nextFollowUpDate || null, nextFollowUpType: draft.nextFollowUpDate ? draft.nextFollowUpType : null, followUpAssignedStaff: draft.followUpAssignedStaff, followUpNotes: draft.followUpNotes });

  return <div className="mx-auto max-w-7xl">
    <AdminPageHeader eyebrow="Clinic treatment history · private" title="Sessions" description="Create one longitudinal treatment record from an arrived or completed appointment, review current or historical post-session Nurse’s Notes, and hand the next action to Follow-Ups." action={<div className="flex flex-wrap gap-2"><Button variant="outline" onClick={() => setLocation("/admin/appointments")}><ChevronLeft className="mr-2 size-4" />Appointments</Button><Button variant="outline" onClick={() => setLocation("/admin/follow-ups")}><CalendarClock className="mr-2 size-4" />Follow-Ups</Button><Button variant="outline" onClick={() => printTable("Session history", ["Patient", "MRN", "Date / time", "Type", "Machine", "Areas", "Status", "Outcome"], rows.map(row => [row.patientName, row.mrn ?? "—", `${row.sessionDate} ${row.sessionTime}`, row.visitType, row.machineNumber ? `${row.machine} · ${row.machineNumber}` : row.machine, row.treatmentAreas.join(", "), row.status, row.outcome ?? "—"]))}><Printer className="mr-2 size-4" />Print</Button><Button onClick={() => { setShowCreate(value => !value); setDraft(null); }}><ClipboardPlus className="mr-2 size-4" />New session record</Button></div>} />
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4"><AdminMetricCard label="Session records" value={metrics.total} note="Current filtered history" icon={FileText} /><AdminMetricCard label="Completed" value={metrics.completed} note="Outcome recorded" icon={CheckCircle2} tone="success" /><AdminMetricCard label="Draft" value={metrics.draft} note="Requires completion" icon={Pencil} tone="warning" /><AdminMetricCard label="Cancelled" value={metrics.cancelled} note="Retained for audit" icon={X} /></div>
    {showCreate ? <section className="mt-6 border border-[#102032]/10 bg-white p-4 sm:p-6"><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="admin-eyebrow">Step 1</p><h2 className="mt-1 font-display text-2xl text-[#102032]">Choose an arrived or completed appointment</h2><p className="mt-1 text-sm text-[#52606B]">Appointments already linked to a session record are excluded.</p></div><Button size="icon" variant="ghost" aria-label="Close appointment selector" onClick={() => { setShowCreate(false); setDraft(null); }}><X className="size-4" /></Button></div><div className="relative mt-4 max-w-xl"><Search className="pointer-events-none absolute left-3 top-3 size-4 text-[#66727A]" /><Input className="pl-9" value={appointmentSearch} onChange={event => setAppointmentSearch(event.target.value)} placeholder="Search patient name or MRN" /></div>{eligible.isLoading ? <AdminLoadingState label="Loading eligible appointments…" /> : eligible.isError ? <AdminErrorState title="Appointments could not be loaded" description={eligible.error.message} /> : (eligible.data?.length ?? 0) === 0 ? <AdminEmptyState icon={CalendarCheck2} title="No eligible appointments" description="Mark an appointment arrived or completed before creating its session record." /> : <div className="mt-4 grid gap-3 lg:grid-cols-2">{eligible.data?.map(appointment => <button key={appointment.id} onClick={() => selectAppointment(appointment)} className={`border p-4 text-left transition hover:border-[#a85438]/50 hover:bg-[#fffaf5] ${draft?.appointmentId === appointment.id ? "border-[#a85438] bg-[#fffaf5]" : "border-[#102032]/10 bg-white"}`}><div className="flex items-start justify-between gap-3"><div><p className="font-semibold text-[#102032]">{appointment.patientName}</p><p className="mt-1 text-xs text-[#66727A]">MRN: {appointment.mrn ?? "Not recorded"}</p></div><StatusBadge value={appointment.status} /></div><p className="mt-3 text-sm text-[#52606B]">{appointment.appointmentDate} · {appointment.appointmentTime} · {appointment.machine ?? "Machine not recorded"}</p></button>)}</div>}</section> : null}
    {draft ? <SessionEditor draft={draft} setDraft={setDraft} machines={machineOptions} onSave={submit} saving={save.isPending} onClose={() => setDraft(null)} /> : null}
    <section className="mt-6 border border-[#102032]/10 bg-white"><div className="flex flex-col gap-3 border-b border-[#102032]/10 p-4 sm:flex-row sm:items-center sm:justify-between sm:p-5"><div><p className="admin-eyebrow">Protected history</p><h2 className="mt-1 font-display text-2xl text-[#102032]">Recorded sessions</h2></div><div className="flex flex-col gap-2 sm:flex-row"><Input value={query} onChange={event => setQuery(event.target.value)} placeholder="Search patient, MRN, or date" aria-label="Search session records" /><select className={fieldClass} value={status} onChange={event => setStatus(event.target.value as typeof status)}><option value="all">All statuses</option><option value="draft">Draft</option><option value="completed">Completed</option><option value="cancelled">Cancelled</option></select></div></div>
      {sessions.isLoading ? <AdminLoadingState label="Loading session history…" /> : sessions.isError ? <AdminErrorState title="Session history could not be loaded" description={sessions.error.message} /> : rows.length === 0 ? <AdminEmptyState icon={FileText} title="No session records" description="Create the first record from an arrived or completed appointment." /> : <div>{rows.map(row => <article key={row.id} className="grid gap-4 border-b border-[#102032]/10 p-4 last:border-0 sm:p-5 lg:grid-cols-[1.3fr_1fr_1fr_auto] lg:items-center"><div><div className="flex flex-wrap items-center gap-2"><h3 className="font-display text-xl text-[#102032]">{row.patientName}</h3><StatusBadge value={row.status} /></div><p className="mt-1 text-xs text-[#66727A]">MRN: {row.mrn ?? "Not recorded"} · Appointment #{row.appointmentId}</p></div><div><p className="text-sm font-semibold text-[#102032]">{row.sessionDate} · {row.sessionTime}</p><p className="mt-1 text-xs capitalize text-[#66727A]">{row.visitType} · {row.treatmentAreas.join(", ")}</p></div><div><p className="text-sm font-semibold text-[#102032]">{row.machine}</p><p className="mt-1 text-xs text-[#66727A]">{row.machineNumber ?? "Internal ID not recorded"} · {row.nurseName ?? "Staff not recorded"}</p></div><Button variant="outline" size="sm" onClick={() => editRecord(row)}><Pencil className="mr-2 size-4" />Edit Nurse’s Notes</Button></article>)}</div>}
    </section>
  </div>;
}

export function FollowUpsWorkspace() {
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();
  const [filter, setFilter] = useState<FollowUpFilter>("open");
  const [showCreate, setShowCreate] = useState(false);
  const [patientSearch, setPatientSearch] = useState("");
  const [selectedPatient, setSelectedPatient] = useState<SelectedPatient | null>(null);
  const [manualType, setManualType] = useState<VisitType>("session");
  const [manualDate, setManualDate] = useState(todayInRiyadh());
  const [manualAssignedStaff, setManualAssignedStaff] = useState("");
  const [manualNotes, setManualNotes] = useState("");
  const [editing, setEditing] = useState<FollowUpDraft | null>(null);
  const followUpsQuery = trpc.admin.followUps.useQuery();
  const patientsQuery = trpc.admin.patients.useQuery({ query: patientSearch || undefined }, { enabled: showCreate });
  const refresh = async () => Promise.all([utils.admin.followUps.invalidate(), utils.admin.reminders.invalidate(), utils.admin.sessionRecords.invalidate()]);
  const track = trpc.admin.trackLegacyFollowUp.useMutation({ onSuccess: async () => { toast.success("Legacy reminder is now an actionable follow-up."); await refresh(); }, onError: error => toast.error(error.message) });
  const create = trpc.admin.createManualFollowUp.useMutation({ onSuccess: async () => { toast.success("Follow-up created."); setShowCreate(false); setSelectedPatient(null); setManualNotes(""); await refresh(); }, onError: error => toast.error(error.message) });
  const update = trpc.admin.updateFollowUp.useMutation({ onSuccess: async () => { toast.success("Follow-up updated."); setEditing(null); await refresh(); }, onError: error => toast.error(error.message) });
  const allRows = followUpsQuery.data ?? [];
  const rows = useMemo(() => allRows.filter(row => filter === "open" ? row.queueStatus !== "completed" && row.queueStatus !== "cancelled" : row.queueStatus === filter), [allRows, filter]);
  const metrics = { open: allRows.filter(row => row.queueStatus !== "completed" && row.queueStatus !== "cancelled").length, due: allRows.filter(row => row.queueStatus === "due").length, overdue: allRows.filter(row => row.queueStatus === "overdue").length, completed: allRows.filter(row => row.queueStatus === "completed").length };
  const filters: Array<{ value: FollowUpFilter; label: string }> = [{ value: "open", label: "Open" }, { value: "due", label: "Due today" }, { value: "upcoming", label: "Upcoming" }, { value: "overdue", label: "Overdue" }, { value: "unscheduled", label: "Needs date" }, { value: "completed", label: "Completed" }, { value: "cancelled", label: "Cancelled" }];

  return <div className="mx-auto max-w-7xl">
    <AdminPageHeader eyebrow="Clinic follow-up · private" title="Follow-Ups" description="Create, assign, contact, reschedule, complete, and document follow-up work without inferring clinical timing or sending automatic messages." action={<div className="flex flex-wrap gap-2"><Button variant="outline" onClick={() => setLocation("/admin/sessions")}><ChevronLeft className="mr-2 size-4" />Sessions</Button><Button variant="outline" onClick={() => printTable("Follow-up queue", ["Patient", "MRN", "Type", "Due", "Queue", "Workflow", "Assigned", "Outcome"], rows.map(row => [row.patientName, row.mrn ?? "—", row.followUpType, row.dueDate ?? "—", row.queueStatus, row.status, row.assignedStaff ?? "—", row.outcome ?? "—"]))}><Printer className="mr-2 size-4" />Print queue</Button><Button onClick={() => { setShowCreate(value => !value); setEditing(null); }}><ClipboardPlus className="mr-2 size-4" />New follow-up</Button></div>} />
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4"><AdminMetricCard label="Open" value={metrics.open} note="Pending or contacted" icon={CalendarClock} /><AdminMetricCard label="Due today" value={metrics.due} note="Explicit staff-entered dates" icon={CalendarCheck2} tone="success" /><AdminMetricCard label="Overdue" value={metrics.overdue} note="Requires staff review" icon={CalendarClock} tone="warning" /><AdminMetricCard label="Completed" value={metrics.completed} note="Outcome retained" icon={CheckCircle2} /></div>
    {showCreate ? <section className="mt-6 border border-[#a85438]/25 bg-[#fffaf5] p-4 sm:p-6"><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="admin-eyebrow">Manual follow-up</p><h2 className="mt-1 font-display text-2xl text-[#102032]">Choose an existing patient</h2><p className="mt-1 text-sm text-[#52606B]">This creates a clinic task only. It does not create an appointment or send a message.</p></div><Button size="icon" variant="ghost" aria-label="Close follow-up creator" onClick={() => { setShowCreate(false); setSelectedPatient(null); }}><X className="size-4" /></Button></div><div className="relative mt-4 max-w-xl"><Search className="pointer-events-none absolute left-3 top-3 size-4 text-[#66727A]" /><Input className="pl-9" value={patientSearch} onChange={event => setPatientSearch(event.target.value)} placeholder="Search patient name, MRN, or WhatsApp" /></div>{patientsQuery.isLoading ? <AdminLoadingState label="Loading patients…" /> : <div className="mt-4 grid max-h-56 gap-2 overflow-y-auto sm:grid-cols-2">{patientsQuery.data?.slice(0, 20).map(patient => <button key={patient.id} onClick={() => setSelectedPatient({ id: patient.id, fullName: patient.fullName, mrn: patient.mrn, whatsapp: patient.whatsapp })} className={`border p-3 text-left ${selectedPatient?.id === patient.id ? "border-[#a85438] bg-white" : "border-[#102032]/10 bg-white/70"}`}><p className="font-semibold text-[#102032]">{patient.fullName}</p><p className="mt-1 text-xs text-[#66727A]">MRN: {patient.mrn ?? "Not recorded"}</p></button>)}</div>}<div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4"><label className={`${labelClass} sm:col-span-2`}>Selected patient<Input value={selectedPatient ? `${selectedPatient.fullName} · ${selectedPatient.mrn ?? "No MRN"}` : ""} readOnly placeholder="Choose a patient above" /></label><label className={labelClass}>Follow-up type<select className={fieldClass} value={manualType} onChange={event => setManualType(event.target.value as VisitType)}><option value="session">Session</option><option value="retouch">Retouch</option></select></label><label className={labelClass}>Due date<Input type="date" value={manualDate} onChange={event => setManualDate(event.target.value)} /></label><label className={`${labelClass} sm:col-span-2`}>Assigned staff<Input value={manualAssignedStaff} onChange={event => setManualAssignedStaff(event.target.value)} /></label><label className={`${labelClass} sm:col-span-2`}>Private note<textarea className={textAreaClass} value={manualNotes} onChange={event => setManualNotes(event.target.value)} /></label></div><div className="mt-5 flex gap-2"><Button disabled={!selectedPatient || !manualDate || create.isPending} onClick={() => selectedPatient && create.mutate({ patientId: selectedPatient.id, followUpType: manualType, dueDate: manualDate, assignedStaff: manualAssignedStaff, notes: manualNotes })}>{create.isPending ? <Loader2 className="mr-2 size-4 animate-spin" /> : <ClipboardPlus className="mr-2 size-4" />}Create follow-up</Button><Button variant="outline" onClick={() => setShowCreate(false)}>Cancel</Button></div></section> : null}
    <section className="mt-6 border border-[#102032]/10 bg-white"><div className="flex flex-wrap gap-2 border-b border-[#102032]/10 p-4 sm:p-5">{filters.map(item => <Button key={item.value} size="sm" variant={filter === item.value ? "default" : "outline"} onClick={() => setFilter(item.value)}>{item.label}</Button>)}</div>
      {followUpsQuery.isLoading ? <AdminLoadingState label="Loading follow-ups…" /> : followUpsQuery.isError ? <AdminErrorState title="Follow-Ups could not be loaded" description={followUpsQuery.error.message} /> : rows.length === 0 ? <AdminEmptyState icon={CalendarClock} title="No matching follow-ups" description="Create a manual follow-up or add one while recording a session." /> : <div>{rows.map(row => <article key={`${row.kind}-${row.id}`} className="border-b border-[#102032]/10 p-4 last:border-0 sm:p-5"><div className="grid gap-4 lg:grid-cols-[1.25fr_0.9fr_0.8fr_auto] lg:items-center"><div><div className="flex flex-wrap items-center gap-2"><h3 className="font-display text-xl text-[#102032]">{row.patientName}</h3><WhatsAppBusinessWebAction phone={row.whatsapp} patientName={row.patientName} subjectType={row.kind === "legacy" ? "appointment" : "follow_up"} subjectId={row.kind === "legacy" ? row.appointmentId : row.id} /><StatusBadge value={row.queueStatus} /><StatusBadge value={row.status} />{row.kind === "legacy" ? <Badge variant="outline">Legacy appointment reminder</Badge> : null}</div><p className="mt-1 text-xs text-[#66727A]">MRN: {row.mrn ?? "Not recorded"} · {row.followUpType === "retouch" ? "Retouch" : "Session"}</p></div><div><p className="text-sm font-semibold text-[#102032]">{row.dueDate ?? "Date not scheduled"}</p><p className="mt-1 text-xs text-[#66727A]">Assigned: {row.assignedStaff ?? "Unassigned"}</p></div><p className="text-sm text-[#52606B] line-clamp-2">{row.outcome || row.notes || "No outcome or note recorded."}</p><div className="flex flex-wrap gap-2">{row.kind === "legacy" ? <Button size="sm" disabled={track.isPending} onClick={() => track.mutate({ appointmentId: row.appointmentId })}>Start tracking</Button> : <Button size="sm" variant="outline" onClick={() => setEditing({ id: row.id, followUpType: row.followUpType, dueDate: row.dueDate ?? "", status: row.status, assignedStaff: row.assignedStaff ?? "", outcome: row.outcome ?? "", notes: row.notes ?? "" })}><Pencil className="mr-2 size-4" />Manage</Button>}<Button size="sm" variant="ghost" onClick={() => setLocation("/admin/patients")}><UserRound className="mr-2 size-4" />Patients</Button></div></div>
        {row.kind === "tracked" && editing?.id === row.id ? <div className="mt-5 border border-[#102032]/10 bg-[#f8f5ef] p-4"><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4"><label className={labelClass}>Due date<Input type="date" value={editing!.dueDate} onChange={event => setEditing({ ...editing!, dueDate: event.target.value })} /></label><label className={labelClass}>Type<select className={fieldClass} value={editing!.followUpType} onChange={event => setEditing({ ...editing!, followUpType: event.target.value as VisitType })}><option value="session">Session</option><option value="retouch">Retouch</option></select></label><label className={labelClass}>Workflow status<select className={fieldClass} value={editing!.status} onChange={event => setEditing({ ...editing!, status: event.target.value as FollowUpStatus })}><option value="pending">Pending</option><option value="contacted">Contacted</option><option value="completed">Completed</option><option value="cancelled">Cancelled</option></select></label><label className={labelClass}>Assigned staff<Input value={editing!.assignedStaff} onChange={event => setEditing({ ...editing!, assignedStaff: event.target.value })} /></label><label className={`${labelClass} sm:col-span-2`}>Outcome<textarea className={textAreaClass} value={editing!.outcome} onChange={event => setEditing({ ...editing!, outcome: event.target.value })} placeholder="Required when completed" /></label><label className={`${labelClass} sm:col-span-2`}>Private notes<textarea className={textAreaClass} value={editing!.notes} onChange={event => setEditing({ ...editing!, notes: event.target.value })} /></label></div><div className="mt-4 flex flex-wrap gap-2"><Button disabled={update.isPending || (editing!.status === "completed" && !editing!.outcome.trim())} onClick={() => update.mutate({ id: editing!.id, followUpType: editing!.followUpType, dueDate: editing!.dueDate || null, status: editing!.status, assignedStaff: editing!.assignedStaff, outcome: editing!.outcome, notes: editing!.notes })}>{update.isPending ? <Loader2 className="mr-2 size-4 animate-spin" /> : <CheckCircle2 className="mr-2 size-4" />}Save follow-up</Button><Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button></div></div> : null}
      </article>)}</div>}
    </section>
  </div>;
}
