import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

const read = (file: string) =>
  fs.readFileSync(path.resolve(process.cwd(), file), "utf8");
const requests = read("client/src/pages/AdminRequestsWorkspace.tsx");
const whatsapp = read("client/src/pages/WhatsAppWorkspace.tsx");
const revenue = read("client/src/pages/RevenueWorkspace.tsx");
const operations = read("client/src/pages/AdminOperations.tsx");
const portal = read("client/src/pages/AdminPortal.tsx");
const css = read("client/src/index.css");
const cmsManager = read("client/src/pages/CmsManager.tsx");
const cmsCatalogues = read("client/src/pages/CmsCatalogues.tsx");
const cmsEducation = read("client/src/pages/CmsEducation.tsx");
const contentCalendar = read("client/src/pages/ContentCalendar.tsx");
const skeleton = read("client/src/components/ui/skeleton.tsx");

describe("authenticated workspace visual redesign", () => {
  it("keeps the protected request workflow while adopting the shared page hierarchy", () => {
    expect(requests).toContain("AdminPageHeader");
    expect(requests).toContain("AdminFilterBar");
    expect(requests).toContain("AdminLoadingState");
    expect(requests).toContain("AdminEmptyState");
    expect(requests).toContain('className="admin-surface overflow-hidden"');
    expect(requests).toContain("Review & approve");
    expect(requests).toContain("onApprove");
    expect(requests).toContain("transferPayload");
  });

  it("adopts the shared WhatsApp header and tab surface without removing provider safeguards", () => {
    expect(whatsapp).toContain("AdminPageHeader");
    expect(whatsapp).toContain("admin-surface mb-5");
    expect(whatsapp).toContain("serviceWindowOpen");
    expect(whatsapp).toContain("Provider-ready architecture");
    expect(whatsapp).toContain("Enable verified automation");
  });

  it("adopts shared financial and analytics metrics while retaining existing data contracts", () => {
    expect(revenue).toContain("AdminMetricCard");
    expect(revenue).toContain("HMS remains the source of truth");
    expect(operations).toContain("AdminMetricCard");
    expect(operations).toContain("Privacy-conscious reporting");
    expect(operations).toContain('Metric label="Social clicks"');
    expect(operations).toContain('Ranked title="Social platforms"');
  });

  it("keeps the selected-date HMS appointment and patient workflows while refining their responsive surfaces", () => {
    expect(portal).toContain('aria-label="Confirmed HMS appointments for selected date"');
    expect(portal).toContain("refetchInterval: 5_000");
    expect(portal).toContain('appointment.source !== "hms_csv"');
    expect(portal).toContain('appointment.status !== "confirmed"');
    expect(portal).toContain('aria-label="Appointment date"');
    expect(portal).toContain("Machine review required");
    expect(portal).toContain("HmsImportPanel");
    expect(portal).toContain("selectedPatientId");
    expect(css).toContain("button.w-full.border.p-5");
  });

  it("retains all clinic and management destinations behind the existing role gates", () => {
    for (const path of [
      "/admin/appointments",
      "/admin/sessions",
      "/admin/follow-ups",
      "/admin/hms",
      "/admin/waiting-list",
      "/admin/patients",
      "/admin/machines",
      "/admin/notifications",
      "/admin/activity",
      "/admin/security",
      "/admin/settings",
      "/admin/data",
      "/admin/redirects",
    ]) {
      expect(portal).toContain(path);
    }
    expect(portal).toContain('user.role !== "owner"');
    expect(portal).toContain("receptionPages.includes(page)");
    expect(portal).toContain('group: "Communication"');
    expect(portal).toContain('group: "Content"');
  });

  it("uses the shared page hierarchy across CMS, catalogue, education, and management workspaces", () => {
    expect(cmsManager).toContain("AdminPageHeader");
    expect(cmsCatalogues).toContain("AdminPageHeader");
    expect(cmsEducation).toContain("AdminPageHeader");
    expect(operations).toContain("AdminPageHeader");
    expect(revenue).toContain("AdminPageHeader");
    expect(whatsapp).toContain("AdminPageHeader");
    expect(cmsManager).toContain("AdminLoadingState");
    expect(cmsManager).toContain("AdminEmptyState");
    expect(cmsManager).toContain("AdminErrorState");
    expect(cmsManager).toContain("data-admin-no-translate");
    expect(cmsManager).toContain("label={`Loading ${label.toLowerCase()}…`}");
  });

  it("keeps explicit loading, empty, error, and retry states for protected management queries", () => {
    expect(cmsManager).toContain("if (activeQuery.isLoading)");
    expect(cmsManager).toContain("if (activeQuery.isError)");
    expect(cmsManager).toContain("No records exist yet");
    expect(cmsManager).toContain("QueryFailure");
    expect(cmsManager).toContain("Loading staff notifications…");
    expect(cmsManager).toContain("No staff notifications yet");
    expect(cmsManager).toContain("Loading staff accounts…");
    expect(cmsManager).toContain("No staff accounts available");
    expect(operations).toContain("Analytics could not be loaded");
    expect(operations).toContain("No redirects are configured");
  });

  it("preserves task-oriented editorial review and external-action safeguards", () => {
    expect(contentCalendar).toContain("External-action safeguard");
    expect(contentCalendar).toContain("owner-authorized access");
    expect(contentCalendar).toContain(
      "Planning status never makes public or external content live"
    );
    expect(contentCalendar).toContain("trpc.cms.contentCalendarItems.useQuery");
  });

  it("preserves server-enforced integration and financial boundaries in the redesigned UI", () => {
    expect(whatsapp).toContain("serviceWindowOpen");
    expect(whatsapp).toContain("approved template");
    expect(revenue).toContain("HMS remains the source of truth");
    expect(revenue).toContain("HMS TOTAL RECONCILIATION FAILED");
    expect(portal).toContain('page === "security" && user.role !== "owner"');
  });

  it("standardizes invalid and disabled controls, dialogs, table density, touch targets, and RTL numeric fields", () => {
    expect(css).toContain(':is(input, select, textarea)[aria-invalid="true"]');
    expect(css).toContain('[role="dialog"]');
    expect(css).toContain("table th");
    expect(css).toContain('input[type="tel"]');
    expect(css).toContain("min-height: 2.75rem");
    expect(css).toContain("scroll-snap-type: x proximity");
  });

  it("ships the complete shared visual contract instead of unstyled admin primitives", () => {
    for (const selector of [
      ".admin-page-header",
      ".admin-page-title",
      ".admin-page-description",
      ".admin-surface",
      ".admin-metric-card",
      ".admin-filter-bar",
      ".admin-empty-state",
      ".admin-loading-state",
      ".admin-language-toggle",
    ]) {
      expect(css).toContain(selector);
    }
    expect(css).toContain('[data-slot="skeleton"]');
    expect(skeleton).toContain('cn("bg-muted animate-pulse rounded-md"');
  });
});
