import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const uploadField = readFileSync(new URL("../components/CmsImageUploadField.tsx", import.meta.url), "utf8");
const results = readFileSync(new URL("./ResultCasesUpload.tsx", import.meta.url), "utf8");
const promotions = readFileSync(new URL("./PromotionCatalogueUpload.tsx", import.meta.url), "utf8");
const manager = readFileSync(new URL("./CmsManager.tsx", import.meta.url), "utf8");
const education = readFileSync(new URL("./CmsEducation.tsx", import.meta.url), "utf8");

describe("CMS image upload controls", () => {
  it("uses the existing protected CMS upload contract with image-only validation", () => {
    expect(uploadField).toContain("trpc.cms.uploadMedia.useMutation");
    expect(uploadField).toContain('"image/jpeg", "image/png", "image/webp", "image/avif"');
    expect(uploadField).toContain("maximumBytes = 10_000_000");
    expect(uploadField).toContain("no image URL needs to be entered");
    expect(uploadField).toContain("altAr: altAr?.trim() || null");
  });

  it("renders upload-backed result media while retaining explicit authorization and publication controls", () => {
    expect(manager).toContain('import { ResultCases } from "./ResultCasesUpload"');
    expect(results).toContain('label="Before image"');
    expect(results).toContain('label="After image"');
    expect(results).toContain("written authorization is recorded");
    expect(results).toContain("Make this authorized case active publicly");
  });

  it("renders the Prices & Promotions uploader without restoring a manual image URL input", () => {
    expect(promotions).toContain('label="Promotion image"');
    expect(promotions).toContain("CmsImageUploadField");
    expect(promotions).not.toContain('label="Image URL"');
    expect(promotions).toContain('status: "draft"');
  });

  it("places protected upload controls directly in the Blog & AI Studio media workflow", () => {
    expect(education).toContain('import { CmsImageUploadField } from "@/components/CmsImageUploadField"');
    expect(education).toContain('label="Featured article image"');
    expect(education).toContain('label="Social preview image"');
    expect(education).toContain('altAr={form.featuredImageAltAr || form.titleAr}');
    expect(education).not.toContain('placeholder="/manus-storage/…"');
  });
});
