import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const source = readFileSync(resolve(process.cwd(), "client/src/pages/PublicContent.tsx"), "utf8");
const guideDetail = readFileSync(resolve(process.cwd(), "client/src/pages/PublicGuidePost.tsx"), "utf8");
const app = readFileSync(resolve(process.cwd(), "client/src/App.tsx"), "utf8");
const policyDetail = readFileSync(resolve(process.cwd(), "client/src/pages/PublicPolicy.tsx"), "utf8");

describe("public CMS content rendering", () => {
  it("keeps published treatment preparation and aftercare accessible from the existing card layout", () => {
    expect(source).toContain("Preparation & aftercare");
    expect(source).toContain("item.preparationEn");
    expect(source).toContain("item.aftercareEn");
  });

  it("links published cards to canonical bilingual blog routes with rich content and social sharing", () => {
    expect(source).toContain("guidePath(item, arabic)");
    expect(source).toContain('/blog/${encodeURIComponent(item.slug)}');
    expect(guideDetail).toContain("<ArticleBody content={body}");
    expect(guideDetail).toContain("publicContent.guidePostBySlug");
    expect(guideDetail).toContain("linkedin.com/sharing/share-offsite");
    expect(guideDetail).toContain("facebook.com/sharer/sharer.php");
    expect(guideDetail).toContain("twitter.com/intent/tweet");
    expect(guideDetail).toContain("guide.socialCaptionEn");
    expect(guideDetail).toContain('setProperty("og:title"');
    expect(guideDetail).toContain('setMeta("twitter:url"');
    expect(app).toContain('path={"/en/blog/:slug"}');
    expect(app).toContain('path={"/ar/blog/:slug"}');
    expect(guideDetail).toContain("noindex, follow, noarchive");
    expect(policyDetail).toContain("noindex, follow, noarchive");
  });
});
