import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const revenue = readFileSync(new URL("./RevenueWorkspace.tsx", import.meta.url), "utf8");
const adminPortal = readFileSync(new URL("./AdminPortal.tsx", import.meta.url), "utf8");
const app = readFileSync(new URL("../App.tsx", import.meta.url), "utf8");
const routers = readFileSync(new URL("../../../server/routers.ts", import.meta.url), "utf8");
const schema = readFileSync(new URL("../../../drizzle/schema.ts", import.meta.url), "utf8");

describe("selective revenue port", () => {
  it("keeps the donor revenue workspace focused on governed HMS reporting", () => {
    expect(revenue).toContain("Upload, review, then import");
    expect(revenue).toContain("Step 3 — Import all service rows");
    expect(revenue).toContain("Reporting detail and import history");
    expect(revenue).toContain("Daily revenue");
    expect(revenue).toContain("By patient");
    expect(revenue).toContain("By service");
    expect(revenue).toContain("Import history");
    expect(revenue).toContain("revenuePreview");
    expect(revenue).toContain("revenueImport");
    expect(revenue).toContain("HMS remains the source of truth");
  });

  it("registers revenue behind the existing protected owner/admin portal boundary", () => {
    expect(adminPortal).toContain('"revenue"');
    expect(adminPortal).toContain('path: "/admin/revenue"');
    expect(adminPortal).toContain('page === "revenue" ? <RevenueWorkspace />');
    expect(adminPortal).toContain('page === "revenue" || clinicalWorkflowPage');
    expect(app).toContain('path={"/admin/revenue"}');
  });

  it("uses the current MySQL/TiDB revenue contract and preserves HMS source safeguards", () => {
    expect(routers).toContain("revenuePreview");
    expect(routers).toContain("revenueImport");
    expect(schema).toContain('mysqlTable("revenueImportBatches"');
    expect(schema).toContain('mysqlTable("revenueTransactions"');
    expect(routers).not.toContain("postgres");
  });
});
