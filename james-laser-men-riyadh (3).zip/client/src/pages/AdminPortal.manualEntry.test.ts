import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("Admin manual patient and appointment entry", () => {
  it("keeps requested manual-entry controls in their protected portal pages", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/AdminPortal.tsx"), "utf8");
    expect(source).toContain("Add patient");
    expect(source).toContain("Add appointment");
    expect(source).toContain("MRN (manual)");
    expect(source).toContain("Nationality");
    expect(source).toContain("Contact number");
    expect(source).toContain("WhatsApp number");
    expect(source).toContain("Email address");
    expect(source).toContain("manualAppointmentTimes");
    expect(source).toContain("1:00 PM through 10:00 PM");
    expect(source).toContain("manualAppointmentTreatmentAreas");
    expect(source).toContain("DEKA AGAIN");
    expect(source).toContain("Session");
    expect(source).toContain("Retouch");
    expect(source).toContain("trpc.admin.createManualPatient.useMutation");
    expect(source).toContain("trpc.admin.createManualAppointment.useMutation");
    expect(source).toContain("This does not create an appointment or public request.");
    expect(source).toContain("This does not create a public request, patient file, consent, or e-signature.");
  });
});
