import { ArrowUpRight, CalendarDays, Clock3, Search, ShieldCheck } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { PublicSiteHeader } from "@/components/PublicSiteHeader";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { publicUrl } from "@/seo";

type Locale = "en" | "ar";
type BlogPost = {
  id: number;
  slug: string;
  titleEn: string;
  titleAr?: string | null;
  summaryEn?: string | null;
  summaryAr?: string | null;
  contentEn?: string | null;
  contentAr?: string | null;
  category?: string | null;
  tags?: string | null;
  featuredImageUrl?: string | null;
  featuredImageAltEn?: string | null;
  featuredImageAltAr?: string | null;
  isClinicallyReviewed: boolean;
  isFeatured: boolean;
  publishedAt?: Date | null;
};

function localized(en: string | null | undefined, ar: string | null | undefined, arabic: boolean) {
  return arabic ? ar || en || "" : en || ar || "";
}

function hasArabic(post: BlogPost) {
  return Boolean(post.titleAr?.trim() && (post.summaryAr?.trim() || post.contentAr?.trim()));
}

function postPath(post: BlogPost, arabic: boolean) {
  const locale = arabic && hasArabic(post) ? "ar" : "en";
  return `/${locale}/blog/${encodeURIComponent(post.slug)}`;
}

function readingMinutes(content: string | null | undefined, arabic: boolean) {
  const words = (content || "").trim().split(/\s+/).filter(Boolean).length;
  const minutes = Math.max(2, Math.ceil(words / (arabic ? 170 : 210)));
  return arabic ? `${minutes} دقائق قراءة` : `${minutes} min read`;
}

function publishedLabel(value: Date | null | undefined, arabic: boolean) {
  if (!value) return arabic ? "منشور" : "Published";
  return new Intl.DateTimeFormat(arabic ? "ar-SA" : "en-SA", { day: "numeric", month: "long", year: "numeric", timeZone: "Asia/Riyadh" }).format(new Date(value));
}

export default function BlogIndex({ locale = "en" }: { locale?: Locale }) {
  const arabic = locale === "ar";
  const clinic = trpc.publicContent.clinicSettings.useQuery();
  const posts = trpc.publicContent.guidePosts.useQuery();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const pathname = arabic ? "/ar/blog" : "/en/blog";
  const title = arabic ? "مدونة إزالة الشعر بالليزر للرجال في الرياض | جيمس ليزر" : "Men’s Laser Hair Removal Blog Riyadh | James Laser";
  const description = arabic
    ? "مقالات مراجعة من العيادة عن إزالة الشعر بالليزر للرجال في الرياض، تشمل التحضير والعناية اللاحقة ومناطق العلاج والتوقعات الواقعية."
    : "Clinic-reviewed articles about men’s laser hair removal in Riyadh, including preparation, aftercare, treatment areas, and realistic expectations.";

  useEffect(() => {
    document.title = title;
    const setMeta = (selector: string, attribute: "name" | "property", key: string, content: string) => {
      const element = document.querySelector(selector) || document.head.appendChild(document.createElement("meta"));
      element.setAttribute(attribute, key);
      element.setAttribute("content", content);
    };
    setMeta('meta[name="description"]', "name", "description", description);
    setMeta('meta[property="og:title"]', "property", "og:title", title);
    setMeta('meta[property="og:description"]', "property", "og:description", description);
    setMeta('meta[property="og:url"]', "property", "og:url", publicUrl(pathname));
    const canonical = document.querySelector('link[rel="canonical"]') || document.head.appendChild(document.createElement("link"));
    canonical.setAttribute("rel", "canonical");
    canonical.setAttribute("href", publicUrl(pathname));
  }, [description, pathname, title]);

  const published = (posts.data ?? []) as BlogPost[];
  const categories = useMemo(() => Array.from(new Set(published.map(post => post.category?.trim()).filter((value): value is string => Boolean(value)))).sort(), [published]);
  const filtered = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase();
    return published.filter(post => {
      if (category !== "all" && post.category !== category) return false;
      if (!needle) return true;
      return [post.titleEn, post.titleAr, post.summaryEn, post.summaryAr, post.category, post.tags].some(value => value?.toLocaleLowerCase().includes(needle));
    });
  }, [category, published, query]);
  const featured = filtered.find(post => post.isFeatured) ?? filtered[0];
  const remaining = featured ? filtered.filter(post => post.id !== featured.id) : [];

  return (
    <main lang={locale} dir={arabic ? "rtl" : "ltr"} className={`blog-index min-h-screen bg-[#F7F3EC] text-[#102032] ${arabic ? "arabic-public-page" : ""}`}>
      <PublicSiteHeader locale={locale} active="blog" />
      <section className="relative overflow-hidden border-b border-[#102032]/10 bg-[#102032] text-white">
        <div className="blog-hero-grid absolute inset-0 opacity-25" aria-hidden="true" />
        <div className="relative mx-auto grid max-w-7xl gap-10 px-4 py-16 sm:px-6 sm:py-20 lg:grid-cols-[1.15fr_0.7fr] lg:px-8 lg:py-24">
          <div>
            <p className="text-[10px] font-extrabold uppercase tracking-[0.22em] text-[#EAB394]">{arabic ? "نيو لوك كلينيك · حي الصحافة" : "New Look Clinic · As Sahafah"}</p>
            <h1 className={`mt-5 max-w-4xl text-5xl tracking-[-0.055em] sm:text-6xl lg:text-7xl ${arabic ? "font-sans font-extrabold leading-[1.18]" : "font-display leading-[0.94]"}`}>{arabic ? "دليل واضح لليزر الرجال في الرياض" : "Clear answers for men considering laser in Riyadh."}</h1>
            <p className="mt-6 max-w-2xl text-base leading-8 text-white/70">{description}</p>
          </div>
          <aside className="self-end border-s border-white/15 ps-6">
            <p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#EAB394]">{arabic ? "منهج التحرير" : "Editorial standard"}</p>
            <p className="mt-4 text-xl leading-8 text-white/90">{arabic ? "معلومات تثقيفية متزنة، بلا وعود بالنتائج أو أسعار مخترعة، مع إظهار حالة المراجعة لكل مقال." : "Measured education without invented prices or outcome promises, with review status shown for each article."}</p>
            <div className="mt-6 flex items-center gap-2 text-xs font-semibold text-white/60"><ShieldCheck className="size-4 text-[#EAB394]" />{arabic ? "محتوى تثقيفي منشور" : "Published educational content"}</div>
          </aside>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="grid gap-4 border-y border-[#102032]/10 py-5 lg:grid-cols-[1fr_auto] lg:items-center">
          <label className="relative block max-w-xl">
            <Search className="pointer-events-none absolute start-4 top-1/2 size-4 -translate-y-1/2 text-[#66727A]" />
            <Input value={query} onChange={event => setQuery(event.target.value)} className="h-12 bg-white ps-11" placeholder={arabic ? "ابحث في المقالات" : "Search the clinic blog"} aria-label={arabic ? "ابحث في المقالات" : "Search the clinic blog"} />
          </label>
          <div className="flex flex-wrap gap-2" aria-label={arabic ? "تصنيفات المقالات" : "Article categories"}>
            <button type="button" onClick={() => setCategory("all")} aria-pressed={category === "all"} className={`blog-filter ${category === "all" ? "is-active" : ""}`}>{arabic ? "الكل" : "All"}</button>
            {categories.map(value => <button type="button" key={value} onClick={() => setCategory(value)} aria-pressed={category === value} className={`blog-filter ${category === value ? "is-active" : ""}`}>{value}</button>)}
          </div>
        </div>

        {posts.isLoading ? <div className="grid min-h-80 place-items-center text-sm text-[#52606B]">{arabic ? "جارٍ تحميل المقالات…" : "Loading articles…"}</div> : posts.isError ? <div role="alert" className="my-10 border border-red-200 bg-red-50 p-6 text-sm text-red-800">{arabic ? "تعذر تحميل المقالات المنشورة." : "Published articles could not be loaded."} <button type="button" className="font-bold underline" onClick={() => posts.refetch()}>{arabic ? "حاول مرة أخرى" : "Try again"}</button></div> : !featured ? <div className="my-10 border border-dashed border-[#102032]/20 bg-white p-8 text-sm leading-6 text-[#52606B]">{arabic ? "لا توجد مقالات مطابقة منشورة حاليًا." : "No matching published articles are available yet."}</div> : (
          <>
            <article className="mt-10 grid overflow-hidden border border-[#102032]/10 bg-white lg:grid-cols-[1.05fr_0.95fr]">
              <div className="min-h-72 bg-[#D9D0C2]">
                {featured.featuredImageUrl ? <img src={featured.featuredImageUrl} alt={localized(featured.featuredImageAltEn, featured.featuredImageAltAr, arabic) || localized(featured.titleEn, featured.titleAr, arabic)} className="h-full min-h-72 w-full object-cover" /> : <div className="blog-image-placeholder grid h-full min-h-72 place-items-end p-6"><span className="text-[10px] font-extrabold uppercase tracking-[0.2em] text-white/70">James Laser · Riyadh</span></div>}
              </div>
              <div className="flex flex-col justify-center p-7 sm:p-10 lg:p-12">
                <p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#B85E3C]">{featured.category || (arabic ? "مقال مميز" : "Featured article")}</p>
                <h2 className={`mt-4 text-4xl tracking-[-0.045em] sm:text-5xl ${arabic ? "font-sans font-extrabold leading-[1.2]" : "font-display leading-[1]"}`}>{localized(featured.titleEn, featured.titleAr, arabic)}</h2>
                <p className="mt-5 text-sm leading-7 text-[#52606B]">{localized(featured.summaryEn, featured.summaryAr, arabic)}</p>
                <div className="mt-6 flex flex-wrap gap-4 text-xs text-[#66727A]"><span className="inline-flex items-center gap-2"><CalendarDays className="size-4 text-[#B85E3C]" />{publishedLabel(featured.publishedAt, arabic)}</span><span className="inline-flex items-center gap-2"><Clock3 className="size-4 text-[#B85E3C]" />{readingMinutes(localized(featured.contentEn, featured.contentAr, arabic), arabic)}</span>{featured.isClinicallyReviewed ? <span className="inline-flex items-center gap-2"><ShieldCheck className="size-4 text-[#B85E3C]" />{arabic ? "مراجَع قبل النشر" : "Reviewed before publication"}</span> : null}</div>
                <a href={postPath(featured, arabic)} className="mt-7 inline-flex w-fit items-center gap-2 bg-[#102032] px-5 py-3 text-[11px] font-extrabold uppercase tracking-[0.14em] text-white transition hover:bg-[#B85E3C]">{arabic ? "اقرأ المقال" : "Read article"}<ArrowUpRight className={arabic ? "size-4 -scale-x-100" : "size-4"} /></a>
              </div>
            </article>

            {remaining.length ? <div className="mt-12 grid gap-5 md:grid-cols-2 xl:grid-cols-3">{remaining.map(post => <article key={post.id} className="group flex flex-col overflow-hidden border border-[#102032]/10 bg-white transition duration-200 hover:-translate-y-1 hover:shadow-[0_18px_50px_rgb(16_32_50_/_0.10)]">{post.featuredImageUrl ? <img src={post.featuredImageUrl} alt={localized(post.featuredImageAltEn, post.featuredImageAltAr, arabic) || localized(post.titleEn, post.titleAr, arabic)} className="h-48 w-full object-cover" loading="lazy" /> : <div className="blog-card-placeholder h-32" aria-hidden="true" />}<div className="flex flex-1 flex-col p-6"><p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#B85E3C]">{post.category || (arabic ? "تثقيف المرضى" : "Patient education")}</p><h2 className={`mt-3 text-3xl tracking-[-0.04em] ${arabic ? "font-sans font-extrabold leading-[1.25]" : "font-display leading-[1.05]"}`}>{localized(post.titleEn, post.titleAr, arabic)}</h2><p className="mt-4 line-clamp-3 text-sm leading-6 text-[#52606B]">{localized(post.summaryEn, post.summaryAr, arabic)}</p><div className="mt-5 flex gap-3 text-[11px] text-[#66727A]"><span>{publishedLabel(post.publishedAt, arabic)}</span><span aria-hidden="true">·</span><span>{readingMinutes(localized(post.contentEn, post.contentAr, arabic), arabic)}</span></div><a href={postPath(post, arabic)} className="mt-6 inline-flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.14em] text-[#B85E3C]">{arabic ? "متابعة القراءة" : "Continue reading"}<ArrowUpRight className={arabic ? "size-4 -scale-x-100" : "size-4"} /></a></div></article>)}</div> : null}
          </>
        )}
      </section>

      <section className="border-t border-[#102032]/10 bg-[#EDE5D8]"><div className="mx-auto grid max-w-7xl gap-6 px-4 py-10 sm:px-6 md:grid-cols-[1fr_auto] md:items-center lg:px-8"><div><p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#B85E3C]">{clinic.data?.clinicName || "New Look Clinic"} · Riyadh</p><h2 className={`mt-2 text-3xl ${arabic ? "font-sans font-extrabold" : "font-display"}`}>{arabic ? "هل تريد خطة تناسب بشرتك وشعرك؟" : "Need guidance for your skin, hair, and treatment area?"}</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-[#52606B]">{arabic ? "المقالات للتثقيف العام. تؤكد العيادة الملاءمة والخطوات الفردية بعد التقييم." : "Articles provide general education. The clinic confirms individual suitability and next steps after assessment."}</p></div><a href={arabic ? "/ar/appointment" : "/appointment"} className="inline-flex min-h-12 items-center justify-center gap-2 bg-[#B85E3C] px-5 text-xs font-extrabold uppercase tracking-[0.14em] text-white">{arabic ? "طلب موعد" : "Request appointment"}<ArrowUpRight className={arabic ? "size-4 -scale-x-100" : "size-4"} /></a></div></section>
    </main>
  );
}
