import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const source = readFileSync(
  resolve(process.cwd(), "client/src/pages/CmsManager.tsx"),
  "utf8"
);

describe("Google Business review sync feedback", () => {
  it("keeps a persistent accessible progress state during synchronization", () => {
    expect(source).toContain("Syncing reviews securely");
    expect(source).toContain('role="status"');
    expect(source).toContain("Keep this page open");
    expect(source).toContain("nothing is published or changed");
    expect(source).toContain("on Google while the private moderation queue refreshes");
  });

  it("shows safe recovery guidance and a retry control after a sync failure", () => {
    expect(source).toContain("getGoogleBusinessSyncFeedback");
    expect(source).toContain("Review sync did not finish. Review the recovery guidance below.");
    expect(source).toContain('role="alert"');
    expect(source).toContain("Retrying sync…");
  });
});
