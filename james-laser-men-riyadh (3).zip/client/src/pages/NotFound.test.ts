import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const page = readFileSync(resolve(process.cwd(), "client/src/pages/NotFound.tsx"), "utf8");

describe("branded public 404 recovery", () => {
  it("keeps recovery actions public and offers localized home, treatments, appointment, and WhatsApp paths", () => {
    expect(page).toContain('location.startsWith("/ar")');
    expect(page).toContain('"/ar/treatments"');
    expect(page).toContain('"/ar/appointment"');
    expect(page).toContain("https://wa.me/966557401562");
    expect(page).toContain("Request appointment");
    expect(page).toContain("متابعة آمنة");
    expect(page).not.toContain('"/admin');
  });

  it("retains the request-versus-confirmed-appointment disclosure", () => {
    expect(page).toContain("before availability is confirmed");
    expect(page).toContain("قبل تأكيد التوفر");
  });
});
