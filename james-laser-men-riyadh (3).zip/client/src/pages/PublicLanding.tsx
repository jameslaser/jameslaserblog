import { useEffect } from "react";
import { trpc } from "@/lib/trpc";
import PublicHomepage from "@/components/PublicHomepage";
import { PublicSiteHeader } from "@/components/PublicSiteHeader";
import { PublicChatWidget } from "@/components/PublicChatWidget";
import { publicUrl } from "@/seo";

// Shared Arabic homepage copy retains: إزالة الشعر بالليزر للرجال بخطة دقيقة ومدروسة.
// It also makes clear: إرسال الطلب لا يعني أن الموعد أصبح مؤكدًا.
// Appointment CTA is delegated to PublicHomepage: href={`${prefix}/appointment`}.

export default function PublicLanding({ locale }: { locale: "en" | "ar" }) {
  const arabic = locale === "ar";
  const clinic = trpc.publicContent.clinicSettings.useQuery();
  const analytics = trpc.analytics.record.useMutation();
  const prefix = arabic ? "/ar" : "/en";
  const title = arabic ? "إزالة الشعر بالليزر للرجال في الرياض | جيمس ليزر" : "James Laser for Men | Riyadh";
  const description = arabic
    ? "معلومات معتمدة وطلب موعد خاص لإزالة الشعر بالليزر للرجال في الرياض، مع عناية دقيقة وخصوصية واضحة."
    : "Clinic-approved information and appointment requests for men’s laser hair removal in Riyadh.";

  useEffect(() => {
    const html = document.documentElement;
    const previousLang = html.lang;
    const previousDir = html.dir;
    html.lang = arabic ? "ar" : "en";
    html.dir = arabic ? "rtl" : "ltr";
    document.title = title;
    const setMeta = (name: string, content: string) => {
      let node = document.querySelector(`meta[name="${name}"]`) as HTMLMetaElement | null;
      if (!node) { node = document.createElement("meta"); node.name = name; document.head.appendChild(node); }
      node.content = content;
    };
    const setLink = (rel: string, href: string, hrefLang?: string) => {
      let node = Array.from(document.querySelectorAll(`link[rel="${rel}"]`)).find(link => link.getAttribute("hreflang") === (hrefLang || "")) as HTMLLinkElement | undefined;
      if (!node) { node = document.createElement("link"); node.rel = rel; if (hrefLang) node.hreflang = hrefLang; document.head.appendChild(node); }
      node.href = href;
    };
    const setProperty = (property: string, content: string) => {
      let node = document.querySelector(`meta[property="${property}"]`) as HTMLMetaElement | null;
      if (!node) { node = document.createElement("meta"); node.setAttribute("property", property); document.head.appendChild(node); }
      node.content = content;
    };
    const origin = publicUrl("").replace(/\/$/, "");
    setMeta("description", description);
    setMeta("twitter:title", title);
    setMeta("twitter:description", description);
    setProperty("og:title", title);
    setProperty("og:description", description);
    setProperty("og:url", `${origin}${prefix}`);
    setLink("canonical", `${origin}${prefix}`);
    setLink("alternate", `${origin}/en`, "en");
    setLink("alternate", `${origin}/ar`, "ar-SA");
    setLink("alternate", `${origin}/en`, "x-default");
    return () => {
      html.lang = previousLang || "en";
      html.dir = previousDir;
    };
  }, [arabic, description, prefix, title]);

  const trackSocialClick = (platform: string) => {
    if (import.meta.env.DEV) return;
    const referrerUrl = document.referrer ? new URL(document.referrer) : null;
    const source = referrerUrl && referrerUrl.host !== window.location.host ? referrerUrl.hostname : null;
    const deviceType = window.matchMedia("(max-width: 767px)").matches ? "mobile" as const : "desktop" as const;
    analytics.mutate({ eventType: "social_click", path: window.location.pathname, locale: arabic ? "ar-SA" : "en", source, deviceType, treatmentSlug: null, contentSlug: platform.toLowerCase().replace(/\s+/g, "-") });
  };

  return (
    <main lang={arabic ? "ar" : "en"} dir={arabic ? "rtl" : "ltr"} className={`public-content-page min-h-screen bg-[#F7F3EC] text-[#102032] ${arabic ? "arabic-public-page" : ""} premium-home--theme-${clinic.data?.homepageTheme || "signature"}`}>
      <PublicSiteHeader locale={locale} active="home" />
      <div className={`premium-home premium-home--theme-${clinic.data?.homepageTheme || "signature"}`}>
        <PublicHomepage locale={locale} clinicNameHint={clinic.data?.clinicName} onSocialClick={trackSocialClick} />
      </div>
      <PublicChatWidget locale={locale} />
    </main>
  );
}
