// @vitest-environment jsdom
import { act, createElement } from "react";
import { cleanup, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";

(globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

const mocks = vi.hoisted(() => ({
  appointmentOptions: null as { onError?: (error: Error) => void } | null,
  mutate: vi.fn(),
  reset: vi.fn(),
  analyticsMutate: vi.fn(),
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    publicContent: { clinicSettings: { useQuery: () => ({ data: { clinicName: "New Look Clinic", whatsapp: "+966557401562", appointmentFormEnabled: true } }) } },
    analytics: { record: { useMutation: () => ({ mutate: mocks.analyticsMutate }) } },
    appointmentRequest: { create: { useMutation: (options: { onError?: (error: Error) => void }) => { mocks.appointmentOptions = options; return { mutate: mocks.mutate, reset: mocks.reset, isPending: false }; } } },
  },
}));

vi.mock("@/components/AppointmentConsentWorkflow", async () => {
  const React = await vi.importActual<typeof import("react")>("react");
  return {
    default: ({ onReadComplete, onAcknowledgementChange, onSignatureChange }: { onReadComplete: () => void; onAcknowledgementChange: (value: boolean) => void; onSignatureChange: (value: string) => void }) => React.createElement("button", { type: "button", onClick: () => { onReadComplete(); onAcknowledgementChange(true); onSignatureChange("data:image/png;base64,AA=="); } }, "Complete consent and signature"),
  };
});

vi.mock("wouter", async () => {
  const React = await vi.importActual<typeof import("react")>("react");
  return {
    Link: ({ children, href, className }: { children: React.ReactNode; href: string; className?: string }) => React.createElement("a", { href, className }, children),
    useLocation: () => ["/appointment", vi.fn()],
  };
});

import AppointmentRequest from "./AppointmentRequest";

describe("AppointmentRequest failed submission recovery", () => {
  beforeEach(() => {
    cleanup();
    mocks.appointmentOptions = null;
    mocks.mutate.mockReset();
    mocks.reset.mockReset();
    mocks.analyticsMutate.mockReset();
  });

  it("keeps English appointment values and renders Retry plus WhatsApp after a mocked failure", async () => {
    const user = userEvent.setup();
    render(createElement(AppointmentRequest, { locale: "en" }));

    expect(document.title).toBe("Men’s Laser Hair Removal Appointment Riyadh | James Laser");
    expect(document.querySelector('meta[name="description"]')?.getAttribute("content")).toContain("private men’s laser hair removal appointment request");
    expect(document.querySelector('link[rel="canonical"]')?.getAttribute("href")).toContain("/appointment");

    await user.type(screen.getByLabelText("Full Name *"), "Test Client");
    await user.clear(screen.getByLabelText("Mobile / WhatsApp Number *"));
    await user.type(screen.getByLabelText("Mobile / WhatsApp Number *"), "+966 501234567");
    await user.type(screen.getByLabelText("Nationality *"), "Saudi Arabian");
    const timeSelect = screen.getAllByRole("combobox").find(element => element.tagName === "SELECT") as HTMLSelectElement;
    await user.selectOptions(timeSelect, "18:15");
    await user.click(screen.getByLabelText("Full Face"));
    await user.click(screen.getByRole("button", { name: "Complete consent and signature" }));
    await user.click(screen.getByLabelText(/I confirm that the information I provided is accurate/));
    await user.click(screen.getByLabelText(/I understand this is an appointment request only/));
    await user.click(screen.getByLabelText(/I have read and agree to the Privacy Policy/));
    await user.click(screen.getByLabelText(/I explicitly agree that the clinic may use the health-screening information/));
    await user.click(screen.getByRole("button", { name: "Request Appointment" }));
    await user.click(screen.getByRole("button", { name: "Request Appointment" }));

    expect(mocks.mutate).toHaveBeenCalledOnce();
    await act(async () => { mocks.appointmentOptions?.onError?.(new Error("mocked failure")); });

    expect(screen.getByRole("alert").textContent).toContain("We couldn’t submit your request");
    expect(screen.getByRole("button", { name: "Try again" })).toBeTruthy();
    expect(screen.getByRole("link", { name: "Contact via WhatsApp" }).getAttribute("href")).toBe("https://wa.me/966557401562");
    expect((screen.getByLabelText("Full Name *") as HTMLInputElement).value).toBe("Test Client");
    expect((screen.getByLabelText("Mobile / WhatsApp Number *") as HTMLInputElement).value).toBe("+966 501234567");
    expect(timeSelect.value).toBe("18:15");
    expect((screen.getByLabelText("Full Face") as HTMLInputElement).checked).toBe(true);
    await user.click(screen.getByRole("button", { name: "Try again" }));
    expect(mocks.reset).toHaveBeenCalledOnce();
  });

  it("renders Arabic localized recovery actions after a mocked failure without submitting data", async () => {
    render(createElement(AppointmentRequest, { locale: "ar" }));
    expect(mocks.mutate).not.toHaveBeenCalled();
    expect(document.title).toBe("طلب موعد ليزر للرجال الرياض | جيمس ليزر");
    expect(document.querySelector('meta[name="description"]')?.getAttribute("content")).toContain("طلب موعد خاص");
    expect(document.querySelector('link[rel="canonical"]')?.getAttribute("href")).toContain("/ar/appointment");

    await act(async () => { mocks.appointmentOptions?.onError?.(new Error("mocked failure")); });

    expect(screen.getByRole("alert").textContent).toContain("تعذر إرسال طلبك");
    expect(screen.getByRole("button", { name: "حاول مرة أخرى" })).toBeTruthy();
    expect(screen.getByRole("link", { name: "التواصل عبر واتساب" }).getAttribute("href")).toBe("https://wa.me/966557401562");
  });

  it.each([
    ["en", "Enter a valid mobile or WhatsApp number.", "Please enter a valid mobile or WhatsApp number."],
    ["en", "Choose today or a future date in Riyadh.", "Please choose today or a future date in Riyadh."],
    ["en", "Choose a 15-minute preference between 1:00 PM and 10:00 PM.", "Please choose a 15-minute preference between 1:00 PM and 10:00 PM."],
    ["ar", "أدخل رقم جوال أو واتساب صحيحًا.", "يرجى إدخال رقم جوال أو واتساب صحيح."],
    ["ar", "اختر تاريخ اليوم أو تاريخًا مستقبليًا في الرياض.", "يرجى اختيار تاريخ اليوم أو تاريخ مستقبلي في الرياض."],
    ["ar", "اختر وقتًا كل 15 دقيقة بين 1:00 ظهرًا و10:00 مساءً.", "يرجى اختيار وقت كل 15 دقيقة بين 1:00 ظهرًا و10:00 مساءً."],
  ] as const)("shows the %s localized field error in the production recovery UI", async (locale, serverMessage, expectedMessage) => {
    cleanup();
    render(createElement(AppointmentRequest, { locale }));
    await act(async () => { mocks.appointmentOptions?.onError?.(new Error(serverMessage)); });
    expect(screen.getByRole("alert").textContent).toContain(expectedMessage);
  });
});
