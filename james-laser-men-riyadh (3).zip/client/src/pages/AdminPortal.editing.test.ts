import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const source = readFileSync(resolve(process.cwd(), "client/src/pages/AdminPortal.tsx"), "utf8");
const serverSource = readFileSync(resolve(process.cwd(), "server/db.ts"), "utf8");
const routerSource = readFileSync(resolve(process.cwd(), "server/routers.ts"), "utf8");
const whatsappActionSource = readFileSync(resolve(process.cwd(), "client/src/components/WhatsAppBusinessWebAction.tsx"), "utf8");
const followUpsSource = readFileSync(resolve(process.cwd(), "client/src/pages/SessionFollowUpWorkspaces.tsx"), "utf8");
const hmsSection = source.slice(source.indexOf("function HmsWorkspace()"), source.indexOf("function AppointmentEditPanel"));
const waitingSection = source.slice(source.indexOf("function ArrivalDetailsPanel"), source.indexOf("function Patients()"));
const patientsSection = source.slice(source.indexOf("function Patients()"), source.indexOf("function PatientEditPanel"));

describe("protected clinic editing and HMS access", () => {
  it("exposes patient and HMS appointment edits through the protected portal", () => {
    expect(source).toContain("updatePatientFile.useMutation");
    expect(source).toContain("updateAppointmentDetails.useMutation");
    expect(source).toContain("Edit patient");
    expect(source).toContain("Protected appointment edit");
    expect(source).toContain('<option value="" disabled>Select machine</option>');
    expect(source).toContain('<option value="" disabled>Select visit type</option>');
  });

  it("places the manual WhatsApp Business Web fallback beside every protected patient name", () => {
    expect(source).toContain('import { WhatsAppBusinessWebAction } from "@/components/WhatsAppBusinessWebAction"');
    expect(patientsSection).toContain("function PatientListEntry");
    expect(patientsSection).toContain('phone={patient.whatsapp} patientName={patient.fullName} subjectType="patient" subjectId={patient.id}');
    expect(whatsappActionSource).toContain("Open WhatsApp Business Web");
  });

  it("uses the tracked fallback on Waiting List and Follow-Ups while Appointments keeps its focused HMS schedule", () => {
    expect(waitingSection).toContain('phone={appointment.whatsapp || appointment.contactNumber} patientName={appointment.patientName} subjectType="appointment" subjectId={appointment.id}');
    expect(followUpsSource).toContain('subjectType={row.kind === "legacy" ? "appointment" : "follow_up"} subjectId={row.kind === "legacy" ? row.appointmentId : row.id}');
    expect(followUpsSource).not.toContain("https://wa.me/");
    expect(whatsappActionSource).toContain("recordLaunch.mutate({ subjectType, subjectId })");
  });

  it("loads an official HTTPS HMS URL inside the Admin Portal without opening a new tab", () => {
    expect(source).toContain("HMS workspace");
    expect(source).toContain('parsed.protocol !== "https:"');
    expect(source).toContain('title="Official HMS sign-in and workspace"');
    expect(source).toContain("Load HMS inside page");
    expect(source).toContain("does not store HMS usernames, passwords, browser sessions");
    expect(source).toContain("Download HMS clinic records");
    expect(source).toContain("Download clinic records CSV");
    expect(source).toContain("trpc.admin.hmsExportCsv.useQuery");
    expect(source).toContain("anchor.download = `james-laser-hms-clinic-records-");
    expect(hmsSection).not.toContain("window.open");
    expect(hmsSection).not.toContain("_blank");
  });

  it("allows audited local HMS overrides without updating immutable source evidence", () => {
    expect(serverSource).not.toContain("HMS-imported appointments must be updated in HMS");
    expect(serverSource).toContain("Updated HMS appointment local details; source evidence preserved");
    const updateStart = serverSource.indexOf("await tx.update(appointments).set({", serverSource.indexOf("export async function updateAppointmentDetails"));
    const updateEnd = serverSource.indexOf("}).where(eq(appointments.id", updateStart);
    const updateSet = serverSource.slice(updateStart, updateEnd);
    for (const immutableField of ["source:", "sourceRowNumber:", "importBatchId:", "importFingerprint:", "hmsImportIdentityKey:", "originalAppointmentDate:", "originalAppointmentStartTime:", "originalAppointmentEndTime:", "originalTelephone:", "originalRowData:"]) {
      expect(updateSet).not.toContain(immutableField);
    }
  });

  it("keeps the HMS export source-separated and restricted to NR011", () => {
    expect(serverSource).toContain("exportHmsClinicRecordsCsv");
    expect(serverSource).toContain('eq(appointments.source, "hms_csv")');
    expect(serverSource).toContain('eq(hmsImportBatches.providerCode, "NR011")');
    expect(serverSource).toContain("raw source JSON are intentionally excluded");
  });

  it("opens arrival details before marking arrived and requires protected nurse notes", () => {
    expect(waitingSection).toContain("ArrivalDetailsPanel");
    expect(waitingSection).toContain("Arrival & notes");
    expect(waitingSection).toContain("Record arrival details and notes for");
    expect(waitingSection).toContain("min-h-11 touch-manipulation");
    expect(waitingSection).toContain("Nurse’s notes");
    expect(waitingSection).toContain("Save arrival and patient profile");
    expect(waitingSection).toContain("Save waiting patient and profile");
    expect(waitingSection).toContain("Mark waiting");
    expect(waitingSection).toContain("Mark arrived");
    expect(waitingSection).toContain("trpc.admin.confirmArrival.useMutation");
    expect(waitingSection).toContain("trpc.admin.markWaiting.useMutation");
    expect(routerSource).toContain("nurseNotes: z.string().trim().min(2");
    expect(routerSource).toContain('status: z.enum(["arrived", "no-show", "cancelled"])');
    expect(waitingSection).toContain("PostSessionNotesPanel");
    expect(waitingSection).toContain("Save notes & finish session");
  });

  it("requires structured session or retouch, approved machine, and multi-area arrival details", () => {
    expect(waitingSection).toContain("Session / Retouch");
    expect(waitingSection).toContain("Machine used");
    expect(waitingSection).toContain("TreatmentAreaChecklist");
    expect(source).toContain("select all that apply");
    expect(routerSource).toContain("treatmentAreas: multiTreatmentAreasInput");
    expect(routerSource).toContain("machine: machineInput");
    expect(routerSource).toContain("visitType: visitTypeInput");
  });

  it("creates or links one patient profile by MRN/mobile and retains nurse notes in patient history", () => {
    expect(serverSource).toContain("confirmAppointmentArrival");
    expect(serverSource).toContain("markAppointmentWaiting");
    expect(serverSource).toContain("resolveSinglePatientFile({");
    expect(serverSource).toContain('source: "waiting_list_intake"');
    expect(serverSource).toContain("status: targetStatus");
    expect(serverSource).toContain('return recordWaitingListPatient(input, recordedBy, "arrived")');
    expect(serverSource).toContain("internalNotes: input.nurseNotes");
    expect(serverSource).toContain("treatmentAreas: JSON.stringify(input.treatmentAreas)");
    expect(serverSource).toContain("machine: input.machine");
    expect(serverSource).toContain("visitType: input.visitType");
    expect(source).toContain("Nurse’s notes:");
    expect(source).toContain("appointment.internalNotes");
    expect(source).toContain("appointmentAreaSummary(appointment)");
    expect(source).toContain("Machine not recorded");
  });
});
