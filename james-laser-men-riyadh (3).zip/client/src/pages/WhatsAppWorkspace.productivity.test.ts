import fs from "node:fs";
import path from "node:path";
import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it, vi } from "vitest";
import { WhatsAppMessageHistory, WhatsAppQuickReplies } from "@/components/WhatsAppProductivityTools";

vi.mock("@/contexts/AdminLocaleContext", () => ({
  useAdminLocale: () => ({ locale: "en" as const }),
}));

const read = (file: string) => fs.readFileSync(path.resolve(process.cwd(), file), "utf8");
const workspace = read("client/src/pages/WhatsAppWorkspace.tsx");
const tools = read("client/src/components/WhatsAppProductivityTools.tsx");
const service = read("server/whatsappService.ts");
const access = read("server/whatsappAccess.test.ts");
const activation = read("server/whatsappActivation.test.ts");

describe("WhatsApp workspace productivity integration", () => {
  it("renders authorized message counts and persisted bodies through the filter component", () => {
    const html = renderToStaticMarkup(
      React.createElement(WhatsAppMessageHistory, { messages: [
        { id: 1, direction: "inbound", messageType: "text", body: "Original customer message", templateName: null, status: "received", createdAt: "2026-09-06T10:00:00Z" },
        { id: 2, direction: "outbound", messageType: "text", body: "Original staff message", templateName: null, status: "delivered", createdAt: "2026-09-06T10:05:00Z" },
      ] }),
    );
    expect(html).toContain("Showing 2 of 2");
    expect(html).toContain("Original customer message");
    expect(html).toContain("data-admin-no-translate");
    expect(html).toContain("Clear filters");
  });

  it("renders the truthful no-match empty state for an active local filter", () => {
    const html = renderToStaticMarkup(
      React.createElement(WhatsAppMessageHistory, {
        messages: [{ id: 1, direction: "inbound", messageType: "text", body: "Original customer message", templateName: null, status: "received", createdAt: "2026-09-06T10:00:00Z" }],
        initialFilters: { query: "not-present", direction: "all", messageType: "all", status: "all" },
      }),
    );
    expect(html).toContain("Showing 0 of 1");
    expect(html).toContain("No persisted messages match the current filters.");
  });

  it("renders six draft-only quick replies and disables them when the service window is closed", () => {
    const html = renderToStaticMarkup(
      React.createElement(WhatsAppQuickReplies, { conversationLanguage: "en", serviceWindowOpen: false, draft: "", onDraftChange: vi.fn() }),
    );
    expect(html).toContain("Staff quick replies");
    expect(html).toContain("changes the draft only");
    expect(html).toContain("outside the customer-service window");
    expect((html.match(/disabled/g) ?? []).length).toBeGreaterThanOrEqual(9);
  });

  it("keeps reply selection separate from the existing explicit send mutation", () => {
    expect(tools).toContain("onDraftChange(applyQuickReplyToDraft");
    expect(tools).not.toContain("sendText.mutate");
    expect(tools).not.toContain("trpc.");
    expect(workspace).toContain("<WhatsAppQuickReplies");
    expect(workspace).toContain("<WhatsAppMessageHistory");
    expect(workspace).toContain("sendText.mutate({ conversationId: selected.data!.id, body: draft })");
  });

  it("preserves the server service-window and approved-template boundaries", () => {
    expect(service).toContain("if (!isServiceWindowOpen(conversation)) throw new Error");
    expect(service).toContain("Send an approved template instead.");
    expect(service).toContain('template.status !== "approved"');
    expect(workspace).toContain("disabled={!draft.trim() || !selected.data.serviceWindowOpen || sendText.isPending}");
    expect(workspace).toContain("disabled={!templateId || sendTemplate.isPending");
  });

  it("uses an inline, guarded configuration form for appointment automation settings", () => {
    expect(workspace).toContain("function AutomationSettingsForm");
    expect(workspace).toContain("Save appointment automation settings");
    expect(workspace).toContain("Outbound automation paused");
    expect(workspace).toContain("onSave={input => updateAutomationSettings.mutate");
    expect(workspace).not.toContain('window.prompt("Riyadh reminder sending time');
  });

  it("limits provider setup metadata to authorized roles and avoids a false setup state", () => {
    expect(workspace).toContain('enabled: isAutomationManager && tab === "settings"');
    expect(workspace).toContain('tabs.filter(item => item.id !== "settings")');
    expect(workspace).toContain("WhatsApp settings could not be loaded");
    expect(workspace).toContain("No provider metadata returned");
    expect(workspace).not.toContain('value: settings.data ? "Configured" : "Owner setup required"');
  });

  it("preserves protected access, no-translation record boundaries, and dormant activation", () => {
    expect(access).toContain("receptionProcedure");
    expect(access).toContain("content-editor navigation allowlist");
    expect(activation).toContain("rejects incomplete configuration without exposing values");
    expect(activation).toContain('mode: "dry-run"');
    expect(workspace.match(/data-admin-no-translate/g)?.length ?? 0).toBeGreaterThanOrEqual(10);
    expect(workspace).toContain("setAutomationActivation");
    expect(workspace).toContain("Automation remains paused.");
  });

  it("protects every persisted context-sidebar value from presentation translation", () => {
    expect(workspace).toContain('data-admin-no-translate>{selected.data.displayName || "WhatsApp contact"}');
    expect(workspace).toContain('data-admin-no-translate>{selected.data.phoneNumber}');
    expect(workspace).toContain('data-admin-no-translate>{selected.data.language}');
    expect(workspace).toContain('data-admin-no-translate>{selected.data.request.publicRequestId');
    expect(workspace).toContain('data-admin-no-translate>{selected.data.patient.mrn || selected.data.patient.fullName}');
    expect(workspace).toContain('data-admin-no-translate>{selected.data.appointment.appointmentDate}');
    expect(workspace).toContain('data-admin-no-translate>{candidate.publicRequestId');
    expect(workspace).toContain('data-admin-no-translate>{candidate.mrn || candidate.fullName}');
    expect(workspace).toContain('data-admin-no-translate>{candidate.appointmentDate}');
  });
});
