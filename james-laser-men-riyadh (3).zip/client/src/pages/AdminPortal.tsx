import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout, { type DashboardNavItem } from "@/components/DashboardLayout";
import { AdminEmptyState, AdminErrorState, AdminLoadingState, AdminMetricCard, AdminPageHeader } from "@/components/AdminUi";
import { WhatsAppBusinessWebAction } from "@/components/WhatsAppBusinessWebAction";
import { translateAdminText, useAdminLocale } from "@/contexts/AdminLocaleContext";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Bell, BellRing, BookOpen, CalendarDays, Check, CheckCircle2, ChevronLeft, ChevronRight, CircleAlert, ClipboardList, Clock3, Cpu, Download, ExternalLink, FileText, Globe2, HelpCircle, Image, LayoutDashboard, ListChecks, Loader2, LockKeyhole, MessageCircle, MoreHorizontal, Pencil, Phone, Search, ShieldCheck, SlidersHorizontal, Sparkles, Trash2, UserRound, UsersRound, WalletCards, X, XCircle } from "lucide-react";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import type { Appointment, ConsultationRequest, Patient } from "../../../drizzle/schema";
import CmsManager, { type CmsPage } from "./CmsManager";
import AdminOperations, { type OperationsPage } from "./AdminOperations";
import { AppointmentRequestsWorkspace } from "./AdminRequestsWorkspace";
import { WhatsAppWorkspace } from "./WhatsAppWorkspace";
import { WebChatWorkspace } from "./WebChatWorkspace";
import { RevenueWorkspace } from "./RevenueWorkspace";
import { FollowUpsWorkspace, SessionsWorkspace } from "./SessionFollowUpWorkspaces";

type AdminPage = "dashboard" | "requests" | "appointments" | "sessions" | "followups" | "hms" | "attention" | "waiting" | "patients" | "machines" | "whatsapp" | "webchat" | "revenue" | CmsPage | OperationsPage;
type Machine = "DEKA AGAIN" | "CLARITY 2" | "GENTLE PROMAX" | "DUETTO MACHINE";
type VisitType = "session" | "retouch";
type RequestStatusFilter = "pending" | "contacted" | "clarification_requested" | "approved" | "rejected" | "transferred" | "completed" | "cancelled";

const machines: Machine[] = ["DEKA AGAIN", "CLARITY 2", "GENTLE PROMAX", "DUETTO MACHINE"];
const treatmentAreas = ["FACE", "Neck", "Ears", "Underarm", "Chest", "Abdomen", "Full Arms", "Back", "Shoulders", "Bikini", "Thighs", "Legs", "Feet", "Hands", "FULL BODY", "MINI FULL BODY"] as const;
const manualAppointmentTreatmentAreas = ["Face", "Ears", "Neck", "Underarm", "Chest", "Abdomen", "Arms", "Shoulders", "Bikini", "Thighs", "Legs", "Full back", "Buttocks", "Hands", "Feet"] as const;
const manualNationalityOptions = ["Saudi Arabia", "Egypt", "India", "Pakistan", "Philippines", "Sudan", "Yemen", "Other"] as const;
const manualAppointmentTimes = Array.from({ length: 37 }, (_, index) => {
  const totalMinutes = 13 * 60 + index * 15;
  const hour24 = Math.floor(totalMinutes / 60);
  const minute = totalMinutes % 60;
  const hour12 = hour24 > 12 ? hour24 - 12 : hour24;
  return { value: `${String(hour24).padStart(2, "0")}:${String(minute).padStart(2, "0")}`, label: `${hour12}:${String(minute).padStart(2, "0")} PM` };
});
const requestStatusLabels: Record<RequestStatusFilter, string> = { pending: "New request", contacted: "Contacted", clarification_requested: "Clarification requested", approved: "Approved", rejected: "Rejected", transferred: "Transferred", completed: "Completed", cancelled: "Cancelled" };
type TreatmentArea = typeof treatmentAreas[number];
type ApprovalDraft = { fullName: string; whatsapp: string; nationality: string; mrn: string; appointmentDate: string; appointmentTime: string; treatmentArea: TreatmentArea; treatmentAreas: TreatmentArea[]; machine: Machine; visitType: VisitType; finalizedNotes: string; assignedStaff: string | null; durationMinutes: number | null };

const navItems: DashboardNavItem[] = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/admin", group: "Overview" },
  { icon: ClipboardList, label: "Appointment requests", path: "/admin/requests", group: "Clinic" },
  { icon: MessageCircle, label: "Enquiries", path: "/admin/enquiries", group: "Communication" },
  { icon: MessageCircle, label: "Web chat", path: "/admin/web-chat", group: "Communication" },
  { icon: MessageCircle, label: "WhatsApp", path: "/admin/whatsapp", group: "Communication" },
  { icon: CalendarDays, label: "Appointments", path: "/admin/appointments", group: "Clinic" },
  { icon: FileText, label: "Sessions", path: "/admin/sessions", group: "Clinic" },
  { icon: BellRing, label: "Follow-Ups", path: "/admin/follow-ups", group: "Clinic" },
  { icon: Globe2, label: "HMS access", path: "/admin/hms", group: "Clinic" },
  { icon: ListChecks, label: "Waiting list", path: "/admin/waiting-list", group: "Clinic" },
  { icon: UserRound, label: "Patients", path: "/admin/patients", group: "Clinic" },
  { icon: Cpu, label: "Machines", path: "/admin/machines", group: "Clinic" },
  { icon: Sparkles, label: "Attention agent", path: "/admin/attention", group: "Overview" },
  { icon: Globe2, label: "Homepage", path: "/admin/content", group: "Content" },
  { icon: Image, label: "Homepage appearance", path: "/admin/appearance", group: "Content" },
  { icon: FileText, label: "Treatments", path: "/admin/treatments", group: "Content" },
  { icon: CheckCircle2, label: "Prices & promotions", path: "/admin/promotions", group: "Content" },
  { icon: CheckCircle2, label: "Reviews", path: "/admin/reviews", group: "Content" },
  { icon: Image, label: "Before & after", path: "/admin/results", group: "Content" },
  { icon: BookOpen, label: "Blog & AI studio", path: "/admin/guide", group: "Content" },
  { icon: CalendarDays, label: "Content calendar", path: "/admin/calendar", group: "Content" },
  { icon: HelpCircle, label: "FAQ", path: "/admin/faqs", group: "Content" },
  { icon: ShieldCheck, label: "Policies", path: "/admin/policies", group: "Content" },
  { icon: Image, label: "Media library", path: "/admin/media", group: "Content" },
  { icon: LayoutDashboard, label: "Analytics", path: "/admin/analytics", group: "Management" },
  { icon: Search, label: "SEO overview", path: "/admin/seo", group: "Management" },
  { icon: Search, label: "Redirects", path: "/admin/redirects", group: "Management" },
  { icon: UserRound, label: "Clinic info", path: "/admin/clinic", group: "Management" },
  { icon: Bell, label: "Notifications", path: "/admin/notifications", group: "Management" },
  { icon: Clock3, label: "Activity log", path: "/admin/activity", group: "Management" },
  { icon: UsersRound, label: "Users & roles", path: "/admin/security", group: "Management" },
  { icon: SlidersHorizontal, label: "Settings", path: "/admin/settings", group: "Management" },
  { icon: Download, label: "Data & backup", path: "/admin/data", group: "Management" },
  { icon: WalletCards, label: "Revenue", path: "/admin/revenue", group: "Management" },
];

function riyadhToday() {
  return new Intl.DateTimeFormat("sv-SE", { timeZone: "Asia/Riyadh", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
}

function addCalendarDays(date: string, amount: number) {
  const value = new Date(`${date}T12:00:00Z`);
  value.setUTCDate(value.getUTCDate() + amount);
  return value.toISOString().slice(0, 10);
}

function appointmentDateLabel(date: string) {
  return new Intl.DateTimeFormat("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric", timeZone: "Asia/Riyadh" }).format(new Date(`${date}T12:00:00+03:00`));
}

function AccessDenied() {
  const [, setLocation] = useLocation();
  return <main className="grid min-h-screen place-items-center bg-[#f6f1e7] p-6"><section className="max-w-md border border-[#152c3e]/15 bg-white p-8 text-center shadow-sm"><LockKeyhole className="mx-auto size-8 text-[#a85438]" /><h1 className="mt-5 font-display text-3xl tracking-[-0.04em] text-[#102032]">Admin access only</h1><p className="mt-3 text-sm leading-6 text-[#52606B]">This portal is reserved for the clinic owner. Please sign in using the authorized account.</p><Button className="mt-6" onClick={() => setLocation("/")}>Return to public site</Button></section></main>;
}

function AdminShell({ page }: { page: AdminPage }) {
  const { user, loading } = useAuth();
  useEffect(() => {
    const meta = document.querySelector('meta[name="robots"]') ?? document.head.appendChild(document.createElement("meta"));
    meta.setAttribute("name", "robots");
    const previous = meta.getAttribute("content");
    meta.setAttribute("content", "noindex, nofollow, noarchive");
    document.title = "James Laser · Secure Admin";
    return () => { if (previous) meta.setAttribute("content", previous); else meta.remove(); };
  }, []);
  const dashboard = trpc.admin.dashboard.useQuery(undefined, { enabled: Boolean(user) && ["owner", "admin", "reception"].includes(user?.role ?? "") });
  const enquiries = trpc.admin.enquiries.useQuery(undefined, { enabled: Boolean(user) && ["owner", "admin", "reception"].includes(user?.role ?? "") });
  const websiteChat = trpc.webChat.adminInbox.useQuery({ status: "open" }, { enabled: Boolean(user) && ["owner", "admin", "reception"].includes(user?.role ?? "") });
  if (loading) return <main className="grid min-h-screen place-items-center bg-[#f6f1e7]"><Loader2 className="size-6 animate-spin text-[#a85438]" /></main>;
  if (!user) return <DashboardLayout navItems={navItems}><div /></DashboardLayout>;
  const isContentPage = ["clinic", "appearance", "content", "treatments", "promotions", "reviews", "results", "guide", "calendar", "faqs", "media", "policies", "seo", "languages", "activity", "security", "notifications", "settings"].includes(page);
  const isOperationsPage = (value: AdminPage): value is OperationsPage => ["enquiries", "analytics", "data", "redirects"].includes(value);
  const contentAllowed = ["owner", "admin", "content_editor"].includes(user.role);
  const operationalAllowed = ["owner", "admin", "reception"].includes(user.role);
  const receptionPages: AdminPage[] = ["dashboard", "requests", "enquiries", "webchat", "whatsapp", "notifications"];
  const clinicalWorkflowPage = page === "sessions" || page === "followups";

  if ((isContentPage && !contentAllowed) || (!isContentPage && !operationalAllowed) || ((page === "analytics" || page === "data" || page === "redirects" || page === "hms" || page === "attention" || page === "revenue" || clinicalWorkflowPage) && !["owner", "admin"].includes(user.role)) || (page === "security" && user.role !== "owner") || (user.role === "reception" && !receptionPages.includes(page))) return <AccessDenied />;

  const navWithBadges = navItems.map(item => item.path === "/admin/requests" ? { ...item, badge: dashboard.data?.pendingRequests ?? 0 } : item.path === "/admin/enquiries" ? { ...item, badge: enquiries.data?.filter(enquiry => enquiry.status === "new").length ?? 0 } : item.path === "/admin/web-chat" ? { ...item, badge: websiteChat.data?.reduce((total, conversation) => total + conversation.unreadForStaff, 0) ?? 0 } : item);
  const permittedNav = user.role === "content_editor" ? navWithBadges.filter(item => ["Homepage", "Homepage appearance", "Treatments", "Prices & promotions", "Reviews", "Before & after", "Blog & AI studio", "Content calendar", "FAQ", "Media library", "Policies", "SEO overview", "Clinic info", "Settings"].includes(item.label)) : user.role === "reception" ? navWithBadges.filter(item => ["Dashboard", "Appointment requests", "Enquiries", "Web chat", "WhatsApp", "Notifications"].includes(item.label)) : navWithBadges;
  return <DashboardLayout navItems={permittedNav}>{page === "dashboard" ? <AdminDashboard /> : page === "requests" ? <AppointmentRequestsWorkspace /> : page === "webchat" ? <WebChatWorkspace /> : page === "whatsapp" ? <WhatsAppWorkspace /> : page === "appointments" ? <Appointments /> : page === "sessions" ? <SessionsWorkspace /> : page === "followups" ? <FollowUpsWorkspace /> : page === "hms" ? <HmsWorkspace /> : page === "revenue" ? <RevenueWorkspace /> : page === "attention" ? <AdminAttentionAgent /> : page === "waiting" ? <WaitingList /> : page === "patients" ? <Patients /> : page === "machines" ? <Machines /> : isOperationsPage(page) ? <AdminOperations page={page} /> : <CmsManager page={page as CmsPage} />}</DashboardLayout>;
}

function PageHeading({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: React.ReactNode }) {
  return <AdminPageHeader eyebrow={eyebrow} title={title} description={description} action={action} />;
}

function AdminDashboard() {
  const { user } = useAuth();
  const { locale } = useAdminLocale();
  const t = (value: string) => translateAdminText(value, locale);
  const dashboard = trpc.admin.dashboard.useQuery();
  const canSeeCms = ["owner", "admin"].includes(user?.role ?? "");
  const cmsDashboard = trpc.cms.dashboard.useQuery(undefined, { enabled: canSeeCms });
  const recentActivity = trpc.cms.recentActivity.useQuery(undefined, { enabled: canSeeCms });
  const recentRequests = trpc.admin.requests.useQuery({ status: "pending" });
  const [, setLocation] = useLocation();
  const cards = dashboard.data ? [
    { label: "Pending requests", value: dashboard.data.pendingRequests, note: "Awaiting clinic review", icon: ClipboardList, action: () => setLocation("/admin/requests") },
    { label: "Confirmed today", value: dashboard.data.appointmentsToday, note: "Approved appointment records", icon: CalendarDays, action: () => setLocation("/admin/appointments") },
    { label: "Transferred requests", value: dashboard.data.transferredRequests, note: "Linked to appointments", icon: CheckCircle2, action: () => setLocation("/admin/appointments") },
    { label: "Cancelled requests", value: dashboard.data.cancelledRequests, note: "Retained for audit context", icon: XCircle, action: () => setLocation("/admin/requests") },
  ] : [];

  const cmsCards = cmsDashboard.data ? [
    { label: "Pending reviews", value: cmsDashboard.data.reviewsPendingApproval, note: "Awaiting approval", path: "/admin/reviews" },
    { label: "Active promotions", value: cmsDashboard.data.activePromotions, note: "Published offers", path: "/admin/promotions" },
    { label: "Published blog articles", value: cmsDashboard.data.publishedPosts, note: "Live clinic-reviewed content", path: "/admin/guide" },
    { label: "Published reviews", value: cmsDashboard.data.publishedReviews, note: "Approved public reviews", path: "/admin/reviews" },
  ] : [];
  const quickActions = [
    { label: "Review requests", path: "/admin/requests" }, { label: "Appointments", path: "/admin/appointments" }, { label: "Sessions", path: "/admin/sessions" }, { label: "Follow-Ups", path: "/admin/follow-ups" }, { label: "New promotion", path: "/admin/promotions" }, { label: "New blog post", path: "/admin/guide" }, { label: "Edit homepage", path: "/admin/content" }, { label: "Upload media", path: "/admin/media" },
  ];
  return <div className="mx-auto max-w-6xl"><PageHeading eyebrow="James Laser · owner portal" title="Clinic control centre" description="Review new consultation requests, approve suitable clients, and keep confirmed appointments separate from the incoming request queue." />
    {dashboard.isLoading ? <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{Array.from({ length: 4 }).map((_, index) => <Skeleton key={index} className="h-40 rounded-2xl" />)}</div> : dashboard.isError ? <p className="border border-red-200 bg-red-50 p-5 text-sm text-red-800">The dashboard could not be loaded. Please refresh and try again.</p> : <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{cards.map((card, index) => <AdminMetricCard key={card.label} label={card.label} value={card.value} note={card.note} icon={card.icon} tone={index === 0 ? "warning" : index === 1 || index === 2 ? "success" : "default"} onClick={card.action} />)}</div>}
    <section className="mt-8"><div className="mb-4 flex items-center justify-between"><div><p className="admin-eyebrow">{t("Website operations")}</p><h2 className="mt-1 font-display text-2xl text-[#13293a]">{t("Content & moderation")}</h2></div></div><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{cmsDashboard.isLoading ? Array.from({ length: 4 }).map((_, index) => <Skeleton key={index} className="h-32 rounded-2xl" />) : cmsCards.map(card => <AdminMetricCard key={card.label} label={card.label} value={card.value} note={card.note} onClick={() => setLocation(card.path)} />)}</div></section>
    <section className="mt-8 border border-[#102032]/10 bg-white"><div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#102032]/10 px-5 py-4"><div><p className="admin-eyebrow">{t("Attention queue")}</p><h2 className="mt-1 font-display text-2xl text-[#102032]">{t("Recent appointment requests")}</h2></div><Button size="sm" variant="outline" onClick={() => setLocation("/admin/requests")}>{t("View requests")}</Button></div>{recentRequests.isLoading ? <div className="space-y-3 p-5"><Skeleton className="h-14" /><Skeleton className="h-14" /></div> : (recentRequests.data?.length ?? 0) === 0 ? <div className="p-6 text-sm text-[#66727A]">{t("No new appointment requests are waiting for review.")}</div> : <div>{recentRequests.data?.slice(0, 5).map(request => <button key={request.id} onClick={() => setLocation("/admin/requests")} className="grid w-full gap-1 border-b border-[#102032]/10 px-5 py-4 text-start transition hover:bg-[#f5f1e9] sm:grid-cols-[1.1fr_1fr_1fr_0.8fr_auto] sm:items-center sm:gap-4"><span className="font-semibold text-[#102032]">{request.fullName}<small className="mt-1 block text-xs font-normal text-[#66727A]">{request.publicRequestId || `${t("Request")} #${request.id}`}</small></span><span className="text-sm text-[#52606B]">{request.preferredDate}<small className="mt-1 block text-xs">{request.preferredTime}</small></span><span className="text-sm text-[#52606B]">{request.treatmentArea}</span><Badge variant="outline" className="w-fit">{t("New request")}</Badge><span className="text-xs font-bold text-[#a85438]">{t("View")} {locale === "ar" ? "←" : "→"}</span></button>)}</div>}</section>
    <section className="mt-8 grid gap-5 lg:grid-cols-[1fr_1fr]"><div className="border border-[#102032]/10 bg-white p-6"><p className="admin-eyebrow">{t("Quick actions")}</p><div className="mt-4 grid gap-2 sm:grid-cols-2">{quickActions.map(action => <Button key={action.label} variant="outline" className="justify-start" onClick={() => setLocation(action.path)}>{t(action.label)}</Button>)}<Button variant="outline" className="justify-start" onClick={() => window.open("/", "_blank", "noopener")}>{t("Preview website")} <ExternalLink className="ms-2 size-4" /></Button></div></div><div className="border border-[#102032]/10 bg-white p-6"><p className="admin-eyebrow">{t("Recent activity")}</p>{!canSeeCms ? <p className="mt-4 text-sm text-[#66727A]">{t("Activity history is available to owner and administrator roles.")}</p> : recentActivity.isLoading ? <div className="mt-4 space-y-3"><Skeleton className="h-8" /><Skeleton className="h-8" /><Skeleton className="h-8" /></div> : (recentActivity.data?.length ?? 0) === 0 ? <p className="mt-4 text-sm text-[#66727A]">{t("No privileged activity has been recorded yet.")}</p> : <div className="mt-4 space-y-3">{recentActivity.data?.slice(0, 5).map(item => <div key={item.id} className="border-b border-[#102032]/10 pb-3 last:border-0"><p className="text-sm font-semibold text-[#102032]">{item.action}</p><p className="mt-1 text-xs text-[#66727A]">{item.actorName || t("System")} · {new Date(item.createdAt).toLocaleString()}</p></div>)}</div>}</div></section>
    <section className="mt-8 grid gap-4 border border-[#102032]/10 bg-[#102032] p-6 text-white lg:grid-cols-[1fr_auto] lg:items-center"><div><p className="admin-eyebrow !text-[#EAB394]">{t("Workflow safeguard")}</p><h2 className="mt-2 font-display text-2xl tracking-[-0.035em]">{t("A request becomes an appointment only after approval.")}</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-white/70">{t("Patient requests, cancelled requests, and confirmed appointments are deliberately held in separate views to keep the daily schedule accurate.")}</p></div><Button variant="secondary" onClick={() => setLocation("/admin/requests")}>{t("Review requests")}</Button></section>
  </div>;
}

function AdminAttentionAgent() {
  const attention = trpc.admin.attention.useQuery();
  const utils = trpc.useUtils();
  const [, setLocation] = useLocation();
  const notify = trpc.admin.notifyAttention.useMutation({
    onSuccess: async result => {
      toast.success(result.notificationCreated ? "A generic staff attention notice was added." : "The attention scan was recorded without creating a duplicate notice.");
      await Promise.all([utils.admin.attention.invalidate(), utils.admin.notifications.invalidate(), utils.cms.recentActivity.invalidate()]);
    },
    onError: error => toast.error(error.message),
  });
  const findings = attention.data?.findings ?? [];
  const actionableCount = findings.filter(finding => finding.severity !== "review").length;
  const severity = (value: "urgent" | "attention" | "review") => value === "urgent" ? { label: "Urgent", className: "bg-red-50 text-red-800 hover:bg-red-50" } : value === "attention" ? { label: "Attention", className: "bg-amber-50 text-amber-900 hover:bg-amber-50" } : { label: "Review", className: "bg-blue-50 text-blue-800 hover:bg-blue-50" };

  return <div className="mx-auto max-w-6xl"><PageHeading eyebrow="Zero-credit clinic checks" title="Admin Attention Agent" description="A deterministic protected review of authorized workflow counts. It does not use an LLM, send external messages, change appointments, create patients, or expose names, contact details, clinical answers, consent evidence, or raw HMS source values." action={<div className="flex flex-wrap gap-2"><Button variant="outline" disabled={attention.isFetching} onClick={() => attention.refetch()}>{attention.isFetching ? <Loader2 className="mr-2 size-4 animate-spin" /> : <Sparkles className="mr-2 size-4" />}Refresh checks</Button><Button disabled={notify.isPending || actionableCount === 0} onClick={() => notify.mutate()}>{notify.isPending ? <Loader2 className="mr-2 size-4 animate-spin" /> : <BellRing className="mr-2 size-4" />}Notify staff inbox</Button></div>} />
    <section className="border border-[#a85438]/30 bg-[#fffaf5] p-5 sm:p-6"><div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">Agent boundary</p><h2 className="mt-2 font-display text-3xl tracking-[-0.04em] text-[#102032]">Verified signals, not assumptions</h2><p className="mt-2 max-w-3xl text-sm leading-6 text-[#52606B]">Findings are calculated from existing protected status counts only. Staff remain responsible for opening the linked workspace, reviewing the underlying record under normal permissions, and deciding the next action.</p></div><Badge variant="outline" className="w-fit border-[#a85438]/30 text-[#a85438]">ZERO CREDITS</Badge></div><div className="mt-5 grid gap-3 sm:grid-cols-3"><div className="border border-[#102032]/10 bg-white p-4"><p className="text-[10px] font-extrabold uppercase tracking-[0.14em] text-[#66727A]">Current findings</p><p className="mt-1 font-display text-4xl text-[#102032]">{findings.length}</p></div><div className="border border-[#102032]/10 bg-white p-4"><p className="text-[10px] font-extrabold uppercase tracking-[0.14em] text-[#66727A]">Actionable queues</p><p className="mt-1 font-display text-4xl text-[#102032]">{actionableCount}</p></div><div className="border border-[#102032]/10 bg-white p-4"><p className="text-[10px] font-extrabold uppercase tracking-[0.14em] text-[#66727A]">Last check</p><p className="mt-2 text-sm font-semibold text-[#102032]">{attention.data ? attention.data.checkedAt.toLocaleString() : "Loading…"}</p></div></div></section>
    {attention.isLoading ? <div className="mt-6 space-y-3">{Array.from({ length: 3 }).map((_, index) => <Skeleton key={index} className="h-36 rounded-none" />)}</div> : attention.isError ? <div className="mt-6 border border-red-200 bg-red-50 p-5 text-sm text-red-800">The attention scan could not be loaded. <Button variant="link" className="h-auto p-0 text-red-800" onClick={() => attention.refetch()}>Try again.</Button></div> : findings.length === 0 ? <section className="mt-6 border border-emerald-200 bg-emerald-50 p-8 text-center"><CheckCircle2 className="mx-auto size-8 text-emerald-700" /><h2 className="mt-4 font-display text-3xl text-emerald-950">No configured attention signals</h2><p className="mx-auto mt-2 max-w-xl text-sm leading-6 text-emerald-900">The agent found no pending rule-based attention items in the current protected counts. This is not a clinical assessment or a guarantee that every workflow is complete.</p></section> : <section className="mt-6 space-y-3">{findings.map(finding => { const style = severity(finding.severity); return <article key={finding.id} className="border border-[#102032]/10 bg-white p-5"><div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between"><div className="flex gap-4"><div className="grid size-11 shrink-0 place-items-center rounded-full bg-[#f5f1e9] text-[#a85438]"><CircleAlert className="size-5" /></div><div><div className="flex flex-wrap items-center gap-2"><h2 className="font-display text-2xl tracking-[-0.035em] text-[#102032]">{finding.title}</h2><Badge className={style.className}>{style.label}</Badge></div><p className="mt-2 max-w-2xl text-sm leading-6 text-[#52606B]">{finding.summary}</p></div></div><div className="flex shrink-0 items-center gap-3"><p className="font-display text-4xl text-[#102032]">{finding.count}</p><Button variant="outline" onClick={() => setLocation(finding.linkPath)}>Review</Button></div></div></article>; })}</section>}
    <p className="mt-6 text-xs leading-5 text-[#66727A]">“Notify staff inbox” creates at most one unread generic in-portal system notice. It never sends WhatsApp, email, SMS, or a third-party message, and it does not create duplicate clinic records.</p>
  </div>;
}

function LegacyPatientRequests() {
  const [status, setStatus] = useState<RequestStatusFilter>("pending");
  const [drafts, setDrafts] = useState<Record<number, ApprovalDraft>>({});
  const [internalNotes, setInternalNotes] = useState<Record<number, string>>({});
  const requests = trpc.admin.requests.useQuery({ status });
  const utils = trpc.useUtils();
  const refresh = async () => { await Promise.all([utils.admin.requests.invalidate(), utils.admin.dashboard.invalidate(), utils.admin.appointments.invalidate(), utils.admin.patients.invalidate()]); };
  const approve = trpc.admin.approveRequest.useMutation({ onSuccess: async () => { toast.success("Request approved, patient file saved, and appointment scheduled."); await refresh(); }, onError: error => toast.error(error.message) });
  const cancel = trpc.admin.cancelRequest.useMutation({ onSuccess: async () => { toast.success("Request cancelled."); await refresh(); }, onError: error => toast.error(error.message) });
  const updateStatus = trpc.admin.updateRequestStatus.useMutation({ onSuccess: async () => { toast.success("Request workflow updated."); await refresh(); }, onError: error => toast.error(error.message) });
  const remove = trpc.admin.deleteRequest.useMutation({ onSuccess: async () => { toast.success("Request deleted."); await refresh(); }, onError: error => toast.error(error.message) });
  const defaultDraft = (request: ConsultationRequest): ApprovalDraft => { const treatmentArea = treatmentAreas.includes(request.treatmentArea as TreatmentArea) ? request.treatmentArea as TreatmentArea : "FACE"; return { fullName: request.fullName, whatsapp: request.whatsapp, nationality: request.nationality || "Not provided", mrn: "", appointmentDate: request.preferredDate, appointmentTime: request.preferredTime ?? "", treatmentArea, treatmentAreas: [treatmentArea], machine: "GENTLE PROMAX", visitType: request.visitType === "retouch" ? "retouch" : "session", finalizedNotes: request.internalNotes ?? "", assignedStaff: null, durationMinutes: null }; };
  const updateDraft = (request: ConsultationRequest, change: Partial<ApprovalDraft>) => setDrafts(current => ({ ...current, [request.id]: { ...(current[request.id] ?? defaultDraft(request)), ...change } }));
  const busy = approve.isPending || cancel.isPending || updateStatus.isPending || remove.isPending;
  const updateWorkflow = (request: ConsultationRequest, nextStatus: Exclude<RequestStatusFilter, "pending" | "approved" | "transferred">) => updateStatus.mutate({ requestId: request.id, status: nextStatus, internalNotes: internalNotes[request.id] ?? request.internalNotes ?? null });

  return <div className="mx-auto max-w-6xl"><PageHeading eyebrow="Patient requests" title="Consultation requests" description="Review intake screening, document contact progress, then enter final appointment details before approval. Approval alone creates a patient file and one confirmed appointment." action={<Select value={status} onValueChange={value => setStatus(value as RequestStatusFilter)}><SelectTrigger className="w-[210px]"><SelectValue /></SelectTrigger><SelectContent>{(Object.keys(requestStatusLabels) as RequestStatusFilter[]).map(value => <SelectItem key={value} value={value}>{requestStatusLabels[value]}</SelectItem>)}</SelectContent></Select>} />
    {requests.isLoading ? <div className="space-y-4">{Array.from({ length: 3 }).map((_, index) => <Skeleton key={index} className="h-56 rounded-none" />)}</div> : requests.isError ? <p className="border border-red-200 bg-red-50 p-5 text-sm text-red-800">Requests could not be loaded. Please refresh and try again.</p> : requests.data?.length === 0 ? <div className="border border-dashed border-[#102032]/20 bg-white p-10 text-center"><ClipboardList className="mx-auto size-6 text-[#a85438]" /><h2 className="mt-4 font-display text-2xl text-[#102032]">No {requestStatusLabels[status].toLowerCase()} requests</h2><p className="mt-2 text-sm text-[#52606B]">New public requests will appear here for review.</p></div> : <div className="space-y-4">{requests.data?.map(request => { const active = ["pending", "contacted", "clarification_requested"].includes(request.status); const phone = (request.normalizedWhatsapp || request.whatsapp).replace(/\D/g, ""); const selectedTreatmentAreas = request.treatmentAreas ? (() => { try { return (JSON.parse(request.treatmentAreas) as string[]).join(", "); } catch { return request.treatmentArea; } })() : request.treatmentArea; const isArabic = request.language === "ar"; const whatsappMessage = encodeURIComponent(isArabic ? `مرحبًا ${request.fullName}، معك جيمس ليزر في نيو لوك كلينيك بخصوص طلب موعدك بتاريخ ${request.preferredDate} الساعة ${request.preferredTime}.` : `Hello ${request.fullName}, this is James Laser Hair Removal for Men at New Look Clinic regarding your appointment request for ${request.preferredDate} at ${request.preferredTime}.`); return <article key={request.id} className="border border-[#102032]/10 bg-white p-5 sm:p-6"><div className="flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between"><div><div className="flex flex-wrap items-center gap-2"><h2 className="font-display text-2xl tracking-[-0.035em] text-[#102032]">{request.fullName}</h2><Badge variant="outline">{requestStatusLabels[request.status as RequestStatusFilter]}</Badge>{request.isPotentialDuplicate ? <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">Possible duplicate</Badge> : null}</div><p className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm text-[#52606B]"><span>{request.publicRequestId || `Request #${request.id}`}</span><span>•</span><span>{selectedTreatmentAreas}</span><span>•</span><span>{request.preferredDate} · {request.preferredTime}</span><span>•</span><span>{request.visitType === "retouch" ? "Retouch" : "Session"}</span><span>•</span><span>{request.language === "ar" ? "Arabic" : "English"}</span></p></div><div className="flex flex-wrap items-center gap-2"><Button size="sm" variant="outline" asChild><a href={`https://wa.me/${phone}?text=${whatsappMessage}`} target="_blank" rel="noreferrer"><MessageCircle className="mr-1 size-4" />WhatsApp</a></Button><Button size="sm" variant="outline" asChild><a href={`tel:${phone}`}><Phone className="mr-1 size-4" />Call</a></Button></div></div><dl className="mt-5 grid gap-x-5 gap-y-3 border-y border-[#102032]/10 py-4 text-sm sm:grid-cols-2 lg:grid-cols-4"><div><dt className="text-[10px] font-extrabold uppercase tracking-[0.14em] text-[#a85438]">Submitted</dt><dd className="mt-1 text-[#102032]">{new Date(request.createdAt).toLocaleString()}</dd></div><div><dt className="text-[10px] font-extrabold uppercase tracking-[0.14em] text-[#a85438]">Nationality</dt><dd className="mt-1 text-[#102032]">{request.nationality}</dd></div><div><dt className="text-[10px] font-extrabold uppercase tracking-[0.14em] text-[#a85438]">Preferred contact</dt><dd className="mt-1 text-[#102032]">{request.preferredContact}</dd></div><div><dt className="text-[10px] font-extrabold uppercase tracking-[0.14em] text-[#a85438]">Previous laser</dt><dd className="mt-1 text-[#102032]">{request.firstTime ? "No" : "Yes"}</dd></div></dl>{request.notes ? <p className="mt-4 rounded-sm bg-[#f6f1e7] p-3 text-sm leading-6 text-[#52606B]"><strong className="text-[#102032]">Client notes:</strong> {request.notes}</p> : null}<label className="mt-4 grid gap-2 text-xs font-bold text-[#102032]"><span>Internal admin notes</span><textarea className="min-h-20 border border-[#102032]/20 bg-[#fdfbf7] p-3 text-sm font-normal" value={internalNotes[request.id] ?? request.internalNotes ?? ""} onChange={event => setInternalNotes(current => ({ ...current, [request.id]: event.target.value }))} placeholder="Private clinic note — never displayed publicly" /></label>{active ? <><div className="mt-4 flex flex-wrap gap-2"><Button size="sm" variant="outline" disabled={busy} onClick={() => updateWorkflow(request, "contacted")}>Mark contacted</Button><Button size="sm" variant="outline" disabled={busy} onClick={() => updateWorkflow(request, "clarification_requested")}>Request clarification</Button><Button size="sm" variant="outline" disabled={busy} onClick={() => updateWorkflow(request, "rejected")}>Reject</Button><Button size="sm" variant="outline" disabled={busy} onClick={() => updateWorkflow(request, "completed")}>Complete without booking</Button></div><RequestApprovalControls request={request} draft={drafts[request.id] ?? defaultDraft(request)} update={change => updateDraft(request, change)} busy={busy} onApprove={() => approve.mutate({ requestId: request.id, ...(drafts[request.id] ?? defaultDraft(request)) })} onCancel={() => { if (window.confirm(`Cancel ${request.fullName}'s request?`)) cancel.mutate({ requestId: request.id }); }} onDelete={() => { if (window.confirm(`Delete ${request.fullName}'s request permanently?`)) remove.mutate({ requestId: request.id }); }} /></> : <p className="mt-5 text-xs font-semibold text-[#52606B]">Last handled by {request.reviewedBy || "the clinic"}{request.reviewedAt ? ` on ${new Date(request.reviewedAt).toLocaleString()}` : ""}.</p>}</article>; })}</div>}
  </div>;
}

function RequestApprovalControls({ request, draft, update, busy, onApprove, onCancel, onDelete }: { request: ConsultationRequest; draft: ApprovalDraft; update: (change: Partial<ApprovalDraft>) => void; busy: boolean; onApprove: () => void; onCancel: () => void; onDelete: () => void }) {
  return <section className="mt-5 border-t border-[#102032]/10 pt-5"><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">Final appointment details</p><div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-3"><label className="grid gap-1.5 text-xs font-semibold text-[#102032]">Manual MRN<Input value={draft.mrn} onChange={event => update({ mrn: event.target.value })} placeholder="e.g. JL-000124" aria-label={`Manual MRN for ${request.fullName}`} /></label><label className="grid gap-1.5 text-xs font-semibold text-[#102032]">Appointment date<Input type="date" value={draft.appointmentDate} onChange={event => update({ appointmentDate: event.target.value })} /></label><label className="grid gap-1.5 text-xs font-semibold text-[#102032]">Appointment time<Input value={draft.appointmentTime} onChange={event => update({ appointmentTime: event.target.value })} placeholder="e.g. 18:00" /></label><label className="grid gap-1.5 text-xs font-semibold text-[#102032]">Machine<select value={draft.machine} onChange={event => update({ machine: event.target.value as Machine })} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#a85438]">{machines.map(machine => <option key={machine} value={machine}>{machine}</option>)}</select></label><label className="grid gap-1.5 text-xs font-semibold text-[#102032]">Treatment area<select value={draft.treatmentArea} onChange={event => update({ treatmentArea: event.target.value as TreatmentArea })} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#a85438]">{treatmentAreas.map(area => <option key={area} value={area}>{area}</option>)}</select></label><label className="grid gap-1.5 text-xs font-semibold text-[#102032]">Visit type<select value={draft.visitType} onChange={event => update({ visitType: event.target.value as VisitType })} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#a85438]"><option value="session">Session</option><option value="retouch">Retouch</option></select></label></div><div className="mt-4 flex flex-wrap gap-2"><Button disabled={busy || !draft.mrn.trim() || !draft.appointmentDate || !draft.appointmentTime.trim()} onClick={onApprove}><CheckCircle2 className="mr-2 size-4" />Approve & schedule</Button><Button disabled={busy} variant="outline" onClick={onCancel}><XCircle className="mr-2 size-4" />Cancel</Button><Button disabled={busy} variant="ghost" className="text-red-700 hover:bg-red-50 hover:text-red-800" onClick={onDelete}><Trash2 className="mr-2 size-4" />Delete</Button></div></section>;
}

function HmsImportPanel({ onClose }: { onClose: () => void }) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const utils = trpc.useUtils();
  const importMutation = trpc.admin.hmsImport.useMutation({
    onSuccess: async result => {
      toast.success(`HMS sync complete: ${result.importedCount} appointment${result.importedCount === 1 ? "" : "s"} added to the appointment list.`);
      await Promise.all([utils.admin.appointments.invalidate(), utils.admin.waitingList.invalidate(), utils.admin.dashboard.invalidate()]);
      onClose();
    },
    onError: error => toast.error(error.message),
  });
  const previewMutation = trpc.admin.hmsPreview.useMutation({
    onSuccess: (preview, input) => {
      const importable = preview.summary.ready + preview.summary.warnings;
      if (preview.fatalErrors.length || !preview.providerVerifiedFromSource || preview.normalizedProviderCode !== "NR011") {
        toast.error("Upload blocked: the HMS source or provider could not be verified.");
        return;
      }
      if (importable === 0) {
        toast.info(preview.fileAlreadyImported ? "This HMS report has already been synced." : "No valid, new appointments were found to sync.");
        return;
      }
      toast.success(`Validated ${importable} appointment${importable === 1 ? "" : "s"}. Syncing automatically…`);
      importMutation.mutate({ csvText: input.csvText, originalFileName: input.originalFileName, confirm: true });
    },
    onError: error => toast.error(error.message),
  });
  const preview = previewMutation.data;
  const selectFile = (file: File | undefined) => {
    if (!file) return;
    if (!file.name.toLowerCase().endsWith(".csv")) { toast.error("Select the owner-supplied HMS .csv report."); return; }
    if (file.size > 1_000_000) { toast.error("The protected preview limit is 1 MB."); return; }
    const reader = new FileReader();
    reader.onerror = () => toast.error("The selected CSV could not be read.");
    reader.onload = () => {
      const text = typeof reader.result === "string" ? reader.result : "";
      if (!text) { toast.error("The selected CSV is empty."); return; }
      previewMutation.mutate({ csvText: text, originalFileName: file.name });
    };
    reader.readAsText(file, "utf-8");
  };
  const badgeClass = (status: "READY" | "WARNING" | "DUPLICATE" | "ERROR") => status === "READY" ? "bg-emerald-50 text-emerald-700 hover:bg-emerald-50" : status === "WARNING" ? "bg-amber-50 text-amber-800 hover:bg-amber-50" : status === "DUPLICATE" ? "bg-violet-50 text-violet-700 hover:bg-violet-50" : "bg-red-50 text-red-700 hover:bg-red-50";

  return <section className="mb-6 border border-[#a85438]/30 bg-[#fffaf5] p-4 shadow-sm sm:p-5"><div className="flex flex-col gap-4 border-b border-[#102032]/10 pb-4 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">Protected HMS intake</p><h2 className="mt-1 font-display text-2xl tracking-[-0.04em] text-[#102032]">Upload & sync HMS appointments</h2><p className="mt-1 max-w-3xl text-sm leading-6 text-[#52606B]">Choose the original provider-scoped appointment report. The server verifies the exact provider, imports only the <strong>NotAttended</strong> schedule as confirmed appointments, excludes Attended history, rejects errors and duplicates, then automatically refreshes today’s list.</p></div><Button variant="ghost" size="sm" onClick={onClose}>Close</Button></div>
    <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center"><input ref={fileInputRef} className="sr-only" type="file" accept=".csv,text/csv" onChange={event => { selectFile(event.target.files?.[0]); event.currentTarget.value = ""; }} /><Button onClick={() => fileInputRef.current?.click()} disabled={previewMutation.isPending || importMutation.isPending}>{previewMutation.isPending || importMutation.isPending ? <Loader2 className="mr-2 size-4 animate-spin" /> : <FileText className="mr-2 size-4" />}{previewMutation.isPending ? "Validating securely…" : importMutation.isPending ? "Syncing appointments…" : "Choose HMS Report.csv"}</Button><p className="text-xs leading-5 text-[#66727A]">Exact HMS headers only · provider must be NR011 or Mohamed Taha (JF) · UTF-8/BOM accepted · raw CSV file is not retained.</p></div>
    {preview ? <div className="mt-5 space-y-4"><div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">{([['Rows', preview.summary.total, 'text-[#102032]'], ['Ready', preview.summary.ready, 'text-emerald-700'], ['Warnings', preview.summary.warnings, 'text-amber-800'], ['Duplicates', preview.summary.duplicates, 'text-violet-700'], ['Errors', preview.summary.errors, 'text-red-700']] as const).map(([label, value, colour]) => <div key={label} className="border border-[#102032]/10 bg-white px-4 py-3"><p className="text-[10px] font-extrabold uppercase tracking-[0.14em] text-[#66727A]">{label}</p><p className={`mt-1 font-display text-3xl ${colour}`}>{value}</p></div>)}</div>
      {preview.fatalErrors.length ? <div className="border border-red-200 bg-red-50 p-4 text-sm text-red-800"><strong>Upload blocked.</strong><ul className="mt-2 list-disc space-y-1 pl-5">{preview.fatalErrors.map(error => <li key={error}>{error}</li>)}</ul></div> : <>{preview.providerVerifiedFromSource ? <div className="border border-emerald-200 bg-emerald-50 p-4 text-sm leading-6 text-emerald-900"><strong>Provider verified from the HMS source.</strong> The exact source value <strong>{preview.sourceProvider}</strong> is authorized and normalized internally to <strong>NR011 JAMES FLORES</strong>. No fuzzy, provider-less, or unknown provider is accepted.</div> : null}
        <div className="hidden overflow-x-auto border border-[#102032]/10 bg-white md:block"><table className="min-w-[1120px] w-full text-left text-sm"><thead className="bg-[#f5f1e9] text-[10px] uppercase tracking-[0.12em] text-[#52606B]"><tr><th className="px-3 py-3">Source row</th><th className="px-3 py-3">Appointment</th><th className="px-3 py-3">Patient</th><th className="px-3 py-3">Original identifiers</th><th className="px-3 py-3">Validation</th><th className="px-3 py-3">Suggested only</th></tr></thead><tbody>{preview.rows.map(row => <tr key={`${row.sourceRowNumberRaw}-${row.fingerprint}`} className="border-t border-[#102032]/10 align-top"><td className="px-3 py-3 font-mono text-xs text-[#52606B]">{row.sourceRowNumberRaw || "—"}</td><td className="px-3 py-3 text-[#102032]"><strong>{row.appointmentDate || "Invalid date"}</strong><br /><span className="text-xs text-[#66727A]">{row.raw.Datasp_RPTAllAppointment_Screen_FirstAppointment} → {row.raw.Datasp_RPTAllAppointment_Screen_LastAppointment}</span></td><td className="px-3 py-3 text-[#102032]">{row.patientName || "Missing name"}<br /><span className="text-xs text-[#66727A]">{row.nationality || "Nationality blank"}</span></td><td className="px-3 py-3 text-xs leading-5 text-[#52606B]">MRN: {row.originalMrn || "blank"}<br />Phone: {row.originalTelephone || "blank"}<br />Sex / age: {row.originalSex || "blank"} / {row.originalAge || "blank"}</td><td className="px-3 py-3"><Badge className={badgeClass(row.validation)}>{row.validation}</Badge>{row.errors.concat(row.warnings).length ? <ul className="mt-2 max-w-[260px] space-y-1 text-xs leading-5 text-[#66727A]">{row.errors.concat(row.warnings).map((message, index) => <li key={`${message}-${index}`}>• {message}</li>)}</ul> : null}</td><td className="px-3 py-3 text-xs leading-5 text-[#52606B]"><span>{row.suggestedVisitType === "unknown" ? "No visit type suggested" : `Visit: ${row.suggestedVisitType}`}</span><br /><span>{row.suggestedMachine ? `Machine: ${row.suggestedMachine}` : "No machine suggested"}</span><br /><span>{row.suggestedTreatment ? `Area: ${row.suggestedTreatment}` : "No area suggested"}</span><p className="mt-1 italic">Not auto-applied.</p></td></tr>)}</tbody></table></div>
        <div className="space-y-3 md:hidden">{preview.rows.map(row => <article key={`${row.sourceRowNumberRaw}-${row.fingerprint}`} className="border border-[#102032]/10 bg-white p-4"><div className="flex items-start justify-between gap-3"><div><p className="text-[10px] font-extrabold uppercase tracking-[0.14em] text-[#66727A]">Source row {row.sourceRowNumberRaw || "—"}</p><h3 className="mt-1 font-semibold text-[#102032]">{row.patientName || "Missing name"}</h3><p className="mt-1 text-sm text-[#52606B]">{row.appointmentDate || "Invalid date"} · {row.raw.Datasp_RPTAllAppointment_Screen_FirstAppointment} → {row.raw.Datasp_RPTAllAppointment_Screen_LastAppointment}</p></div><Badge className={badgeClass(row.validation)}>{row.validation}</Badge></div><details className="mt-3 border-t border-[#102032]/10 pt-3 text-sm"><summary className="cursor-pointer font-semibold text-[#102032]">View source values & validation</summary><p className="mt-2 text-xs leading-5 text-[#52606B]">MRN: {row.originalMrn || "blank"} · Phone: {row.originalTelephone || "blank"}<br />Sex / age: {row.originalSex || "blank"} / {row.originalAge || "blank"}<br />Nationality: {row.nationality || "blank"}<br />Remarks: {row.remarks || "blank"}</p>{row.errors.concat(row.warnings).length ? <ul className="mt-2 space-y-1 text-xs leading-5 text-[#66727A]">{row.errors.concat(row.warnings).map((message, index) => <li key={`${message}-${index}`}>• {message}</li>)}</ul> : null}</details></article>)}</div>
        <div className="border-t border-[#102032]/10 pt-4 text-xs leading-5 text-[#66727A]"><strong className="text-[#102032]">Automatic sync:</strong> valid READY and WARNING rows are imported after server validation. ERROR and DUPLICATE rows are always excluded. Duplicate detection uses the source fingerprint or matching MRN, normalized phone number, appointment date, and time. The server re-parses the source, records a protected audit batch, and preserves original source values.</div></>}</div> : null}
  </section>;
}

type ManualTreatmentArea = typeof manualAppointmentTreatmentAreas[number];
type ManualEntryDraft = { fullName: string; mrn: string; nationality: string; contactNumber: string; whatsapp: string; email: string; treatmentArea: ManualTreatmentArea; treatmentAreas: ManualTreatmentArea[]; nextFollowUpDate: string; nextFollowUpType: VisitType; notes: string };
const emptyManualEntry = (): ManualEntryDraft => ({ fullName: "", mrn: "", nationality: "", contactNumber: "", whatsapp: "", email: "", treatmentArea: "Face", treatmentAreas: ["Face"], nextFollowUpDate: "", nextFollowUpType: "session", notes: "" });

function normalizeManualArea(value: string): ManualTreatmentArea | null {
  const map: Record<string, ManualTreatmentArea> = { FACE: "Face", Face: "Face", Ears: "Ears", Neck: "Neck", Underarm: "Underarm", Chest: "Chest", Abdomen: "Abdomen", "Full Arms": "Arms", Arms: "Arms", Shoulders: "Shoulders", Bikini: "Bikini", Thighs: "Thighs", Legs: "Legs", Back: "Full back", "Full back": "Full back", Buttocks: "Buttocks", Hands: "Hands", Feet: "Feet" };
  return map[value] ?? null;
}

function appointmentAreaSummary(appointment: Pick<Appointment, "treatmentArea" | "treatmentAreas">) {
  try {
    const parsed = appointment.treatmentAreas ? JSON.parse(appointment.treatmentAreas) as string[] : [];
    if (Array.isArray(parsed) && parsed.length > 0) return parsed.join(", ");
  } catch {
    // Retain the primary-area fallback for legacy records with invalid JSON.
  }
  return appointment.treatmentArea || "Not recorded";
}

function TreatmentAreaChecklist({ value, onChange }: { value: ManualTreatmentArea[]; onChange: (value: ManualTreatmentArea[]) => void }) {
  const toggle = (area: ManualTreatmentArea) => onChange(value.includes(area) ? value.filter(item => item !== area) : [...value, area]);
  return <fieldset className="sm:col-span-2 xl:col-span-3"><legend className="text-xs font-bold text-[#102032]">Treatment areas <span className="font-normal text-[#66727A]">(select all that apply)</span></legend><div className="mt-2 grid gap-2 rounded border border-[#102032]/15 bg-white p-3 sm:grid-cols-3">{manualAppointmentTreatmentAreas.map(area => <label key={area} className="flex items-center gap-2 text-sm font-normal text-[#102032]"><input type="checkbox" className="size-4 accent-[#a85438]" checked={value.includes(area)} onChange={() => toggle(area)} />{area}</label>)}</div>{value.length === 0 ? <p className="mt-1 text-xs text-red-700">Select at least one area.</p> : null}</fieldset>;
}

function ManualPatientPanel({ onClose }: { onClose: () => void }) {
  const [draft, setDraft] = useState(emptyManualEntry);
  const utils = trpc.useUtils();
  const create = trpc.admin.createManualPatient.useMutation({
    onSuccess: async () => { toast.success("Manual patient file created."); await utils.admin.patients.invalidate(); onClose(); },
    onError: error => toast.error(error.message),
  });
  const update = (change: Partial<ManualEntryDraft>) => setDraft(current => ({ ...current, ...change }));
  const ready = Boolean(draft.fullName.trim() && draft.nationality && draft.contactNumber.trim() && draft.whatsapp.trim());
  const submit = () => {
    if (!ready || !window.confirm("Create this protected manual patient file? This does not create an appointment or public request.")) return;
    create.mutate(draft);
  };
  return <section className="mb-6 border border-[#a85438]/30 bg-[#fffaf5] p-4 sm:p-5"><div className="flex flex-wrap items-start justify-between gap-3 border-b border-[#102032]/10 pb-4"><div><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">Protected manual entry</p><h2 className="mt-1 font-display text-2xl tracking-[-0.04em] text-[#102032]">Add patient</h2><p className="mt-1 max-w-2xl text-sm leading-6 text-[#52606B]">Create a protected patient file from staff-entered details. No public appointment request or appointment is created by this form.</p></div><Button variant="ghost" size="sm" onClick={onClose}>Close</Button></div><div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-3"><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Patient name<Input value={draft.fullName} onChange={event => update({ fullName: event.target.value })} placeholder="Full name" /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">MRN (manual)<Input value={draft.mrn} onChange={event => update({ mrn: event.target.value })} placeholder="Optional manual MRN" /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Nationality<select value={draft.nationality} onChange={event => update({ nationality: event.target.value })} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm"><option value="">Select nationality</option>{manualNationalityOptions.map(item => <option key={item} value={item}>{item}</option>)}</select></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Contact number<Input value={draft.contactNumber} onChange={event => update({ contactNumber: event.target.value })} inputMode="tel" placeholder="Phone number" /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">WhatsApp number<Input value={draft.whatsapp} onChange={event => update({ whatsapp: event.target.value })} inputMode="tel" placeholder="WhatsApp number" /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Email address<Input value={draft.email} onChange={event => update({ email: event.target.value })} type="email" placeholder="Optional email" /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Primary treatment area<select value={draft.treatmentArea} onChange={event => update({ treatmentArea: event.target.value as ManualEntryDraft["treatmentArea"] })} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm">{manualAppointmentTreatmentAreas.map(item => <option key={item} value={item}>{item}</option>)}</select></label><label className="grid gap-1.5 text-xs font-bold text-[#102032] sm:col-span-2"><span>Private notes</span><textarea value={draft.notes} onChange={event => update({ notes: event.target.value })} className="min-h-20 border border-[#102032]/20 bg-white p-3 text-sm font-normal" placeholder="Optional protected clinic notes" /></label></div><div className="mt-4 flex flex-wrap items-center gap-3"><Button disabled={!ready || create.isPending} onClick={submit}>{create.isPending ? <Loader2 className="mr-2 size-4 animate-spin" /> : <UserRound className="mr-2 size-4" />}Create patient file</Button><p className="text-xs text-[#66727A]">Required: name, nationality, contact number, and WhatsApp. Medical screening fields remain unassessed, not guessed.</p></div></section>;
}

function ManualAppointmentPanel({ onClose }: { onClose: () => void }) {
  const [draft, setDraft] = useState(() => ({ ...emptyManualEntry(), appointmentDate: riyadhToday(), appointmentTime: "13:00", machine: "DEKA AGAIN" as Machine, visitType: "session" as VisitType }));
  const utils = trpc.useUtils();
  const create = trpc.admin.createManualAppointment.useMutation({
    onSuccess: async () => { toast.success("Manual appointment added to the confirmed schedule."); await Promise.all([utils.admin.appointments.invalidate(), utils.admin.waitingList.invalidate(), utils.admin.dashboard.invalidate()]); onClose(); },
    onError: error => toast.error(error.message),
  });
  const update = (change: Partial<typeof draft>) => setDraft(current => ({ ...current, ...change }));
  const ready = Boolean(draft.fullName.trim() && draft.nationality && draft.contactNumber.trim() && draft.whatsapp.trim() && draft.appointmentDate && draft.appointmentTime && draft.treatmentAreas.length > 0);
  const submit = () => {
    if (!ready || !window.confirm("Add this confirmed manual appointment to the protected schedule? This does not create a public request, patient file, consent, or e-signature.")) return;
    create.mutate(draft);
  };
  return <section className="mb-6 border border-[#a85438]/30 bg-[#fffaf5] p-4 sm:p-5"><div className="flex flex-wrap items-start justify-between gap-3 border-b border-[#102032]/10 pb-4"><div><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">Protected manual entry</p><h2 className="mt-1 font-display text-2xl tracking-[-0.04em] text-[#102032]">Add appointment</h2><p className="mt-1 max-w-2xl text-sm leading-6 text-[#52606B]">Create a staff-entered confirmed appointment. It remains separate from public Patient Requests and does not create a patient file automatically.</p></div><Button variant="ghost" size="sm" onClick={onClose}>Close</Button></div><div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-3"><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Patient name<Input value={draft.fullName} onChange={event => update({ fullName: event.target.value })} placeholder="Full name" /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">MRN (manual)<Input value={draft.mrn} onChange={event => update({ mrn: event.target.value })} placeholder="Optional manual MRN" /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Nationality<select value={draft.nationality} onChange={event => update({ nationality: event.target.value })} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm"><option value="">Select nationality</option>{manualNationalityOptions.map(item => <option key={item} value={item}>{item}</option>)}</select></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Contact number<Input value={draft.contactNumber} onChange={event => update({ contactNumber: event.target.value })} inputMode="tel" placeholder="Phone number" /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">WhatsApp number<Input value={draft.whatsapp} onChange={event => update({ whatsapp: event.target.value })} inputMode="tel" placeholder="WhatsApp number" /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Email address<Input value={draft.email} onChange={event => update({ email: event.target.value })} type="email" placeholder="Optional email" /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Appointment date<Input value={draft.appointmentDate} onChange={event => update({ appointmentDate: event.target.value })} type="date" /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Appointment time<select value={draft.appointmentTime} onChange={event => update({ appointmentTime: event.target.value })} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm">{manualAppointmentTimes.map(item => <option key={item.value} value={item.value}>{item.label}</option>)}</select></label><TreatmentAreaChecklist value={draft.treatmentAreas} onChange={treatmentAreas => update({ treatmentAreas, treatmentArea: treatmentAreas[0] ?? "Face" })} /><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Machine<select value={draft.machine} onChange={event => update({ machine: event.target.value as Machine })} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm">{machines.map(machine => <option key={machine} value={machine}>{machine}</option>)}</select></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Visit type<select value={draft.visitType} onChange={event => update({ visitType: event.target.value as VisitType })} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm"><option value="session">Session</option><option value="retouch">Retouch</option></select></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Next follow-up date<Input value={draft.nextFollowUpDate} onChange={event => update({ nextFollowUpDate: event.target.value })} type="date" /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Next follow-up type<select value={draft.nextFollowUpType} onChange={event => update({ nextFollowUpType: event.target.value as VisitType })} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm"><option value="session">Session</option><option value="retouch">Retouch</option></select></label><label className="grid gap-1.5 text-xs font-bold text-[#102032] sm:col-span-2"><span>Private notes</span><textarea value={draft.notes} onChange={event => update({ notes: event.target.value })} className="min-h-20 border border-[#102032]/20 bg-white p-3 text-sm font-normal" placeholder="Optional protected clinic notes" /></label></div><div className="mt-4 flex flex-wrap items-center gap-3"><Button disabled={!ready || create.isPending} onClick={submit}>{create.isPending ? <Loader2 className="mr-2 size-4 animate-spin" /> : <CalendarDays className="mr-2 size-4" />}Add confirmed appointment</Button><p className="text-xs text-[#66727A]">Times are limited to 15-minute choices from 1:00 PM through 10:00 PM. Server checks prevent mobile/time and machine/time conflicts.</p></div></section>;
}

function AppointmentWhatsAppPanel({ appointmentId }: { appointmentId: number }) {
  const status = trpc.admin.appointmentWhatsAppStatus.useQuery({ appointmentId });
  const utils = trpc.useUtils();
  const [, setLocation] = useLocation();
  const queue = trpc.whatsapp.queueAutomationJob.useMutation({
    onSuccess: async () => {
      toast.success("The message has been queued for the protected provider worker. Delivery status will update only from Meta webhooks.");
      await Promise.all([utils.admin.appointmentWhatsAppStatus.invalidate({ appointmentId }), utils.whatsapp.automationWorkspace.invalidate()]);
    },
    onError: error => toast.error(error.message),
  });
  const deliveryLabel = (job: NonNullable<typeof status.data>["jobs"][number]) => job.providerStatus || job.status;
  const canQueue = (job: NonNullable<typeof status.data>["jobs"][number]) => !["sent", "delivered", "read", "provider_accepted", "claimed", "cancelled"].includes(job.status) && !(job.status === "failed" && !job.retryable);
  const queueNow = (job: NonNullable<typeof status.data>["jobs"][number]) => {
    const reason = window.prompt(`Queue “${job.jobType.replaceAll("_", " ")}” now. Record the staff reason:`)?.trim();
    if (!reason || !window.confirm("Queue this approved-template message for provider submission? The clinic appointment will not be created, moved, or cancelled by this action.")) return;
    queue.mutate({ jobId: job.id, reason });
  };
  const statusClass = (value: string) => value === "delivered" || value === "read" ? "border-emerald-200 bg-emerald-50 text-emerald-800" : value === "failed" ? "border-red-200 bg-red-50 text-red-800" : value === "blocked_consent" || value === "blocked_template" || value === "provider_not_connected" ? "border-amber-200 bg-amber-50 text-amber-900" : "border-sky-200 bg-sky-50 text-sky-800";

  if (status.isLoading) return <section className="mt-4 border border-[#102032]/10 bg-[#fdfbf7] p-4"><Skeleton className="h-14" /></section>;
  if (status.isError || !status.data) return <section className="mt-4 border border-red-200 bg-red-50 p-4 text-sm text-red-800">WhatsApp automation details could not be loaded. No message action was taken.</section>;
  const jobs = status.data.jobs;
  return <section className="mt-4 border border-[#102032]/10 bg-[#fdfbf7] p-4"><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="text-[10px] font-extrabold uppercase tracking-[0.14em] text-[#a85438]">WhatsApp appointment status</p><p className="mt-1 text-sm leading-6 text-[#52606B]">Provider delivery states are shown only after a real Meta webhook. Queueing requires verified patient consent, an approved mapped template, and enabled automation.</p></div><Button size="sm" variant="outline" onClick={() => setLocation("/admin/whatsapp")}>Open WhatsApp centre</Button></div><div className="mt-3 flex flex-wrap gap-2 text-xs"><Badge variant="outline" className={status.data.providerConfigured ? "border-emerald-200 bg-emerald-50 text-emerald-800" : "border-amber-200 bg-amber-50 text-amber-900"}>{status.data.providerConfigured ? "Provider configured" : "Provider not configured"}</Badge><Badge variant="outline" className={status.data.automationEnabled ? "border-emerald-200 bg-emerald-50 text-emerald-800" : "border-amber-200 bg-amber-50 text-amber-900"}>{status.data.automationEnabled ? "Automation enabled" : "Automation paused"}</Badge><Badge variant="outline" className={status.data.appointment.whatsappConsentStatus === "opted_in" ? "border-emerald-200 bg-emerald-50 text-emerald-800" : "border-amber-200 bg-amber-50 text-amber-900"}>{status.data.appointment.whatsappConsentStatus === "opted_in" ? "Consent verified" : "Consent verification required"}</Badge></div>{jobs.length === 0 ? <p className="mt-3 text-sm text-[#66727A]">No eligible automated message is scheduled for this appointment. Review workflow settings in the WhatsApp centre.</p> : <div className="mt-3 space-y-2">{jobs.slice(0, 6).map(job => <div key={job.id} className="flex flex-col gap-2 border border-[#102032]/10 bg-white p-3 sm:flex-row sm:items-center sm:justify-between"><div><p className="text-sm font-semibold capitalize text-[#102032]">{job.jobType.replaceAll("_", " ")}</p><p className="mt-1 text-xs text-[#66727A]">Scheduled: {new Date(job.scheduledFor).toLocaleString()} · Version {status.data.appointment.whatsappAutomationVersion}</p>{job.lastError ? <p className="mt-1 text-xs text-red-700">{job.lastErrorCode ? `${job.lastErrorCode}: ` : ""}{job.lastError}</p> : null}</div><div className="flex items-center gap-2"><Badge variant="outline" className={statusClass(deliveryLabel(job))}>{deliveryLabel(job).replaceAll("_", " ")}</Badge>{canQueue(job) ? <Button size="sm" variant="outline" disabled={queue.isPending} onClick={() => queueNow(job)}>{queue.isPending ? <Loader2 className="size-4 animate-spin" /> : "Queue now"}</Button> : null}</div></div>)}</div>}</section>;
}

export function Appointments() {
  const [importOpen, setImportOpen] = useState(false);
  const [editingAppointmentId, setEditingAppointmentId] = useState<number | null>(null);
  const [manualRefreshing, setManualRefreshing] = useState(false);
  const [selectedDate, setSelectedDate] = useState(riyadhToday);
  const today = riyadhToday();
  const tomorrow = addCalendarDays(today, 1);
  const appointmentQueryInput = useMemo(() => ({ date: selectedDate }), [selectedDate]);
  const appointments = trpc.admin.appointments.useQuery(appointmentQueryInput, { refetchInterval: 5_000, refetchOnWindowFocus: true, refetchOnReconnect: true, staleTime: 0, gcTime: 0 });
  const seen = new Set<string>();
  const selectedAppointments = (appointments.data ?? []).filter(appointment => {
    if (appointment.source !== "hms_csv" || appointment.status !== "confirmed" || appointment.appointmentDate !== selectedDate) return false;
    const identity = appointment.importFingerprint || `${appointment.mrn || appointment.patientName}\u001f${appointment.appointmentDate}\u001f${appointment.appointmentTime}`;
    if (seen.has(identity)) return false;
    seen.add(identity);
    return true;
  }).sort((left, right) => left.appointmentTime.localeCompare(right.appointmentTime) || left.id - right.id);
  const selectedDateName = selectedDate === today ? "Today" : selectedDate === tomorrow ? "Tomorrow" : appointmentDateLabel(selectedDate);
  const machineReviewCount = selectedAppointments.filter(appointment => !appointment.machine || !machines.includes(appointment.machine as Machine)).length;
  const refreshAppointments = async () => { setManualRefreshing(true); try { await appointments.refetch(); } finally { setManualRefreshing(false); } };
  return <div className="mx-auto max-w-6xl"><PageHeading eyebrow="HMS · NR011 JAMES FLORES" title={`${selectedDateName} · confirmed appointments`} description="A protected HMS-only schedule for the selected date. Records are sorted by appointment time; requests, cancellations, pending items, no-shows, and other providers are excluded." action={<div className="flex w-full flex-col gap-2 sm:w-auto"><div className="flex items-center gap-2"><Button size="icon" variant="outline" aria-label="Previous day" title="Previous day" onClick={() => setSelectedDate(current => addCalendarDays(current, -1))}><ChevronLeft className="size-4" /></Button><Input aria-label="Appointment date" className="min-w-0 flex-1 bg-white sm:w-[168px] sm:flex-none" type="date" value={selectedDate} onChange={event => { if (event.target.value) setSelectedDate(event.target.value); }} /><Button size="icon" variant="outline" aria-label="Next day" title="Next day" onClick={() => setSelectedDate(current => addCalendarDays(current, 1))}><ChevronRight className="size-4" /></Button></div><div className="flex flex-wrap gap-2"><Button variant={selectedDate === today ? "default" : "outline"} onClick={() => setSelectedDate(today)}>Today</Button><Button variant={selectedDate === tomorrow ? "default" : "outline"} onClick={() => setSelectedDate(tomorrow)}>Tomorrow</Button><Button variant="outline" onClick={() => setImportOpen(value => !value)}><FileText className="mr-2 size-4" />Upload & sync</Button><Button variant="outline" onClick={refreshAppointments} disabled={manualRefreshing}>{manualRefreshing ? <Loader2 className="mr-2 size-4 animate-spin" /> : <Clock3 className="mr-2 size-4" />}{manualRefreshing ? "Refreshing…" : "Refresh"}</Button></div></div>} />
    {importOpen ? <HmsImportPanel onClose={() => setImportOpen(false)} /> : null}
    <section aria-label="Confirmed HMS appointments for selected date" data-admin-no-translate className="mb-5 flex flex-col gap-3 border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm sm:flex-row sm:items-center sm:justify-between"><div className="flex flex-wrap items-center gap-2 font-semibold text-emerald-950"><span aria-hidden="true" className="size-2 rounded-full bg-emerald-600" />Live · refreshes every 5 seconds{machineReviewCount > 0 ? <Badge role="status" className="gap-1 border border-amber-300 bg-amber-100 text-amber-950 hover:bg-amber-100"><CircleAlert className="size-3.5" />{machineReviewCount} machine review{machineReviewCount === 1 ? "" : "s"}</Badge> : null}</div><div className="text-emerald-900"><strong>{appointmentDateLabel(selectedDate)}</strong> · {selectedAppointments.length} confirmed appointment{selectedAppointments.length === 1 ? "" : "s"}</div></section>
    {appointments.isLoading ? <div className="space-y-4">{Array.from({ length: 3 }).map((_, index) => <Skeleton key={index} className="h-28 rounded-none" />)}</div> : appointments.isError ? <div className="border border-red-200 bg-red-50 p-5 text-sm text-red-800">Appointments could not be loaded. <Button variant="link" className="h-auto p-0 text-red-800" onClick={() => appointments.refetch()}>Try again.</Button></div> : selectedAppointments.length === 0 ? <div className="border border-dashed border-[#102032]/20 bg-white p-10 text-center"><CalendarDays className="mx-auto size-6 text-[#a85438]" /><h2 className="mt-4 font-display text-2xl text-[#102032]">No appointments for selected date</h2><p className="mt-2 text-sm text-[#52606B]">No confirmed NR011 HMS appointments were found for {appointmentDateLabel(selectedDate)}.</p></div> : <div className="space-y-3">{selectedAppointments.map(appointment => { const machineIsControlled = Boolean(appointment.machine && machines.includes(appointment.machine as Machine)); const isEditing = editingAppointmentId === appointment.id; return <React.Fragment key={appointment.id}><article data-admin-no-translate className={`grid gap-4 border bg-white p-5 sm:grid-cols-[minmax(0,1fr)_auto_auto] sm:items-center ${machineIsControlled ? "border-[#102032]/10" : "border-amber-300"}`}><div className="min-w-0"><p className="text-[10px] font-extrabold uppercase tracking-[0.14em] text-[#a85438]">Patient name</p><h2 className="mt-1 break-words font-display text-2xl tracking-[-0.035em] text-[#102032] [overflow-wrap:anywhere]">{appointment.patientName}</h2></div><div className="sm:text-right"><p className="text-[10px] font-extrabold uppercase tracking-[0.14em] text-[#66727A]">Time</p><p className="mt-1 text-base font-bold text-[#102032]">{appointment.appointmentTime}{appointment.appointmentEndTime ? `–${appointment.appointmentEndTime}` : ""}</p></div><div className="flex flex-wrap items-center gap-2 sm:justify-end"><Badge className="bg-blue-50 text-blue-700 hover:bg-blue-50">Confirmed</Badge>{machineIsControlled ? <Badge variant="outline" className="border-[#a85438]/30 text-[#a85438]">{appointment.machine}</Badge> : <Badge role="status" title="Missing or incomplete controlled machine value" className="gap-1 border border-amber-300 bg-amber-100 text-amber-950 hover:bg-amber-100"><CircleAlert className="size-3.5" />Machine review required</Badge>}<Button size="sm" variant="outline" aria-expanded={isEditing} onClick={() => setEditingAppointmentId(current => current === appointment.id ? null : appointment.id)}><Pencil className="mr-1 size-3.5" />{isEditing ? "Close editor" : "Edit appointment"}</Button></div></article>{isEditing ? <AppointmentEditPanel appointment={appointment} onClose={() => setEditingAppointmentId(null)} /> : null}</React.Fragment>; })}</div>}
  </div>;
}

function HmsWorkspace() {
  const [url, setUrl] = useState("");
  const [embeddedUrl, setEmbeddedUrl] = useState("");
  const hmsExport = trpc.admin.hmsExportCsv.useQuery(undefined, { enabled: false });
  const loadHms = () => {
    let parsed: URL;
    try {
      parsed = new URL(url.trim());
    } catch {
      toast.error("Enter the official HMS HTTPS address.");
      return;
    }
    if (parsed.protocol !== "https:") {
      toast.error("Use an HTTPS HMS address.");
      return;
    }
    setEmbeddedUrl(parsed.toString());
  };
  const clearWorkspace = () => {
    setEmbeddedUrl("");
  };
  const downloadHmsCsv = async () => {
    try {
      const result = await hmsExport.refetch();
      if (!result.data) throw new Error("No export was returned.");
      const blob = new Blob([result.data], { type: "text/csv;charset=utf-8" });
      const objectUrl = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = objectUrl;
      anchor.download = `james-laser-hms-clinic-records-${riyadhToday()}.csv`;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      URL.revokeObjectURL(objectUrl);
      toast.success("HMS clinic records downloaded as CSV.");
    } catch {
      toast.error("The HMS clinic-record export could not be prepared. Please try again.");
    }
  };

  return <div className="mx-auto max-w-6xl"><PageHeading eyebrow="External system access" title="HMS workspace" description="Keep the official HMS sign-in inside this protected Admin Portal page. This clinic portal does not store HMS usernames, passwords, browser sessions, or patient data from the external system." />
    <section className="border border-[#102032]/10 bg-white p-5 sm:p-8"><div className="flex flex-wrap items-start justify-between gap-4"><div><Globe2 className="size-7 text-[#a85438]" /><h2 className="mt-5 font-display text-3xl tracking-[-0.04em] text-[#102032]">Sign in to HMS inside this page</h2><p className="mt-3 max-w-3xl text-sm leading-6 text-[#52606B]">Enter the genuine HTTPS address supplied by your HMS provider. The HMS sign-in screen will load below without opening a new tab. Use the provider’s own login form inside the embedded view whenever it appears.</p></div>{embeddedUrl ? <Button variant="outline" onClick={clearWorkspace}>Close HMS view</Button> : null}</div><label className="mt-6 grid gap-2 text-sm font-bold text-[#102032]"><span>Official HMS HTTPS address</span><Input value={url} onChange={event => setUrl(event.target.value)} inputMode="url" placeholder="https://your-hms-provider.example/login" aria-label="Official HMS HTTPS address" /></label><div className="mt-5 flex flex-wrap items-center gap-3"><Button onClick={loadHms} disabled={!url.trim()}><Globe2 className="mr-2 size-4" />Load HMS inside page</Button></div></section><section className="mt-5 border border-[#102032]/10 bg-white p-5 sm:p-6"><div className="flex flex-wrap items-start justify-between gap-4"><div><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">Protected clinic export</p><h2 className="mt-2 font-display text-2xl tracking-[-0.04em] text-[#102032]">Download HMS clinic records</h2><p className="mt-2 max-w-3xl text-sm leading-6 text-[#52606B]">Downloads a transient CSV of HMS-imported appointment records that were attested to provider NR011 — JAMES FLORES. The file is generated from the built-in clinic database and is not saved to portal storage.</p></div><Button variant="outline" onClick={downloadHmsCsv} disabled={hmsExport.isFetching}>{hmsExport.isFetching ? <Loader2 className="mr-2 size-4 animate-spin" /> : <Download className="mr-2 size-4" />}{hmsExport.isFetching ? "Preparing CSV…" : "Download clinic records CSV"}</Button></div><p className="mt-4 text-xs leading-5 text-[#66727A]">The export excludes public requests, internal notes, raw source JSON, and records outside the protected NR011 import boundary. Keep downloaded files secure and delete them when no longer needed.</p></section>{embeddedUrl ? <section className="mt-5 overflow-hidden border border-[#102032]/10 bg-white"><div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#102032]/10 bg-[#f5f1e9] px-4 py-3"><div><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">In-page HMS session</p><p className="mt-1 break-all text-xs text-[#52606B]">{embeddedUrl}</p></div><Button size="sm" variant="outline" onClick={clearWorkspace}>Clear session view</Button></div><iframe title="Official HMS sign-in and workspace" src={embeddedUrl} className="h-[min(72vh,760px)] w-full bg-white" referrerPolicy="no-referrer" /></section> : <section className="mt-5 border border-dashed border-[#102032]/20 bg-white p-10 text-center"><Globe2 className="mx-auto size-8 text-[#a85438]" /><h2 className="mt-4 font-display text-2xl text-[#102032]">HMS will appear here</h2><p className="mx-auto mt-2 max-w-xl text-sm leading-6 text-[#52606B]">No new tab is opened. Enter the official address above, then load it into this page.</p></section>}
    <section className="mt-5 border border-amber-200 bg-amber-50 p-5 text-sm leading-6 text-amber-900"><strong>Provider boundary.</strong> Some HMS providers block embedded sign-in with browser security headers. If the frame is refused or blank, that is controlled by the HMS provider and cannot be bypassed safely from this clinic portal; no new tab will be opened. The existing in-portal CSV intake remains separate and accepts only the protected, NR011-attested workflow.</section><section className="mt-5 border border-[#102032]/10 bg-white p-5 text-sm leading-6 text-[#52606B]"><strong className="text-[#102032]">Source safeguard.</strong> Authorized administrators may apply audited local working-detail overrides from the Appointments page. Original HMS values, provider evidence, source row, fingerprint, identity key, and import batch remain immutable. Correct official source errors in HMS as well.</section>
  </div>;
}

function AppointmentEditPanel({ appointment, onClose }: { appointment: Appointment; onClose: () => void }) {
  const utils = trpc.useUtils();
  const [draft, setDraft] = useState(() => { let parsed: string[] = []; try { parsed = appointment.treatmentAreas ? (JSON.parse(appointment.treatmentAreas) as string[]) : []; } catch { parsed = []; } const parsedAreas = parsed.map(normalizeManualArea).filter((area): area is ManualTreatmentArea => Boolean(area)); const primaryArea = normalizeManualArea(appointment.treatmentArea ?? ""); const selectedAreas = parsedAreas.length ? parsedAreas : primaryArea ? [primaryArea] : []; const machine = appointment.machine && machines.includes(appointment.machine as Machine) ? appointment.machine as Machine : ""; const visitType = appointment.visitType === "session" || appointment.visitType === "retouch" ? appointment.visitType : ""; return { fullName: appointment.patientName, mrn: appointment.mrn ?? "", nationality: appointment.nationality ?? "", contactNumber: appointment.contactNumber ?? "", whatsapp: appointment.whatsapp ?? "", email: appointment.email ?? "", appointmentDate: appointment.appointmentDate, appointmentTime: appointment.appointmentTime, treatmentAreas: selectedAreas, treatmentArea: selectedAreas[0] ?? "", machine: machine as Machine | "", visitType: visitType as VisitType | "", nextFollowUpDate: appointment.nextFollowUpDate ?? "", nextFollowUpType: (appointment.nextFollowUpType ?? "") as VisitType | "", notes: appointment.internalNotes ?? "" }; });
  const update = (change: Partial<typeof draft>) => setDraft(current => ({ ...current, ...change }));
  const save = trpc.admin.updateAppointmentDetails.useMutation({
    onSuccess: async () => { toast.success("Appointment details updated without changing source or consent evidence."); await Promise.all([utils.admin.appointments.invalidate(), utils.admin.waitingList.invalidate(), utils.admin.patientFile.invalidate(), utils.admin.patients.invalidate()]); onClose(); },
    onError: error => toast.error(error.message),
  });
  const ready = Boolean(draft.fullName.trim() && draft.nationality.trim() && draft.contactNumber.trim() && draft.whatsapp.trim() && draft.appointmentDate && draft.appointmentTime && draft.treatmentAreas.length > 0 && draft.machine && draft.visitType);
  const submit = () => {
    if (!ready || !draft.machine || !draft.visitType || !window.confirm("Save these local appointment details? The original HMS source evidence will remain unchanged.")) return;
    save.mutate({ appointmentId: appointment.id, ...draft, machine: draft.machine, visitType: draft.visitType, nextFollowUpType: draft.nextFollowUpType || null });
  };
  return <section className="border border-[#a85438]/30 bg-[#fffaf5] p-4 sm:p-5"><div className="flex flex-wrap items-start justify-between gap-3 border-b border-[#102032]/10 pb-4"><div><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">Protected appointment edit</p><h3 className="mt-1 break-words font-display text-2xl text-[#102032] [overflow-wrap:anywhere]">Edit {appointment.patientName}</h3><p className="mt-1 max-w-2xl text-sm leading-6 text-[#52606B]">Save audited local working details. The HMS provider, source row, fingerprint, identity key, import batch, original values, consent references, and signature evidence remain unchanged.</p></div><Button variant="ghost" size="sm" onClick={onClose}>Close</Button></div><div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-3"><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Patient name<Input value={draft.fullName} onChange={event => update({ fullName: event.target.value })} /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">MRN<Input value={draft.mrn} onChange={event => update({ mrn: event.target.value })} /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Nationality<Input value={draft.nationality} onChange={event => update({ nationality: event.target.value })} /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Contact number<Input value={draft.contactNumber} onChange={event => update({ contactNumber: event.target.value })} inputMode="tel" /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">WhatsApp number<Input value={draft.whatsapp} onChange={event => update({ whatsapp: event.target.value })} inputMode="tel" /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Email<Input value={draft.email} onChange={event => update({ email: event.target.value })} type="email" /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Date<Input value={draft.appointmentDate} onChange={event => update({ appointmentDate: event.target.value })} type="date" /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Time<select value={draft.appointmentTime} onChange={event => update({ appointmentTime: event.target.value })} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm">{manualAppointmentTimes.map(item => <option key={item.value} value={item.value}>{item.label}</option>)}</select></label><TreatmentAreaChecklist value={draft.treatmentAreas} onChange={treatmentAreas => update({ treatmentAreas, treatmentArea: treatmentAreas[0] ?? "" })} /><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Machine<select value={draft.machine} onChange={event => update({ machine: event.target.value as Machine | "" })} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm"><option value="" disabled>Select machine</option>{machines.map(machine => <option key={machine} value={machine}>{machine}</option>)}</select></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Visit type<select value={draft.visitType} onChange={event => update({ visitType: event.target.value as VisitType | "" })} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm"><option value="" disabled>Select visit type</option><option value="session">Session</option><option value="retouch">Retouch</option></select></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Next follow-up date<Input value={draft.nextFollowUpDate} onChange={event => update({ nextFollowUpDate: event.target.value })} type="date" /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Next follow-up type<select value={draft.nextFollowUpType} onChange={event => update({ nextFollowUpType: event.target.value as VisitType | "" })} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm"><option value="">Not scheduled</option><option value="session">Session</option><option value="retouch">Retouch</option></select></label><label className="grid gap-1.5 text-xs font-bold text-[#102032] sm:col-span-2"><span>Private notes</span><textarea value={draft.notes} onChange={event => update({ notes: event.target.value })} className="min-h-20 border border-[#102032]/20 bg-white p-3 text-sm font-normal" /></label></div><div className="mt-4 flex flex-wrap items-center gap-3"><Button disabled={!ready || save.isPending} onClick={submit}>{save.isPending ? <Loader2 className="mr-2 size-4 animate-spin" /> : <CheckCircle2 className="mr-2 size-4" />}Save appointment details</Button><p className="text-xs text-[#66727A]">Required fields, treatment areas, machine, and visit type must be completed. Server checks prevent schedule conflicts and reject any MRN/mobile match that resolves to different patient files.</p></div></section>;
}

function ArrivalDetailsPanel({ appointment, onClose, mode = "arrived" }: { appointment: Appointment; onClose: () => void; mode?: "waiting" | "arrived" }) {
  const utils = trpc.useUtils();
  const [draft, setDraft] = useState(() => {
    let parsedAreas: string[] = [];
    try { parsedAreas = appointment.treatmentAreas ? JSON.parse(appointment.treatmentAreas) as string[] : []; } catch { parsedAreas = []; }
    const normalizedAreas = parsedAreas.map(normalizeManualArea).filter((area): area is ManualTreatmentArea => Boolean(area));
    const fallbackArea = normalizeManualArea(appointment.treatmentArea ?? "");
    return {
      fullName: appointment.patientName,
      mrn: appointment.mrn ?? "",
      nationality: appointment.nationality ?? "",
      contactNumber: appointment.contactNumber ?? appointment.whatsapp ?? "",
      whatsapp: appointment.whatsapp ?? appointment.contactNumber ?? "",
      email: appointment.email ?? "",
      treatmentAreas: normalizedAreas.length > 0 ? normalizedAreas : fallbackArea ? [fallbackArea] : [] as ManualTreatmentArea[],
      machine: (appointment.machine ?? "") as Machine | "",
      visitType: (appointment.visitType === "session" || appointment.visitType === "retouch" ? appointment.visitType : "") as VisitType | "",
      nurseNotes: appointment.internalNotes ?? "",
    };
  });
  const update = (change: Partial<typeof draft>) => setDraft(current => ({ ...current, ...change }));
  const confirmArrival = trpc.admin.confirmArrival.useMutation({
    onSuccess: async result => {
      toast.success(result.createdPatient ? "Arrival saved and patient profile created." : "Arrival saved and existing patient profile linked.");
      await Promise.all([
        utils.admin.waitingList.invalidate(),
        utils.admin.dashboard.invalidate(),
        utils.admin.appointments.invalidate(),
        utils.admin.patients.invalidate(),
        utils.admin.patientFile.invalidate(),
      ]);
      onClose();
    },
    onError: error => toast.error(error.message),
  });
  const markWaiting = trpc.admin.markWaiting.useMutation({
    onSuccess: async result => {
      toast.success(result.createdPatient ? "Patient marked waiting and patient profile created." : "Patient marked waiting and existing patient profile linked.");
      await Promise.all([
        utils.admin.waitingList.invalidate(),
        utils.admin.dashboard.invalidate(),
        utils.admin.appointments.invalidate(),
        utils.admin.patients.invalidate(),
        utils.admin.patientFile.invalidate(),
      ]);
      onClose();
    },
    onError: error => toast.error(error.message),
  });
  const ready = Boolean(draft.fullName.trim() && draft.nationality.trim() && draft.contactNumber.trim().length >= 7 && draft.whatsapp.trim().length >= 7 && draft.treatmentAreas.length > 0 && draft.machine && draft.visitType && draft.nurseNotes.trim().length >= 2);
  const isSaving = confirmArrival.isPending || markWaiting.isPending;
  const isWaiting = mode === "waiting";

  const savePatientIntake = () => {
    if (!ready || !draft.machine || !draft.visitType) return;
    const input = {
      appointmentId: appointment.id,
      ...draft,
      machine: draft.machine,
      visitType: draft.visitType,
    };
    if (isWaiting) markWaiting.mutate(input); else confirmArrival.mutate(input);
  };

  return <section className={`mt-3 border p-4 sm:p-5 ${isWaiting ? "border-amber-300 bg-amber-50/70" : "border-emerald-300 bg-emerald-50/70"}`}>
    <div className={`flex flex-wrap items-start justify-between gap-3 border-b pb-4 ${isWaiting ? "border-amber-200" : "border-emerald-200"}`}>
      <div><p className={`text-[10px] font-extrabold uppercase tracking-[0.16em] ${isWaiting ? "text-amber-800" : "text-emerald-700"}`}>{isWaiting ? "Waiting-list intake · protected" : "Arrival details · protected"}</p><h3 className="mt-1 font-display text-2xl text-[#102032]">{isWaiting ? `Mark ${appointment.patientName} as waiting` : `Confirm ${appointment.patientName} has arrived`}</h3><p className="mt-1 max-w-3xl text-sm leading-6 text-[#52606B]">Review the patient details, choose session or retouch, record the machine and all treatment areas, then add the nurse’s notes. The server will create one patient profile or link the matching MRN/mobile file.</p></div>
      <Button variant="ghost" size="sm" onClick={onClose}>Close</Button>
    </div>
    <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
      <label className="grid gap-1.5 text-xs font-bold text-[#102032]">Patient name<Input value={draft.fullName} onChange={event => update({ fullName: event.target.value })} /></label>
      <label className="grid gap-1.5 text-xs font-bold text-[#102032]">MRN <span className="font-normal text-[#66727A]">(optional)</span><Input value={draft.mrn} onChange={event => update({ mrn: event.target.value })} /></label>
      <label className="grid gap-1.5 text-xs font-bold text-[#102032]">Nationality<Input value={draft.nationality} onChange={event => update({ nationality: event.target.value })} /></label>
      <label className="grid gap-1.5 text-xs font-bold text-[#102032]">Contact number<Input value={draft.contactNumber} onChange={event => update({ contactNumber: event.target.value })} inputMode="tel" /></label>
      <label className="grid gap-1.5 text-xs font-bold text-[#102032]">WhatsApp number<Input value={draft.whatsapp} onChange={event => update({ whatsapp: event.target.value })} inputMode="tel" /></label>
      <label className="grid gap-1.5 text-xs font-bold text-[#102032]">Email <span className="font-normal text-[#66727A]">(optional)</span><Input value={draft.email} onChange={event => update({ email: event.target.value })} type="email" /></label>
      <label className="grid gap-1.5 text-xs font-bold text-[#102032]">Session / Retouch<select value={draft.visitType} onChange={event => update({ visitType: event.target.value as VisitType | "" })} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm font-normal"><option value="" disabled>Select visit type</option><option value="session">Session</option><option value="retouch">Retouch</option></select></label>
      <label className="grid gap-1.5 text-xs font-bold text-[#102032] sm:col-span-1 xl:col-span-2">Machine used<select value={draft.machine} onChange={event => update({ machine: event.target.value as Machine | "" })} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm font-normal"><option value="" disabled>Select machine used</option>{machines.map(machine => <option key={machine} value={machine}>{machine}</option>)}</select></label>
      <TreatmentAreaChecklist value={draft.treatmentAreas} onChange={treatmentAreas => update({ treatmentAreas })} />
      <label className="grid gap-1.5 text-xs font-bold text-[#102032] sm:col-span-2 xl:col-span-3"><span>Nurse’s notes <span className="text-red-700">*</span></span><textarea value={draft.nurseNotes} onChange={event => update({ nurseNotes: event.target.value })} maxLength={12000} placeholder="Record the arrival assessment or visit note for the protected patient history." className="min-h-28 border border-[#102032]/20 bg-white p-3 text-sm font-normal" /></label>
    </div>
    <div className="mt-4 flex flex-wrap items-center gap-3"><Button disabled={!ready || isSaving} onClick={savePatientIntake}>{isSaving ? <Loader2 className="mr-2 size-4 animate-spin" /> : isWaiting ? <Clock3 className="mr-2 size-4" /> : <CheckCircle2 className="mr-2 size-4" />}{isWaiting ? "Save waiting patient and profile" : "Save arrival and patient profile"}</Button><p className="text-xs leading-5 text-[#66727A]">Appointment: {appointment.appointmentDate} at {appointment.appointmentTime}. Structured visit details are saved locally; HMS source evidence remains unchanged.</p></div>
  </section>;
}

function PostSessionNotesPanel({ appointment, onClose }: { appointment: Appointment; onClose: () => void }) {
  const utils = trpc.useUtils();
  const [nurseName, setNurseName] = useState(appointment.assignedStaff ?? "");
  const [outcome, setOutcome] = useState("");
  const [notes, setNotes] = useState("");
  const finishSession = trpc.admin.finishSession.useMutation({
    onSuccess: async () => {
      toast.success("Session finished and post-session notes saved.");
      await Promise.all([
        utils.admin.waitingList.invalidate(),
        utils.admin.dashboard.invalidate(),
        utils.admin.appointments.invalidate(),
        utils.admin.sessionRecords.invalidate(),
        utils.admin.eligibleSessionAppointments.invalidate(),
      ]);
      onClose();
    },
    onError: error => toast.error(error.message),
  });
  const ready = Boolean(outcome.trim().length >= 2 && notes.trim().length >= 2);

  return <section className="mt-3 border border-blue-300 bg-blue-50/70 p-4 sm:p-5">
    <div className="flex flex-wrap items-start justify-between gap-3 border-b border-blue-200 pb-4"><div><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-blue-800">Post-session record · protected</p><h3 className="mt-1 font-display text-2xl text-[#102032]">Nurse’s Notes — {appointment.patientName}</h3><p className="mt-1 max-w-3xl text-sm leading-6 text-[#52606B]">Record the completed session outcome and private nurse’s notes. Saving this form creates one protected session record and marks the arrived appointment as finished together.</p></div><Button variant="ghost" size="sm" disabled={finishSession.isPending} onClick={onClose}>Cancel</Button></div>
    <div className="mt-4 grid gap-3 sm:grid-cols-2"><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Nurse / specialist <span className="font-normal text-[#66727A]">(optional — signed-in staff is recorded)</span><Input value={nurseName} maxLength={120} onChange={event => setNurseName(event.target.value)} placeholder="Staff name" /></label><div className="border border-blue-200 bg-white/70 p-3 text-sm text-[#52606B]"><p className="font-semibold text-[#102032]">Session details</p><p className="mt-1">{appointment.appointmentDate} · {appointment.appointmentTime}</p><p className="mt-1">{appointment.machine ?? "Machine not recorded"} · {appointment.visitType === "retouch" ? "Retouch" : "Session"}</p></div><label className="grid gap-1.5 text-xs font-bold text-[#102032] sm:col-span-2"><span>Session outcome <span className="text-red-700">*</span></span><textarea value={outcome} onChange={event => setOutcome(event.target.value)} maxLength={12000} placeholder="Record the treatment outcome." className="min-h-24 border border-[#102032]/20 bg-white p-3 text-sm font-normal" /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032] sm:col-span-2"><span>Private Nurse’s Notes <span className="text-red-700">*</span></span><textarea value={notes} onChange={event => setNotes(event.target.value)} maxLength={12000} placeholder="Record the post-session clinical or operational notes for the protected patient history." className="min-h-28 border border-[#102032]/20 bg-white p-3 text-sm font-normal" /></label></div>
    <div className="mt-4 flex flex-wrap items-center gap-3"><Button disabled={!ready || finishSession.isPending} onClick={() => finishSession.mutate({ appointmentId: appointment.id, nurseName, outcome, notes })}>{finishSession.isPending ? <Loader2 className="mr-2 size-4 animate-spin" /> : <CheckCircle2 className="mr-2 size-4" />}Save notes & finish session</Button><p className="text-xs leading-5 text-[#52606B]">The appointment remains Arrived until this protected record is saved. HMS source evidence is not changed.</p></div>
  </section>;
}

export function WaitingList() {
  const [date, setDate] = useState(riyadhToday);
  const [arrivalAppointmentId, setArrivalAppointmentId] = useState<number | null>(null);
  const [waitingAppointmentId, setWaitingAppointmentId] = useState<number | null>(null);
  const [postSessionAppointmentId, setPostSessionAppointmentId] = useState<number | null>(null);
  const today = riyadhToday();
  const canUpdateAttendance = date === today;
  const waitingList = trpc.admin.waitingList.useQuery({ date }, {
    // The page is mounted only for the active Waiting List route. Poll only today’s
    // live queue, pause while the tab is backgrounded, and let React Query own one
    // interval per observer so no duplicate timers are created.
    refetchInterval: canUpdateAttendance ? 5000 : false,
    refetchIntervalInBackground: false,
    staleTime: 0,
  });
  const utils = trpc.useUtils();
  const attendance = trpc.admin.markAttendance.useMutation({
    onSuccess: async (_result, variables) => {
      toast.success(variables.status === "no-show" ? "No-show recorded." : "Patient attendance updated.");
      await Promise.all([utils.admin.waitingList.invalidate(), utils.admin.dashboard.invalidate(), utils.admin.appointments.invalidate()]);
    },
    onError: error => toast.error(error.message),
  });
  const closePanels = () => { setArrivalAppointmentId(null); setWaitingAppointmentId(null); setPostSessionAppointmentId(null); };

  const statusBadge = (status: Appointment["status"]) => {
    if (status === "waiting") return <Badge className="bg-amber-100 text-amber-900 hover:bg-amber-100">Waiting</Badge>;
    if (status === "arrived") return <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100">Arrived</Badge>;
    if (status === "completed") return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Completed</Badge>;
    if (status === "cancelled") return <Badge variant="secondary">Cancelled</Badge>;
    if (status === "no-show") return <Badge variant="secondary">No show</Badge>;
    return <Badge variant="outline">Awaiting arrival</Badge>;
  };

  return <div className="mx-auto max-w-6xl"><PageHeading eyebrow={`${date === today ? "Today" : "Selected date"} · Riyadh`} title="Waiting list" description={canUpdateAttendance ? "Today’s appointment record. Record the same protected patient and visit details to place a confirmed appointment in Waiting or Arrived, then complete the visit when finished. Each outcome remains visible today." : "Review the retained appointment outcomes for this selected date. Attendance actions are available only for the current Riyadh date."} action={<div className="flex flex-wrap gap-2"><Input aria-label="Waiting list date" className="w-[160px]" type="date" value={date} onChange={event => { setDate(event.target.value); closePanels(); }} /><Button variant="outline" onClick={() => { setDate(today); closePanels(); }}>Today</Button></div>} />
    {waitingList.isLoading ? <AdminLoadingState label="Loading waiting list…" /> : waitingList.isError ? <AdminErrorState title="Waiting list unavailable" description="The waiting list could not be loaded from the protected clinic database." onRetry={() => waitingList.refetch()} /> : waitingList.data?.length === 0 ? <AdminEmptyState title="No appointments in today’s record" description="Confirmed appointments for today will appear here in time order." icon={ListChecks} /> : <div className="space-y-3">{waitingList.data?.map(appointment => {
      const isPending = attendance.isPending && attendance.variables?.appointmentId === appointment.id;
      const isConfirmed = appointment.status === "confirmed";
      const isWaiting = appointment.status === "waiting";
      const isArrived = appointment.status === "arrived";
      const cardClass = isWaiting ? "border-amber-200 bg-amber-50/60" : isArrived ? "border-emerald-200 bg-emerald-50/50" : appointment.status === "completed" ? "border-blue-200 bg-blue-50/50" : appointment.status === "no-show" || appointment.status === "cancelled" ? "border-slate-200 bg-slate-50" : "border-[#102032]/10 bg-white";
      return <div key={appointment.id}><article className={`flex flex-col gap-4 border p-5 transition sm:flex-row sm:items-center sm:justify-between ${cardClass}`}><div className="flex min-w-0 items-start gap-4"><div className="grid size-11 shrink-0 place-items-center rounded-full bg-[#102032] font-display text-lg text-white">{appointment.appointmentTime.slice(0, 2)}</div><div className="min-w-0"><div className="flex flex-wrap items-center gap-3"><h2 className="font-display text-2xl tracking-[-0.035em] text-[#102032]">{appointment.patientName}</h2><WhatsAppBusinessWebAction phone={appointment.whatsapp || appointment.contactNumber} patientName={appointment.patientName} subjectType="appointment" subjectId={appointment.id} />{statusBadge(appointment.status)}</div><p className="mt-1 flex flex-wrap gap-x-3 gap-y-1 text-sm text-[#52606B]"><span>{appointment.appointmentTime}</span><span>•</span><span>{appointment.treatmentArea || "Not recorded"}</span><span>•</span><span>{appointment.machine || "Not assigned"}</span></p><p className="mt-1 text-xs text-[#66727A]">{appointment.whatsapp || "Contact not supplied"}</p></div></div><div className="flex shrink-0 flex-wrap items-center gap-2 self-end sm:self-auto">{isConfirmed ? <><Button disabled={isPending || !canUpdateAttendance} size="sm" aria-label={`Record arrival details and notes for ${appointment.patientName}`} className="min-h-11 touch-manipulation bg-emerald-600 hover:bg-emerald-700" onClick={() => { setArrivalAppointmentId(current => current === appointment.id ? null : appointment.id); setWaitingAppointmentId(null); }}><Check className="mr-2 size-5" />Arrival & notes</Button><Button disabled={isPending || !canUpdateAttendance} size="sm" variant="outline" className="min-h-11 touch-manipulation border-amber-300 text-amber-900 hover:bg-amber-100 hover:text-amber-950" onClick={() => { setWaitingAppointmentId(current => current === appointment.id ? null : appointment.id); setArrivalAppointmentId(null); }}><Clock3 className="mr-2 size-4" />Mark waiting</Button><Button disabled={isPending || !canUpdateAttendance} size="sm" variant="outline" aria-label={`Mark ${appointment.patientName} as no show`} className="min-h-11 touch-manipulation border-red-200 text-red-700 hover:bg-red-50 hover:text-red-800" onClick={() => attendance.mutate({ appointmentId: appointment.id, status: "no-show" })}>{isPending ? <Loader2 className="size-4 animate-spin" /> : <X className="mr-2 size-4" />}No show</Button><Button disabled={isPending || !canUpdateAttendance} size="sm" variant="outline" className="min-h-11 touch-manipulation" onClick={() => attendance.mutate({ appointmentId: appointment.id, status: "cancelled" })}>Cancel</Button></> : isWaiting ? <><Button disabled={isPending || !canUpdateAttendance} size="sm" className="min-h-11 touch-manipulation bg-emerald-600 hover:bg-emerald-700" onClick={() => attendance.mutate({ appointmentId: appointment.id, status: "arrived" })}>{isPending ? <Loader2 className="mr-2 size-4 animate-spin" /> : <Check className="mr-2 size-4" />}Mark arrived</Button><Button disabled={isPending || !canUpdateAttendance} size="sm" variant="outline" aria-label={`Mark waiting patient ${appointment.patientName} as no show`} className="min-h-11 touch-manipulation border-red-200 text-red-700 hover:bg-red-50 hover:text-red-800" onClick={() => attendance.mutate({ appointmentId: appointment.id, status: "no-show" })}>{isPending ? <Loader2 className="size-4 animate-spin" /> : <X className="mr-2 size-4" />}No show</Button><Button disabled={isPending || !canUpdateAttendance} size="sm" variant="outline" className="min-h-11 touch-manipulation" onClick={() => attendance.mutate({ appointmentId: appointment.id, status: "cancelled" })}>Cancel</Button></> : isArrived ? <Button disabled={!canUpdateAttendance} size="sm" className="min-h-11 touch-manipulation" onClick={() => { setPostSessionAppointmentId(current => current === appointment.id ? null : appointment.id); setArrivalAppointmentId(null); setWaitingAppointmentId(null); }}><CheckCircle2 className="mr-2 size-4" />Finish</Button> : <span className="text-xs font-semibold text-[#66727A]">Status recorded</span>}</div></article>{arrivalAppointmentId === appointment.id && isConfirmed && canUpdateAttendance ? <ArrivalDetailsPanel appointment={appointment} onClose={() => setArrivalAppointmentId(null)} /> : null}{waitingAppointmentId === appointment.id && isConfirmed && canUpdateAttendance ? <ArrivalDetailsPanel appointment={appointment} mode="waiting" onClose={() => setWaitingAppointmentId(null)} /> : null}{postSessionAppointmentId === appointment.id && isArrived && canUpdateAttendance ? <PostSessionNotesPanel appointment={appointment} onClose={() => setPostSessionAppointmentId(null)} /> : null}</div>;
    })}</div>}
    {!canUpdateAttendance ? <p className="mt-5 border border-[#102032]/10 bg-[#f5f1e9] p-4 text-sm leading-6 text-[#52606B]">Attendance controls are intentionally read-only for past or future dates. Return to Today to record the current Riyadh operational outcome.</p> : null}
  </div>;
}

function Patients() {
  const [search, setSearch] = useState("");
  const [selectedPatientId, setSelectedPatientId] = useState<number | null>(null);
  const [manualOpen, setManualOpen] = useState(false);
  const [editingPatientId, setEditingPatientId] = useState<number | null>(null);
  const patients = trpc.admin.patients.useQuery({ query: search.trim() || undefined });
  const patientFile = trpc.admin.patientFile.useQuery({ patientId: selectedPatientId ?? 0 }, { enabled: selectedPatientId !== null });

  return <div className="mx-auto max-w-6xl"><PageHeading eyebrow="Clinic records" title="Patients" description="One protected patient file per WhatsApp number. Open a file to review the patient’s contact details, intake screening, notes, and linked appointment history." action={<div className="flex w-full flex-wrap gap-2 sm:w-auto"><Button onClick={() => setManualOpen(value => !value)}><UserRound className="mr-2 size-4" />Add patient</Button><div className="relative min-w-[220px] flex-1 sm:w-[280px]"><Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-[#66727A]" /><Input value={search} onChange={event => setSearch(event.target.value)} className="pl-9" placeholder="Search name or WhatsApp" aria-label="Search patients" /></div></div>} />
    {manualOpen ? <ManualPatientPanel onClose={() => setManualOpen(false)} /> : null}
    <div className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">{patients.isLoading ? <div className="space-y-3">{Array.from({ length: 5 }).map((_, index) => <Skeleton key={index} className="h-24 rounded-none" />)}</div> : patients.isError ? <p className="border border-red-200 bg-red-50 p-5 text-sm text-red-800">Patient records could not be loaded. Please refresh and try again.</p> : patients.data?.length === 0 ? <div className="border border-dashed border-[#102032]/20 bg-white p-10 text-center"><UserRound className="mx-auto size-7 text-[#a85438]" /><h2 className="mt-4 font-display text-2xl text-[#102032]">No patient files yet</h2><p className="mt-2 text-sm text-[#52606B]">A patient file is created after request approval or through the protected Add patient action.</p></div> : <div className="space-y-3">{patients.data?.map(patient => <PatientListEntry key={patient.id} patient={patient} selected={selectedPatientId === patient.id} onSelect={() => setSelectedPatientId(patient.id)} />)}</div>}
      <section className="min-h-[420px] border border-[#102032]/10 bg-white p-5 sm:p-7">{selectedPatientId === null ? <div className="grid h-full place-items-center text-center"><div><UserRound className="mx-auto size-8 text-[#a85438]" /><h2 className="mt-4 font-display text-3xl tracking-[-0.04em] text-[#102032]">Open a patient file</h2><p className="mt-2 max-w-sm text-sm leading-6 text-[#52606B]">Select an approved patient to view the complete clinic record and appointment history.</p></div></div> : patientFile.isLoading ? <div className="space-y-4"><Skeleton className="h-10 w-2/3" /><Skeleton className="h-28" /><Skeleton className="h-36" /></div> : patientFile.isError || !patientFile.data ? <p className="border border-red-200 bg-red-50 p-5 text-sm text-red-800">This patient file could not be loaded. Please select another file.</p> : <><PatientFile data={patientFile.data} onEdit={() => setEditingPatientId(patientFile.data.patient.id)} />{editingPatientId === patientFile.data.patient.id ? <PatientEditPanel patient={patientFile.data.patient} onClose={() => setEditingPatientId(null)} /> : null}</>}</section>
    </div>
  </div>;
}

function PatientListEntry({ patient, selected, onSelect }: { patient: Patient; selected: boolean; onSelect: () => void }) {
  return <article className={`border p-5 transition ${selected ? "border-[#a85438] bg-[#fdf8f1]" : "border-[#102032]/10 bg-white hover:border-[#a85438]/45"}`}><div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-2"><button type="button" onClick={onSelect} className="min-w-0 text-left focus-visible:outline-2 focus-visible:outline-[#a85438]"><div className="flex items-start justify-between gap-3"><div className="min-w-0"><h2 className="truncate font-display text-2xl tracking-[-0.035em] text-[#102032]">{patient.fullName}</h2><p className="mt-1 text-sm text-[#52606B]">{patient.whatsapp}</p></div><Badge variant="outline" className="hidden sm:inline-flex">File #{patient.id}</Badge></div><p className="mt-4 text-sm text-[#52606B]"><strong className="text-[#102032]">{patient.treatmentArea}</strong> · {patient.nationality}</p></button><WhatsAppBusinessWebAction phone={patient.whatsapp} patientName={patient.fullName} subjectType="patient" subjectId={patient.id} /></div></article>;
}

function PatientFile({ data, onEdit }: { data: { patient: Patient; appointments: Appointment[] }; onEdit: () => void }) {
  const { patient, appointments } = data;
  const bool = (value: boolean | null) => value === null ? "Not assessed" : value ? "Yes" : "No";
  return <div><div className="flex flex-col gap-4 border-b border-[#102032]/10 pb-5 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">Patient file #{patient.id}{patient.mrn ? ` · MRN ${patient.mrn}` : ""}</p><div className="mt-2 flex flex-wrap items-center gap-2"><button type="button" onClick={onEdit} className="font-display text-4xl tracking-[-0.05em] text-[#102032] underline decoration-[#a85438]/60 decoration-2 underline-offset-4 hover:text-[#a85438] focus-visible:outline-2 focus-visible:outline-[#a85438]">{patient.fullName}</button><WhatsAppBusinessWebAction phone={patient.whatsapp} patientName={patient.fullName} subjectType="patient" subjectId={patient.id} /></div><p className="mt-2 flex flex-wrap gap-x-3 gap-y-1 text-sm text-[#52606B]"><span>{patient.whatsapp}</span>{patient.email ? <><span>•</span><span>{patient.email}</span></> : null}</p></div><Button variant="outline" size="sm" onClick={onEdit}>Edit patient</Button></div>
    <div className="mt-6 grid gap-6"><section><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">Profile & treatment</p><dl className="mt-3 grid gap-3 text-sm sm:grid-cols-2"><div><dt className="text-[#66727A]">Nationality</dt><dd className="mt-1 font-semibold text-[#102032]">{patient.nationality}</dd></div><div><dt className="text-[#66727A]">Preferred contact</dt><dd className="mt-1 font-semibold text-[#102032]">{patient.preferredContact}</dd></div><div><dt className="text-[#66727A]">Requested area</dt><dd className="mt-1 font-semibold text-[#102032]">{patient.treatmentArea}</dd></div><div><dt className="text-[#66727A]">Previous laser</dt><dd className="mt-1 font-semibold text-[#102032]">{patient.firstTime ? "First treatment" : patient.lastLaserSession || "Previous treatment"}</dd></div><div><dt className="text-[#66727A]">WhatsApp communication</dt><dd className="mt-1 font-semibold capitalize text-[#102032]">{patient.whatsappConsentStatus === "unknown" ? "Consent verification required" : patient.whatsappConsentStatus.replaceAll("_", " ")}{patient.whatsappConsentAt ? <small className="mt-1 block text-xs font-normal text-[#66727A]">Recorded {new Date(patient.whatsappConsentAt).toLocaleString()}</small> : null}</dd></div></dl></section>
      <section className="border-y border-[#102032]/10 py-5"><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">Safety screening</p><dl className="mt-3 grid gap-3 text-sm sm:grid-cols-2"><div><dt className="text-[#66727A]">Medication</dt><dd className="mt-1 font-semibold text-[#102032]">{patient.takingMedication === null ? "Not assessed" : patient.takingMedication ? patient.medicationDetails || "Yes" : "No"}</dd></div><div><dt className="text-[#66727A]">Vitamin D</dt><dd className="mt-1 font-semibold text-[#102032]">{patient.tookVitaminD === null ? "Not assessed" : patient.tookVitaminD ? patient.vitaminDLastTaken || "Yes" : "No"}</dd></div><div><dt className="text-[#66727A]">Iron</dt><dd className="mt-1 font-semibold text-[#102032]">{patient.takingIron === null ? "Not assessed" : patient.takingIron ? patient.ironLastTaken || "Yes" : "No"}</dd></div><div><dt className="text-[#66727A]">Tanned within 3 months</dt><dd className="mt-1 font-semibold text-[#102032]">{bool(patient.tannedPastThreeMonths)}</dd></div><div><dt className="text-[#66727A]">Moroccan bath within 7 days</dt><dd className="mt-1 font-semibold text-[#102032]">{bool(patient.hadMoroccanBathLastSevenDays)}</dd></div><div><dt className="text-[#66727A]">Recent skin treatment</dt><dd className="mt-1 font-semibold text-[#102032]">{patient.hadSkinTreatment === null ? "Not assessed" : patient.hadSkinTreatment ? patient.skinTreatmentDetails || "Yes" : "No"}</dd></div><div><dt className="text-[#66727A]">Severe sun exposure</dt><dd className="mt-1 font-semibold text-[#102032]">{bool(patient.hadSevereSunExposure)}</dd></div></dl>{patient.notes ? <p className="mt-4 rounded-sm bg-[#f5f1e9] p-3 text-sm leading-6 text-[#52606B]"><strong className="text-[#102032]">Notes:</strong> {patient.notes}</p> : null}</section>
      <section><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">Appointment history</p>{appointments.length === 0 ? <p className="mt-3 text-sm text-[#52606B]">No linked appointments yet.</p> : <div className="mt-3 space-y-2">{appointments.map(appointment => <div key={appointment.id} className="border border-[#102032]/10 p-3 text-sm"><div className="flex flex-wrap items-center justify-between gap-2"><div><p className="font-semibold text-[#102032]">{appointment.appointmentDate} · {appointment.appointmentTime}</p><p className="mt-1 text-xs text-[#52606B]"><span className="capitalize">{appointment.visitType}</span> · {appointment.machine || "Machine not recorded"}</p><p className="mt-1 text-xs text-[#52606B]">Areas: {appointmentAreaSummary(appointment)}</p><p className="mt-1 text-xs text-[#52606B]">WhatsApp: {appointment.whatsappAttendanceConfirmation.replaceAll("_", " ")}{appointment.whatsappAttendanceConfirmedAt ? ` · confirmed ${new Date(appointment.whatsappAttendanceConfirmedAt).toLocaleString()}` : appointment.whatsappCannotAttendAt ? ` · response ${new Date(appointment.whatsappCannotAttendAt).toLocaleString()}` : ""}</p></div><Badge variant="outline" className="capitalize">{appointment.status}</Badge></div>{appointment.internalNotes ? <p className="mt-3 border-s-2 border-[#a85438] bg-[#f5f1e9] p-3 text-xs leading-5 text-[#52606B]"><strong className="text-[#102032]">Nurse’s notes:</strong> {appointment.internalNotes}</p> : null}</div>)}</div>}</section>
    </div>
  </div>;
}

function PatientEditPanel({ patient, onClose }: { patient: Patient; onClose: () => void }) {
  const utils = trpc.useUtils();
  const [draft, setDraft] = useState(() => ({ fullName: patient.fullName, mrn: patient.mrn ?? "", nationality: patient.nationality, contactNumber: patient.contactNumber ?? "", whatsapp: patient.whatsapp, email: patient.email ?? "", treatmentArea: patient.treatmentArea, notes: patient.notes ?? "" }));
  const update = (change: Partial<typeof draft>) => setDraft(current => ({ ...current, ...change }));
  const save = trpc.admin.updatePatientFile.useMutation({
    onSuccess: async () => { toast.success("Patient file updated without creating a duplicate record."); await Promise.all([utils.admin.patients.invalidate(), utils.admin.patientFile.invalidate(), utils.admin.appointments.invalidate()]); onClose(); },
    onError: error => toast.error(error.message),
  });
  const ready = Boolean(draft.fullName.trim() && draft.nationality.trim() && draft.contactNumber.trim() && draft.whatsapp.trim() && draft.treatmentArea.trim());
  return <section className="mt-6 border border-[#a85438]/30 bg-[#fffaf5] p-4 sm:p-5"><div className="flex flex-wrap items-start justify-between gap-3 border-b border-[#102032]/10 pb-4"><div><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">Protected patient edit</p><h3 className="mt-1 font-display text-2xl text-[#102032]">Edit {patient.fullName}</h3><p className="mt-1 max-w-2xl text-sm leading-6 text-[#52606B]">Source intake and safety-screening history remain retained. The server rejects an MRN or mobile number that belongs to a different patient file.</p></div><Button variant="ghost" size="sm" onClick={onClose}>Close</Button></div><div className="mt-4 grid gap-3 sm:grid-cols-2"><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Full name<Input value={draft.fullName} onChange={event => update({ fullName: event.target.value })} /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">MRN<Input value={draft.mrn} onChange={event => update({ mrn: event.target.value })} /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Nationality<Input value={draft.nationality} onChange={event => update({ nationality: event.target.value })} /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Treatment area<Input value={draft.treatmentArea} onChange={event => update({ treatmentArea: event.target.value })} /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Contact number<Input value={draft.contactNumber} onChange={event => update({ contactNumber: event.target.value })} inputMode="tel" /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">WhatsApp number<Input value={draft.whatsapp} onChange={event => update({ whatsapp: event.target.value })} inputMode="tel" /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032] sm:col-span-2">Email<Input value={draft.email} onChange={event => update({ email: event.target.value })} type="email" /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032] sm:col-span-2"><span>Private notes</span><textarea value={draft.notes} onChange={event => update({ notes: event.target.value })} className="min-h-20 border border-[#102032]/20 bg-white p-3 text-sm font-normal" /></label></div><div className="mt-4 flex flex-wrap items-center gap-3"><Button disabled={!ready || save.isPending} onClick={() => save.mutate({ patientId: patient.id, ...draft })}>{save.isPending ? <Loader2 className="mr-2 size-4 animate-spin" /> : <CheckCircle2 className="mr-2 size-4" />}Save patient file</Button><p className="text-xs text-[#66727A]">One patient file is retained for each matching manual MRN or normalized mobile number.</p></div></section>;
}

export function Machines() {
  const inventory = trpc.admin.machines.useQuery();
  const utils = trpc.useUtils();
  const [numbers, setNumbers] = useState<Record<string, string>>({});
  const update = trpc.admin.updateMachineNumber.useMutation({
    onSuccess: async () => { toast.success("Machine ID updated."); await utils.admin.machines.invalidate(); },
    onError: error => toast.error(error.message),
  });

  return <div className="mx-auto max-w-6xl"><PageHeading eyebrow="Clinic equipment" title="Machines" description="Maintain a unique internal machine ID for each clinic machine. These are manual clinic identifiers and do not replace the manufacturer serial number." />
    {inventory.isLoading ? <AdminLoadingState label="Loading machine records…" /> : inventory.isError ? <AdminErrorState title="Machines unavailable" description="Machine inventory could not be loaded from the protected clinic database." onRetry={() => inventory.refetch()} /> : inventory.data?.length === 0 ? <AdminEmptyState title="No machine records" description="No clinic machine records are currently available." icon={Cpu} /> : <div className="grid gap-4 md:grid-cols-2">{inventory.data?.map(machine => { const machineNumber = numbers[machine.name] ?? machine.machineNumber; const pending = update.isPending && update.variables?.name === machine.name; return <article key={machine.id} className="border border-[#102032]/10 bg-white p-6"><Cpu className="size-6 text-[#a85438]" /><h2 className="mt-6 font-display text-3xl tracking-[-0.04em] text-[#102032]" data-admin-no-translate>{machine.name}</h2><p className="mt-2 text-sm leading-6 text-[#52606B]">Use the internal machine ID consistently in operational records and printouts.</p><label className="mt-5 grid gap-2 text-xs font-bold text-[#102032]"><span>Internal machine ID</span><Input value={machineNumber} onChange={event => setNumbers(current => ({ ...current, [machine.name]: event.target.value }))} aria-label={`Internal machine ID for ${machine.name}`} /></label><Button className="mt-3" disabled={pending || !machineNumber.trim()} onClick={() => update.mutate({ name: machine.name, machineNumber })}>{pending ? <Loader2 className="me-2 size-4 animate-spin" /> : null}Save ID</Button></article>; })}</div>}
  </div>;
}

export default function AdminPortal({ page }: { page: AdminPage }) { return <AdminShell page={page} />; }
