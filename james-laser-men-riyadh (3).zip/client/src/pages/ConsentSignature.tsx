import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import type { OriginalConsentDocument } from "@shared/originalConsent";
import { CheckCircle2, ExternalLink, FileSignature, FileText, RotateCcw, ShieldCheck } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";

type Locale = "en" | "ar";

const copy = {
  en: {
    eyebrow: "Secure consent signature",
    title: "Review and sign the original clinic forms",
    lead: "This secure link is connected to a pending appointment request. Signing records evidence separately and does not confirm an appointment.",
    documents: "Original consent documents",
    view: "View original form",
    required: "Open all original forms before confirming that you have read them.",
    read: "All original forms have been opened.",
    acknowledgement: "I confirm that I opened and reviewed all original consent forms before signing.",
    signer: "Full name of signer",
    signature: "Draw your signature",
    signatureHint: "Use your finger, stylus, or mouse inside the signature panel.",
    clear: "Clear signature",
    submit: "Record secure signature",
    success: "Signature recorded",
    successLead: "Your signature evidence has been recorded. The clinic will continue its normal request-review process; this does not confirm an appointment.",
    invalid: "This signing link is invalid, expired, or no longer available.",
    loading: "Loading secure consent forms…",
  },
  ar: {
    eyebrow: "توقيع موافقة آمن",
    title: "راجع ووقّع نماذج العيادة الأصلية",
    lead: "يرتبط هذا الرابط الآمن بطلب موعد معلّق. يحفظ التوقيع دليلاً منفصلاً ولا يؤكد الموعد.",
    documents: "نماذج الموافقة الأصلية",
    view: "عرض النموذج الأصلي",
    required: "افتح جميع النماذج الأصلية قبل تأكيد قراءتها.",
    read: "تم فتح جميع النماذج الأصلية.",
    acknowledgement: "أؤكد أنني فتحت وراجعت جميع نماذج الموافقة الأصلية قبل التوقيع.",
    signer: "الاسم الكامل للموقّع",
    signature: "ارسم توقيعك",
    signatureHint: "استخدم إصبعك أو القلم أو الفأرة داخل مربع التوقيع.",
    clear: "مسح التوقيع",
    submit: "حفظ التوقيع الآمن",
    success: "تم حفظ التوقيع",
    successLead: "تم حفظ دليل توقيعك. ستستمر العيادة في مراجعة الطلب المعتادة؛ هذا لا يؤكد الموعد.",
    invalid: "رابط التوقيع غير صالح أو انتهت صلاحيته أو لم يعد متاحًا.",
    loading: "جارٍ تحميل نماذج الموافقة الآمنة…",
  },
} as const;

function tokenFromFragment() {
  if (typeof window === "undefined") return "";
  return new URLSearchParams(window.location.hash.replace(/^#/, "")).get("token")?.trim() ?? "";
}

function parseDocuments(value: string): OriginalConsentDocument[] {
  try {
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.filter((item): item is OriginalConsentDocument => Boolean(item && typeof item === "object" && "id" in item && "url" in item && "titleEn" in item && "titleAr" in item && typeof item.url === "string")) : [];
  } catch {
    return [];
  }
}

export default function ConsentSignature() {
  const token = useMemo(tokenFromFragment, []);
  const [session, setSession] = useState<{ consentSetReference: string; sourceConsentDocuments: string; language: Locale; expiresAt: Date } | null>(null);
  const [error, setError] = useState("");
  const [openedIds, setOpenedIds] = useState<string[]>([]);
  const [acknowledged, setAcknowledged] = useState(false);
  const [signerName, setSignerName] = useState("");
  const [hasSignature, setHasSignature] = useState(false);
  const [successReference, setSuccessReference] = useState("");
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const drawingRef = useRef(false);
  const getSession = trpc.consentSignature.getSession.useMutation({ onSuccess: value => setSession(value), onError: () => setError("invalid") });
  const submit = trpc.consentSignature.submit.useMutation({ onSuccess: value => setSuccessReference(value.signatureReference), onError: () => setError("submit") });

  useEffect(() => {
    document.title = "Secure Consent Signature | James Laser";
    let meta = document.querySelector('meta[name="robots"]');
    if (!meta) { meta = document.createElement("meta"); meta.setAttribute("name", "robots"); document.head.appendChild(meta); }
    meta.setAttribute("content", "noindex, nofollow, noarchive");
    if (!token) setError("invalid"); else getSession.mutate({ token });
  }, [token]);

  const locale: Locale = session?.language ?? "en";
  const t = copy[locale];
  const rtl = locale === "ar";
  const documents = useMemo(() => session ? parseDocuments(session.sourceConsentDocuments) : [], [session]);
  const allOpened = documents.length === 3 && openedIds.length === documents.length;
  const recordOpen = (id: string) => setOpenedIds(current => current.includes(id) ? current : [...current, id]);
  const clearSignature = () => { const canvas = canvasRef.current; const context = canvas?.getContext("2d"); if (canvas && context) context.clearRect(0, 0, canvas.width, canvas.height); setHasSignature(false); };
  const point = (event: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current!; const rect = canvas.getBoundingClientRect();
    return { x: (event.clientX - rect.left) * (canvas.width / rect.width), y: (event.clientY - rect.top) * (canvas.height / rect.height) };
  };
  const beginSignature = (event: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current; const context = canvas?.getContext("2d"); if (!canvas || !context) return;
    event.currentTarget.setPointerCapture(event.pointerId); const { x, y } = point(event); context.beginPath(); context.moveTo(x, y); context.lineCap = "round"; context.lineJoin = "round"; context.strokeStyle = "#102032"; context.lineWidth = 3; drawingRef.current = true;
  };
  const drawSignature = (event: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawingRef.current) return; const context = canvasRef.current?.getContext("2d"); if (!context) return; const { x, y } = point(event); context.lineTo(x, y); context.stroke(); setHasSignature(true);
  };
  const endSignature = () => { drawingRef.current = false; };
  const sign = () => {
    const canvas = canvasRef.current;
    if (!canvas || !session || !allOpened || !acknowledged || !hasSignature || !signerName.trim()) return;
    submit.mutate({ token, signerName: signerName.trim(), signatureDataUrl: canvas.toDataURL("image/png"), acknowledgement: true });
  };

  if (successReference) return <main dir={rtl ? "rtl" : "ltr"} className="min-h-screen bg-[#f5f1e9] px-4 py-16 text-[#102032]"><section className="mx-auto max-w-xl border border-emerald-200 bg-white p-8 text-center shadow-xl shadow-[#102032]/5"><CheckCircle2 className="mx-auto size-10 text-emerald-700" /><p className="mt-5 text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#a85438]">James Laser · Riyadh</p><h1 className="mt-3 font-display text-4xl tracking-[-0.05em]">{t.success}</h1><p className="mt-4 text-sm leading-6 text-[#52606B]">{t.successLead}</p><p className="mt-5 rounded-md bg-[#f5f1e9] p-3 text-xs font-bold text-[#102032]">{successReference}</p></section></main>;
  if (error || (!session && !getSession.isPending)) return <main dir={rtl ? "rtl" : "ltr"} className="min-h-screen bg-[#f5f1e9] px-4 py-16 text-[#102032]"><section className="mx-auto max-w-xl border border-red-200 bg-white p-8 text-center"><ShieldCheck className="mx-auto size-10 text-[#a85438]" /><h1 className="mt-4 font-display text-4xl tracking-[-0.05em]">{t.invalid}</h1><p className="mt-4 text-sm leading-6 text-[#52606B]">{rtl ? "تواصل مع العيادة للحصول على رابط جديد إذا لزم الأمر." : "Please contact the clinic if you need a new signing link."}</p></section></main>;
  if (!session) return <main className="grid min-h-screen place-items-center bg-[#f5f1e9] text-sm text-[#52606B]">{t.loading}</main>;

  return <main dir={rtl ? "rtl" : "ltr"} className="min-h-screen bg-[#f5f1e9] px-4 py-8 text-[#102032] sm:py-14"><section className="mx-auto max-w-3xl border border-[#102032]/10 bg-white p-5 shadow-xl shadow-[#102032]/5 sm:p-9"><p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#a85438]">{t.eyebrow}</p><h1 className="mt-3 font-display text-4xl tracking-[-0.05em] sm:text-5xl">{t.title}</h1><p className="mt-4 max-w-2xl text-sm leading-6 text-[#52606B]">{t.lead}</p><p className="mt-4 text-xs text-[#66727A]">{rtl ? "تنتهي صلاحية الرابط في" : "This link expires"} {session.expiresAt.toLocaleString(locale === "ar" ? "ar-SA" : "en-GB", { timeZone: "Asia/Riyadh", dateStyle: "medium", timeStyle: "short" })} · Riyadh</p><section className="mt-8 border-t border-[#102032]/10 pt-6"><h2 className="font-display text-2xl">{t.documents}</h2><div className="mt-4 grid gap-3">{documents.map(document => <div key={document.id} className="flex flex-wrap items-center justify-between gap-3 border border-[#102032]/10 bg-[#fdfbf7] p-3"><p className="flex items-center gap-2 text-sm font-semibold"><FileText className="size-4 text-[#a85438]" />{rtl ? document.titleAr : document.titleEn}</p><Button asChild size="sm" variant="outline"><a href={document.url} target="_blank" rel="noreferrer" onClick={() => recordOpen(document.id)}>{t.view}<ExternalLink className="ms-1 size-3.5" /></a></Button></div>)}</div><p className={`mt-3 text-xs font-semibold ${allOpened ? "text-emerald-700" : "text-[#a85438]"}`}>{allOpened ? t.read : t.required}</p></section><section className="mt-8 border-t border-[#102032]/10 pt-6"><label className="flex gap-3 text-sm leading-6"><input disabled={!allOpened} type="checkbox" checked={acknowledged} onChange={event => setAcknowledged(event.target.checked)} className="mt-1 size-4 shrink-0 accent-[#a85438]" /><span>{t.acknowledgement}</span></label><label className="mt-6 grid gap-2 text-sm font-bold"><span>{t.signer}</span><Input disabled={!acknowledged} value={signerName} onChange={event => setSignerName(event.target.value)} autoComplete="name" /></label><div className="mt-6"><div className="flex flex-wrap items-center justify-between gap-3"><div><h2 className="font-display text-2xl">{t.signature}</h2><p className="mt-1 text-xs text-[#66727A]">{t.signatureHint}</p></div><Button type="button" size="sm" variant="outline" onClick={clearSignature}><RotateCcw className="mr-1 size-4" />{t.clear}</Button></div><canvas ref={canvasRef} width={720} height={220} onPointerDown={beginSignature} onPointerMove={drawSignature} onPointerUp={endSignature} onPointerCancel={endSignature} className="mt-4 h-44 w-full touch-none border border-dashed border-[#102032]/30 bg-[#fdfbf7]" aria-label={t.signature} /></div><Button type="button" className="mt-7 w-full" size="lg" disabled={!allOpened || !acknowledged || !hasSignature || !signerName.trim() || submit.isPending} onClick={sign}>{submit.isPending ? (rtl ? "جارٍ الحفظ" : "Recording signature") : <><FileSignature className="mr-2 size-4" />{t.submit}</>}</Button>{submit.isError ? <p role="alert" className="mt-3 text-sm text-red-700">{t.invalid}</p> : null}</section></section></main>;
}
