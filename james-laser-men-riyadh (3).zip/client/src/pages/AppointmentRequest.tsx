import AppointmentConsentWorkflow from "@/components/AppointmentConsentWorkflow";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { publicUrl } from "@/seo";
import { ArrowLeft, ArrowRight, CheckCircle2, Clock3, Loader2, MessageCircle, ShieldCheck } from "lucide-react";
import React, { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import { Link, useLocation } from "wouter";

type Locale = "en" | "ar";
type MedicationType = "Roaccutane / Isotretinoin" | "Iron" | "Vitamin D" | "Other";
type RecentExposure = "tanning" | "hammam" | "skin_treatment";

const areas = [
  { group: "Face & neck", groupAr: "الوجه والرقبة", options: [["Full Face", "الوجه بالكامل"], ["Beard Lining", "تحديد اللحية"], ["Lower Beard Lining", "تحديد أسفل اللحية"], ["Neck", "الرقبة"], ["Nape", "مؤخرة الرقبة"], ["Ears", "الأذنان"], ["External Nose", "الأنف الخارجي"]] },
  { group: "Upper body", groupAr: "الجزء العلوي", options: [["Underarms", "تحت الإبط"], ["Chest", "الصدر"], ["Abdomen", "البطن"], ["Shoulders", "الأكتاف"], ["Full Back", "الظهر بالكامل"], ["Arms", "الذراعان"], ["Hands", "اليدان"]] },
  { group: "Lower body", groupAr: "الجزء السفلي", options: [["Bikini / Boxer", "البكيني / البوكسر"], ["Buttocks", "المؤخرة"], ["Thighs", "الفخذان"], ["Legs", "الساقان"], ["Feet", "القدمان"]] },
  { group: "Packages", groupAr: "الباقات", options: [["Mini Full Body", "ميني فل بودي"], ["Full Body", "فل بودي كامل"]] },
] as const;
const allAreas = areas.flatMap(group => group.options.map(option => option[0]));
export const allAppointmentAreas = allAreas;
const nationalities = ["Saudi Arabian", "Egyptian", "Filipino", "Indian", "Pakistani", "Sudanese", "Syrian", "Yemeni", "Jordanian", "Lebanese", "Moroccan", "Turkish", "British", "American", "Other"];
const medications: Array<{ value: MedicationType; en: string; ar: string }> = [
  { value: "Roaccutane / Isotretinoin", en: "Roaccutane / Isotretinoin", ar: "روكتان / إيزوتريتينوين" },
  { value: "Iron", en: "Iron", ar: "حديد" },
  { value: "Vitamin D", en: "Vitamin D", ar: "فيتامين د" },
  { value: "Other", en: "Other", ar: "أخرى" },
];
const exposures: Array<{ value: RecentExposure; en: string; ar: string }> = [
  { value: "tanning", en: "Tanning or strong sun exposure", ar: "تسمير أو تعرض قوي للشمس" },
  { value: "hammam", en: "Moroccan bath or body scrub", ar: "حمام مغربي أو تقشير للجسم" },
  { value: "skin_treatment", en: "Other skin treatment or exfoliation", ar: "علاج جلدي أو تقشير آخر" },
];
const timeOptions = Array.from({ length: 37 }, (_, index) => {
  const minutes = 13 * 60 + index * 15;
  const hour = Math.floor(minutes / 60);
  const minute = minutes % 60;
  const value = `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
  const displayHour = hour > 12 ? hour - 12 : hour;
  return { value, label: `${displayHour}:${String(minute).padStart(2, "0")} PM`, labelAr: `${displayHour}:${String(minute).padStart(2, "0")} م` };
});

const copy = {
  en: {
    brand: "James Laser", back: "Back to home", title: "Request an Appointment", subtitle: "Share your preference and screening information privately. The clinic reviews every request before confirming availability.",
    name: "Full Name", mobile: "Mobile / WhatsApp Number", nationality: "Nationality", date: "Preferred Date", time: "Preferred Time", timing: "The clinic will confirm availability later.", visit: "Visit Type", session: "Session", retouch: "Retouch",
    retouchNote: "Retouch timing and eligibility will be reviewed by the clinic before confirmation.", treatmentAreas: "Treatment Area(s)", selectAll: "Select all", clearAll: "Clear selection", previous: "Have you had laser hair removal before?", lastSession: "Last laser session date", yes: "Yes", no: "No",
    medication: "Are you currently taking any medicine or supplements?", medicationTypes: "Medication or supplement", otherMedication: "Specify the other medication or supplement", lastTaken: "When was it last taken?", dosage: "Dosage (write ‘unknown’ if not known)",
    exposure: "Recent skin exposure or treatment", exposureQuestion: "Select anything that applies", exposureDate: "When did the most recent item occur?", skinCondition: "Do you currently have a skin condition in a treatment area?", skinDetails: "Describe the skin condition for clinic review",
    notes: "Additional Notes", notesHelp: "Share information relevant to clinic review. This request is stored privately.", consent: "Consent and electronic signature", accuracy: "I confirm that the information I provided is accurate and complete to the best of my knowledge.", acknowledgement: "I understand this is an appointment request only. My preferred date and time are not confirmed until the clinic contacts me and confirms availability.", privacy: "I have read and agree to the Privacy Policy.", healthScreening: "I explicitly agree that the clinic may use the health-screening information in this request only to review my appointment request and contact me about the next step. This is not consent to treatment.", marketing: "I would like to receive occasional promotions or updates by WhatsApp.",
    submit: "Request Appointment", secure: "Private request · protected staff review", successTitle: "Request Received", successText: "Thank you. Your request has been received. Your preferred date and time are not yet confirmed. Our team will contact you to review availability and confirm next steps.", request: "Request Number", whatsapp: "Contact via WhatsApp", sendDetails: "Send Details via WhatsApp", home: "Return to Home", error: "We couldn’t submit your request. Your information is still here; check your connection and try again.", invalidMobile: "Please enter a valid mobile or WhatsApp number.", invalidDate: "Please choose today or a future date in Riyadh.", invalidTime: "Please choose a 15-minute preference between 1:00 PM and 10:00 PM.", unavailableDay: "Please choose a request day enabled by the clinic.", retry: "Try again", review: "Reviewing your preferences", English: "English", Arabic: "العربية", required: "Please complete all required fields, consent, and signature.",
  },
  ar: {
    brand: "جيمس ليزر", back: "العودة للرئيسية", title: "طلب موعد", subtitle: "شارك تفضيلاتك ومعلومات المراجعة بشكل خاص. تراجع العيادة كل طلب قبل تأكيد التوفر.",
    name: "الاسم الكامل", mobile: "رقم الجوال / واتساب", nationality: "الجنسية", date: "التاريخ المفضل", time: "الوقت المفضل", timing: "سيتم تأكيد التوفر من قبل العيادة لاحقًا.", visit: "نوع الزيارة", session: "جلسة", retouch: "رتوش",
    retouchNote: "ستراجع العيادة توقيت الرتوش والأهلية قبل التأكيد.", treatmentAreas: "منطقة / مناطق العلاج", selectAll: "تحديد الكل", clearAll: "إلغاء التحديد", previous: "هل أجريت إزالة شعر بالليزر من قبل؟", lastSession: "تاريخ آخر جلسة ليزر", yes: "نعم", no: "لا",
    medication: "هل تتناول حاليًا أي دواء أو مكمل؟", medicationTypes: "الدواء أو المكمل", otherMedication: "حدد الدواء أو المكمل الآخر", lastTaken: "متى تم تناوله آخر مرة؟", dosage: "الجرعة (اكتب «غير معروف» إذا لم تكن تعرف)",
    exposure: "تعرض أو علاج جلدي حديث", exposureQuestion: "حدد كل ما ينطبق", exposureDate: "متى حدث أحدث عنصر؟", skinCondition: "هل توجد لديك حاليًا حالة جلدية في منطقة العلاج؟", skinDetails: "صف حالة الجلد لمراجعة العيادة",
    notes: "ملاحظات إضافية", notesHelp: "شارك المعلومات ذات الصلة بمراجعة العيادة. يُحفظ هذا الطلب بشكل خاص.", consent: "الموافقة والتوقيع الإلكتروني", accuracy: "أؤكد أن المعلومات التي قدمتها دقيقة وكاملة حسب أفضل معرفتي.", acknowledgement: "أفهم أن هذا طلب موعد فقط، وأن التاريخ والوقت المفضلين غير مؤكدين حتى تتواصل العيادة معي وتؤكد التوفر.", privacy: "اطلعت وأوافق على سياسة الخصوصية.", healthScreening: "أوافق صراحة على أن تستخدم العيادة معلومات الفحص الصحي في هذا الطلب فقط لمراجعته والتواصل معي بشأن الخطوة التالية. ولا تعد هذه موافقة على العلاج.", marketing: "أرغب في تلقي عروض أو تحديثات من حين لآخر عبر واتساب.",
    submit: "إرسال طلب الموعد", secure: "طلب خاص · مراجعة محمية للموظفين", successTitle: "تم استلام الطلب", successText: "شكرًا لك. تم استلام طلبك. التاريخ والوقت المفضلان غير مؤكدين حتى الآن. سيتواصل معك فريقنا لمراجعة التوفر وتأكيد الخطوات التالية.", request: "رقم الطلب", whatsapp: "التواصل عبر واتساب", sendDetails: "إرسال التفاصيل عبر واتساب", home: "العودة للرئيسية", error: "تعذر إرسال طلبك. ما زالت معلوماتك موجودة؛ تحقق من الاتصال وحاول مرة أخرى.", invalidMobile: "يرجى إدخال رقم جوال أو واتساب صحيح.", invalidDate: "يرجى اختيار تاريخ اليوم أو تاريخ مستقبلي في الرياض.", invalidTime: "يرجى اختيار وقت كل 15 دقيقة بين 1:00 ظهرًا و10:00 مساءً.", unavailableDay: "يرجى اختيار يوم مفعل ضمن إعدادات العيادة.", retry: "حاول مرة أخرى", review: "نراجع تفضيلاتك", English: "English", Arabic: "العربية", required: "يرجى تعبئة جميع الحقول المطلوبة والموافقة والتوقيع.",
  },
} as const;

function riyadhToday() { return new Intl.DateTimeFormat("sv-SE", { timeZone: "Asia/Riyadh", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date()); }
function createSubmissionId() {
  if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID();
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, character => {
    const random = Math.floor(Math.random() * 16);
    return (character === "x" ? random : (random & 0x3) | 0x8).toString(16);
  });
}
function isProductionVisitor() { return typeof window !== "undefined" && window.location.hostname.endsWith(".manus.space"); }
function setAppointmentMetadata(locale: Locale) {
  const arabic = locale === "ar";
  const title = arabic ? "طلب موعد ليزر للرجال الرياض | جيمس ليزر" : "Men’s Laser Hair Removal Appointment Riyadh | James Laser";
  const description = arabic ? "أرسل طلب موعد خاص لإزالة الشعر بالليزر للرجال في الرياض. سيتم تأكيد التوفر من العيادة لاحقًا." : "Send a private men’s laser hair removal appointment request in Riyadh. Clinic availability is confirmed separately.";
  const path = arabic ? "/ar/appointment" : "/appointment";
  document.title = title;
  const descriptionTag = document.querySelector('meta[name="description"]') || document.head.appendChild(document.createElement("meta")); descriptionTag.setAttribute("name", "description"); descriptionTag.setAttribute("content", description);
  const canonicalTag = document.querySelector('link[rel="canonical"]') || document.head.appendChild(document.createElement("link")); canonicalTag.setAttribute("rel", "canonical"); canonicalTag.setAttribute("href", publicUrl(path));
  const setProperty = (property: string, content: string) => { const tag = document.querySelector(`meta[property="${property}"]`) || document.head.appendChild(document.createElement("meta")); tag.setAttribute("property", property); tag.setAttribute("content", content); };
  setProperty("og:title", title); setProperty("og:description", description); setProperty("og:url", publicUrl(path));
  const setAlternate = (hrefLang: string, href: string) => { let tag = Array.from(document.querySelectorAll('link[rel="alternate"]')).find(node => node.getAttribute("hreflang") === hrefLang) as HTMLLinkElement | undefined; if (!tag) { tag = document.createElement("link"); tag.rel = "alternate"; tag.hreflang = hrefLang; document.head.appendChild(tag); } tag.href = href; };
  setAlternate("en", publicUrl("/appointment")); setAlternate("ar-SA", publicUrl("/ar/appointment")); setAlternate("x-default", publicUrl("/appointment"));
}
export function appointmentSubmissionError(locale: Locale, error: unknown) {
  const message = error instanceof Error ? error.message : String(error || ""); const t = copy[locale];
  if (/valid mobile|أدخل رقم جوال/i.test(message)) return t.invalidMobile;
  if (/today or a future date|اختر تاريخ اليوم/i.test(message)) return t.invalidDate;
  if (/15-minute preference|اختر وقتًا كل 15 دقيقة/i.test(message)) return t.invalidTime;
  return t.error;
}

export default function AppointmentRequest({ locale = "en" }: { locale?: Locale }) {
  const t = copy[locale]; const rtl = locale === "ar"; const [, setLocation] = useLocation();
  const settings = trpc.publicContent.clinicSettings.useQuery(); const analytics = trpc.analytics.record.useMutation();
  const [clientSubmissionId] = useState(createSubmissionId); const submissionLock = useRef(false);
  const [fullName, setFullName] = useState(""); const [whatsapp, setWhatsapp] = useState("+966 "); const [nationality, setNationality] = useState("");
  const [preferredDate, setPreferredDate] = useState(riyadhToday); const [preferredTime, setPreferredTime] = useState(""); const [visitType, setVisitType] = useState<"session" | "retouch">("session"); const [selectedAreas, setSelectedAreas] = useState<string[]>([]);
  const [previousLaser, setPreviousLaser] = useState(false); const [lastLaserSession, setLastLaserSession] = useState("");
  const [takingMedication, setTakingMedication] = useState(false); const [medicationTypes, setMedicationTypes] = useState<MedicationType[]>([]); const [medicationDetails, setMedicationDetails] = useState(""); const [medicationLastTaken, setMedicationLastTaken] = useState(""); const [medicationDosage, setMedicationDosage] = useState("");
  const [recentExposures, setRecentExposures] = useState<RecentExposure[]>([]); const [recentExposureDate, setRecentExposureDate] = useState("");
  const [hasSkinCondition, setHasSkinCondition] = useState(false); const [skinConditionDetails, setSkinConditionDetails] = useState(""); const [notes, setNotes] = useState("");
  const [consentReadComplete, setConsentReadComplete] = useState(false); const [consentAcknowledgement, setConsentAcknowledgement] = useState(false); const [signatureDataUrl, setSignatureDataUrl] = useState("");
  const [informationAccuracy, setInformationAccuracy] = useState(false); const [appointmentAcknowledgement, setAppointmentAcknowledgement] = useState(false); const [privacy, setPrivacy] = useState(false); const [healthScreeningConsent, setHealthScreeningConsent] = useState(false); const [marketing, setMarketing] = useState(false);
  const [website, setWebsite] = useState(""); const [hasStarted, setHasStarted] = useState(false); const [clientError, setClientError] = useState(""); const [success, setSuccess] = useState<{ requestId: string } | null>(null);

  const submit = trpc.appointmentRequest.create.useMutation({
    onSuccess: data => { submissionLock.current = true; setSuccess({ requestId: data.requestId }); setClientError(""); },
    onError: error => { submissionLock.current = false; setClientError(appointmentSubmissionError(locale, error)); },
  });
  const clinicWhatsapp = (settings.data?.whatsapp || "+966557401562").replace(/\D/g, "");
  const trackStart = () => { if (!hasStarted) { setHasStarted(true); if (isProductionVisitor()) analytics.mutate({ eventType: "appointment_form_start", path: rtl ? "/ar/appointment" : "/appointment", locale: rtl ? "ar-SA" : "en", source: window.location.hostname, deviceType: "unknown" }); } };
  useEffect(() => { setAppointmentMetadata(locale); if (isProductionVisitor()) analytics.mutate({ eventType: "page_view", path: rtl ? "/ar/appointment" : "/appointment", locale: rtl ? "ar-SA" : "en", source: window.location.hostname, deviceType: "unknown" }); }, [locale]);
  useEffect(() => { if (!success) return; const meta = document.querySelector('meta[name="robots"]') || document.head.appendChild(document.createElement("meta")); meta.setAttribute("name", "robots"); meta.setAttribute("content", "noindex, nofollow, noarchive"); return () => { meta.setAttribute("content", "index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1"); }; }, [success]);

  const configuredTimes = useMemo(() => { const values = settings.data?.preferredTimes?.split(",").map(value => value.trim()).filter(Boolean) ?? []; return values.length ? timeOptions.filter(option => values.includes(option.value)) : timeOptions; }, [settings.data?.preferredTimes]);
  const configuredAreas = useMemo(() => { const values = settings.data?.appointmentTreatmentOptions?.split(",").map(value => value.trim()).filter(Boolean) ?? []; return values.length ? allAreas.filter(area => values.includes(area)) : allAreas; }, [settings.data?.appointmentTreatmentOptions]);
  const configuredVisitTypes = useMemo(() => { const values = settings.data?.visitTypeOptions?.split(",").map(value => value.trim()) ?? []; return values.length ? values.filter((value): value is "session" | "retouch" => value === "session" || value === "retouch") : ["session", "retouch"]; }, [settings.data?.visitTypeOptions]);
  const configuredDays = useMemo(() => settings.data?.availableDays?.split(",").map(value => value.trim().toLowerCase()).filter(Boolean) ?? [], [settings.data?.availableDays]);
  const selectionLabel = useMemo(() => selectedAreas.join(", "), [selectedAreas]);
  const toggleValue = <T extends string>(value: T, setter: React.Dispatch<React.SetStateAction<T[]>>) => setter(current => current.includes(value) ? current.filter(item => item !== value) : [...current, value]);
  const toggleArea = (area: string) => { trackStart(); setSelectedAreas(current => current.includes(area) ? current.filter(item => item !== area) : [...current, area]); };
  const selectAll = () => setSelectedAreas(current => current.length === configuredAreas.length ? [] : [...configuredAreas]);

  const submitRequest = (event: FormEvent) => {
    event.preventDefault(); if (submissionLock.current || submit.isPending) return; setClientError("");
    const weekday = new Intl.DateTimeFormat("en-US", { weekday: "long", timeZone: "Asia/Riyadh" }).format(new Date(`${preferredDate}T12:00:00+03:00`)).toLowerCase();
    const conditionalComplete = (!previousLaser || Boolean(lastLaserSession)) && (!takingMedication || (medicationTypes.length > 0 && Boolean(medicationLastTaken) && Boolean(medicationDosage.trim()) && (!medicationTypes.includes("Other") || Boolean(medicationDetails.trim())))) && (recentExposures.length === 0 || Boolean(recentExposureDate)) && (!hasSkinCondition || Boolean(skinConditionDetails.trim()));
    if (!fullName.trim() || !whatsapp.replace(/\D/g, "") || !nationality.trim() || !preferredDate || !preferredTime || selectedAreas.length === 0 || !conditionalComplete || !consentReadComplete || !consentAcknowledgement || !signatureDataUrl || !informationAccuracy || !appointmentAcknowledgement || !privacy || !healthScreeningConsent) { setClientError(t.required); return; }
    if (configuredDays.length && !configuredDays.includes(weekday)) { setClientError(t.unavailableDay); return; }
    submissionLock.current = true;
    submit.mutate({
      clientSubmissionId, fullName, whatsapp, nationality, preferredDate, preferredTime, visitType, treatmentAreas: selectedAreas as any, previousLaser, lastLaserSession: previousLaser ? lastLaserSession : null,
      takingMedication, medicationTypes, medicationDetails: takingMedication && medicationTypes.includes("Other") ? medicationDetails : null, medicationLastTaken: takingMedication ? medicationLastTaken : null, medicationDosage: takingMedication ? medicationDosage : null,
      recentExposures, recentExposureDate: recentExposures.length ? recentExposureDate : null, hasSkinCondition, skinConditionDetails: hasSkinCondition ? skinConditionDetails : null, notes: notes || null,
      appointmentAcknowledgement: true, informationAccuracyAcknowledgement: true, originalConsentAcknowledgement: true, privacyConsent: true, healthScreeningConsent: true, marketingConsent: marketing, signatureDataUrl, language: locale, source: rtl ? "appointment_page_ar" : "appointment_page_en", website,
    });
  };
  const retrySubmission = () => { submissionLock.current = false; setClientError(""); submit.reset(); };
  const customerSummary = encodeURIComponent(`${rtl ? "طلب موعد" : "Appointment Request"}\n${rtl ? "الاسم" : "Name"}: ${fullName}\n${rtl ? "التاريخ المفضل" : "Preferred Date"}: ${preferredDate}\n${rtl ? "الوقت المفضل" : "Preferred Time"}: ${preferredTime}\n${rtl ? "نوع الزيارة" : "Visit Type"}: ${visitType === "retouch" ? t.retouch : t.session}\n${rtl ? "المناطق" : "Treatment Areas"}: ${selectionLabel}\n${rtl ? "رقم الطلب" : "Request Number"}: ${success?.requestId || ""}`);
  if (success) return <main dir={rtl ? "rtl" : "ltr"} className="min-h-screen bg-[#f5f1e9] text-[#102032]"><AppointmentHeader locale={locale} /><section className="mx-auto grid min-h-[75vh] max-w-3xl place-items-center px-4 py-12 sm:px-6"><AppointmentSubmissionSuccess locale={locale} requestId={success.requestId} clinicWhatsapp={clinicWhatsapp} customerSummary={customerSummary} onReturnHome={() => setLocation(rtl ? "/ar" : "/")} /></section></main>;

  const paused = settings.data?.appointmentFormEnabled === false || settings.data?.maintenanceMode === true;
  return <main dir={rtl ? "rtl" : "ltr"} className={`min-h-screen bg-[#f5f1e9] text-[#102032] ${rtl ? "arabic-public-page" : ""}`}>
    <AppointmentHeader locale={locale} />
    <div className="mx-auto grid max-w-7xl gap-8 px-4 py-8 sm:px-6 lg:grid-cols-[0.72fr_1.28fr] lg:gap-12 lg:py-14">
      <aside className="lg:sticky lg:top-24 lg:h-fit"><p className="text-[10px] font-extrabold uppercase tracking-[0.2em] text-[#a85438]">{settings.data?.clinicName || "New Look Clinic"} · Riyadh</p><h1 className="mt-4 font-display text-4xl leading-[1.02] tracking-[-0.05em] sm:text-5xl">{t.title}</h1><p className="mt-6 max-w-md text-base leading-7 text-[#52606B]">{t.subtitle}</p><div className="mt-8 border-y border-[#102032]/10 py-5"><div className="flex gap-3"><ShieldCheck className="mt-0.5 size-5 shrink-0 text-[#a85438]" /><p className="text-sm leading-6 text-[#52606B]">{t.secure}</p></div><div className="mt-4 flex gap-3"><Clock3 className="mt-0.5 size-5 shrink-0 text-[#a85438]" /><p className="text-sm leading-6 text-[#52606B]">{settings.data?.workingHours || "1:00 PM – 10:00 PM"} · Riyadh</p></div></div></aside>
      <form noValidate onSubmit={submitRequest} onFocus={trackStart} className="public-form-surface border border-[#102032]/10 bg-white p-5 shadow-[0_1px_2px_rgb(16_32_50_/_0.03),0_14px_36px_rgb(16_32_50_/_0.06)] sm:p-8">
        <input aria-hidden tabIndex={-1} autoComplete="off" className="hidden" name="website" value={website} onChange={event => setWebsite(event.target.value)} />
        <FormSection index="01" title={rtl ? "معلومات التواصل" : "Contact details"}><Field label={t.name} required><Input value={fullName} onChange={event => setFullName(event.target.value)} autoComplete="name" /></Field><Field label={t.mobile} required><Input value={whatsapp} onChange={event => setWhatsapp(event.target.value)} inputMode="tel" autoComplete="tel" /></Field><Field label={t.nationality} required><Input list="nationalities" value={nationality} onChange={event => setNationality(event.target.value)} autoComplete="country-name" /><datalist id="nationalities">{nationalities.map(item => <option key={item} value={item} />)}</datalist></Field></FormSection>
        <FormSection index="02" title={rtl ? "تفضيلات الموعد" : "Appointment preferences"}><Field label={t.date} required><Input min={riyadhToday()} type="date" value={preferredDate} onChange={event => setPreferredDate(event.target.value)} /></Field><Field label={t.time} required><select aria-label={t.time} value={preferredTime} onChange={event => setPreferredTime(event.target.value)} className="h-10 w-full border border-[#102032]/20 bg-white px-3 text-sm outline-none focus:ring-2 focus:ring-[#a85438]"><option value="">{rtl ? "اختر الوقت" : "Select a time"}</option>{configuredTimes.map(time => <option key={time.value} value={time.value}>{rtl ? time.labelAr : time.label}</option>)}</select><p className="mt-1 text-xs text-[#66727A]">{t.timing}</p></Field><YesNoLegend label={t.visit}><Choice label={t.session} active={visitType === "session"} onClick={() => setVisitType("session")} />{configuredVisitTypes.includes("retouch") ? <Choice label={t.retouch} active={visitType === "retouch"} onClick={() => setVisitType("retouch")} /> : null}{visitType === "retouch" ? <p className="col-span-2 border-s border-[#a85438] bg-[#fff8f2] p-3 text-xs leading-5 text-[#52606B]">{t.retouchNote}</p> : null}</YesNoLegend></FormSection>
        <FormSection index="03" title={t.treatmentAreas}><div className="sm:col-span-2"><div className="mb-4 flex justify-end"><Button type="button" variant="outline" size="sm" onClick={selectAll}>{selectedAreas.length === configuredAreas.length ? t.clearAll : t.selectAll}</Button></div><div className="space-y-5">{areas.map(group => { const visible = group.options.filter(([value]) => configuredAreas.includes(value)); return visible.length ? <fieldset key={group.group}><legend className="mb-2 text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">{rtl ? group.groupAr : group.group}</legend><div className="grid gap-2 sm:grid-cols-2">{visible.map(([value, ar]) => <CheckOption key={value} checked={selectedAreas.includes(value)} onChange={() => toggleArea(value)} label={rtl ? ar : value} />)}</div></fieldset> : null; })}</div></div></FormSection>
        <FormSection index="04" title={rtl ? "تجربة الليزر السابقة" : "Previous laser experience"}><YesNoLegend label={t.previous}><Choice label={t.no} active={!previousLaser} onClick={() => { setPreviousLaser(false); setLastLaserSession(""); }} /><Choice label={t.yes} active={previousLaser} onClick={() => setPreviousLaser(true)} /></YesNoLegend>{previousLaser ? <Field label={t.lastSession} required><Input type="date" max={riyadhToday()} value={lastLaserSession} onChange={event => setLastLaserSession(event.target.value)} /></Field> : null}</FormSection>
        <FormSection index="05" title={rtl ? "الأدوية والمكملات" : "Medication and supplements"}><YesNoLegend label={t.medication}><Choice label={t.no} active={!takingMedication} onClick={() => { setTakingMedication(false); setMedicationTypes([]); setMedicationDetails(""); setMedicationLastTaken(""); setMedicationDosage(""); }} /><Choice label={t.yes} active={takingMedication} onClick={() => setTakingMedication(true)} /></YesNoLegend>{takingMedication ? <><fieldset className="sm:col-span-2"><legend className="mb-2 text-xs font-bold">{t.medicationTypes} <span className="text-[#a85438]">*</span></legend><div className="grid gap-2 sm:grid-cols-2">{medications.map(item => <CheckOption key={item.value} checked={medicationTypes.includes(item.value)} onChange={() => toggleValue(item.value, setMedicationTypes)} label={rtl ? item.ar : item.en} />)}</div></fieldset>{medicationTypes.includes("Other") ? <Field label={t.otherMedication} required><Input value={medicationDetails} onChange={event => setMedicationDetails(event.target.value)} /></Field> : null}<Field label={t.lastTaken} required><Input type="date" max={riyadhToday()} value={medicationLastTaken} onChange={event => setMedicationLastTaken(event.target.value)} /></Field><Field label={t.dosage} required><Input value={medicationDosage} onChange={event => setMedicationDosage(event.target.value)} /></Field></> : null}</FormSection>
        <FormSection index="06" title={t.exposure}><fieldset className="sm:col-span-2"><legend className="mb-2 text-xs font-bold">{t.exposureQuestion}</legend><div className="grid gap-2 sm:grid-cols-2">{exposures.map(item => <CheckOption key={item.value} checked={recentExposures.includes(item.value)} onChange={() => toggleValue(item.value, setRecentExposures)} label={rtl ? item.ar : item.en} />)}</div></fieldset>{recentExposures.length ? <Field label={t.exposureDate} required><Input type="date" max={riyadhToday()} value={recentExposureDate} onChange={event => setRecentExposureDate(event.target.value)} /></Field> : null}</FormSection>
        <FormSection index="07" title={rtl ? "حالة الجلد" : "Skin condition"}><YesNoLegend label={t.skinCondition}><Choice label={t.no} active={!hasSkinCondition} onClick={() => { setHasSkinCondition(false); setSkinConditionDetails(""); }} /><Choice label={t.yes} active={hasSkinCondition} onClick={() => setHasSkinCondition(true)} /></YesNoLegend>{hasSkinCondition ? <Field label={t.skinDetails} required><textarea value={skinConditionDetails} onChange={event => setSkinConditionDetails(event.target.value)} maxLength={2000} className="min-h-28 w-full resize-y border border-[#102032]/20 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-[#a85438]" /></Field> : null}</FormSection>
        <FormSection index="08" title={t.notes}><Field label={t.notes}><textarea value={notes} onChange={event => setNotes(event.target.value)} maxLength={2000} className="min-h-28 w-full resize-y border border-[#102032]/20 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-[#a85438]" /><p className="mt-1 text-xs text-[#66727A]">{t.notesHelp}</p></Field></FormSection>
        <FormSection index="09" title={t.consent}><AppointmentConsentWorkflow locale={locale} signerName={fullName} readComplete={consentReadComplete} acknowledgement={consentAcknowledgement} signatureDataUrl={signatureDataUrl} onReadComplete={() => setConsentReadComplete(true)} onAcknowledgementChange={setConsentAcknowledgement} onSignatureChange={setSignatureDataUrl} /></FormSection>
        <section className="border-t border-[#102032]/10 pt-6"><ConsentCheck checked={informationAccuracy} onChange={setInformationAccuracy} label={t.accuracy} /><ConsentCheck checked={appointmentAcknowledgement} onChange={setAppointmentAcknowledgement} label={t.acknowledgement} /><ConsentCheck checked={privacy} onChange={setPrivacy} label={<>{t.privacy} <a className="font-semibold text-[#a85438] underline" href={rtl ? "/ar/policies/privacy-policy" : "/policies/privacy-policy"}>{rtl ? "سياسة الخصوصية" : "Privacy Policy"}</a></>} /><ConsentCheck checked={healthScreeningConsent} onChange={setHealthScreeningConsent} label={<>{t.healthScreening} <a className="font-semibold text-[#a85438] underline" href={rtl ? "/ar/privacy-rights" : "/privacy-rights"}>{rtl ? "حقوق المريض والخصوصية" : "Patient rights & privacy"}</a></>} /><ConsentCheck checked={marketing} onChange={setMarketing} label={t.marketing} optional /></section>
        {clientError ? <div role="alert" className="mt-5 border border-red-200 bg-red-50 p-3 text-sm text-red-800"><p>{clientError}</p><div className="mt-3 flex flex-wrap gap-2"><Button type="button" size="sm" variant="outline" onClick={retrySubmission}>{t.retry}</Button><Button size="sm" type="button" asChild><a href={`https://wa.me/${clinicWhatsapp}`} target="_blank" rel="noreferrer"><MessageCircle className="me-1 size-4" />{t.whatsapp}</a></Button></div></div> : null}
        <Button className="mt-6 w-full" size="lg" disabled={submit.isPending || paused} type="submit">{submit.isPending ? <Loader2 className="me-2 size-4 animate-spin" /> : <ArrowRight className={rtl ? "ms-2 size-4 rotate-180" : "me-2 size-4"} />}{submit.isPending ? (rtl ? "جارٍ الإرسال" : "Sending request") : t.submit}</Button>
        {paused ? <p className="mt-3 text-center text-xs text-[#66727A]">{rtl ? "طلبات المواعيد متوقفة مؤقتًا. تواصل معنا عبر واتساب." : "Appointment requests are temporarily paused. Please contact the clinic via WhatsApp."}</p> : null}
      </form>
    </div>
  </main>;
}

function AppointmentHeader({ locale }: { locale: Locale }) { const rtl = locale === "ar"; const t = copy[locale]; return <header dir={rtl ? "rtl" : "ltr"} className="sticky top-0 z-40 border-b border-white/10 bg-[#102032]/97 text-white shadow-[0_8px_28px_rgb(6_18_28_/_0.08)] backdrop-blur-xl"><div className="mx-auto flex min-h-[4.5rem] max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6"><Link href={rtl ? "/ar" : "/"} className="font-display text-lg tracking-[-0.035em]">{t.brand}<span className="ms-2 font-sans text-[9px] font-bold uppercase tracking-[0.18em] text-[#e7b99e]">Riyadh</span></Link><div className="flex items-center gap-3 text-sm"><Link href={rtl ? "/appointment" : "/ar/appointment"} className="border border-white/20 px-3 py-2 font-semibold text-white/85">{rtl ? t.English : t.Arabic}</Link><Link href={rtl ? "/ar" : "/"} className="hidden items-center gap-1 text-white/75 sm:flex">{rtl ? <ArrowRight className="size-4" /> : <ArrowLeft className="size-4" />}{t.back}</Link></div></div></header>; }
function FormSection({ index, title, children }: { index: string; title: string; children: React.ReactNode }) { return <section className="border-b border-[#102032]/10 py-6 first:pt-0 last:border-0"><div className="mb-5 flex items-baseline gap-3"><span className="text-[10px] font-extrabold tracking-[0.18em] text-[#a85438]">{index}</span><h2 className="font-display text-2xl tracking-[-0.035em]">{title}</h2></div><div className="grid gap-4 sm:grid-cols-2">{children}</div></section>; }
function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) { return <label className="grid gap-1.5 text-xs font-bold text-[#102032]"><span>{label}{required ? <span className="text-[#a85438]"> *</span> : null}</span>{children}</label>; }
function Choice({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) { return <button type="button" aria-pressed={active} onClick={onClick} className={`border px-3 py-3 text-sm font-semibold transition ${active ? "border-[#a85438] bg-[#fff8f2] text-[#102032]" : "border-[#102032]/15 bg-white text-[#52606B] hover:border-[#a85438]/35"}`}>{label}</button>; }
function YesNoLegend({ label, children }: { label: string; children: React.ReactNode }) { return <fieldset className="sm:col-span-2"><legend className="mb-2 text-xs font-bold text-[#102032]">{label} <span className="text-[#a85438]">*</span></legend><div className="grid grid-cols-2 gap-2">{children}</div></fieldset>; }
function CheckOption({ checked, onChange, label }: { checked: boolean; onChange: () => void; label: string }) { return <label className={`flex cursor-pointer items-center gap-3 border p-3 text-sm transition ${checked ? "border-[#a85438] bg-[#fff8f2]" : "border-[#102032]/10 hover:border-[#a85438]/35"}`}><input type="checkbox" checked={checked} onChange={onChange} className="size-4 accent-[#a85438]" /><span>{label}</span></label>; }
function ConsentCheck({ checked, onChange, label, optional = false }: { checked: boolean; onChange: (value: boolean) => void; label: React.ReactNode; optional?: boolean }) { return <label className={`flex gap-3 text-sm leading-6 ${optional ? "mt-4 text-[#52606B]" : "mt-4 first:mt-0"}`}><input required={!optional} type="checkbox" checked={checked} onChange={event => onChange(event.target.checked)} className="mt-1 size-4 shrink-0 accent-[#a85438]" /><span>{label}</span></label>; }

export function AppointmentSubmissionSuccess({ locale, requestId, clinicWhatsapp, customerSummary, onReturnHome }: { locale: Locale; requestId: string; clinicWhatsapp: string; customerSummary: string; onReturnHome: () => void }) {
  const t = copy[locale];
  return <div className="w-full border border-[#102032]/10 bg-white p-7 text-center shadow-xl shadow-[#102032]/5 sm:p-10"><CheckCircle2 className="mx-auto size-11 text-[#a85438]" /><p className="mt-6 text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#a85438]">{t.review}</p><h1 className="mt-2 font-display text-4xl tracking-[-0.05em]">{t.successTitle}</h1><p className="mx-auto mt-4 max-w-xl text-sm leading-7 text-[#52606B]">{t.successText}</p><div className="mx-auto mt-7 max-w-sm border border-[#a85438]/30 bg-[#fff8f2] p-4"><p className="text-xs font-bold text-[#a85438]">{t.request}</p><p className="mt-1 font-display text-3xl tracking-[0.06em] text-[#102032]">{requestId}</p></div><div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row"><Button asChild><a href={`https://wa.me/${clinicWhatsapp}`} target="_blank" rel="noreferrer"><MessageCircle className="me-2 size-4" />{t.whatsapp}</a></Button><Button variant="outline" asChild><a href={`https://wa.me/${clinicWhatsapp}?text=${customerSummary}`} target="_blank" rel="noreferrer">{t.sendDetails}</a></Button><Button variant="ghost" onClick={onReturnHome}>{t.home}</Button></div></div>;
}
