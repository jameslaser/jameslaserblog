import { ArrowLeft, ArrowRight, ExternalLink, FileCheck2, Mail, Phone, ShieldCheck, UserRoundCheck } from "lucide-react";
import { useEffect } from "react";
import { Link } from "wouter";
import { PublicSiteHeader } from "@/components/PublicSiteHeader";
import { trpc } from "@/lib/trpc";
import { publicUrl } from "@/seo";

type Locale = "en" | "ar";

const MOH_PATIENT_RIGHTS_URL = "https://www.moh.gov.sa/en/HealthAwareness/EducationalContent/HealthTips/Documents/Patient-Bill-of-Rights-and-Responsibilities.pdf";

function setPageMetadata(locale: Locale) {
  const arabic = locale === "ar";
  const title = arabic ? "حقوق المريض والخصوصية | جيمس ليزر الرياض" : "Patient Rights & Privacy | James Laser Riyadh";
  const description = arabic
    ? "معلومات عن حقوق المريض والخصوصية وطلب البيانات لدى جيمس ليزر في الرياض."
    : "Patient-rights, privacy, and personal-data request information for James Laser in Riyadh.";
  const path = arabic ? "/ar/privacy-rights" : "/privacy-rights";
  document.title = title;
  const descriptionTag = document.querySelector('meta[name="description"]') || document.head.appendChild(document.createElement("meta"));
  descriptionTag.setAttribute("name", "description");
  descriptionTag.setAttribute("content", description);
  const canonicalTag = document.querySelector('link[rel="canonical"]') || document.head.appendChild(document.createElement("link"));
  canonicalTag.setAttribute("rel", "canonical");
  canonicalTag.setAttribute("href", publicUrl(path));
}

export default function PrivacyRights({ locale = "en" }: { locale?: Locale }) {
  const arabic = locale === "ar";
  const clinic = trpc.publicContent.clinicSettings.useQuery();
  const policyPath = arabic ? "/ar/policies/privacy-policy" : "/policies/privacy-policy";
  const appointmentPath = arabic ? "/ar/appointment" : "/appointment";
  const homePath = arabic ? "/ar" : "/";
  const t = arabic ? {
    title: "حقوق المريض والخصوصية",
    eyebrow: "معلومات العيادة · الرياض",
    intro: "هذه الصفحة تشرح الطريقة العملية لطلب المساعدة بشأن الخصوصية أو حقوق المريض عند استخدام الموقع أو التواصل مع العيادة.",
    privacyTitle: "طلب متعلق ببياناتك الشخصية",
    privacyBody: "يمكنك طلب معلومات عن بياناتك الشخصية، أو نسخة منها، أو تصحيحها أو تحديثها، أو طلب إتلافها عندما لا تكون هناك حاجة نظامية للاحتفاظ بها. قد تطلب العيادة التحقق من الهوية قبل الإفصاح أو التعديل لحماية خصوصيتك.",
    privacySafety: "لا ترسل أرقام الهوية أو كلمات المرور أو التقارير الطبية أو معلومات الدفع عبر نموذج عام أو رسالة واتساب. استخدم قناة الاتصال الرسمية أدناه لبدء الطلب، ثم تتواصل العيادة معك بشكل آمن عند الحاجة.",
    patientTitle: "حقوق المريض",
    patientBody: "تشمل حقوق المرضى السرية، وشرح الخطة العلاجية بلغة مفهومة، والموافقة أو الرفض قبل الإجراء، وطلب المعلومات والسجلات وفق الضوابط المعمول بها، وتقديم شكوى من دون تقييد. توضح وثيقة وزارة الصحة الحقوق والمسؤوليات بالتفصيل.",
    consentTitle: "الموافقة العلاجية",
    consentBody: "تأكيد الخصوصية أو طلب الموعد عبر الموقع ليس موافقة طبية على إجراء. تناقش العيادة ملاءمة العلاج وخطته والموافقة المطلوبة معك قبل أي إجراء.",
    contactTitle: "كيف تبدأ طلبك",
    contactBody: "استخدم البريد الإلكتروني أو الهاتف أو واتساب الرسمي للعيادة. اذكر أن رسالتك طلب خصوصية أو حقوق مريض، واكتب أقل قدر ممكن من التفاصيل في الرسالة الأولى. ستوثق العيادة الطلب وتتحقق من الهوية عند الحاجة قبل الإفصاح أو التعديل.",
    policy: "سياسة الخصوصية",
    appointment: "طلب موعد",
    back: "العودة للرئيسية",
    officialBill: "وثيقة حقوق ومسؤوليات المرضى — وزارة الصحة",
    email: "البريد الإلكتروني للعيادة",
    phone: "اتصل بالعيادة",
    whatsapp: "واتساب العيادة",
    unavailable: "قنوات الاتصال الرسمية للعيادة غير معروضة حاليًا. يرجى استخدام معلومات التواصل المنشورة في الصفحة الرئيسية.",
  } : {
    title: "Patient Rights & Privacy",
    eyebrow: "Clinic information · Riyadh",
    intro: "This page explains the practical route for privacy and patient-rights help when you use this website or communicate with the clinic.",
    privacyTitle: "Request about your personal data",
    privacyBody: "You may ask about your personal data, request a copy, ask for correction or update, or request destruction where there is no legal need to retain it. The clinic may verify identity before disclosure or change in order to protect your privacy.",
    privacySafety: "Do not send ID numbers, passwords, medical reports, or payment information through a public form or WhatsApp message. Use an official clinic channel below to begin the request; the clinic can arrange a safer follow-up where needed.",
    patientTitle: "Patient rights",
    patientBody: "Patient rights include confidentiality, discussion of the treatment plan in an understandable language, consent or refusal before a procedure, access to information and records subject to applicable controls, and the ability to raise a complaint without restriction. The Ministry of Health document explains the rights and responsibilities in detail.",
    consentTitle: "Treatment consent",
    consentBody: "A website privacy acknowledgement or appointment request is not medical consent for a procedure. The clinic discusses suitability, the treatment plan, and the required clinical consent with you before any procedure.",
    contactTitle: "How to start a request",
    contactBody: "Use the clinic’s official email, telephone, or WhatsApp channel. State that your message is a privacy or patient-rights request and include only the minimum detail in the first message. The clinic should log the request and verify identity where needed before disclosure or change.",
    policy: "Privacy Policy",
    appointment: "Request appointment",
    back: "Back to home",
    officialBill: "Patient Rights and Responsibilities — Saudi Ministry of Health",
    email: "Clinic email",
    phone: "Call the clinic",
    whatsapp: "Clinic WhatsApp",
    unavailable: "Official clinic contact channels are not currently shown. Please use the contact information published on the homepage.",
  };

  useEffect(() => { setPageMetadata(locale); }, [locale]);

  const email = clinic.data?.email?.trim() || null;
  const telephone = clinic.data?.telephone?.trim() || null;
  const whatsapp = clinic.data?.whatsapp?.replace(/\D/g, "") || null;

  return (
    <main lang={arabic ? "ar" : "en"} dir={arabic ? "rtl" : "ltr"} className={`min-h-screen bg-[#F7F3EC] text-[#102032] ${arabic ? "arabic-public-page" : ""}`}>
      <PublicSiteHeader locale={locale} active="privacyRights" />
      <section className="border-b border-[#102032]/10 bg-[#EDE5D8]">
        <div className="mx-auto max-w-5xl px-4 py-14 sm:px-6 lg:px-8 lg:py-20">
          <p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#B85E3C]">{t.eyebrow}</p>
          <h1 className={`mt-4 max-w-3xl text-5xl tracking-[-0.055em] sm:text-6xl ${arabic ? "font-sans font-extrabold leading-[1.2]" : "font-display leading-[0.94]"}`}>{t.title}</h1>
          <p className="mt-6 max-w-3xl text-base leading-8 text-[#52606B]">{t.intro}</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href={policyPath} className="inline-flex min-h-11 items-center gap-2 bg-[#102032] px-4 text-[11px] font-extrabold uppercase tracking-[0.12em] text-white transition hover:bg-[#B85E3C] active:scale-[0.97]">{t.policy}<ArrowRight className={arabic ? "size-4 rotate-180" : "size-4"} /></Link>
            <Link href={appointmentPath} className="inline-flex min-h-11 items-center gap-2 border border-[#102032]/20 px-4 text-[11px] font-extrabold uppercase tracking-[0.12em] transition hover:border-[#B85E3C]">{t.appointment}</Link>
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-5xl gap-5 px-4 py-12 sm:px-6 lg:grid-cols-2 lg:px-8">
        <article className="border border-[#102032]/10 bg-white p-6 sm:p-7"><ShieldCheck className="size-6 text-[#B85E3C]" /><h2 className={`mt-4 text-2xl ${arabic ? "font-sans font-extrabold" : "font-display"}`}>{t.privacyTitle}</h2><p className="mt-3 text-sm leading-7 text-[#52606B]">{t.privacyBody}</p><p className="mt-4 border-s-2 border-[#B85E3C] bg-[#FFF8F2] p-3 text-sm leading-6 text-[#52606B]">{t.privacySafety}</p></article>
        <article className="border border-[#102032]/10 bg-white p-6 sm:p-7"><UserRoundCheck className="size-6 text-[#B85E3C]" /><h2 className={`mt-4 text-2xl ${arabic ? "font-sans font-extrabold" : "font-display"}`}>{t.patientTitle}</h2><p className="mt-3 text-sm leading-7 text-[#52606B]">{t.patientBody}</p><a href={MOH_PATIENT_RIGHTS_URL} target="_blank" rel="noreferrer" className="mt-5 inline-flex items-center gap-2 text-sm font-bold text-[#B85E3C] underline underline-offset-4">{t.officialBill}<ExternalLink className="size-4" /></a></article>
        <article className="border border-[#102032]/10 bg-white p-6 sm:p-7"><FileCheck2 className="size-6 text-[#B85E3C]" /><h2 className={`mt-4 text-2xl ${arabic ? "font-sans font-extrabold" : "font-display"}`}>{t.consentTitle}</h2><p className="mt-3 text-sm leading-7 text-[#52606B]">{t.consentBody}</p></article>
        <article className="border border-[#102032]/10 bg-white p-6 sm:p-7"><Mail className="size-6 text-[#B85E3C]" /><h2 className={`mt-4 text-2xl ${arabic ? "font-sans font-extrabold" : "font-display"}`}>{t.contactTitle}</h2><p className="mt-3 text-sm leading-7 text-[#52606B]">{t.contactBody}</p><div className="mt-5 flex flex-wrap gap-3">{email ? <a href={`mailto:${email}?subject=${encodeURIComponent(arabic ? "طلب خصوصية أو حقوق مريض" : "Privacy or patient-rights request")}`} className="inline-flex min-h-10 items-center gap-2 border border-[#102032]/20 px-3 text-xs font-bold hover:border-[#B85E3C]"><Mail className="size-4" />{t.email}</a> : null}{telephone ? <a href={`tel:${telephone.replace(/\s/g, "")}`} className="inline-flex min-h-10 items-center gap-2 border border-[#102032]/20 px-3 text-xs font-bold hover:border-[#B85E3C]"><Phone className="size-4" />{t.phone}</a> : null}{whatsapp ? <a href={`https://wa.me/${whatsapp}`} target="_blank" rel="noreferrer" className="inline-flex min-h-10 items-center gap-2 border border-[#102032]/20 px-3 text-xs font-bold hover:border-[#B85E3C]"><Phone className="size-4" />{t.whatsapp}</a> : null}{!email && !telephone && !whatsapp ? <p className="text-sm text-[#52606B]">{t.unavailable}</p> : null}</div></article>
      </section>
      <div className="mx-auto max-w-5xl px-4 pb-12 sm:px-6 lg:px-8"><Link href={homePath} className="inline-flex items-center gap-2 text-sm font-bold text-[#102032] underline underline-offset-4">{arabic ? <ArrowRight className="size-4" /> : <ArrowLeft className="size-4" />}{t.back}</Link></div>
    </main>
  );
}
