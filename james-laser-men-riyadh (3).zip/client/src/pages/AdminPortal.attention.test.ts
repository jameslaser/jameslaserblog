import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const portal = readFileSync(resolve(process.cwd(), "client/src/pages/AdminPortal.tsx"), "utf8");
const routes = readFileSync(resolve(process.cwd(), "client/src/App.tsx"), "utf8");
const router = readFileSync(resolve(process.cwd(), "server/routers.ts"), "utf8");

describe("Admin Attention Agent workspace", () => {
  it("registers a protected owner/admin route and navigation item", () => {
    expect(routes).toContain('/admin/attention');
    expect(portal).toContain('label: "Attention agent"');
    expect(portal).toContain('page === "attention"');
    expect(portal).toContain('page === "attention"');
    expect(portal).toContain('clinicalWorkflowPage) && !["owner", "admin"].includes(user.role)');
  });

  it("uses deterministic zero-credit findings and exposes no LLM invocation", () => {
    expect(portal).toContain("ZERO CREDITS");
    expect(portal).toContain("It does not use an LLM");
    expect(portal).not.toContain("invokeLLM");
    expect(router).toContain("attention: adminProcedure.query");
  });

  it("keeps notification behavior generic, deduplicated, and in-portal", () => {
    expect(router).toContain('linkPath === "/admin/attention"');
    expect(router).toContain('title: "Admin attention review needed"');
    expect(portal).toContain("at most one unread generic in-portal system notice");
    expect(portal).toContain("It never sends WhatsApp, email, SMS, or a third-party message");
  });
});
