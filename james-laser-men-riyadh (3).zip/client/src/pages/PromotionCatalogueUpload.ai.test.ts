import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const source = readFileSync(resolve(process.cwd(), "client/src/pages/PromotionCatalogueUpload.tsx"), "utf8");

describe("promotion upload and review-draft interface", () => {
  it("uses the protected server AI draft procedure without publishing by default", () => {
    expect(source).toContain("trpc.cms.generatePromotionDraft.useMutation");
    expect(source).toContain("Generate private AI draft");
    expect(source).toContain('status: "draft"');
    expect(source).toContain('featured: false');
    expect(source).toContain("Nothing is sent to the public website until an authorized editor saves, checks, and explicitly publishes the offer");
  });

  it("requires an approved source and makes homepage placement explicit", () => {
    expect(source).toContain("Promotion detail image");
    expect(source).toContain("Approved promotion details");
    expect(source).toContain("sourceDetails.trim().length < 20");
    expect(source).toContain("Feature on public homepage after publishing");
    expect(source).toContain("published</strong> and marked <strong>featured");
  });
});
