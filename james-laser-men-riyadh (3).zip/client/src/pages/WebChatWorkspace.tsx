import { useEffect, useMemo, useRef, useState } from "react";
import { CheckCheck, CheckCircle2, ClipboardList, FileText, Inbox, Loader2, MessageCircle, Plus, Search, Send, SlidersHorizontal, Sparkles, X } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { AdminPageHeader } from "@/components/AdminUi";
import { trpc } from "@/lib/trpc";

type WorkspaceTab = "inbox" | "sent" | "templates";
type ConversationStatus = "open" | "resolved" | "archived";
type MessageSource = "manual" | "template" | "ai_draft";
type InboxSort = "newest" | "oldest" | "unread";

type TemplateDraft = {
  id?: number;
  label: string;
  language: "en" | "ar";
  body: string;
  isActive: boolean;
};

const emptyTemplate: TemplateDraft = { label: "", language: "en", body: "", isActive: true };

function formatTime(value: Date | string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return date.toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
}

function statusClass(status: string) {
  if (status === "open") return "border-emerald-700/20 bg-emerald-50 text-emerald-800";
  if (status === "resolved") return "border-sky-700/20 bg-sky-50 text-sky-800";
  return "border-[#102032]/15 bg-[#f7f3ec] text-[#52606B]";
}

function EmptyState({ icon: Icon, title, detail }: { icon: typeof Inbox; title: string; detail: string }) {
  return <div className="grid min-h-64 place-items-center p-8 text-center"><div><div className="mx-auto grid size-11 place-items-center rounded-full bg-[#f7f3ec] text-[#a85438]"><Icon className="size-5" /></div><h3 className="mt-4 font-display text-2xl text-[#102032]">{title}</h3><p className="mx-auto mt-2 max-w-md text-sm leading-6 text-[#66727A]">{detail}</p></div></div>;
}

export function WebChatWorkspace() {
  const [tab, setTab] = useState<WorkspaceTab>("inbox");
  const [status, setStatus] = useState<ConversationStatus | "all">("open");
  const [language, setLanguage] = useState<"all" | "en" | "ar">("all");
  const [unreadOnly, setUnreadOnly] = useState(false);
  const [sort, setSort] = useState<InboxSort>("newest");
  const [query, setQuery] = useState("");
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [reply, setReply] = useState("");
  const [replySource, setReplySource] = useState<MessageSource>("manual");
  const [suggestionLabel, setSuggestionLabel] = useState<string | null>(null);
  const [templateEditor, setTemplateEditor] = useState<TemplateDraft | null>(null);
  const lastTypingSentAt = useRef(0);
  const utils = trpc.useUtils();
  const inboxInput = useMemo(() => ({ status: status === "all" ? undefined : status, language: language === "all" ? undefined : language, unreadOnly: unreadOnly || undefined, sort, query: query.trim() || undefined }), [language, query, sort, status, unreadOnly]);
  const inbox = trpc.webChat.adminInbox.useQuery(inboxInput, { refetchInterval: tab === "inbox" ? 8_000 : false });
  const selected = trpc.webChat.adminConversation.useQuery({ conversationId: selectedId ?? 0 }, { enabled: Boolean(selectedId), refetchInterval: tab === "inbox" ? 8_000 : false });
  const templates = trpc.webChat.templates.useQuery();
  const sent = trpc.webChat.sent.useQuery(undefined, { enabled: tab === "sent" });

  useEffect(() => {
    if (!selectedId && inbox.data?.[0]) setSelectedId(inbox.data[0].id);
  }, [inbox.data, selectedId]);

  const refreshInbox = async () => {
    await Promise.all([utils.webChat.adminInbox.invalidate(), utils.webChat.adminConversation.invalidate(), utils.webChat.sent.invalidate()]);
  };
  const markRead = trpc.webChat.markRead.useMutation({ onSuccess: refreshInbox, onError: error => toast.error(error.message) });
  const setConversationStatus = trpc.webChat.setStatus.useMutation({ onSuccess: refreshInbox, onError: error => toast.error(error.message) });
  const staffTyping = trpc.webChat.staffTyping.useMutation();
  const send = trpc.webChat.send.useMutation({
    onSuccess: async () => {
      setReply("");
      setReplySource("manual");
      setSuggestionLabel(null);
      await refreshInbox();
      toast.success("Reply added to the website chat.");
    },
    onError: error => toast.error(error.message),
  });
  const smartSuggestion = trpc.webChat.suggestTemplateReply.useMutation({
    onSuccess: result => {
      setReply(result.body);
      setReplySource("template");
      setSuggestionLabel(result.templateLabel);
      toast.success(`Suggested from “${result.templateLabel}”. Review before sending.`);
    },
    onError: error => toast.error(error.message),
  });
  const saveTemplate = trpc.webChat.saveTemplate.useMutation({
    onSuccess: async () => {
      setTemplateEditor(null);
      await templates.refetch();
      toast.success("Reply template saved.");
    },
    onError: error => toast.error(error.message),
  });

  const chooseConversation = (id: number) => {
    setSelectedId(id);
    setReply("");
    setReplySource("manual");
    setSuggestionLabel(null);
    markRead.mutate({ conversationId: id });
  };

  const activeTemplates = (templates.data ?? []).filter(template => template.isActive);
  const useTemplate = (body: string, label: string) => {
    setReply(body);
    setReplySource("template");
    setSuggestionLabel(label);
    toast.message("Template copied into the reply box. Review it before sending.");
  };
  const updateReply = (value: string) => {
    setReply(value);
    setSuggestionLabel(null);
    if (replySource === "template") setReplySource("manual");
    if (!selectedId || !value.trim() || Date.now() - lastTypingSentAt.current < 3_000) return;
    lastTypingSentAt.current = Date.now();
    staffTyping.mutate({ conversationId: selectedId });
  };

  const renderInbox = () => <section className="grid min-h-[720px] overflow-hidden border border-[#102032]/10 bg-white xl:grid-cols-[350px_minmax(0,1fr)_300px]">
    <aside className={`border-b border-[#102032]/10 xl:border-b-0 xl:border-r ${selectedId ? "hidden xl:block" : "block"}`}><div className="border-b border-[#102032]/10 p-4"><div className="flex items-center justify-between gap-3"><div><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">Protected website channel</p><h2 className="mt-1 font-display text-2xl text-[#102032]">Inbox</h2></div><Badge variant="outline">{inbox.data?.length ?? 0}</Badge></div><div className="relative mt-4"><Search className="pointer-events-none absolute left-3 top-3 size-4 text-[#66727A]" /><Input className="pl-9" value={query} onChange={event => setQuery(event.target.value)} placeholder="Search message text or chat #" /></div><div className="mt-3 flex gap-2 overflow-x-auto pb-1">{(["open", "resolved", "archived", "all"] as const).map(value => <button key={value} type="button" onClick={() => setStatus(value)} className={`shrink-0 border px-2.5 py-1 text-xs font-semibold capitalize transition ${status === value ? "border-[#a85438] bg-[#a85438] text-white" : "border-[#102032]/15 text-[#52606B] hover:bg-[#f7f3ec]"}`}>{value}</button>)}</div><div className="mt-3 grid grid-cols-2 gap-2"><Select value={language} onValueChange={value => setLanguage(value as "all" | "en" | "ar")}><SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Language" /></SelectTrigger><SelectContent><SelectItem value="all">All languages</SelectItem><SelectItem value="en">English</SelectItem><SelectItem value="ar">Arabic</SelectItem></SelectContent></Select><Select value={sort} onValueChange={value => setSort(value as InboxSort)}><SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Sort" /></SelectTrigger><SelectContent><SelectItem value="newest">Newest first</SelectItem><SelectItem value="oldest">Oldest first</SelectItem><SelectItem value="unread">Unread first</SelectItem></SelectContent></Select></div><button type="button" onClick={() => setUnreadOnly(current => !current)} className={`mt-2 flex w-full items-center gap-2 border px-2.5 py-2 text-left text-xs font-semibold transition ${unreadOnly ? "border-[#a85438] bg-[#fff3ec] text-[#893a21]" : "border-[#102032]/15 text-[#52606B] hover:bg-[#f7f3ec]"}`}><SlidersHorizontal className="size-3.5" />{unreadOnly ? "Unread only enabled" : "Show unread only"}</button></div><div className="max-h-[584px] overflow-y-auto">{inbox.isLoading ? <div className="space-y-3 p-4"><Skeleton className="h-24" /><Skeleton className="h-24" /><Skeleton className="h-24" /></div> : inbox.data?.length ? inbox.data.map(item => <button key={item.id} type="button" onClick={() => chooseConversation(item.id)} className={`w-full border-b border-[#102032]/10 p-4 text-left transition hover:bg-[#f8f5ef] ${selectedId === item.id ? "bg-[#f8f5ef]" : "bg-white"}`}><div className="flex items-start justify-between gap-2"><p className="font-semibold text-[#102032]">Website chat #{item.id}</p><span className="shrink-0 text-[11px] text-[#66727A]">{formatTime(item.lastMessageAt)}</span></div><p className="mt-2 line-clamp-2 text-sm leading-5 text-[#52606B]">{item.latestMessage?.body || "No stored messages"}</p><div className="mt-3 flex items-center gap-2"><Badge variant="outline" className={`capitalize ${statusClass(item.status)}`}>{item.status}</Badge><Badge variant="outline" className="uppercase">{item.language}</Badge>{item.unreadForStaff > 0 ? <span className="grid size-5 place-items-center rounded-full bg-[#a85438] text-[10px] font-bold text-white">{item.unreadForStaff}</span> : null}{item.visitorIsTyping ? <span className="text-[10px] font-semibold text-[#a85438]">Visitor typing…</span> : null}</div></button>) : <EmptyState icon={Inbox} title="No matching messages" detail="Adjust the filters or search term. New public website chats remain separate from WhatsApp and appointment requests." />}</div></aside>
    <main className={selectedId ? "block" : "hidden xl:block"}>{selected.isLoading ? <div className="space-y-4 p-6"><Skeleton className="h-16" /><Skeleton className="h-32" /><Skeleton className="h-32" /></div> : selected.data ? <><header className="flex flex-wrap items-center justify-between gap-3 border-b border-[#102032]/10 p-4"><div><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">Anonymous visitor thread</p><h2 className="mt-1 font-display text-2xl text-[#102032]">Website chat #{selected.data.id}</h2><p className="mt-1 text-xs text-[#66727A]">Started {formatTime(selected.data.createdAt)} · {selected.data.language.toUpperCase()}</p>{selected.data.visitorIsTyping ? <p className="mt-2 text-xs font-semibold text-[#a85438]">Visitor is typing…</p> : null}</div><Select value={selected.data.status} onValueChange={value => setConversationStatus.mutate({ conversationId: selected.data!.id, status: value as ConversationStatus })}><SelectTrigger className="w-32"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="open">Open</SelectItem><SelectItem value="resolved">Resolved</SelectItem><SelectItem value="archived">Archived</SelectItem></SelectContent></Select></header><div className="max-h-[410px] min-h-[320px] space-y-3 overflow-y-auto bg-[#f7f3ec] p-5">{selected.data.messages.map(message => { const isVisitor = message.direction === "visitor"; const latestStaffId = [...selected.data!.messages].reverse().find(item => item.direction === "staff")?.id; const visitorSawMessage = !isVisitor && message.id === latestStaffId && selected.data!.lastVisitorReadAt && new Date(message.createdAt) <= new Date(selected.data!.lastVisitorReadAt); return <div key={message.id} className={`flex ${isVisitor ? "justify-start" : "justify-end"}`}><div className={`max-w-[86%] rounded-2xl px-4 py-3 text-sm leading-6 ${isVisitor ? "rounded-tl-sm border border-[#102032]/10 bg-white text-[#263746]" : "rounded-tr-sm bg-[#102032] text-white"}`}><p className={`mb-1 text-[10px] font-extrabold uppercase tracking-[0.14em] ${isVisitor ? "text-[#a85438]" : "text-[#eab394]"}`}>{isVisitor ? "Visitor" : message.staffName || "Clinic team"}</p><p className="whitespace-pre-wrap">{message.body}</p><div className={`mt-1 flex items-center gap-1 text-[10px] ${isVisitor ? "text-[#83909a]" : "text-white/60"}`}><span>{formatTime(message.createdAt)}</span>{visitorSawMessage ? <><CheckCheck className="size-3" /><span>Seen by visitor</span></> : null}</div></div></div>; })}</div><div className="border-t border-[#102032]/10 bg-white p-4"><div className="mb-3 flex flex-wrap items-center justify-between gap-2"><p className="text-xs leading-5 text-[#66727A]">Replies stay general and staff-reviewed. Do not provide medical advice, confirm appointments, or request personal information in this chat.</p><Button variant="outline" size="sm" disabled={smartSuggestion.isPending || !selected.data.messages.some(message => message.direction === "visitor")} onClick={() => smartSuggestion.mutate({ conversationId: selected.data!.id })}>{smartSuggestion.isPending ? <Loader2 className="mr-2 size-4 animate-spin" /> : <Sparkles className="mr-2 size-4" />}Suggest from templates</Button></div><div className="flex items-end gap-2"><Textarea value={reply} onChange={event => updateReply(event.target.value)} className="min-h-24 resize-none" maxLength={1500} placeholder="Write or select a reviewed reply…" /><Button size="icon" className="size-11 shrink-0 bg-[#102032] text-white hover:bg-[#1c3b51]" disabled={!reply.trim() || send.isPending} onClick={() => send.mutate({ conversationId: selected.data!.id, body: reply.trim(), source: replySource })}>{send.isPending ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}<span className="sr-only">Send reply</span></Button></div>{suggestionLabel ? <p className="mt-2 text-xs text-[#a85438]">Suggested from the saved “{suggestionLabel}” template. It has not been sent; staff review remains required.</p> : null}</div></> : <EmptyState icon={MessageCircle} title="Select a conversation" detail="Choose a website chat to read the message history and prepare a reviewed reply." />}</main>
    <aside className="hidden border-l border-[#102032]/10 xl:block"><div className="border-b border-[#102032]/10 p-5"><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">Ready-made replies</p><h2 className="mt-1 font-display text-2xl text-[#102032]">Templates</h2><p className="mt-2 text-sm leading-6 text-[#66727A]">Templates copy into the composer only. A staff member still chooses whether to send.</p></div><div className="max-h-[600px] space-y-3 overflow-y-auto p-4">{templates.isLoading ? <><Skeleton className="h-24" /><Skeleton className="h-24" /></> : activeTemplates.filter(template => !selected.data || template.language === selected.data.language).map(template => <button key={template.id} type="button" onClick={() => useTemplate(template.body, template.label)} className="w-full border border-[#102032]/10 bg-[#fcfaf6] p-3 text-left transition hover:border-[#a85438]/50 hover:bg-[#fff8f3]"><div className="flex items-center justify-between gap-2"><p className="text-sm font-semibold text-[#102032]">{template.label}</p><Badge variant="outline" className="uppercase">{template.language}</Badge></div><p className="mt-2 line-clamp-3 text-xs leading-5 text-[#66727A]">{template.body}</p></button>)}{!templates.isLoading && !activeTemplates.length ? <p className="text-sm text-[#66727A]">No active templates are available.</p> : null}</div></aside>
  </section>;

  const renderSent = () => <section className="border border-[#102032]/10 bg-white"><div className="flex flex-wrap items-end justify-between gap-4 border-b border-[#102032]/10 p-5"><div><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">Protected audit view</p><h2 className="mt-1 font-display text-3xl text-[#102032]">Sent replies</h2><p className="mt-2 text-sm leading-6 text-[#66727A]">Review the latest 100 staff replies across the website chat channel. This is separate from WhatsApp history.</p></div><Badge variant="outline">{sent.data?.length ?? 0} replies</Badge></div>{sent.isLoading ? <div className="space-y-3 p-5"><Skeleton className="h-16" /><Skeleton className="h-16" /></div> : sent.data?.length ? <div className="divide-y divide-[#102032]/10">{sent.data.map(item => <article key={item.id} className="grid gap-3 p-5 sm:grid-cols-[1fr_auto]"><div><div className="flex flex-wrap items-center gap-2"><p className="font-semibold text-[#102032]">Website chat #{item.conversationId}</p><Badge variant="outline" className={statusClass(item.status)}>{item.status}</Badge><Badge variant="outline" className="capitalize">{item.source.replace("_", " ")}</Badge></div><p className="mt-2 whitespace-pre-wrap text-sm leading-6 text-[#52606B]">{item.body}</p><p className="mt-2 text-xs text-[#66727A]">{item.staffName || "Clinic team"} · {formatTime(item.createdAt)}</p></div><Button variant="outline" size="sm" onClick={() => { setTab("inbox"); chooseConversation(item.conversationId); }}>Open thread</Button></article>)}</div> : <EmptyState icon={Send} title="No replies sent" detail="Staff replies will appear here after they are sent through the protected website-chat inbox." />}</section>;

  const renderTemplates = () => <section className="border border-[#102032]/10 bg-white"><div className="flex flex-wrap items-end justify-between gap-4 border-b border-[#102032]/10 p-5"><div><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">Staff-reviewed library</p><h2 className="mt-1 font-display text-3xl text-[#102032]">Reply templates</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-[#66727A]">Create short, clinic-reviewed replies for general website questions. Templates do not send automatically and must not contain medical advice, prices, availability, or appointment confirmations.</p></div><Button onClick={() => setTemplateEditor(emptyTemplate)}><Plus className="mr-2 size-4" />New template</Button></div>{templateEditor ? <form className="border-b border-[#102032]/10 bg-[#f8f5ef] p-5" onSubmit={event => { event.preventDefault(); if (!templateEditor.label.trim() || !templateEditor.body.trim()) return; saveTemplate.mutate({ ...templateEditor, label: templateEditor.label.trim(), body: templateEditor.body.trim() }); }}><div className="flex flex-wrap items-center justify-between gap-3"><h3 className="font-display text-2xl text-[#102032]">{templateEditor.id ? "Edit template" : "New template"}</h3><Button type="button" variant="ghost" size="icon" onClick={() => setTemplateEditor(null)} aria-label="Close template editor"><X className="size-4" /></Button></div><div className="mt-4 grid gap-4 lg:grid-cols-[1fr_180px]"><label className="grid gap-1.5 text-xs font-bold text-[#102032]"><span>Template label</span><Input value={templateEditor.label} onChange={event => setTemplateEditor(current => current ? { ...current, label: event.target.value } : current)} maxLength={120} required /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]"><span>Language</span><Select value={templateEditor.language} onValueChange={value => setTemplateEditor(current => current ? { ...current, language: value as "en" | "ar" } : current)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="en">English</SelectItem><SelectItem value="ar">Arabic</SelectItem></SelectContent></Select></label></div><label className="mt-4 grid gap-1.5 text-xs font-bold text-[#102032]"><span>Reply text</span><Textarea value={templateEditor.body} onChange={event => setTemplateEditor(current => current ? { ...current, body: event.target.value } : current)} maxLength={1500} className="min-h-28 resize-y" required dir={templateEditor.language === "ar" ? "rtl" : "ltr"} /></label><label className="mt-4 flex items-center gap-2 text-sm font-medium text-[#102032]"><input type="checkbox" checked={templateEditor.isActive} onChange={event => setTemplateEditor(current => current ? { ...current, isActive: event.target.checked } : current)} className="size-4 accent-[#a85438]" />Available to staff</label><div className="mt-5 flex gap-2"><Button type="submit" disabled={saveTemplate.isPending}>{saveTemplate.isPending ? <Loader2 className="mr-2 size-4 animate-spin" /> : <CheckCircle2 className="mr-2 size-4" />}Save template</Button><Button type="button" variant="outline" onClick={() => setTemplateEditor(null)}>Cancel</Button></div></form> : null}<div className="divide-y divide-[#102032]/10">{templates.isLoading ? <div className="p-5"><Skeleton className="h-24" /></div> : templates.data?.map(template => <article key={template.id} className="grid gap-4 p-5 lg:grid-cols-[1fr_auto]"><div><div className="flex flex-wrap items-center gap-2"><h3 className="font-semibold text-[#102032]">{template.label}</h3><Badge variant="outline" className="uppercase">{template.language}</Badge><Badge variant="outline" className={template.isActive ? "border-emerald-700/20 bg-emerald-50 text-emerald-800" : "border-[#102032]/15 bg-[#f7f3ec] text-[#52606B]"}>{template.isActive ? "Active" : "Inactive"}</Badge></div><p className="mt-3 whitespace-pre-wrap text-sm leading-6 text-[#52606B]">{template.body}</p></div><Button size="sm" variant="outline" onClick={() => setTemplateEditor({ id: template.id, label: template.label, language: template.language, body: template.body, isActive: template.isActive })}><FileText className="mr-2 size-4" />Edit</Button></article>)}</div></section>;

  const tabs: Array<{ id: WorkspaceTab; label: string; icon: typeof Inbox }> = [{ id: "inbox", label: "Inbox", icon: Inbox }, { id: "sent", label: "Sent", icon: Send }, { id: "templates", label: "Templates", icon: ClipboardList }];
  return <div className="mx-auto max-w-[1500px]"><AdminPageHeader eyebrow="Website communication" title="Web chat workspace" description="A protected inbox for the public website widget. Visitor chats are isolated from WhatsApp, appointment requests, and patient records. Keep replies general and staff-reviewed." /><div className="mt-6 flex flex-wrap gap-2 border-b border-[#102032]/10 pb-4">{tabs.map(item => <Button key={item.id} variant={tab === item.id ? "default" : "outline"} className={tab === item.id ? "bg-[#102032] text-white hover:bg-[#1c3b51]" : "bg-white"} onClick={() => setTab(item.id)}><item.icon className="mr-2 size-4" />{item.label}</Button>)}</div><div className="mt-5">{tab === "inbox" ? renderInbox() : tab === "sent" ? renderSent() : renderTemplates()}</div><p className="mt-5 text-xs leading-5 text-[#66727A]">Smart suggestions are zero-credit matches against the saved, staff-reviewed templates. They do not invoke a language model, never send automatically, and never create or change appointments, patient records, HMS data, or WhatsApp messages.</p></div>;
}
