import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const appearance = readFileSync(resolve(process.cwd(), "client/src/pages/HomepageAppearance.tsx"), "utf8");
const portal = readFileSync(resolve(process.cwd(), "client/src/pages/AdminPortal.tsx"), "utf8");
const cmsManager = readFileSync(resolve(process.cwd(), "client/src/pages/CmsManager.tsx"), "utf8");
const settings = readFileSync(resolve(process.cwd(), "client/src/components/SettingsControlCenter.tsx"), "utf8");
const css = readFileSync(resolve(process.cwd(), "client/src/index.css"), "utf8");

describe("homepage appearance controls", () => {
  it("offers only vetted public themes and uses the protected media uploader", () => {
    expect(appearance).toContain('value: "signature"');
    expect(appearance).toContain('value: "graphite"');
    expect(appearance).toContain('value: "sage"');
    expect(appearance).toContain("CmsImageUploadField");
    expect(appearance).toContain("homepageHeroImageUrl");
    expect(appearance).toContain("homepageSpecialistImageUrl");
    expect(appearance).toContain("homepageClinicImageUrl");
    expect(appearance).toContain("Server-authorized");
    expect(appearance).toContain("Publication safeguard");
  });

  it("preserves an uploaded image selection until its saved server state returns", () => {
    expect(appearance).toContain("const serverBaselineRef = useRef<string | null>(null)");
    expect(appearance).toContain("const hasUnsavedChanges = serverBaselineRef.current !== null && currentFingerprint !== serverBaselineRef.current");
    expect(appearance).toContain("if (currentFingerprint === nextFingerprint)");
    expect(appearance).toContain("if (hasUnsavedChanges) return current");
    expect(appearance).toContain("serverBaselineRef.current = JSON.stringify(saved); setForm(saved);");
  });

  it("keeps appearance controls within authorized CMS navigation", () => {
    expect(portal).toContain('path: "/admin/appearance"');
    expect(cmsManager).toContain('page === "appearance"');
    expect(settings).toContain('path: "/admin/appearance"');
  });

  it("scopes approved theme changes to public presentation variables", () => {
    expect(css).toContain(".premium-home--theme-graphite");
    expect(css).toContain(".premium-home--theme-sage");
    expect(css).toContain(".premium-home__hero--image");
  });
});
