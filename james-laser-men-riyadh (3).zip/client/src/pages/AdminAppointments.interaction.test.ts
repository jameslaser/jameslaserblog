// @vitest-environment jsdom
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";
import React from "react";

const mocks = vi.hoisted(() => ({
  appointments: [] as any[],
  queryInputs: [] as Array<{ date: string }>,
  refetch: vi.fn(),
  updateMutate: vi.fn(),
}));

const invalidate = vi.fn();

vi.mock("@/lib/trpc", () => ({
  trpc: {
    useUtils: () => ({
      admin: {
        appointments: { invalidate },
        waitingList: { invalidate },
        patientFile: { invalidate },
        patients: { invalidate },
      },
    }),
    admin: {
      appointments: {
        useQuery: (input: { date: string }) => {
          mocks.queryInputs.push(input);
          return { data: mocks.appointments, isLoading: false, isError: false, isFetching: false, refetch: mocks.refetch };
        },
      },
      updateAppointmentDetails: {
        useMutation: () => ({ mutate: mocks.updateMutate, isPending: false }),
      },
    },
  },
}));

vi.mock("wouter", () => ({ useLocation: () => ["/admin/appointments", vi.fn()] }));

vi.mock("@/contexts/AdminLocaleContext", () => ({
  useAdminLocale: () => ({ locale: "en", isArabic: false, setLocale: vi.fn() }),
  translateAdminText: (value: string) => value,
  adminShellCopy: { en: {}, ar: {} },
  localizeAdminGroup: (value: string) => value,
  localizeAdminLabel: (value: string) => value,
}));

import { Appointments } from "./AdminPortal";

function riyadhDate() {
  return new Intl.DateTimeFormat("sv-SE", { timeZone: "Asia/Riyadh", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
}

function addDay(date: string) {
  const value = new Date(`${date}T12:00:00Z`);
  value.setUTCDate(value.getUTCDate() + 1);
  return value.toISOString().slice(0, 10);
}

function editableHmsAppointment() {
  return {
    id: 71,
    appointmentDate: riyadhDate(),
    appointmentTime: "13:15",
    appointmentEndTime: null,
    patientName: "Editable HMS patient",
    status: "confirmed",
    source: "hms_csv",
    importFingerprint: "hms-fingerprint-71",
    machine: null,
    mrn: "JL-0071",
    nationality: "Saudi",
    contactNumber: "0500000000",
    whatsapp: "0500000000",
    email: null,
    treatmentArea: "Chest",
    treatmentAreas: JSON.stringify(["Chest"]),
    visitType: "session",
    nextFollowUpDate: null,
    nextFollowUpType: null,
    internalNotes: null,
  };
}

describe("Appointments selected-date controls and protected editing", () => {
  beforeEach(() => {
    cleanup();
    mocks.appointments = [];
    mocks.queryInputs.length = 0;
    mocks.refetch.mockReset();
    mocks.updateMutate.mockReset();
    invalidate.mockReset();
    vi.restoreAllMocks();
  });

  it("defaults to Riyadh today and queries tomorrow or an arbitrary selected date without changing source/status rules", async () => {
    const user = userEvent.setup();
    render(React.createElement(Appointments));

    const today = riyadhDate();
    expect(mocks.queryInputs.at(-1)).toEqual({ date: today });

    await user.click(screen.getByRole("button", { name: "Tomorrow" }));
    expect(mocks.queryInputs.at(-1)).toEqual({ date: addDay(today) });
    expect(screen.getByRole("heading", { name: "Tomorrow · confirmed appointments" })).toBeTruthy();

    const dateInput = screen.getByLabelText("Appointment date") as HTMLInputElement;
    fireEvent.change(dateInput, { target: { value: "2026-09-25" } });
    expect(mocks.queryInputs.at(-1)).toEqual({ date: "2026-09-25" });
    expect(dateInput.value).toBe("2026-09-25");
  });

  it("opens the editor from an HMS card and submits only validated local working details", async () => {
    const user = userEvent.setup();
    mocks.appointments = [editableHmsAppointment()];
    vi.spyOn(window, "confirm").mockReturnValue(true);
    render(React.createElement(Appointments));

    await user.click(screen.getByRole("button", { name: "Edit appointment" }));
    expect(screen.getByRole("heading", { name: "Edit Editable HMS patient" })).toBeTruthy();
    expect(screen.getByText(/fingerprint, identity key, import batch, original values/)).toBeTruthy();

    const name = screen.getByLabelText("Patient name") as HTMLInputElement;
    await user.clear(name);
    await user.type(name, "Updated local patient");
    await user.selectOptions(screen.getByLabelText("Machine"), "CLARITY 2");
    await user.click(screen.getByRole("button", { name: "Save appointment details" }));

    expect(window.confirm).toHaveBeenCalledOnce();
    expect(mocks.updateMutate).toHaveBeenCalledOnce();
    const payload = mocks.updateMutate.mock.calls[0]?.[0];
    expect(payload).toMatchObject({ appointmentId: 71, fullName: "Updated local patient", machine: "CLARITY 2", appointmentTime: "13:15" });
    for (const immutableField of ["source", "sourceRowNumber", "importBatchId", "importFingerprint", "hmsImportIdentityKey", "originalRowData"]) {
      expect(payload).not.toHaveProperty(immutableField);
    }
  });
});
