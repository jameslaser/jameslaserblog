import { ArrowUpRight, CalendarDays, Home, MessageCircle, Sparkles } from "lucide-react";
import { useLocation } from "wouter";

const copy = {
  en: {
    eyebrow: "James Laser · Riyadh",
    title: "This page is not here.",
    description: "The page may have moved, or the link may be incomplete. Continue with a public page or contact the clinic about an appointment request.",
    location: "New Look Clinic · Al Sahafah, Riyadh",
    home: "Home",
    treatments: "Treatments",
    appointment: "Request appointment",
    whatsapp: "WhatsApp",
    status: "404 · Page not found",
    continue: "Continue safely",
    note: "An appointment request is reviewed by the clinic before availability is confirmed.",
  },
  ar: {
    eyebrow: "جيمس ليزر · الرياض",
    title: "هذه الصفحة غير متاحة.",
    description: "ربما تم نقل الصفحة أو أن الرابط غير مكتمل. يمكنك متابعة تصفح الصفحات العامة أو التواصل مع العيادة بشأن طلب موعد.",
    location: "نيو لوك كلينيك · حي الصحافة، الرياض",
    home: "الرئيسية",
    treatments: "العلاجات",
    appointment: "طلب موعد",
    whatsapp: "واتساب",
    status: "404 · الصفحة غير متاحة",
    continue: "متابعة آمنة",
    note: "تتم مراجعة طلب الموعد من العيادة قبل تأكيد التوفر.",
  },
} as const;

export default function NotFound() {
  const [location, setLocation] = useLocation();
  const locale = location.startsWith("/ar") ? "ar" : "en";
  const text = copy[locale];
  const isArabic = locale === "ar";
  const homePath = isArabic ? "/ar" : "/en";
  const treatmentsPath = isArabic ? "/ar/treatments" : "/en/treatments";
  const appointmentPath = isArabic ? "/ar/appointment" : "/appointment";
  const whatsapp = `https://wa.me/966557401562?text=${encodeURIComponent(isArabic ? "مرحبًا، أحتاج إلى مساعدة بشأن طلب موعد ليزر." : "Hello, I need help with a laser appointment request.")}`;

  return <main lang={isArabic ? "ar" : "en"} dir={isArabic ? "rtl" : "ltr"} className="grid min-h-screen place-items-center bg-[#102032] px-5 py-10 text-white sm:px-8"><section className="relative w-full max-w-4xl overflow-hidden border border-white/15 bg-[#132A3D] p-7 sm:p-12"><div className="pointer-events-none absolute -right-24 -top-28 size-80 rounded-full border border-white/10" /><div className="pointer-events-none absolute -bottom-40 left-1/4 size-80 rounded-full border border-[#B85E3C]/25" /><div className="relative grid gap-10 lg:grid-cols-[1fr_0.8fr] lg:items-end"><div><div className="flex items-center gap-3 text-[#EAB394]"><span className="grid size-10 place-items-center rounded-full border border-current"><span className="text-[11px] font-extrabold tracking-[-0.08em]">JL</span></span><p className="text-[10px] font-extrabold uppercase tracking-[0.2em]">{text.eyebrow}</p></div><p className="mt-14 text-[11px] font-extrabold uppercase tracking-[0.22em] text-[#EAB394]">{text.status}</p><h1 className="mt-5 max-w-xl font-display text-5xl leading-[0.94] tracking-[-0.055em] sm:text-7xl">{text.title}</h1><p className="mt-6 max-w-xl text-sm leading-7 text-white/70 sm:text-base">{text.description}</p><p className="mt-5 flex items-center gap-2 text-xs font-semibold text-white/55"><Sparkles className="size-3.5 text-[#EAB394]" />{text.location}</p></div><aside className="relative border border-white/15 bg-white/[0.04] p-5 sm:p-6"><p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#EAB394]">{text.continue}</p><div className="mt-5 grid gap-3"><button type="button" onClick={() => setLocation(homePath)} className="flex min-h-12 items-center justify-between bg-[#B85E3C] px-4 text-left text-[11px] font-extrabold uppercase tracking-[0.13em] text-white transition hover:bg-[#D1714C] active:scale-[0.98]"><span className="flex items-center gap-2"><Home className="size-4" />{text.home}</span><ArrowUpRight className="size-4" /></button><button type="button" onClick={() => setLocation(treatmentsPath)} className="flex min-h-12 items-center justify-between border border-white/25 px-4 text-left text-[11px] font-extrabold uppercase tracking-[0.13em] text-white transition hover:border-[#EAB394] hover:text-[#EAB394] active:scale-[0.98]"><span>{text.treatments}</span><ArrowUpRight className="size-4" /></button><button type="button" onClick={() => setLocation(appointmentPath)} className="flex min-h-12 items-center justify-between border border-white/25 px-4 text-left text-[11px] font-extrabold uppercase tracking-[0.13em] text-white transition hover:border-[#EAB394] hover:text-[#EAB394] active:scale-[0.98]"><span className="flex items-center gap-2"><CalendarDays className="size-4" />{text.appointment}</span><ArrowUpRight className="size-4" /></button><a href={whatsapp} target="_blank" rel="noreferrer" className="flex min-h-12 items-center justify-between border border-white/25 px-4 text-[11px] font-extrabold uppercase tracking-[0.13em] text-white transition hover:border-[#EAB394] hover:text-[#EAB394]"><span className="flex items-center gap-2"><MessageCircle className="size-4" />{text.whatsapp}</span><ArrowUpRight className="size-4" /></a></div><p className="mt-5 border-t border-white/10 pt-4 text-xs leading-5 text-white/55">{text.note}</p></aside></div></section></main>;
}
