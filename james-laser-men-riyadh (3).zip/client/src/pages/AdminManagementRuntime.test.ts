import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

type QueryState = { isLoading: boolean; isError: boolean; data: any; refetch: () => void };
const state = vi.hoisted(() => ({
  machines: {} as QueryState,
  waiting: {} as QueryState,
  appointments: {} as QueryState,
  settings: {} as QueryState,
  notifications: {} as QueryState,
  staff: {} as QueryState,
  media: {} as QueryState,
  policies: {} as QueryState,
  seo: {} as QueryState,
  activity: {} as QueryState,
}));

const query = (data: any = []) => ({ isLoading: false, isError: false, data, refetch: vi.fn() });

vi.mock("@/contexts/AdminLocaleContext", () => ({
  useAdminLocale: () => ({ locale: "en", isArabic: false, setLocale: vi.fn() }),
  translateAdminText: (value: string) => value,
  adminShellCopy: { en: {}, ar: {} },
  localizeAdminGroup: (value: string) => value,
  localizeAdminLabel: (value: string) => value,
}));

vi.mock("wouter", () => ({ useLocation: () => ["/admin/appointments", vi.fn()] }));

vi.mock("@/lib/trpc", () => {
  const useMutation = () => ({ mutate: vi.fn(), isPending: false, variables: undefined });
  return { trpc: {
    useUtils: () => ({
      admin: { machines: { invalidate: vi.fn() }, notifications: { invalidate: vi.fn() }, waitingList: { invalidate: vi.fn() }, dashboard: { invalidate: vi.fn() }, appointments: { invalidate: vi.fn() }, appointmentWhatsAppStatus: { invalidate: vi.fn() } },
      whatsapp: { automationWorkspace: { invalidate: vi.fn() } },
      cms: { staffUsers: { invalidate: vi.fn() }, mediaItems: { invalidate: vi.fn() }, policies: { invalidate: vi.fn() }, seoSettings: { invalidate: vi.fn() }, settingsControl: { invalidate: vi.fn() }, settingsChangeAudit: { invalidate: vi.fn() }, clinicSettings: { invalidate: vi.fn() } },
      publicContent: { clinicSettings: { invalidate: vi.fn() } },
    }),
    admin: {
      machines: { useQuery: () => state.machines },
      updateMachineNumber: { useMutation },
      waitingList: { useQuery: () => state.waiting },
      markAttendance: { useMutation },
      appointments: { useQuery: () => state.appointments },
      appointmentWhatsAppStatus: { useQuery: () => query({ providerConfigured: false, automationEnabled: false, appointment: { whatsappConsentStatus: "unknown", whatsappAutomationVersion: 1 }, jobs: [] }) },
      recordManualWhatsAppLaunch: { useMutation },
      notifications: { useQuery: () => state.notifications },
      markNotificationRead: { useMutation },
      markAllNotificationsRead: { useMutation },
    },
    whatsapp: { queueAutomationJob: { useMutation }, settings: { useQuery: () => query(null) } },
    cms: {
      staffUsers: { useQuery: () => state.staff },
      clinicSettings: { useQuery: () => state.settings },
      updateClinicSettings: { useMutation },
      settingsControl: { useQuery: () => state.settings },
      updateSettingsControl: { useMutation },
      settingsChangeAudit: { useQuery: () => query([]) },
      updateStaffRole: { useMutation },
      mediaItems: { useQuery: () => state.media },
      policies: { useQuery: () => state.policies },
      seoSettings: { useQuery: () => state.seo },
      recentActivity: { useQuery: () => state.activity },
      uploadMedia: { useMutation },
      updateMediaItem: { useMutation },
      deleteMediaItem: { useMutation },
      savePolicy: { useMutation },
      saveSeoSettings: { useMutation },
    },
  } };
});

import { Appointments, Machines, WaitingList } from "./AdminPortal";
import { AppointmentSettings, Library, Notifications, Security } from "./CmsManager";

const render = (component: React.ReactElement) => renderToStaticMarkup(component);

beforeEach(() => {
  state.machines = query([]);
  state.waiting = query([]);
  state.appointments = query([]);
  state.settings = query({ availableDays: null, preferredTimes: null, appointmentTreatmentOptions: null, visitTypeOptions: null, defaultLanguage: "en", maintenanceMode: false, appointmentFormEnabled: true });
  state.notifications = query([]);
  state.staff = query([]);
  state.media = query([]);
  state.policies = query([]);
  state.seo = query([]);
  state.activity = query([]);
});

describe("machines runtime states", () => {
  it("renders loading, error, empty, and loaded branches", () => {
    state.machines = { ...query(), isLoading: true };
    expect(render(React.createElement(Machines))).toContain("Loading machine records");
    state.machines = { ...query(), isError: true };
    expect(render(React.createElement(Machines))).toContain("Machines unavailable");
    state.machines = query([]);
    expect(render(React.createElement(Machines))).toContain("No machine records");
    state.machines = query([{ id: 1, name: "Clinic device A", machineNumber: "JL-M-001" }]);
    const loaded = render(React.createElement(Machines));
    expect(loaded).toContain("Clinic device A");
    expect(loaded).toContain("Save ID");
  });
});

describe("waiting-list runtime states", () => {
  it("renders loading, error, empty, and confirmed appointment branches", () => {
    state.waiting = { ...query(), isLoading: true };
    expect(render(React.createElement(WaitingList))).toContain("Loading waiting list");
    state.waiting = { ...query(), isError: true };
    expect(render(React.createElement(WaitingList))).toContain("Waiting list unavailable");
    state.waiting = query([]);
    expect(render(React.createElement(WaitingList))).toContain("No appointments in today’s record");
    state.waiting = query([{ id: 1, appointmentDate: "2026-09-07", appointmentTime: "13:00", patientName: "Protected patient", status: "confirmed", treatmentArea: "Recorded area", machine: "Clinic device A", whatsapp: null }]);
    const loaded = render(React.createElement(WaitingList));
    expect(loaded).toContain("Protected patient");
    expect(loaded).toContain("Arrival &amp; notes");
    expect(loaded).toContain("Mark waiting");
  });
});

describe("appointments runtime states", () => {
  it("renders loading, error, selected-date empty, confirmed HMS, and machine-warning branches", () => {
    state.appointments = { ...query(), isLoading: true };
    expect(render(React.createElement(Appointments))).toContain("Today · confirmed appointments");
    state.appointments = { ...query(), isError: true };
    expect(render(React.createElement(Appointments))).toContain("Appointments could not be loaded");
    state.appointments = query([]);
    expect(render(React.createElement(Appointments))).toContain("No appointments for selected date");
    const appointmentDate = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Riyadh", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
    state.appointments = query([
      { id: 2, appointmentDate, appointmentTime: "14:00", appointmentEndTime: "14:15", patientName: "Protected appointment", status: "confirmed", source: "hms_csv", importFingerprint: "source-a", machine: "DEKA AGAIN" },
      { id: 5, appointmentDate, appointmentTime: "15:00", appointmentEndTime: "15:15", patientName: "Machine review appointment", status: "confirmed", source: "hms_csv", importFingerprint: "source-c", machine: null },
      { id: 3, appointmentDate, appointmentTime: "13:00", appointmentEndTime: null, patientName: "Manual record", status: "confirmed", source: "manual_admin", importFingerprint: null, machine: "CLARITY 2" },
      { id: 4, appointmentDate, appointmentTime: "12:00", appointmentEndTime: null, patientName: "Cancelled HMS record", status: "cancelled", source: "hms_csv", importFingerprint: "source-b", machine: "GENTLE PROMAX" },
    ]);
    const loaded = render(React.createElement(Appointments));
    expect(loaded).toContain("Protected appointment");
    expect(loaded).toContain("Confirmed");
    expect(loaded).toContain("DEKA AGAIN");
    expect(loaded).toContain("Machine review appointment");
    expect(loaded).toContain("Machine review required");
    expect(loaded).toContain("1 machine review");
    expect(loaded).not.toContain("Manual record");
    expect(loaded).not.toContain("Cancelled HMS record");
  });
});

describe("appointment settings runtime states", () => {
  it("renders loading, error, and loaded configuration branches", () => {
    state.settings = { ...query(), isLoading: true };
    expect(render(React.createElement(AppointmentSettings))).toContain("Loading settings control centre");
    state.settings = { ...query(), isError: true };
    expect(render(React.createElement(AppointmentSettings))).toContain("Settings unavailable");
    state.settings = query({ availableDays: null, preferredTimes: null, appointmentTreatmentOptions: null, visitTypeOptions: null, defaultLanguage: "en", maintenanceMode: false, appointmentFormEnabled: true });
    const loaded = render(React.createElement(AppointmentSettings));
    expect(loaded).toContain("Available request days");
    expect(loaded).toContain("Save appointment settings");
  });
});

describe("notifications runtime states", () => {
  it("renders loading, error, empty, and loaded branches", () => {
    state.notifications = { ...query(), isLoading: true };
    expect(render(React.createElement(Notifications))).toContain("Loading staff notifications");
    state.notifications = { ...query(), isError: true };
    expect(render(React.createElement(Notifications))).toContain("Notifications unavailable");
    state.notifications = query([]);
    expect(render(React.createElement(Notifications))).toContain("No staff notifications yet");
    state.notifications = query([{ id: 1, isRead: false, title: "Protected alert", message: "Open the protected workspace.", createdAt: new Date("2026-09-01T12:00:00Z"), linkPath: "/admin/requests" }]);
    const loaded = render(React.createElement(Notifications));
    expect(loaded).toContain("Protected alert");
    expect(loaded).toContain("Mark read");
  });
});

describe("staff security runtime states", () => {
  it("renders loading, error, empty, and loaded owner-role branches", () => {
    state.staff = { ...query(), isLoading: true };
    expect(render(React.createElement(Security))).toContain("Loading staff accounts");
    state.staff = { ...query(), isError: true };
    expect(render(React.createElement(Security))).toContain("Staff security unavailable");
    state.staff = query([]);
    expect(render(React.createElement(Security))).toContain("No staff accounts available");
    state.staff = query([{ id: 1, name: "Authorized owner", email: "owner@example.invalid", lastSignedIn: new Date("2026-09-01T12:00:00Z"), role: "owner" }]);
    const loaded = render(React.createElement(Security));
    expect(loaded).toContain("Authorized owner");
    expect(loaded).toContain("Owner");
    expect(loaded).toContain("disabled");
  });
});

describe("CMS library runtime states", () => {
  it.each([
    ["activity", "activity", [{ id: 1, action: "Protected action", actorName: "Clinic owner", createdAt: new Date("2026-09-01T12:00:00Z") }], "Protected action"],
    ["seo", "seo", [{ id: 1, locale: "en", title: "Verified SEO title" }], "Verified SEO title"],
    ["languages", "seo", [{ id: 1, locale: "ar-SA", title: "عنوان عربي معتمد" }], "عنوان عربي معتمد"],
    ["media", "media", [{ id: 1, fileName: "clinic-image.webp", altEn: "Clinic room", altAr: null, mimeType: "image/webp", url: "/protected-media" }], "clinic-image.webp"],
    ["policies", "policies", [{ id: 1, titleEn: "Privacy Policy", status: "draft" }], "Privacy Policy"],
  ] as const)("renders loading, error, empty, and loaded %s branches", (page, key, records, expected) => {
    state[key] = { ...query(), isLoading: true };
    expect(render(React.createElement(Library, { page }))).toContain("Loading");
    state[key] = { ...query(), isError: true };
    expect(render(React.createElement(Library, { page }))).toContain("unavailable");
    state[key] = query([]);
    expect(render(React.createElement(Library, { page }))).toContain("No records exist yet");
    state[key] = query(records);
    expect(render(React.createElement(Library, { page }))).toContain(expected);
  });
});
