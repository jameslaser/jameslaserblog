import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("Admin Appointments HMS import interface", () => {
  it("keeps upload inside Appointments with source verification and automatic list synchronization", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/AdminPortal.tsx"), "utf8");
    expect(source).toContain("Upload & sync HMS appointments");
    expect(source).toContain("trpc.admin.hmsPreview.useMutation");
    expect(source).toContain("Syncing automatically");
    expect(source).toContain("trpc.admin.hmsImport.useMutation");
    expect(source).toContain("utils.admin.appointments.invalidate()");
    expect(source).toContain("preview.providerVerifiedFromSource");
    expect(source).toContain("Provider verified from the HMS source");
    expect(source).toContain("No fuzzy, provider-less, or unknown provider is accepted");
    expect(source).toContain("ERROR and DUPLICATE rows are always excluded");
    expect(source).toContain("automatically refreshes today’s list");
    expect(source).toContain("matching MRN, normalized phone number, appointment date, and time");
    expect(source).not.toContain("providerAttested");
    expect(source).not.toContain("trpc.admin.approveRequest.useMutation({ csvText");
  });
});
