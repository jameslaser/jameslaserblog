import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const source = readFileSync(resolve(process.cwd(), "client/src/pages/CmsManager.tsx"), "utf8");

describe("CMS bilingual privacy policy editor", () => {
  it("loads the existing privacy-policy record with Arabic fields", () => {
    expect(source).toContain('item.slug === "privacy-policy"');
    expect(source).toContain("titleAr: existing.titleAr ?? \"\"");
    expect(source).toContain("contentAr: existing.contentAr ?? \"\"");
  });

  it("submits both language fields and preserves the publish state", () => {
    expect(source).toContain("titleAr: blankToNull(policyForm.titleAr)");
    expect(source).toContain("contentAr: blankToNull(policyForm.contentAr)");
    expect(source).toContain("status: policyForm.status");
    expect(source).toContain('option value="published">Publish</option>');
  });
});
