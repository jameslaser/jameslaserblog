import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const portal = readFileSync(resolve(process.cwd(), "client/src/pages/AdminPortal.tsx"), "utf8");
const requests = readFileSync(resolve(process.cwd(), "client/src/pages/AdminRequestsWorkspace.tsx"), "utf8");
const sessionFollowUps = readFileSync(resolve(process.cwd(), "client/src/pages/SessionFollowUpWorkspaces.tsx"), "utf8");
const app = readFileSync(resolve(process.cwd(), "client/src/App.tsx"), "utf8");

describe("Admin Portal workflow extensions", () => {
  it("keeps patient and HMS appointment editing protected", () => {
    expect(portal).toContain("Edit appointment");
    expect(portal).toContain("AppointmentEditPanel");
    expect(portal).toContain('onClick={onEdit} className="font-display');
    expect(portal).toContain("Protected patient edit");
    expect(portal).toContain("Protected appointment edit");
    expect(portal).toContain("selectedDateName");
    expect(portal).toContain("confirmed appointments");
  });

  it("supports selecting all applicable treatment areas", () => {
    expect(portal).toContain("select all that apply");
    expect(portal).toContain("treatmentAreas.length > 0");
    expect(portal).toContain("onChange={treatmentAreas => update({ treatmentAreas");
    expect(requests).toContain("select all that apply");
  });

  it("registers protected, connected Sessions and Follow-Ups workspaces", () => {
    expect(app).toContain('/admin/sessions');
    expect(app).toContain('/admin/follow-ups');
    expect(app).toContain('/admin/reminders');
    expect(portal).toContain('label: "Sessions"');
    expect(portal).toContain('label: "Follow-Ups"');
    expect(portal).toContain("<SessionsWorkspace />");
    expect(portal).toContain("<FollowUpsWorkspace />");
    expect(sessionFollowUps).toContain("trpc.admin.saveSessionRecord.useMutation");
    expect(sessionFollowUps).toContain("trpc.admin.updateFollowUp.useMutation");
    expect(sessionFollowUps).toContain("trpc.admin.trackLegacyFollowUp.useMutation");
    expect(sessionFollowUps).toContain("printTable(\"Session history\"");
    expect(sessionFollowUps).toContain("printTable(\"Follow-up queue\"");
  });

  it("keeps request editing separate from immutable consent evidence", () => {
    expect(requests).toContain('onClick={() => setExpandedId(open ? null : request.id)}');
    expect(requests).toContain("Editable request details");
    expect(requests).toContain("Original consent evidence and audit fields are retained unchanged.");
    expect(requests).toContain("trpc.admin.updateRequestDetails.useMutation");
  });
});
