// @vitest-environment jsdom
import { cleanup, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { createElement } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { AdminLocaleProvider } from "@/contexts/AdminLocaleContext";

const mocks = vi.hoisted(() => ({
  queryInputs: [] as Array<{ dateFrom?: string; dateTo?: string }>,
  invalidate: vi.fn(),
  preview: null as any,
}));

const revenueData = {
  rows: [{ id: 1 }],
  patients: [],
  services: [],
  daily: [],
  batches: [],
  summary: { gross: 1_000, quantity: 1, discount: 0, deduct: 0, net: 1_000 },
  monthlySummary: [
    { month: "2026-09", totalIncome: 1_000 },
    { month: "2026-08", totalIncome: 10_000 },
    { month: "2026-06", totalIncome: 100_000 },
  ],
};

vi.mock("@/lib/trpc", () => ({
  trpc: {
    admin: {
      revenuePreview: {
        useMutation: () => ({
          mutate: vi.fn(),
          isPending: false,
          reset: vi.fn(),
          data: mocks.preview,
        }),
      },
      revenueImport: {
        useMutation: () => ({ mutate: vi.fn(), isPending: false }),
      },
      revenueWorkspace: {
        useQuery: (input: { dateFrom?: string; dateTo?: string }) => {
          mocks.queryInputs.push(input);
          return { data: revenueData, isLoading: false, isError: false };
        },
      },
      revenueBatch: { useQuery: () => ({ data: null, isLoading: false }) },
    },
    useUtils: () => ({
      admin: {
        revenueWorkspace: { invalidate: mocks.invalidate },
        dashboard: { invalidate: mocks.invalidate },
      },
    }),
  },
}));

import {
  buildPaymentDifferencesSupportSummary,
  copyPaymentDifferencesSummary,
  RevenueWorkspace,
} from "./RevenueWorkspace";

function renderRevenue() {
  return render(
    createElement(AdminLocaleProvider, null, createElement(RevenueWorkspace))
  );
}

describe("RevenueWorkspace monthly commission experience", () => {
  beforeEach(() => {
    cleanup();
    localStorage.clear();
    mocks.queryInputs.length = 0;
    mocks.invalidate.mockReset();
    mocks.preview = null;
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it("prioritizes the exact commission and updates the protected calendar-month query", async () => {
    const user = userEvent.setup();
    renderRevenue();

    expect(screen.getAllByText("SAR 22.50").length).toBeGreaterThan(0);
    expect(
      screen.getAllByText("3% of commissionable income").length
    ).toBeGreaterThan(0);
    expect(
      screen.getByText("See exactly how the commission is calculated")
    ).toBeTruthy();
    expect(screen.getByText("Commission history")).toBeTruthy();
    expect(screen.getByText("Upload, review, then import")).toBeTruthy();
    expect(screen.getByText("Upload HMS CSV")).toBeTruthy();
    expect(screen.getByText("Review details")).toBeTruthy();
    const sourceRecords = screen
      .getByText("Reporting detail and import history")
      .closest("details") as HTMLDetailsElement;
    expect(sourceRecords.open).toBe(false);

    await user.selectOptions(
      screen.getByLabelText("Select revenue month"),
      "2026-08"
    );
    expect(mocks.queryInputs.at(-1)).toEqual({
      dateFrom: "2026-08-01",
      dateTo: "2026-08-31",
    });

    await user.click(screen.getByText("Open reports"));
    expect(sourceRecords.open).toBe(true);
  });

  it("uses Arabic direction and localized commission content when Arabic is selected", async () => {
    localStorage.setItem("james-laser-admin-locale", "ar");
    renderRevenue();

    expect(document.documentElement.dir).toBe("rtl");
    expect(await screen.findByText("العمولة الشهرية")).toBeTruthy();
    expect(await screen.findByText("عمولة الممرض جيمس")).toBeTruthy();
    expect(screen.getByRole("combobox").textContent).toMatch(/[٠-٩]/);
  });

  it("prioritizes red payment amounts while retaining MRN-led audit evidence", () => {
    mocks.preview = {
      fromDate: "2026-09-01",
      toDate: "2026-09-19",
      account: null,
      printDate: "02/12/2015 10:53:49",
      fileAlreadyImported: false,
      fatalErrors: [
        "HMS SUBTOTAL RECONCILIATION FAILED: 1 patient subtotal does not match its service rows.",
        "HMS TOTAL RECONCILIATION FAILED: service-row totals do not equal the HMS Grand Total.",
      ],
      reconciliationDifferences: [
        {
          scope: "PATIENT_SUBTOTAL",
          sourceRowNumber: 14,
          mrn: "1001",
          reported: {
            gross: 200,
            quantity: 1,
            discount: 110,
            deduct: 0,
            net: 90,
          },
          calculated: {
            gross: 200,
            quantity: 1,
            discount: 100,
            deduct: 0,
            net: 100,
          },
          differences: { discount: -10, net: 10 },
        },
        {
          scope: "GRAND_TOTAL",
          sourceRowNumber: 20,
          mrn: null,
          reported: {
            gross: 200,
            quantity: 1,
            discount: 105,
            deduct: 0,
            net: 95,
          },
          calculated: {
            gross: 200,
            quantity: 1,
            discount: 100,
            deduct: 0,
            net: 100,
          },
          differences: { discount: -5, net: 5 },
        },
      ],
      mrnDuplicateEntries: [
        {
          mrn: "1001",
          sourceRowNumbers: [8, 9],
          serviceCode: "CLT02",
          serviceName: "Clarity Any Small Area",
          totals: {
            gross: 200,
            quantity: 1,
            discount: 100,
            deduct: 0,
            net: 100,
          },
        },
      ],
      rows: [],
      summary: {
        gross: 200,
        quantity: 1,
        discount: 100,
        deduct: 0,
        net: 100,
        patients: 1,
        serviceRows: 2,
        invalidRows: 0,
        duplicateRows: 0,
        warnings: 0,
        unmatchedPatients: 0,
        reconciliation: "FAIL",
      },
    };

    renderRevenue();

    expect(screen.getByText("Payment amount differences")).toBeTruthy();
    expect(
      screen.getByText("Net payment amounts do not match — import paused")
    ).toBeTruthy();
    expect(screen.getByText("Patient payment total · MRN 1001")).toBeTruthy();
    expect(screen.getByText("Total payment amount")).toBeTruthy();
    expect(screen.getAllByText("Net payment (priority)")).toHaveLength(2);
    expect(screen.getByText("MRN-led double-entry review")).toBeTruthy();
    expect(screen.getByText(/source rows 8, 9/)).toBeTruthy();
    expect(
      screen.getByText(
        "Patient payment total mismatch — check the red MRN payment amount(s)."
      )
    ).toBeTruthy();
    expect(
      screen.getByText(
        "Total payment mismatch — check the red Total payment amount."
      )
    ).toBeTruthy();
    expect(
      screen.getByText(
        "Step 3 is locked until reconciliation passes, no duplicate or invalid rows remain, and any warnings are acknowledged."
      )
    ).toBeTruthy();
    expect(
      screen.getByText(
        "Payment amounts do not match HMS. Import is paused until the red Net payment amounts and audit checks agree."
      )
    ).toBeTruthy();
  });

  it("copies a payment-only HMS support summary without patient names", async () => {
    const clipboardWrite = vi.fn().mockResolvedValue(undefined);
    mocks.preview = {
      fromDate: "2026-09-01",
      toDate: "2026-09-19",
      account: null,
      printDate: "02/12/2015 10:53:49",
      fileAlreadyImported: false,
      fatalErrors: [
        "HMS SUBTOTAL RECONCILIATION FAILED: 1 patient subtotal does not match its service rows.",
      ],
      reconciliationDifferences: [
        {
          scope: "PATIENT_SUBTOTAL",
          sourceRowNumber: 14,
          mrn: "1001",
          reported: {
            gross: 200,
            quantity: 1,
            discount: 110,
            deduct: 0,
            net: 90,
          },
          calculated: {
            gross: 200,
            quantity: 1,
            discount: 100,
            deduct: 0,
            net: 100,
          },
          differences: { discount: -10, net: 10 },
        },
      ],
      mrnDuplicateEntries: [
        {
          mrn: "1001",
          sourceRowNumbers: [8, 9],
          serviceCode: "CLT02",
          serviceName: "Clarity Any Small Area",
          totals: {
            gross: 200,
            quantity: 1,
            discount: 100,
            deduct: 0,
            net: 100,
          },
        },
      ],
      rows: [],
      summary: {
        gross: 200,
        quantity: 1,
        discount: 100,
        deduct: 0,
        net: 100,
        patients: 1,
        serviceRows: 2,
        invalidRows: 0,
        duplicateRows: 0,
        warnings: 0,
        unmatchedPatients: 0,
        reconciliation: "FAIL",
      },
    };

    renderRevenue();

    expect(
      screen.getByRole("button", { name: "Copy payment differences" })
    ).toBeTruthy();
    const summary = buildPaymentDifferencesSupportSummary({
      fromDate: mocks.preview.fromDate,
      toDate: mocks.preview.toDate,
      printDate: mocks.preview.printDate,
      reconciliationDifferences: mocks.preview.reconciliationDifferences,
      mrnDuplicateEntries: mocks.preview.mrnDuplicateEntries,
    });
    await copyPaymentDifferencesSummary(summary, {
      writeText: clipboardWrite,
    } as Pick<Clipboard, "writeText">);
    expect(clipboardWrite).toHaveBeenCalledTimes(1);
    const copied = clipboardWrite.mock.calls[0]?.[0] as string;
    expect(copied).toContain("HMS payment reconciliation summary");
    expect(copied).toContain("MRN 1001");
    expect(copied).toContain(
      "Net payment (priority): HMS SAR 90.00 | Service SAR 100.00 | Difference +SAR 10.00"
    );
    expect(copied).toContain(
      "Requested action: correct the source record in HMS"
    );
    expect(copied).not.toContain("Clarity Any Small Area");
  });

  it("builds a support summary without clinical or patient-name fields", () => {
    const summary = buildPaymentDifferencesSupportSummary({
      fromDate: "2026-09-01",
      toDate: "2026-09-19",
      printDate: "02/12/2015 10:53:49",
      reconciliationDifferences: [
        {
          scope: "GRAND_TOTAL",
          sourceRowNumber: 20,
          mrn: null,
          reported: {
            gross: 200,
            quantity: 1,
            discount: 105,
            deduct: 0,
            net: 95,
          },
          calculated: {
            gross: 200,
            quantity: 1,
            discount: 100,
            deduct: 0,
            net: 100,
          },
          differences: { discount: -5, net: 5 },
        },
      ],
      mrnDuplicateEntries: [],
    });

    expect(summary).toContain("Total payment amount | HMS report row 20");
    expect(summary).toContain(
      "Patient names, contact details, and clinical information are not included."
    );
    expect(summary).not.toContain("Patient Name");
    expect(summary).not.toContain("Clarity Any Small Area");
  });
});
