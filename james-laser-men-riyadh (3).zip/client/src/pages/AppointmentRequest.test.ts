import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it, vi } from "vitest";
import { AppointmentSubmissionSuccess } from "./AppointmentRequest";

describe("AppointmentSubmissionSuccess", () => {
  it("renders the English availability-only confirmation with a safe request reference", () => {
    const html = renderToStaticMarkup(createElement(AppointmentSubmissionSuccess, { locale: "en", requestId: "JR-2099-000007", clinicWhatsapp: "966557401562", customerSummary: "safe-summary", onReturnHome: vi.fn() }));

    expect(html).toContain("Request Received");
    expect(html).toContain("JR-2099-000007");
    expect(html).toContain("not yet confirmed");
    expect(html).toContain("Contact via WhatsApp");
    expect(html).not.toContain("Ahmad Khalid");
  });

  it("renders the Arabic confirmation and optional WhatsApp follow-up without customer details", () => {
    const html = renderToStaticMarkup(createElement(AppointmentSubmissionSuccess, { locale: "ar", requestId: "JR-2099-000008", clinicWhatsapp: "966557401562", customerSummary: "safe-summary", onReturnHome: vi.fn() }));

    expect(html).toContain("تم استلام الطلب");
    expect(html).toContain("JR-2099-000008");
    expect(html).toContain("غير مؤكدين");
    expect(html).toContain("التواصل عبر واتساب");
    expect(html).not.toContain("Ahmad Khalid");
  });

  it("marks the private confirmation state noindex while preserving the public form state on reset", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/AppointmentRequest.tsx"), "utf8");
    expect(source).toContain('meta.setAttribute("content", "noindex, nofollow, noarchive")');
    expect(source).toContain('meta.setAttribute("content", "index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1")');
  });

  it("keeps the production failure path localized, recoverable, and state-preserving", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/AppointmentRequest.tsx"), "utf8");
    const onErrorHandler = source.slice(source.indexOf("onError:"), source.indexOf("const clinicWhatsapp"));

    expect(source).toContain("retrySubmission");
    expect(source).toContain("{t.retry}");
    expect(source).toContain("{t.whatsapp}");
    expect(onErrorHandler).toContain("setClientError(appointmentSubmissionError(locale, error))");
    expect(onErrorHandler).not.toContain("setFullName");
    expect(onErrorHandler).not.toContain("setWhatsapp");
    expect(onErrorHandler).not.toContain("setSelectedAreas");
  });

  it("requires complete in-form consent review and electronic signature before submission", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/AppointmentRequest.tsx"), "utf8");
    const consentSource = readFileSync(resolve(process.cwd(), "client/src/components/AppointmentConsentWorkflow.tsx"), "utf8");

    expect(source).toContain("AppointmentConsentWorkflow");
    expect(source).toContain("originalConsentAcknowledgement: true");
    expect(source).toContain("informationAccuracyAcknowledgement: true");
    expect(source).toContain("signatureDataUrl");
    expect(consentSource).toContain("ORIGINAL_CONSENT_DOCUMENTS");
    expect(consentSource).toContain("appointment-consent-reader");
    expect(consentSource).toContain("onScroll={handleConsentScroll}");
    expect(consentSource).toContain("<iframe");
    expect(consentSource).toContain('canvas.toDataURL("image/png")');
  });

  it("keeps the health-screening acknowledgement separate from treatment consent", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/AppointmentRequest.tsx"), "utf8");
    expect(source).toContain("healthScreeningConsent: true");
    expect(source).toContain("This is not consent to treatment.");
    expect(source).toContain('"/privacy-rights"');
  });
});
