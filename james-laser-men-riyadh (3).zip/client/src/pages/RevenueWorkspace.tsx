import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertTriangle,
  ArrowDown,
  Calculator,
  CalendarDays,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Copy,
  FileSpreadsheet,
  Loader2,
  ShieldCheck,
  Upload,
  WalletCards,
  XCircle,
} from "lucide-react";
import React, { useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { AdminMetricCard, AdminPageHeader } from "@/components/AdminUi";
import {
  translateAdminText,
  useAdminLocale,
} from "@/contexts/AdminLocaleContext";

const riyadhDate = (date = new Date()) =>
  new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Riyadh",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(date);
const formatSar = (value: number | string | null | undefined) =>
  `SAR ${Number(value ?? 0).toLocaleString("en-SA", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const formatQty = (value: number | string | null | undefined) =>
  Number(value ?? 0).toLocaleString("en-SA", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 3,
  });
const formatDifference = (field: string, value: number | string) => {
  const numeric = Number(value ?? 0);
  const sign = numeric > 0 ? "+" : "";
  const formatted =
    field === "quantity" ? formatQty(numeric) : formatSar(numeric);
  return `${sign}${formatted}`;
};
const formatDate = (value: string | null | undefined) =>
  value
    ? new Date(`${value}T12:00:00Z`).toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      })
    : "—";

type Money = {
  gross: number;
  quantity: number;
  discount: number;
  deduct: number;
  net: number;
};

function MoneyLine({
  totals,
  compact = false,
}: {
  totals: Money;
  compact?: boolean;
}) {
  return (
    <div
      className={`grid gap-x-4 gap-y-2 text-sm ${compact ? "grid-cols-2 sm:grid-cols-5" : "grid-cols-2 sm:grid-cols-5"}`}
    >
      <div>
        <span className="text-[#66727A]">Gross</span>
        <strong className="mt-0.5 block text-[#102032]">
          {formatSar(totals.gross)}
        </strong>
      </div>
      <div>
        <span className="text-[#66727A]">Qty</span>
        <strong className="mt-0.5 block text-[#102032]">
          {formatQty(totals.quantity)}
        </strong>
      </div>
      <div>
        <span className="text-[#66727A]">Discount</span>
        <strong className="mt-0.5 block text-[#102032]">
          {formatSar(totals.discount)}
        </strong>
      </div>
      <div>
        <span className="text-[#66727A]">Deduct</span>
        <strong className="mt-0.5 block text-[#102032]">
          {formatSar(totals.deduct)}
        </strong>
      </div>
      <div>
        <span className="text-[#a85438]">Net</span>
        <strong className="mt-0.5 block text-[#a85438]">
          {formatSar(totals.net)}
        </strong>
      </div>
    </div>
  );
}

const reconciliationLabels: Record<string, string> = {
  gross: "Gross amount",
  quantity: "Quantity (audit check)",
  discount: "Discount amount",
  deduct: "Deduct amount",
  net: "Net payment (priority)",
};

const reconciliationPriority: Record<string, number> = {
  net: 0,
  gross: 1,
  discount: 2,
  deduct: 3,
  quantity: 4,
};

function paymentFirstDifferences(differences: Record<string, unknown>) {
  return Object.entries(differences).sort(
    ([first], [second]) =>
      (reconciliationPriority[first] ?? 99) -
      (reconciliationPriority[second] ?? 99)
  );
}

function simplifyRevenueImportError(error: string) {
  if (error.startsWith("HMS SUBTOTAL RECONCILIATION FAILED")) {
    return "Patient payment total mismatch — check the red MRN payment amount(s).";
  }
  if (error.startsWith("HMS TOTAL RECONCILIATION FAILED")) {
    return "Total payment mismatch — check the red Total payment amount.";
  }
  return error;
}

type PaymentDifferenceRecord = {
  scope: string;
  sourceRowNumber: number;
  mrn: string | null;
  reported: Record<string, number | string | null | undefined>;
  calculated: Record<string, number | string | null | undefined>;
  differences: Record<string, number | string>;
};

type MrnDuplicateEntry = {
  mrn: string | null;
  sourceRowNumbers: number[];
  serviceCode: string;
  totals: Money;
};

type PaymentDifferencesSupportSource = {
  fromDate?: string | null;
  toDate?: string | null;
  printDate?: string | null;
  reconciliationDifferences: PaymentDifferenceRecord[];
  mrnDuplicateEntries: MrnDuplicateEntry[];
};

function summaryValue(
  field: string,
  value: number | string | null | undefined
) {
  return field === "quantity" ? formatQty(value) : formatSar(value);
}

function supportDifferenceScope(item: PaymentDifferenceRecord) {
  return item.scope === "GRAND_TOTAL"
    ? "Total payment amount"
    : `Patient payment total · MRN ${item.mrn || "not supplied"}`;
}

/** Shares only reconciliation evidence needed by HMS support—never patient names or contact details. */
export function buildPaymentDifferencesSupportSummary({
  fromDate,
  toDate,
  printDate,
  reconciliationDifferences,
  mrnDuplicateEntries,
}: PaymentDifferencesSupportSource) {
  const lines = [
    "HMS payment reconciliation summary",
    "Status: import paused — payment totals do not match.",
    `Report period: ${fromDate || "not detected"} to ${toDate || "not detected"}`,
    ...(printDate ? [`HMS Print Date: ${printDate}`] : []),
    "Calculation: service total minus HMS total.",
    "Patient names, contact details, and clinical information are not included.",
    "",
    "Payment differences:",
  ];

  reconciliationDifferences.forEach((item, index) => {
    lines.push(
      `${index + 1}. ${supportDifferenceScope(item)} | HMS report row ${item.sourceRowNumber}`
    );
    paymentFirstDifferences(item.differences).forEach(([field, difference]) => {
      const label = reconciliationLabels[field] || field;
      lines.push(
        `   - ${label}: HMS ${summaryValue(field, item.reported[field])} | Service ${summaryValue(field, item.calculated[field])} | Difference ${formatDifference(field, difference as number)}`
      );
    });
  });

  if (mrnDuplicateEntries.length) {
    lines.push("", "MRN duplicate review:");
    mrnDuplicateEntries.forEach(item => {
      lines.push(
        `- MRN ${item.mrn || "not supplied"} | Service ${item.serviceCode || "not supplied"} | HMS report rows ${item.sourceRowNumbers.join(", ")} | Net payment ${formatSar(item.totals.net)} each`
      );
    });
  }

  lines.push(
    "",
    "Requested action: correct the source record in HMS, export a new Detail Revenue By Patient CSV, then upload it again."
  );
  return lines.join("\n");
}

export async function copyPaymentDifferencesSummary(
  value: string,
  clipboard?: Pick<Clipboard, "writeText"> | null
) {
  const browserClipboard =
    clipboard ??
    (typeof navigator !== "undefined" ? navigator.clipboard : undefined);
  if (browserClipboard?.writeText) {
    await browserClipboard.writeText(value);
    return true;
  }
  if (typeof document === "undefined") return false;
  const textarea = document.createElement("textarea");
  textarea.value = value;
  textarea.setAttribute("readonly", "");
  textarea.style.position = "fixed";
  textarea.style.opacity = "0";
  document.body.appendChild(textarea);
  textarea.select();
  const copied = document.execCommand("copy");
  textarea.remove();
  return copied;
}

function ReconciliationDifferences({
  differences,
  mrnDuplicateEntries,
  fromDate,
  toDate,
  printDate,
}: {
  differences: PaymentDifferenceRecord[];
  mrnDuplicateEntries: MrnDuplicateEntry[];
  fromDate?: string | null;
  toDate?: string | null;
  printDate?: string | null;
}) {
  const hasDifferences = differences.length > 0;
  const hasMrnDuplicates = mrnDuplicateEntries.length > 0;
  const [isCopying, setIsCopying] = useState(false);
  const copySupportSummary = async () => {
    setIsCopying(true);
    try {
      const copied = await copyPaymentDifferencesSummary(
        buildPaymentDifferencesSupportSummary({
          fromDate,
          toDate,
          printDate,
          reconciliationDifferences: differences,
          mrnDuplicateEntries,
        })
      );
      if (!copied) throw new Error("Clipboard is unavailable");
      toast.success(
        "Payment difference summary copied. Paste it into the HMS support request."
      );
    } catch {
      toast.error(
        "Could not copy the summary. Select the payment differences and copy them manually."
      );
    } finally {
      setIsCopying(false);
    }
  };
  return (
    <section
      aria-live="polite"
      className={
        "mt-4 border p-4 sm:p-5 " +
        (hasDifferences || hasMrnDuplicates
          ? "border-red-300 bg-red-50"
          : "border-emerald-200 bg-emerald-50")
      }
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex min-w-0 items-start gap-3">
          <AlertTriangle
            className={
              "mt-0.5 size-5 shrink-0 " +
              (hasDifferences || hasMrnDuplicates
                ? "text-red-700"
                : "text-emerald-700")
            }
          />
          <div>
            <p
              className={
                "text-[10px] font-extrabold uppercase tracking-[0.16em] " +
                (hasDifferences || hasMrnDuplicates
                  ? "text-red-800"
                  : "text-emerald-800")
              }
            >
              Payment amount differences
            </p>
            <h3
              className={
                "mt-1 font-display text-xl tracking-[-0.03em] " +
                (hasDifferences || hasMrnDuplicates
                  ? "text-red-950"
                  : "text-emerald-950")
              }
            >
              {hasDifferences || hasMrnDuplicates
                ? "Net payment amounts do not match — import paused"
                : "Payment amounts and audit checks match the HMS export"}
            </h3>
            <p className="mt-1 text-sm leading-6 text-[#52606B]">
              Start with the red <strong>Net payment</strong> amount. Compare
              the HMS total with the service total, correct the amount in HMS,
              export a fresh CSV, and upload it again. The red audit fields must
              also agree before import can open. Patient names stay hidden; use
              the MRN and HMS report row to find the source record.
            </p>
          </div>
        </div>
        {hasDifferences || hasMrnDuplicates ? (
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => void copySupportSummary()}
            disabled={isCopying}
            className="border-red-300 bg-white text-red-900 hover:bg-red-100"
          >
            <Copy className="mr-2 size-3.5" aria-hidden="true" />
            {isCopying ? "Copying…" : "Copy payment differences"}
          </Button>
        ) : null}
      </div>

      {hasDifferences ? (
        <div className="mt-4 space-y-3">
          {differences.map((item, index) => (
            <article
              key={`${item.scope}-${item.sourceRowNumber}-${item.mrn ?? "grand"}-${index}`}
              className="overflow-x-auto border border-red-200 bg-white"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-red-100 bg-red-100/70 px-3 py-2 text-xs font-bold text-red-950">
                <span>
                  {item.scope === "GRAND_TOTAL"
                    ? "Total payment amount"
                    : `Patient payment total · MRN ${item.mrn || "not supplied"}`}
                </span>
                <span>HMS report row {item.sourceRowNumber}</span>
              </div>
              <table className="min-w-[600px] w-full text-left text-xs">
                <thead className="bg-red-50 text-[10px] font-extrabold uppercase tracking-[0.12em] text-red-800">
                  <tr>
                    <th className="px-3 py-2.5">Payment check</th>
                    <th className="px-3 py-2.5">HMS total</th>
                    <th className="px-3 py-2.5">Service total</th>
                    <th className="px-3 py-2.5">Amount difference</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-red-100">
                  {paymentFirstDifferences(item.differences).map(
                    ([field, difference]) => (
                      <tr
                        key={field}
                        className={field === "net" ? "bg-red-50/80" : undefined}
                      >
                        <td className="px-3 py-2.5 font-bold text-red-950">
                          {reconciliationLabels[field] || field}
                        </td>
                        <td className="px-3 py-2.5 text-[#52606B]">
                          {field === "quantity"
                            ? formatQty(item.reported[field])
                            : formatSar(item.reported[field])}
                        </td>
                        <td className="px-3 py-2.5 text-[#52606B]">
                          {field === "quantity"
                            ? formatQty(item.calculated[field])
                            : formatSar(item.calculated[field])}
                        </td>
                        <td className="px-3 py-2.5 font-extrabold text-red-700">
                          {formatDifference(field, difference as number)}
                        </td>
                      </tr>
                    )
                  )}
                </tbody>
              </table>
            </article>
          ))}
        </div>
      ) : null}

      {hasMrnDuplicates ? (
        <div className="mt-4 border border-red-200 bg-white p-3">
          <p className="text-xs font-extrabold uppercase tracking-[0.12em] text-red-800">
            MRN-led double-entry review
          </p>
          <p className="mt-1 text-xs leading-5 text-[#52606B]">
            The primary indicator is MRN. A candidate is shown only when the
            same MRN has an identical service and identical amounts more than
            once, so different services for one patient are not treated as a
            duplicate.
          </p>
          <ul className="mt-3 space-y-2 text-xs">
            {mrnDuplicateEntries.map(item => (
              <li
                key={`${item.mrn}-${item.serviceCode}-${item.sourceRowNumbers.join("-")}`}
                className="border-l-2 border-red-500 pl-3 text-red-950"
              >
                <strong>MRN {item.mrn}</strong> · {item.serviceCode} · source
                rows {item.sourceRowNumbers.join(", ")} ·{" "}
                {formatSar(item.totals.net)} net each
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </section>
  );
}

function PageHeading() {
  return (
    <AdminPageHeader
      eyebrow="Protected revenue · commission tracking"
      title="Monthly commission"
      description="A clear monthly view of the clinic’s imported HMS income and Nurse James’ commission. The 25% deduction is always applied before the 3% commission calculation."
      action={
        <div className="flex max-w-md items-start gap-2 text-xs leading-5 text-[#66727A]">
          <ShieldCheck className="mt-0.5 size-4 shrink-0 text-[#a85438]" />
          HMS remains the source of truth. Print Date is stored as source
          metadata and is never used as a revenue date.
        </div>
      }
    />
  );
}

function RevenueImportSteps({
  selected,
  preview,
  canImport,
}: {
  selected: boolean;
  preview: any;
  canImport: boolean;
}) {
  const reconciliationPassed = preview?.summary.reconciliation === "PASS";
  const steps = [
    {
      number: "1",
      title: "Upload CSV",
      note: selected ? "CSV selected" : "Choose the HMS export",
      state: selected ? "complete" : "current",
    },
    {
      number: "2",
      title: "Review details",
      note: preview
        ? reconciliationPassed
          ? "Reconciliation passed"
          : "Correct red differences"
        : selected
          ? "Parsing source rows"
          : "Preview appears after upload",
      state: preview
        ? reconciliationPassed
          ? "complete"
          : "blocked"
        : "waiting",
    },
    {
      number: "3",
      title: "Import all rows",
      note: canImport
        ? "Ready to create the batch"
        : "Locked until every check passes",
      state: canImport ? "ready" : "waiting",
    },
  ] as const;
  const stateClass = (state: (typeof steps)[number]["state"]) =>
    state === "complete" || state === "ready"
      ? "border-emerald-300 bg-emerald-50 text-emerald-800"
      : state === "blocked"
        ? "border-red-300 bg-red-50 text-red-800"
        : "border-[#102032]/15 bg-white text-[#52606B]";

  return (
    <ol
      aria-label="Revenue import steps"
      className="mt-5 grid gap-2 border-y border-[#102032]/10 py-4 sm:grid-cols-3"
    >
      {steps.map(step => (
        <li
          key={step.number}
          className={`flex items-start gap-3 border p-3 ${stateClass(step.state)}`}
        >
          <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-[#102032] text-xs font-extrabold text-white">
            {step.number}
          </span>
          <span>
            <strong className="block text-sm">{step.title}</strong>
            <span className="mt-0.5 block text-xs leading-5">{step.note}</span>
          </span>
        </li>
      ))}
    </ol>
  );
}

function RevenueImportPanel({
  onImported,
}: {
  onImported: () => Promise<void>;
}) {
  const fileInput = useRef<HTMLInputElement>(null);
  const [selected, setSelected] = useState<{
    text: string;
    fileName: string;
  } | null>(null);
  const [includeWarnings, setIncludeWarnings] = useState(false);
  const previewMutation = trpc.admin.revenuePreview.useMutation({
    onError: error => toast.error(error.message),
    onSuccess: preview =>
      toast.success(
        `Revenue preview ready: ${preview.summary.serviceRows} service rows checked. Nothing has been saved.`
      ),
  });
  const importMutation = trpc.admin.revenueImport.useMutation({
    onError: error => toast.error(error.message),
    onSuccess: async result => {
      toast.success(
        `Revenue batch ${result.batchId} imported: ${result.importedCount} service rows.`
      );
      setSelected(null);
      previewMutation.reset();
      setIncludeWarnings(false);
      await onImported();
    },
  });
  const preview = previewMutation.data;
  const canImport = Boolean(
    selected &&
      preview &&
      preview.summary.reconciliation === "PASS" &&
      !preview.fileAlreadyImported &&
      preview.mrnDuplicateEntries.length === 0 &&
      preview.summary.invalidRows === 0 &&
      preview.summary.duplicateRows === 0 &&
      (!preview.summary.warnings || includeWarnings)
  );
  const selectFile = (file: File | undefined) => {
    if (!file) return;
    if (!file.name.toLowerCase().endsWith(".csv")) {
      toast.error("Select the HMS Detail Revenue By Patient CSV file.");
      return;
    }
    if (file.size > 1_000_000) {
      toast.error("The protected preview limit is 1 MB.");
      return;
    }
    const reader = new FileReader();
    reader.onerror = () => toast.error("The selected CSV could not be read.");
    reader.onload = () => {
      const text = typeof reader.result === "string" ? reader.result : "";
      if (!text) {
        toast.error("The selected CSV is empty.");
        return;
      }
      setSelected({ text, fileName: file.name });
      previewMutation.mutate({ csvText: text, originalFileName: file.name });
    };
    reader.readAsText(file, "utf-8");
  };
  return (
    <section className="border border-[#a85438]/30 bg-[#fffaf5] p-5 shadow-sm sm:p-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="size-5 text-[#a85438]" />
            <p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">
              Governed HMS intake
            </p>
          </div>
          <h2 className="mt-2 font-display text-2xl tracking-[-0.04em] text-[#102032]">
            Upload, review, then import
          </h2>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-[#52606B]">
            Upload the Detail Revenue By Patient CSV. The preview shows the
            exact reconciliation details before the protected import becomes
            available.
          </p>
        </div>
        <Button
          variant="outline"
          onClick={() => fileInput.current?.click()}
          disabled={previewMutation.isPending}
        >
          <Upload className="mr-2 size-4" />
          {previewMutation.isPending ? "Parsing…" : "Upload HMS CSV"}
        </Button>
      </div>
      <RevenueImportSteps
        selected={Boolean(selected)}
        preview={preview}
        canImport={canImport}
      />
      <input
        ref={fileInput}
        type="file"
        accept=".csv,text/csv"
        className="hidden"
        onChange={event => {
          selectFile(event.target.files?.[0]);
          event.currentTarget.value = "";
        }}
      />
      {selected ? (
        <p className="mt-4 break-all text-xs text-[#52606B]">
          Step 1 complete — selected:{" "}
          <strong className="text-[#102032]">{selected.fileName}</strong>
        </p>
      ) : (
        <p className="mt-4 text-xs text-[#66727A]">
          CSV only · maximum 1 MB · selecting a file does not import or create
          patient data.
        </p>
      )}
      {preview ? (
        <div className="mt-5 border-t border-[#102032]/10 pt-5">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
            <div>
              <p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">
                Step 2 — Review reconciliation details
              </p>
              <p className="mt-2 text-sm text-[#52606B]">
                Report period:{" "}
                <strong className="text-[#102032]">
                  {formatDate(preview.fromDate)} → {formatDate(preview.toDate)}
                </strong>
                {preview.account ? ` · ${preview.account}` : ""}
              </p>
              <p className="mt-1 text-xs text-[#66727A]">
                Print Date retained as source metadata:{" "}
                {preview.printDate || "Not detected"}
              </p>
            </div>
            <Badge
              className={
                preview.summary.reconciliation === "PASS"
                  ? "bg-emerald-50 text-emerald-700 hover:bg-emerald-50"
                  : "bg-red-50 text-red-700 hover:bg-red-50"
              }
            >
              {preview.summary.reconciliation === "PASS"
                ? "RECONCILIATION PASS"
                : "RECONCILIATION FAILED"}
            </Badge>
          </div>
          <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <div className="border border-[#102032]/10 bg-white p-3">
              <span className="text-[10px] font-extrabold uppercase tracking-[0.13em] text-[#66727A]">
                Patients detected
              </span>
              <strong className="mt-1 block text-xl text-[#102032]">
                {preview.summary.patients}
              </strong>
            </div>
            <div className="border border-[#102032]/10 bg-white p-3">
              <span className="text-[10px] font-extrabold uppercase tracking-[0.13em] text-[#66727A]">
                Service rows
              </span>
              <strong className="mt-1 block text-xl text-[#102032]">
                {preview.summary.serviceRows}
              </strong>
            </div>
            <div className="border border-[#102032]/10 bg-white p-3">
              <span className="text-[10px] font-extrabold uppercase tracking-[0.13em] text-[#66727A]">
                Unmatched patients
              </span>
              <strong className="mt-1 block text-xl text-[#102032]">
                {preview.summary.unmatchedPatients}
              </strong>
            </div>
            <div className="border border-[#102032]/10 bg-white p-3">
              <span className="text-[10px] font-extrabold uppercase tracking-[0.13em] text-[#66727A]">
                Duplicates / invalid
              </span>
              <strong className="mt-1 block text-xl text-[#102032]">
                {preview.summary.duplicateRows} / {preview.summary.invalidRows}
              </strong>
            </div>
          </div>
          <div className="mt-4 border border-[#102032]/10 bg-white p-4">
            <MoneyLine totals={preview.summary} />
            <div className="mt-4 border-t border-[#102032]/10 pt-4">
              <p
                className={`text-sm font-bold ${preview.summary.reconciliation === "PASS" ? "text-emerald-700" : "text-red-700"}`}
              >
                {preview.summary.reconciliation === "PASS"
                  ? "Net payment amounts match HMS. The Gross, Discount, Deduct, and Quantity audit checks also agree."
                  : "Payment amounts do not match HMS. Import is paused until the red Net payment amounts and audit checks agree."}
              </p>
              {preview.fatalErrors.length ? (
                <ul className="mt-2 border-l-2 border-red-500 bg-red-50 py-2 pl-7 pr-3 text-xs leading-5 text-red-800">
                  {preview.fatalErrors.map(error => (
                    <li key={error}>{simplifyRevenueImportError(error)}</li>
                  ))}
                </ul>
              ) : null}
            </div>
          </div>
          <ReconciliationDifferences
            differences={preview.reconciliationDifferences}
            mrnDuplicateEntries={preview.mrnDuplicateEntries}
            fromDate={preview.fromDate}
            toDate={preview.toDate}
            printDate={preview.printDate}
          />
          {preview.summary.warnings > 0 ? (
            <label className="mt-4 flex items-start gap-2 text-sm text-[#52606B]">
              <input
                type="checkbox"
                checked={includeWarnings}
                onChange={event => setIncludeWarnings(event.target.checked)}
                className="mt-1 accent-[#a85438]"
              />
              <span>
                Include {preview.summary.warnings} warning row
                {preview.summary.warnings === 1 ? "" : "s"} after review. HMS
                values will be stored unchanged.
              </span>
            </label>
          ) : null}
          {preview.fileAlreadyImported ? (
            <p className="mt-4 flex items-center gap-2 text-sm font-bold text-violet-700">
              <XCircle className="size-4" />
              EXACT DUPLICATE FILE — this report was already imported.
            </p>
          ) : null}
          <div className="mt-5 flex flex-wrap gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setSelected(null);
                previewMutation.reset();
                setIncludeWarnings(false);
              }}
            >
              Cancel
            </Button>
            <Button
              disabled={!canImport || importMutation.isPending}
              onClick={() => {
                if (
                  !window.confirm(
                    `Import ${preview.summary.serviceRows} HMS revenue service rows? This will create one immutable Revenue transaction per service row and will not create patient files.`
                  )
                )
                  return;
                importMutation.mutate({
                  csvText: selected!.text,
                  originalFileName: selected!.fileName,
                  confirm: true,
                  includeWarnings: Boolean(includeWarnings),
                });
              }}
            >
              {importMutation.isPending ? (
                <Loader2 className="mr-2 size-4 animate-spin" />
              ) : (
                <CheckCircle2 className="mr-2 size-4" />
              )}
              {importMutation.isPending
                ? "Importing…"
                : "Step 3 — Import all service rows"}
            </Button>
          </div>
          {!canImport ? (
            <p className="mt-3 text-xs font-semibold text-[#66727A]">
              Step 3 is locked until reconciliation passes, no duplicate or
              invalid rows remain, and any warnings are acknowledged.
            </p>
          ) : null}
          <div className="mt-5 overflow-x-auto border border-[#102032]/10 bg-white">
            <table className="min-w-[760px] w-full text-left text-xs">
              <thead className="bg-[#f5f1e9] text-[10px] font-extrabold uppercase tracking-[0.12em] text-[#66727A]">
                <tr>
                  <th className="px-3 py-3">Row</th>
                  <th className="px-3 py-3">MRN / patient</th>
                  <th className="px-3 py-3">Service</th>
                  <th className="px-3 py-3">Gross</th>
                  <th className="px-3 py-3">Qty</th>
                  <th className="px-3 py-3">Discount</th>
                  <th className="px-3 py-3">Deduct</th>
                  <th className="px-3 py-3">Net</th>
                  <th className="px-3 py-3">Check</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#102032]/10">
                {preview.rows.slice(0, 14).map(row => (
                  <tr key={row.fingerprint}>
                    <td className="px-3 py-3 text-[#66727A]">
                      {row.sourceRowNumber}
                    </td>
                    <td className="px-3 py-3">
                      <strong className="block text-[#102032]">
                        {row.mrn || "No MRN"}
                      </strong>
                      <span className="text-[#66727A]">
                        {row.patientName || "Unnamed"}
                      </span>
                    </td>
                    <td className="px-3 py-3">
                      <strong className="block text-[#102032]">
                        {row.serviceCode}
                      </strong>
                      <span className="text-[#66727A]">{row.serviceName}</span>
                    </td>
                    <td className="px-3 py-3">{formatSar(row.gross)}</td>
                    <td className="px-3 py-3">{formatQty(row.quantity)}</td>
                    <td className="px-3 py-3">{formatSar(row.discount)}</td>
                    <td className="px-3 py-3">{formatSar(row.deduct)}</td>
                    <td className="px-3 py-3 font-bold text-[#a85438]">
                      {formatSar(row.net)}
                    </td>
                    <td className="px-3 py-3">
                      <Badge
                        className={
                          row.validation === "READY"
                            ? "bg-emerald-50 text-emerald-700 hover:bg-emerald-50"
                            : row.validation === "WARNING"
                              ? "bg-amber-50 text-amber-800 hover:bg-amber-50"
                              : row.validation === "DUPLICATE"
                                ? "bg-violet-50 text-violet-700 hover:bg-violet-50"
                                : "bg-red-50 text-red-700 hover:bg-red-50"
                        }
                      >
                        {row.validation}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {preview.rows.length > 14 ? (
              <p className="border-t border-[#102032]/10 px-3 py-3 text-xs text-[#66727A]">
                Showing the first 14 of {preview.rows.length} service rows. All
                rows are included in reconciliation.
              </p>
            ) : null}
          </div>
        </div>
      ) : null}
    </section>
  );
}

const roundCurrency = (value: number) =>
  Math.round((value + Number.EPSILON) * 100) / 100;
const riyadhMonth = (date = new Date()) => riyadhDate(date).slice(0, 7);
const previousMonth = (month: string) => {
  const value = new Date(month + "-01T12:00:00Z");
  value.setUTCMonth(value.getUTCMonth() - 1);
  return value.toISOString().slice(0, 7);
};
const monthBounds = (month: string) => {
  const first = new Date(month + "-01T12:00:00Z");
  const last = new Date(first);
  last.setUTCMonth(last.getUTCMonth() + 1, 0);
  return { dateFrom: month + "-01", dateTo: last.toISOString().slice(0, 10) };
};
const formatMonth = (month: string, isArabic = false) =>
  new Intl.DateTimeFormat(isArabic ? "ar-SA" : "en-GB", {
    timeZone: "Asia/Riyadh",
    month: "long",
    year: "numeric",
  }).format(new Date(month + "-01T12:00:00Z"));

type CommissionBreakdown = {
  totalIncome: number;
  deduction: number;
  commissionableIncome: number;
  commission: number;
};
type MonthlyIncomeSummary = { month: string; totalIncome: number };

/** Applies the agreed sequence exactly: income → 25% deduction → 3% commission. */
export function calculateCommission(totalIncome: number): CommissionBreakdown {
  const income = Math.max(0, Number(totalIncome) || 0);
  const deduction = income * 0.25;
  const commissionableIncome = income - deduction;
  return {
    totalIncome: roundCurrency(income),
    deduction: roundCurrency(deduction),
    commissionableIncome: roundCurrency(commissionableIncome),
    commission: roundCurrency(commissionableIncome * 0.03),
  };
}

function MonthSelector({
  currentMonth,
  selectedMonth,
  monthlySummary,
  onChange,
}: {
  currentMonth: string;
  selectedMonth: string;
  monthlySummary: MonthlyIncomeSummary[];
  onChange: (month: string) => void;
}) {
  const { locale, isArabic } = useAdminLocale();
  const priorMonth = previousMonth(currentMonth);
  const historicalMonths = monthlySummary
    .map(item => item.month)
    .filter(month => month !== currentMonth && month !== priorMonth);
  const options = Array.from(
    new Set([currentMonth, priorMonth, ...historicalMonths])
  ).sort((left, right) => right.localeCompare(left));
  return (
    <section className="border border-[#102032]/10 bg-white p-4 shadow-sm sm:flex sm:items-end sm:justify-between sm:gap-6 sm:p-5">
      <div>
        <div className="flex items-center gap-2">
          <CalendarDays className="size-4 text-[#a85438]" />
          <p className="text-[10px] font-extrabold uppercase tracking-[0.15em] text-[#a85438]">
            {translateAdminText("Select month", locale)}
          </p>
        </div>
        <p className="mt-2 text-sm leading-6 text-[#52606B]">
          Commission calculations use the selected calendar month in{" "}
          <strong className="text-[#102032]">Asia/Riyadh</strong>.
        </p>
      </div>
      <label className="mt-4 grid gap-1.5 text-xs font-bold text-[#102032] sm:mt-0 sm:w-[260px]">
        <span className="sr-only">
          {translateAdminText("Select revenue month", locale)}
        </span>
        <select
          aria-label={translateAdminText("Select revenue month", locale)}
          value={selectedMonth}
          onChange={event => onChange(event.target.value)}
          className="h-11 border border-[#102032]/20 bg-[#fffdf9] px-3 text-sm font-semibold text-[#102032] focus:outline-none focus:ring-2 focus:ring-[#a85438]/35"
        >
          <option value={currentMonth}>
            {translateAdminText("Current month", locale)} ·{" "}
            {formatMonth(currentMonth, isArabic)}
          </option>
          <option value={priorMonth}>
            {translateAdminText("Previous month", locale)} ·{" "}
            {formatMonth(priorMonth, isArabic)}
          </option>
          {options
            .filter(month => month !== currentMonth && month !== priorMonth)
            .map(month => (
              <option key={month} value={month}>
                {formatMonth(month, isArabic)}
              </option>
            ))}
        </select>
      </label>
    </section>
  );
}

function CommissionPrimaryCard({
  month,
  breakdown,
  transactionCount,
}: {
  month: string;
  breakdown: CommissionBreakdown;
  transactionCount: number;
}) {
  const { locale, isArabic } = useAdminLocale();
  const calculated = transactionCount > 0;
  const sourceNote = calculated
    ? "Based on " +
      transactionCount +
      " imported HMS service row" +
      (transactionCount === 1 ? "." : "s.")
    : "No imported HMS revenue transactions are available for this month.";
  return (
    <section className="overflow-hidden border border-[#a85438]/40 bg-[#102032] text-white shadow-lg">
      <div className="grid gap-6 p-6 sm:p-7 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-end">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <WalletCards className="size-5 text-[#f0b798]" />
            <p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#f0b798]">
              {translateAdminText("Nurse James commission", locale)}
            </p>
          </div>
          <p className="mt-4 font-display text-5xl tracking-[-0.06em] sm:text-6xl">
            {formatSar(breakdown.commission)}
          </p>
          <p className="mt-3 text-sm font-semibold text-white/90">
            {translateAdminText("3% of commissionable income", locale)}
          </p>
        </div>
        <div className="border border-white/15 bg-white/[0.07] p-4 text-sm lg:max-w-xs">
          <p className="text-[10px] font-extrabold uppercase tracking-[0.14em] text-[#f0b798]">
            {formatMonth(month, isArabic)}
          </p>
          <p className="mt-2 font-semibold">
            {calculated ? "Calculated" : "Awaiting revenue data"}
          </p>
          <p className="mt-1 leading-5 text-white/70">{sourceNote}</p>
        </div>
      </div>
    </section>
  );
}

function CommissionCards({ breakdown }: { breakdown: CommissionBreakdown }) {
  const cards = [
    {
      label: "Total income",
      value: breakdown.totalIncome,
      note: "HMS net revenue for the selected month",
    },
    {
      label: "25% deduction",
      value: breakdown.deduction,
      note: "Applied before commission",
    },
    {
      label: "Commissionable income",
      value: breakdown.commissionableIncome,
      note: "Income after the 25% deduction",
    },
    {
      label: "My commission",
      value: breakdown.commission,
      note: "3% of commissionable income",
      featured: true,
    },
  ];
  return (
    <section
      aria-label="Monthly commission figures"
      className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4"
    >
      {cards.map(card => (
        <AdminMetricCard
          key={card.label}
          label={card.label}
          value={formatSar(card.value)}
          note={card.note}
          tone={card.featured ? "accent" : "default"}
        />
      ))}
    </section>
  );
}

function CalculationFlow({ breakdown }: { breakdown: CommissionBreakdown }) {
  const steps = [
    {
      label: "Total income",
      value: breakdown.totalIncome,
      note: "HMS net revenue",
    },
    {
      label: "25% deduction",
      value: breakdown.deduction,
      note: "Total income × 25%",
      subtract: true,
    },
    {
      label: "Commissionable income",
      value: breakdown.commissionableIncome,
      note: "Total income − 25% deduction",
    },
    {
      label: "Nurse James commission",
      value: breakdown.commission,
      note: "Commissionable income × 3%",
      featured: true,
    },
  ];
  return (
    <section className="border border-[#102032]/10 bg-white p-5 sm:p-6">
      <div>
        <p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">
          Calculation flow
        </p>
        <h2 className="mt-2 font-display text-2xl tracking-[-0.04em] text-[#102032]">
          See exactly how the commission is calculated
        </h2>
      </div>
      <ol className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {steps.map((step, index) => (
          <li
            key={step.label}
            className={
              "border p-4 " +
              (step.featured
                ? "border-[#a85438]/35 bg-[#fff7f1]"
                : "border-[#102032]/10 bg-[#fffdf9]")
            }
          >
            <p className="text-[10px] font-extrabold uppercase tracking-[0.13em] text-[#66727A]">
              Step {index + 1}
            </p>
            <p
              className={
                "mt-2 font-display text-2xl tracking-[-0.04em] " +
                (step.featured ? "text-[#a85438]" : "text-[#102032]")
              }
            >
              {step.subtract ? "− " : ""}
              {formatSar(step.value)}
            </p>
            <p className="mt-2 text-sm font-bold text-[#102032]">
              {step.label}
            </p>
            <p className="mt-1 text-xs leading-5 text-[#66727A]">{step.note}</p>
            {index < steps.length - 1 ? (
              <ArrowDown
                aria-hidden="true"
                className="mt-4 size-4 text-[#a85438]"
              />
            ) : null}
          </li>
        ))}
      </ol>
    </section>
  );
}

function CommissionFormula({ breakdown }: { breakdown: CommissionBreakdown }) {
  return (
    <section className="border border-[#102032]/10 bg-[#f5f1e9] p-5 sm:p-6">
      <div className="flex gap-3">
        <Calculator className="mt-0.5 size-5 shrink-0 text-[#a85438]" />
        <div>
          <p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">
            How is my commission calculated?
          </p>
          <p className="mt-2 font-display text-2xl tracking-[-0.04em] text-[#102032]">
            Total Income × 75% × 3% = Nurse James Commission
          </p>
          <p className="mt-2 text-sm leading-6 text-[#52606B]">
            The 25% deduction happens first. The commission is never calculated
            as 3% of the total income.
          </p>
          <p className="mt-4 border-l-2 border-[#a85438] pl-3 text-sm font-semibold text-[#102032]">
            {formatSar(breakdown.totalIncome)} × 75% × 3% ={" "}
            <span className="text-[#a85438]">
              {formatSar(breakdown.commission)}
            </span>
          </p>
        </div>
      </div>
    </section>
  );
}

function MonthlySummary({
  monthlySummary,
}: {
  monthlySummary: MonthlyIncomeSummary[];
}) {
  const { isArabic } = useAdminLocale();
  const rows = monthlySummary.map(item => ({
    ...item,
    ...calculateCommission(item.totalIncome),
  }));
  return (
    <section className="border border-[#102032]/10 bg-white">
      <div className="border-b border-[#102032]/10 p-5 sm:p-6">
        <p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">
          Monthly summary
        </p>
        <h2 className="mt-2 font-display text-2xl tracking-[-0.04em] text-[#102032]">
          Commission history
        </h2>
        <p className="mt-2 text-sm leading-6 text-[#52606B]">
          Only calendar months with existing imported HMS revenue are listed. No
          values are estimated or created manually.
        </p>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-[760px] w-full text-start text-sm">
          <thead className="bg-[#fffaf5] text-[10px] font-extrabold uppercase tracking-[0.13em] text-[#66727A]">
            <tr>
              <th className="px-5 py-4">Month</th>
              <th className="px-5 py-4">Total income</th>
              <th className="px-5 py-4">25% deduction</th>
              <th className="px-5 py-4">Commissionable</th>
              <th className="px-5 py-4">3% commission</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#102032]/10">
            {rows.length ? (
              rows.map(row => (
                <tr key={row.month}>
                  <td className="px-5 py-4 font-semibold text-[#102032]">
                    {formatMonth(row.month, isArabic)}
                  </td>
                  <td className="px-5 py-4">{formatSar(row.totalIncome)}</td>
                  <td className="px-5 py-4">{formatSar(row.deduction)}</td>
                  <td className="px-5 py-4">
                    {formatSar(row.commissionableIncome)}
                  </td>
                  <td className="px-5 py-4 font-bold text-[#a85438]">
                    {formatSar(row.commission)}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td
                  colSpan={5}
                  className="px-5 py-12 text-center text-sm text-[#66727A]"
                >
                  No imported HMS revenue is available yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function WorkspaceReports({ data }: { data: any }) {
  const [tab, setTab] = useState<"daily" | "patients" | "services" | "history">(
    "daily"
  );
  const [expanded, setExpanded] = useState<string | null>(null);
  const [batchId, setBatchId] = useState<number | null>(null);
  const batch = trpc.admin.revenueBatch.useQuery(
    { batchId: batchId ?? 0 },
    { enabled: batchId !== null }
  );
  const togglePatient = (key: string) =>
    setExpanded(current => (current === key ? null : key));
  const tabs = [
    { key: "daily", label: "Daily revenue" },
    { key: "patients", label: "By patient" },
    { key: "services", label: "By service" },
    { key: "history", label: "Import history" },
  ] as const;
  return (
    <section className="mt-6 border border-[#102032]/10 bg-white">
      <div className="flex flex-wrap gap-1 border-b border-[#102032]/10 bg-[#f5f1e9] p-2">
        {tabs.map(item => (
          <button
            type="button"
            key={item.key}
            onClick={() => setTab(item.key)}
            className={`px-3 py-2 text-xs font-bold transition-colors ${tab === item.key ? "bg-[#102032] text-white" : "text-[#52606B] hover:bg-white"}`}
          >
            {item.label}
          </button>
        ))}
      </div>
      {tab === "daily" ? (
        <div className="overflow-x-auto">
          <table className="min-w-[720px] w-full text-left text-sm">
            <thead className="bg-[#fffaf5] text-[10px] font-extrabold uppercase tracking-[0.13em] text-[#66727A]">
              <tr>
                <th className="px-5 py-4">Report date</th>
                <th className="px-5 py-4">Gross</th>
                <th className="px-5 py-4">Quantity</th>
                <th className="px-5 py-4">Discount</th>
                <th className="px-5 py-4">Deduct</th>
                <th className="px-5 py-4">Net</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#102032]/10">
              {data.daily.length ? (
                data.daily.map((item: any) => (
                  <tr key={item.date}>
                    <td className="px-5 py-4 font-semibold text-[#102032]">
                      {formatDate(item.date)}
                    </td>
                    <td className="px-5 py-4">
                      {formatSar(item.totals.gross)}
                    </td>
                    <td className="px-5 py-4">
                      {formatQty(item.totals.quantity)}
                    </td>
                    <td className="px-5 py-4">
                      {formatSar(item.totals.discount)}
                    </td>
                    <td className="px-5 py-4">
                      {formatSar(item.totals.deduct)}
                    </td>
                    <td className="px-5 py-4 font-bold text-[#a85438]">
                      {formatSar(item.totals.net)}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td
                    colSpan={6}
                    className="px-5 py-12 text-center text-sm text-[#66727A]"
                  >
                    No revenue rows match the selected filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      ) : tab === "patients" ? (
        <div className="divide-y divide-[#102032]/10">
          {data.patients.length ? (
            data.patients.map((patient: any) => {
              const key = `${patient.mrn ?? "unmatched"}-${patient.patientName}`;
              const isOpen = expanded === key;
              return (
                <div key={key}>
                  <button
                    type="button"
                    onClick={() => togglePatient(key)}
                    className="grid w-full gap-3 px-4 py-4 text-left hover:bg-[#fffaf5] sm:grid-cols-[minmax(220px,1fr)_minmax(0,2fr)] sm:items-center sm:px-5"
                  >
                    <span className="flex items-start gap-2">
                      {isOpen ? (
                        <ChevronDown className="mt-1 size-4 shrink-0 text-[#a85438]" />
                      ) : (
                        <ChevronRight className="mt-1 size-4 shrink-0 text-[#66727A]" />
                      )}
                      <span>
                        <strong className="block text-[#102032]">
                          {patient.mrn || "Unmatched patient"}
                        </strong>
                        <span className="text-sm text-[#52606B]">
                          {patient.patientName || "Name not supplied"}
                        </span>
                        {patient.patientId ? (
                          <Badge className="ml-2 bg-emerald-50 text-emerald-700 hover:bg-emerald-50">
                            Matched
                          </Badge>
                        ) : (
                          <Badge className="ml-2 bg-amber-50 text-amber-800 hover:bg-amber-50">
                            Unmatched
                          </Badge>
                        )}
                      </span>
                    </span>
                    <MoneyLine totals={patient.totals} compact />
                  </button>
                  {isOpen ? (
                    <div className="overflow-x-auto border-t border-[#102032]/10 bg-[#fbfaf7] px-4 py-4 sm:px-12">
                      <table className="min-w-[680px] w-full text-left text-xs">
                        <thead className="text-[10px] font-extrabold uppercase tracking-[0.12em] text-[#66727A]">
                          <tr>
                            <th className="pb-3">Service code</th>
                            <th className="pb-3">Service name</th>
                            <th className="pb-3">Gross</th>
                            <th className="pb-3">Qty</th>
                            <th className="pb-3">Discount</th>
                            <th className="pb-3">Deduct</th>
                            <th className="pb-3">Net</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#102032]/10">
                          {patient.rows.map((row: any) => (
                            <tr key={row.id}>
                              <td className="py-3 pr-3 font-bold text-[#102032]">
                                {row.serviceCode}
                              </td>
                              <td className="py-3 pr-3 text-[#52606B]">
                                {row.serviceName}
                              </td>
                              <td className="py-3 pr-3">
                                {formatSar(row.gross)}
                              </td>
                              <td className="py-3 pr-3">
                                {formatQty(row.quantity)}
                              </td>
                              <td className="py-3 pr-3">
                                {formatSar(row.discount)}
                              </td>
                              <td className="py-3 pr-3">
                                {formatSar(row.deduct)}
                              </td>
                              <td className="py-3 font-bold text-[#a85438]">
                                {formatSar(row.net)}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : null}
                </div>
              );
            })
          ) : (
            <p className="p-10 text-center text-sm text-[#66727A]">
              No patient revenue matches the selected filters.
            </p>
          )}
        </div>
      ) : tab === "services" ? (
        <div className="overflow-x-auto">
          <table className="min-w-[760px] w-full text-left text-sm">
            <thead className="bg-[#fffaf5] text-[10px] font-extrabold uppercase tracking-[0.13em] text-[#66727A]">
              <tr>
                <th className="px-5 py-4">Service code</th>
                <th className="px-5 py-4">Service name</th>
                <th className="px-5 py-4">Quantity</th>
                <th className="px-5 py-4">Gross</th>
                <th className="px-5 py-4">Discount</th>
                <th className="px-5 py-4">Deduct</th>
                <th className="px-5 py-4">Net</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#102032]/10">
              {data.services.length ? (
                data.services.map((service: any) => (
                  <tr key={`${service.serviceCode}-${service.serviceName}`}>
                    <td className="px-5 py-4 font-bold text-[#102032]">
                      {service.serviceCode}
                    </td>
                    <td className="px-5 py-4 text-[#52606B]">
                      {service.serviceName}
                    </td>
                    <td className="px-5 py-4">
                      {formatQty(service.totals.quantity)}
                    </td>
                    <td className="px-5 py-4">
                      {formatSar(service.totals.gross)}
                    </td>
                    <td className="px-5 py-4">
                      {formatSar(service.totals.discount)}
                    </td>
                    <td className="px-5 py-4">
                      {formatSar(service.totals.deduct)}
                    </td>
                    <td className="px-5 py-4 font-bold text-[#a85438]">
                      {formatSar(service.totals.net)}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td
                    colSpan={7}
                    className="px-5 py-12 text-center text-sm text-[#66727A]"
                  >
                    No service revenue matches the selected filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-[940px] w-full text-left text-sm">
            <thead className="bg-[#fffaf5] text-[10px] font-extrabold uppercase tracking-[0.13em] text-[#66727A]">
              <tr>
                <th className="px-5 py-4">Batch</th>
                <th className="px-5 py-4">Filename / period</th>
                <th className="px-5 py-4">Patients</th>
                <th className="px-5 py-4">Rows</th>
                <th className="px-5 py-4">Gross</th>
                <th className="px-5 py-4">Qty</th>
                <th className="px-5 py-4">Discount</th>
                <th className="px-5 py-4">Deduct</th>
                <th className="px-5 py-4">Net</th>
                <th className="px-5 py-4">Imported</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#102032]/10">
              {data.batches.length ? (
                data.batches.map((item: any) => (
                  <tr key={item.id}>
                    <td className="px-5 py-4">
                      <button
                        type="button"
                        className="font-bold text-[#a85438] underline-offset-2 hover:underline"
                        onClick={() => setBatchId(item.id)}
                      >
                        #{item.id}
                      </button>
                    </td>
                    <td className="px-5 py-4">
                      <strong className="block max-w-[240px] truncate text-[#102032]">
                        {item.originalFileName}
                      </strong>
                      <span className="text-xs text-[#66727A]">
                        {formatDate(item.reportFromDate)} →{" "}
                        {formatDate(item.reportToDate)}
                      </span>
                    </td>
                    <td className="px-5 py-4">{item.patientCount}</td>
                    <td className="px-5 py-4">{item.serviceRowCount}</td>
                    <td className="px-5 py-4">{formatSar(item.grandGross)}</td>
                    <td className="px-5 py-4">
                      {formatQty(item.grandQuantity)}
                    </td>
                    <td className="px-5 py-4">
                      {formatSar(item.grandDiscount)}
                    </td>
                    <td className="px-5 py-4">{formatSar(item.grandDeduct)}</td>
                    <td className="px-5 py-4 font-bold text-[#a85438]">
                      {formatSar(item.grandNet)}
                    </td>
                    <td className="px-5 py-4 text-xs text-[#66727A]">
                      {item.importedByName || "Authorized admin"}
                      <br />
                      {new Date(item.importedAt).toLocaleString("en-GB", {
                        timeZone: "Asia/Riyadh",
                      })}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td
                    colSpan={10}
                    className="px-5 py-12 text-center text-sm text-[#66727A]"
                  >
                    No Revenue imports yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
          {batchId !== null ? (
            <div className="border-t border-[#102032]/10 bg-[#fbfaf7] p-5">
              {batch.isLoading ? (
                <Skeleton className="h-20 rounded-none" />
              ) : batch.data ? (
                <>
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p className="text-[10px] font-extrabold uppercase tracking-[0.15em] text-[#a85438]">
                        Exact imported records
                      </p>
                      <p className="mt-1 text-sm text-[#52606B]">
                        Batch #{batch.data.batch.id} · {batch.data.rows.length}{" "}
                        immutable service rows · SHA-256 protected file identity
                      </p>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setBatchId(null)}
                    >
                      Close
                    </Button>
                  </div>
                  <div className="mt-4 max-h-72 overflow-auto border border-[#102032]/10 bg-white">
                    <div className="divide-y divide-[#102032]/10">
                      {batch.data.rows.map((row: any) => (
                        <div
                          key={row.id}
                          className="grid gap-2 px-4 py-3 text-xs sm:grid-cols-[80px_1fr_1.5fr_auto]"
                        >
                          <span className="text-[#66727A]">
                            Row {row.sourceRowNumber}
                          </span>
                          <strong className="text-[#102032]">
                            {row.hmsMrn || "No MRN"} · {row.patientName}
                          </strong>
                          <span className="text-[#52606B]">
                            {row.serviceCode} · {row.serviceName}
                          </span>
                          <strong className="text-[#a85438]">
                            {formatSar(row.net)}
                          </strong>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              ) : (
                <p className="text-sm text-red-700">
                  The selected batch could not be loaded.
                </p>
              )}
            </div>
          ) : null}
        </div>
      )}
    </section>
  );
}

export function RevenueWorkspace() {
  const [currentMonth] = useState(() => riyadhMonth());
  const [selectedMonth, setSelectedMonth] = useState(currentMonth);
  const bounds = useMemo(() => monthBounds(selectedMonth), [selectedMonth]);
  const filters = useMemo(() => bounds, [bounds]);
  const revenue = trpc.admin.revenueWorkspace.useQuery(filters);
  const utils = trpc.useUtils();

  return (
    <div className="mx-auto max-w-7xl">
      <PageHeading />
      {revenue.isLoading ? (
        <div className="space-y-5">
          <Skeleton className="h-24 rounded-none" />
          <Skeleton className="h-64 rounded-none" />
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            {Array.from({ length: 4 }).map((_, index) => (
              <Skeleton key={index} className="h-36 rounded-none" />
            ))}
          </div>
        </div>
      ) : revenue.isError ? (
        <p className="border border-red-200 bg-red-50 p-5 text-sm text-red-800">
          Protected revenue data could not be loaded. Please refresh and try
          again.
        </p>
      ) : revenue.data ? (
        (() => {
          const breakdown = calculateCommission(revenue.data.summary.net);
          return (
            <>
              <MonthSelector
                currentMonth={currentMonth}
                selectedMonth={selectedMonth}
                monthlySummary={revenue.data.monthlySummary}
                onChange={setSelectedMonth}
              />
              <div className="mt-5">
                <RevenueImportPanel
                  onImported={async () => {
                    await Promise.all([
                      utils.admin.revenueWorkspace.invalidate(),
                      utils.admin.dashboard.invalidate(),
                    ]);
                  }}
                />
              </div>
              <div className="mt-5">
                <CommissionPrimaryCard
                  month={selectedMonth}
                  breakdown={breakdown}
                  transactionCount={revenue.data.rows.length}
                />
              </div>
              <div className="mt-5">
                <CommissionCards breakdown={breakdown} />
              </div>
              <div className="mt-5">
                <CalculationFlow breakdown={breakdown} />
              </div>
              <div className="mt-5">
                <CommissionFormula breakdown={breakdown} />
              </div>
              <div className="mt-5">
                <MonthlySummary monthlySummary={revenue.data.monthlySummary} />
              </div>
              <details className="mt-6 border border-[#102032]/10 bg-white">
                <summary className="cursor-pointer list-none p-5 text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-[#a85438] sm:p-6">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">
                        Revenue reports
                      </p>
                      <h2 className="mt-2 font-display text-2xl tracking-[-0.04em] text-[#102032]">
                        Reporting detail and import history
                      </h2>
                      <p className="mt-2 max-w-3xl text-sm leading-6 text-[#52606B]">
                        Review daily, patient, service, and batch records after
                        using the upload workflow above.
                      </p>
                    </div>
                    <span className="text-xs font-bold text-[#a85438]">
                      Open reports
                    </span>
                  </div>
                </summary>
                <div className="border-t border-[#102032]/10 p-4 sm:p-6">
                  <WorkspaceReports data={revenue.data} />
                </div>
              </details>
            </>
          );
        })()
      ) : null}
    </div>
  );
}
