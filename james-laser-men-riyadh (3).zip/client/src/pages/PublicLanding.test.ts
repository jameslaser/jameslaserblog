import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const appSource = readFileSync(resolve(process.cwd(), "client/src/App.tsx"), "utf8");
const landingSource = readFileSync(resolve(process.cwd(), "client/src/pages/PublicLanding.tsx"), "utf8");
const publicHeaderSource = readFileSync(resolve(process.cwd(), "client/src/components/PublicSiteHeader.tsx"), "utf8");
const seoSource = readFileSync(resolve(process.cwd(), "client/src/seo.ts"), "utf8");

describe("localized public landing routes", () => {
  it("keeps English and Arabic landing paths registered instead of falling through to the 404 route", () => {
    expect(appSource).toContain('path={"/en"}');
    expect(appSource).toContain('path={"/ar"}');
    expect(appSource).toContain('path={"/en"} component={Home}');
    expect(appSource).toContain('<PublicLanding locale="ar" />');
  });

  it("uses the published clinic setting and an RTL-aware document shell", () => {
    expect(landingSource).toContain("trpc.publicContent.clinicSettings.useQuery()");
    expect(landingSource).toContain('lang={arabic ? "ar" : "en"}');
    expect(landingSource).toContain('html.dir = arabic ? "rtl" : "ltr"');
    expect(landingSource).toContain('className={`public-content-page min-h-screen bg-[#F7F3EC] text-[#102032] ${arabic ? "arabic-public-page" : ""} premium-home--theme-');
    expect(landingSource).toContain('href={`${prefix}/appointment`}');
  });

  it("renders a two-language selector and accurate Arabic homepage messaging", () => {
    expect(landingSource).toContain('<PublicSiteHeader locale={locale} active="home" />');
    expect(publicHeaderSource).toContain('aria-label={arabic ? "اختيار اللغة" : "Choose language"}');
    expect(publicHeaderSource).toContain('return locale === "ar" ? "/ar" : "/en"');
    expect(publicHeaderSource).toContain('lang={alternateLocale}');
    expect(landingSource).toContain("إزالة الشعر بالليزر للرجال بخطة دقيقة ومدروسة");
    expect(landingSource).toContain("إرسال الطلب لا يعني أن الموعد أصبح مؤكدًا");
    expect(landingSource).toContain("إزالة الشعر بالليزر للرجال في الرياض | جيمس ليزر");
  });

  it("supports a host-specific public origin for previews while retaining the production-domain default", () => {
    expect(seoSource).toContain("VITE_PUBLIC_SITE_ORIGIN");
    expect(seoSource).toContain("https://www.jameslaserformen.com");
  });
});
