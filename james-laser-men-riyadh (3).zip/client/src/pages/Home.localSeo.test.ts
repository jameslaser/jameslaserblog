import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const wrapperSource = readFileSync(resolve(process.cwd(), "client/src/pages/Home.tsx"), "utf8");
const source = readFileSync(resolve(process.cwd(), "client/src/components/PublicHomepage.tsx"), "utf8");

describe("homepage local SEO location actions", () => {
  it("keeps the supplied clinic identity and exact owner-provided map link visible", () => {
    expect(source).toContain("New Look Clinic, Al Sahafah, Riyadh, Saudi Arabia");
    expect(source).toContain("https://maps.app.goo.gl/LYx98uWLW8kHdsMv7?g_st=ic");
    expect(source).not.toContain("https://www.google.com/maps/search/?api=1");
    expect(source).toContain("https://www.google.com/maps?q=");
    expect(source).toContain("<iframe");
    expect(source).toContain("Directions");
    expect(source).toContain('section.sectionKey.toLowerCase() === "hero"');
  });

  it("keeps a separate WhatsApp conversion action in the location section", () => {
    expect(source).toContain("WhatsApp");
    expect(wrapperSource).toContain("whatsapp_click");
  });

  it("uses only verified public storage media instead of the retired broken paths", () => {
    expect(source).toContain("nurse-james-laser-hair-removal-specialist-riyadh_f79913ca.jpg");
    expect(source).toContain("male-laser-back-treatment_3bb98402.jpg");
    expect(source).toContain("james-laser-mens-facial-laser-hair-removal-riyadh_fb2a3e42.mp4");
    expect(source).not.toContain("NURE JAMES_2d04b670.jpg");
    expect(source).not.toContain("clinic-reception.png");
    expect(source).not.toContain("male-back-laser-treatment_82510dea.png");
  });

  it("presents the approved clinic machines with the supplied device photography and claim-safe copy", () => {
    expect(source).toContain('["DEKA AGAIN", "CLARITY 2", "GENTLE PROMAX", "DUETTO MACHINE"]');
    expect(source).toContain("deka-again-riyadh-photo_ac4f0d6e.jpeg");
    expect(source).toContain("gentle-promax-riyadh-photo_30349ffb.jpeg");
    expect(source).toContain("duetto-machine-riyadh-photo_03e9b4c8.jpeg");
    expect(source).toContain("premium-home__machine-media");
    expect(source).toContain("premium-home__machine-copy");
    expect(source).not.toContain("without pain");
    expect(source).not.toContain("just 30 minutes");
  });

  it("renders configured social profiles as safe, icon-led external links", () => {
    expect(source).toContain("Icon: Instagram");
    expect(source).toContain("Icon: Music2");
    expect(source).toContain("Icon: Ghost");
    expect(source).toContain("Icon: Facebook");
    expect(source).toContain("Icon: Youtube");
    expect(source).toContain("Icon: Twitter");
    expect(source).toContain("Icon: Building2");
    expect(source).toContain('className="premium-home__social-link"');
    expect(source).toContain('rel="noopener noreferrer"');
  });

  it("records anonymous social engagement without collecting profile URLs or visitor identifiers", () => {
    expect(source).toContain("onSocialClick?: (platform: string) => void");
    expect(source).toContain("onClick={() => onSocialClick?.(label)}");
    expect(wrapperSource).toContain('"social_click"');
    expect(wrapperSource).toContain("platform.toLowerCase().replace");
    expect(wrapperSource).not.toContain("href: href");
  });

  it("uses saved CMS appearance values with existing approved media as a safe fallback", () => {
    expect(source).toContain("homepageTheme");
    expect(source).toContain("homepageHeroImageUrl");
    expect(source).toContain("homepageSpecialistImageUrl");
    expect(source).toContain("homepageClinicImageUrl");
    expect(source).toContain("premium-home__hero--image");
    expect(source).toContain("nurse-james-laser-hair-removal-specialist-riyadh_f79913ca.jpg");
    expect(source).toContain("male-laser-back-treatment_3bb98402.jpg");
    expect(wrapperSource).toContain("premium-home--theme-");
  });

  it("renders published blog excerpts on both localized homepages from the public CMS feed", () => {
    expect(source).toContain("publicContent.guidePosts.useQuery");
    expect(source).toContain("article.summaryEn");
    expect(source).toContain("article.summaryAr");
    expect(source).toContain("premium-home__blog-grid");
    expect(source).toContain("${prefix}/blog/${encodeURIComponent(article.slug)}");
    expect(source).toContain("View all articles");
    expect(source).toContain("عرض جميع المقالات");
  });
});
