import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const source = readFileSync(resolve(process.cwd(), "client/src/pages/PublicPolicy.tsx"), "utf8");

describe("public policy SEO metadata", () => {
  it("uses the configured public-site origin for policy canonicals", () => {
    expect(source).toContain('import { publicUrl } from "@/seo"');
    expect(source).toContain('canonicalTag.setAttribute("href", publicUrl(canonicalPath));');
    expect(source).not.toContain("`${window.location.origin}${canonicalPath}`");
  });

  it("shows the published policy update date when metadata is available", () => {
    expect(source).toContain("Last updated:");
    expect(source).toContain("آخر تحديث:");
    expect(source).toContain("policy?.updatedAt");
  });
});
