import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const home = readFileSync(resolve(process.cwd(), "client/src/pages/Home.tsx"), "utf8");
const app = readFileSync(resolve(process.cwd(), "client/src/App.tsx"), "utf8");
const styles = readFileSync(resolve(process.cwd(), "client/src/index.css"), "utf8");
const html = readFileSync(resolve(process.cwd(), "client/index.html"), "utf8");

describe("public homepage language selector", () => {
  it("shows both English and Arabic choices on the full English homepage", () => {
    expect(home).toContain('aria-label="Choose language"');
    expect(home).toContain('href="/" lang="en" aria-current="page"');
    expect(home).toContain('href="/ar" lang="ar" dir="rtl"');
    expect(home).toContain('href="/appointment"');
    expect(app).toContain('path={"/en"} component={Home}');
  });

  it("sets English document attributes and retains bilingual alternates", () => {
    expect(home).toContain('html.lang = "en"');
    expect(home).toContain('html.dir = "ltr"');
    expect(home).toContain('setAlternate(`${origin}/`, "en")');
    expect(home).toContain('setAlternate(`${origin}/ar`, "ar-SA")');
    expect(home).toContain('setAlternate(`${origin}/`, "x-default")');
  });

  it("ships an Arabic-capable font and RTL typography treatment", () => {
    expect(html).toContain("Noto+Sans+Arabic");
    expect(styles).toContain(".arabic-public-page");
    expect(styles).toContain('font-family: "Noto Sans Arabic"');
  });
});
