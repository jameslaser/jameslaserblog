import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("ConsentSignature public workflow", () => {
  it("uses a fragment token, requires explicit opening of all original forms, and keeps the signing page noindex", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/ConsentSignature.tsx"), "utf8");

    expect(source).toContain("window.location.hash");
    expect(source).toContain('meta.setAttribute("content", "noindex, nofollow, noarchive")');
    expect(source).toContain("allOpened = documents.length === 3");
    expect(source).toContain("recordOpen(document.id)");
    expect(source).toContain("signatureDataUrl: canvas.toDataURL(\"image/png\")");
    expect(source).toContain("acknowledgement: true");
    expect(source).not.toContain("fetch(");
  });
});
