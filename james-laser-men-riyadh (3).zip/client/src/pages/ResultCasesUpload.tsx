import { CmsImageUploadField } from "@/components/CmsImageUploadField";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Check, Loader2, Save } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

const emptyResult = { title: "", treatmentArea: "", beforeImageUrl: "", afterImageUrl: "", consent: false, isActive: false };

export function ResultCases() {
  const cases = trpc.cms.resultCases.useQuery();
  const utils = trpc.useUtils();
  const [form, setForm] = useState(emptyResult);
  const save = trpc.cms.saveResultCase.useMutation({
    onSuccess: async () => {
      toast.success("Result case saved with its recorded authorization.");
      setForm(emptyResult);
      await utils.cms.resultCases.invalidate();
    },
    onError: error => toast.error(error.message),
  });
  const update = (change: Partial<typeof form>) => setForm(current => ({ ...current, ...change }));
  const ready = Boolean(form.title.trim() && form.treatmentArea.trim() && form.beforeImageUrl && form.afterImageUrl && form.consent);

  return <div className="mx-auto max-w-6xl"><header className="mb-8 border-b border-[#102032]/10 pb-6"><p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#a85438]">Consent-controlled evidence</p><h1 className="mt-2 font-display text-4xl tracking-[-0.05em] text-[#102032]">Before & after cases</h1><p className="mt-2 max-w-3xl text-sm leading-6 text-[#52606B]">Upload only real, de-identified before-and-after images with recorded authorization. Images remain a private case reference until you explicitly make the completed case active publicly.</p></header><div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]"><form onSubmit={event => { event.preventDefault(); save.mutate({ title: form.title, treatmentArea: form.treatmentArea, beforeImageUrl: form.beforeImageUrl, afterImageUrl: form.afterImageUrl, additionalImages: null, sessionCount: null, descriptionEn: null, descriptionAr: null, disclaimerEn: null, disclaimerAr: null, consentConfirmed: true, isFeatured: false, isActive: form.isActive, displayOrder: 0 }); }} className="grid gap-4 border border-[#102032]/10 bg-white p-5 sm:grid-cols-2"><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Neutral case title<Input required value={form.title} onChange={event => update({ title: event.target.value })} /></label><label className="grid gap-1.5 text-xs font-bold text-[#102032]">Treatment area<Input required value={form.treatmentArea} onChange={event => update({ treatmentArea: event.target.value })} /></label><CmsImageUploadField label="Before image" value={form.beforeImageUrl} onChange={beforeImageUrl => update({ beforeImageUrl })} altEn={`Before treatment image — ${form.treatmentArea || "case"}`} /><CmsImageUploadField label="After image" value={form.afterImageUrl} onChange={afterImageUrl => update({ afterImageUrl })} altEn={`After treatment image — ${form.treatmentArea || "case"}`} /><label className="flex gap-2 text-sm font-semibold text-[#102032] sm:col-span-2"><input required type="checkbox" checked={form.consent} onChange={event => update({ consent: event.target.checked })} />I confirm written authorization is recorded and the media contains no patient name, contact detail, or other identifier.</label><label className="flex gap-2 text-sm font-semibold text-[#102032] sm:col-span-2"><input type="checkbox" checked={form.isActive} onChange={event => update({ isActive: event.target.checked })} />Make this authorized case active publicly</label><div className="flex flex-wrap gap-2 sm:col-span-2"><Button type="submit" disabled={!ready || save.isPending}>{save.isPending ? <Loader2 className="mr-2 size-4 animate-spin" /> : <Save className="mr-2 size-4" />}Save result case</Button><Button type="button" variant="outline" onClick={() => setForm(emptyResult)}>Clear</Button></div></form><section className="space-y-3">{cases.isLoading ? <div className="grid min-h-44 place-items-center border border-[#102032]/10 bg-white"><Loader2 className="size-5 animate-spin text-[#a85438]" /></div> : cases.isError ? <p className="border border-red-200 bg-red-50 p-5 text-sm text-red-800">Result cases could not be loaded. Please refresh and try again.</p> : cases.data?.length ? cases.data.map(item => <article key={item.id} className="overflow-hidden border border-[#102032]/10 bg-white"><div className="grid grid-cols-2">{item.beforeImageUrl ? <img src={item.beforeImageUrl} alt="" className="aspect-square w-full object-cover" /> : null}{item.afterImageUrl ? <img src={item.afterImageUrl} alt="" className="aspect-square w-full object-cover" /> : null}</div><div className="p-4"><div className="flex flex-wrap items-center justify-between gap-2"><p className="font-semibold text-[#102032]">{item.title}</p><Badge variant={item.isActive ? "default" : "outline"}>{item.isActive ? "Active" : "Private"}</Badge></div><p className="mt-1 text-xs text-[#52606B]">{item.treatmentArea} · consent {item.consentConfirmed ? "recorded" : "missing"}</p></div></article>) : <div className="border border-dashed border-[#102032]/20 bg-white p-6 text-sm text-[#52606B]">No authorized result cases are saved. Never upload or create a case without real consented, de-identified source media.</div>}</section></div></div>;
}
