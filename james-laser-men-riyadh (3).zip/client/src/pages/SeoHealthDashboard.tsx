import { AlertTriangle, CheckCircle2, FileText, Globe2 } from "lucide-react";
import { trpc } from "@/lib/trpc";

function Metric({ label, value, tone = "default" }: { label: string; value: number; tone?: "default" | "warning" }) {
  return <div className="border border-[#102032]/10 bg-[#F7F3EC] p-3"><p className={tone === "warning" ? "text-2xl font-bold text-[#B85E3C]" : "text-2xl font-bold text-[#102032]"}>{value}</p><p className="mt-1 text-xs font-semibold text-[#52606B]">{label}</p></div>;
}

/** Local publication health only; it deliberately does not estimate Google metrics or index coverage. */
export function SeoHealthDashboard() {
  const cms = trpc.cms as any;
  // The panel is supplementary to existing SEO controls. Graceful absence is
  // useful in constrained test harnesses and never affects CMS publishing.
  if (!cms.guidePosts?.useQuery || !cms.policies?.useQuery || !cms.treatments?.useQuery) return null;
  const guides = cms.guidePosts.useQuery();
  const policies = cms.policies.useQuery();
  const treatments = cms.treatments.useQuery();
  if (guides.isLoading || policies.isLoading || treatments.isLoading) return null;
  if (guides.isError || policies.isError || treatments.isError) return null;
  const publishedGuides = (guides.data ?? []).filter((item: any) => item.status === "published");
  const publishedPolicies = (policies.data ?? []).filter((item: any) => item.status === "published");
  const activeTreatments = (treatments.data ?? []).filter((item: any) => item.isActive);
  const guideFallbacks = publishedGuides.filter((item: any) => !item.seoTitle?.trim() || !item.metaDescription?.trim());
  const missingArabicGuides = publishedGuides.filter((item: any) => Boolean(item.titleAr?.trim()) !== Boolean(item.summaryAr?.trim() || item.contentAr?.trim()));
  const sitemapEntries = 16 + publishedGuides.length + publishedGuides.filter((item: any) => item.titleAr?.trim() && (item.summaryAr?.trim() || item.contentAr?.trim())).length + publishedPolicies.length + publishedPolicies.filter((item: any) => item.titleAr?.trim() && item.contentAr?.trim()).length;

  return <section className="mt-4 space-y-4 border border-[#102032]/10 bg-white p-5"><div className="flex items-start gap-3"><Globe2 className="mt-0.5 size-5 shrink-0 text-[#B85E3C]" /><div><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">Published-content SEO health</p><p className="mt-1 text-sm leading-6 text-[#52606B]">Live local checks for canonical public pages and publication readiness. This dashboard does not claim Google indexing or Search Console performance.</p></div></div><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4"><Metric label="Current sitemap URLs" value={sitemapEntries} /><Metric label="Published guide pages" value={publishedGuides.length} /><Metric label="Published policies" value={publishedPolicies.length} /><Metric label="Active treatments" value={activeTreatments.length} /></div><div className="grid gap-3 lg:grid-cols-2"><div className="border border-[#102032]/10 p-4"><p className="flex items-center gap-2 text-sm font-bold text-[#102032]"><FileText className="size-4 text-[#B85E3C]" />Metadata fallbacks</p><p className="mt-2 text-sm leading-6 text-[#52606B]">{guideFallbacks.length ? `${guideFallbacks.length} published guide ${guideFallbacks.length === 1 ? "uses" : "use"} a title or description fallback. Add a custom SEO title and description when ready.` : "All published guides have custom SEO title and description fields."}</p></div><div className="border border-[#102032]/10 p-4"><p className="flex items-center gap-2 text-sm font-bold text-[#102032]">{missingArabicGuides.length ? <AlertTriangle className="size-4 text-[#B85E3C]" /> : <CheckCircle2 className="size-4 text-[#477953]" />}{missingArabicGuides.length ? "Arabic detail-page check" : "Arabic detail-page check passed"}</p><p className="mt-2 text-sm leading-6 text-[#52606B]">{missingArabicGuides.length ? `${missingArabicGuides.length} published guide record has incomplete Arabic detail content, so it remains English-only until Arabic title plus summary or content is supplied.` : "Published Arabic guide pages are included only when author-provided Arabic title and body content are both present."}</p></div></div><p className="text-xs leading-5 text-[#66727A]">The dynamic sitemap excludes admin, API, consent, draft, inactive, and approval-pending content. It refreshes from publication data on each request.</p></section>;
}
