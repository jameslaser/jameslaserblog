import { ArrowLeft, ArrowRight, ArrowUpRight, CalendarDays, Clock3, Copy, ExternalLink, Facebook, Linkedin, Send, Share2, ShieldCheck } from "lucide-react";
import { Fragment, useEffect, useMemo, useState } from "react";
import { Link, useRoute } from "wouter";
import { PublicSiteHeader } from "@/components/PublicSiteHeader";
import { trpc } from "@/lib/trpc";
import { publicUrl } from "@/seo";

type Locale = "en" | "ar";

type GuidePost = {
  slug: string;
  postType: "blog" | "video";
  titleEn: string;
  titleAr?: string | null;
  summaryEn?: string | null;
  summaryAr?: string | null;
  contentEn?: string | null;
  contentAr?: string | null;
  category?: string | null;
  tags?: string | null;
  featuredImageUrl?: string | null;
  featuredImageAltEn?: string | null;
  featuredImageAltAr?: string | null;
  videoUrl?: string | null;
  seoTitle?: string | null;
  metaDescription?: string | null;
  socialImageUrl?: string | null;
  socialCaptionEn?: string | null;
  socialCaptionAr?: string | null;
  socialHashtags?: string | null;
  authorName?: string | null;
  isClinicallyReviewed: boolean;
  publishedAt?: Date | null;
  updatedAt?: Date | null;
};

function setDocumentMetadata(title: string, description: string, canonicalPath: string, locale: Locale, image?: string | null, imageAlt?: string, publishedAt?: Date | null, updatedAt?: Date | null, category?: string | null) {
  document.title = title;
  const setMeta = (name: string, value: string) => {
    const element = document.querySelector(`meta[name="${name}"]`) || document.head.appendChild(document.createElement("meta"));
    element.setAttribute("name", name);
    element.setAttribute("content", value);
  };
  const setProperty = (property: string, value: string) => {
    const element = document.querySelector(`meta[property="${property}"]`) || document.head.appendChild(document.createElement("meta"));
    element.setAttribute("property", property);
    element.setAttribute("content", value);
  };
  const canonical = document.querySelector('link[rel="canonical"]') || document.head.appendChild(document.createElement("link"));
  canonical.setAttribute("rel", "canonical");
  canonical.setAttribute("href", publicUrl(canonicalPath));
  setMeta("description", description);
  setMeta("robots", "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1");
  setMeta("twitter:title", title);
  setMeta("twitter:description", description);
  setMeta("twitter:url", publicUrl(canonicalPath));
  setMeta("twitter:card", image ? "summary_large_image" : "summary");
  setProperty("og:type", "article");
  setProperty("og:site_name", "James Laser Hair Removal for Men Riyadh @ New Look Clinic");
  setProperty("og:title", title);
  setProperty("og:description", description);
  setProperty("og:url", publicUrl(canonicalPath));
  setProperty("og:locale", locale === "ar" ? "ar_SA" : "en_SA");
  if (publishedAt) setProperty("article:published_time", new Date(publishedAt).toISOString());
  if (updatedAt) setProperty("article:modified_time", new Date(updatedAt).toISOString());
  if (category) setProperty("article:section", category);
  if (image) {
    const absoluteImage = image.startsWith("/") ? publicUrl(image) : image;
    setProperty("og:image", absoluteImage);
    setProperty("og:image:alt", imageAlt || title);
    setMeta("twitter:image", absoluteImage);
  }
  document.documentElement.lang = locale;
  document.documentElement.dir = locale === "ar" ? "rtl" : "ltr";
}

function inlineText(value: string) {
  return value.split(/(\*\*[^*]+\*\*)/g).filter(Boolean).map((part, index) => part.startsWith("**") && part.endsWith("**") ? <strong key={`${part}-${index}`}>{part.slice(2, -2)}</strong> : <Fragment key={`${part}-${index}`}>{part}</Fragment>);
}

function ArticleBody({ content }: { content: string }) {
  const blocks = content.split(/\n\s*\n/).map(block => block.trim()).filter(Boolean);
  return <div className="blog-prose">{blocks.map((block, index) => {
    if (block.startsWith("### ")) return <h3 key={index}>{inlineText(block.slice(4))}</h3>;
    if (block.startsWith("## ")) return <h2 key={index}>{inlineText(block.slice(3))}</h2>;
    const lines = block.split("\n").map(line => line.trim()).filter(Boolean);
    if (lines.length && lines.every(line => /^[-*] /.test(line))) return <ul key={index}>{lines.map((line, lineIndex) => <li key={lineIndex}>{inlineText(line.replace(/^[-*] /, ""))}</li>)}</ul>;
    if (lines.length && lines.every(line => /^\d+\. /.test(line))) return <ol key={index}>{lines.map((line, lineIndex) => <li key={lineIndex}>{inlineText(line.replace(/^\d+\. /, ""))}</li>)}</ol>;
    return <p key={index}>{lines.map((line, lineIndex) => <Fragment key={lineIndex}>{lineIndex ? <br /> : null}{inlineText(line)}</Fragment>)}</p>;
  })}</div>;
}

function readingMinutes(content: string, arabic: boolean) {
  const words = content.trim().split(/\s+/).filter(Boolean).length;
  const minutes = Math.max(2, Math.ceil(words / (arabic ? 170 : 210)));
  return arabic ? `${minutes} دقائق قراءة` : `${minutes} min read`;
}

export default function PublicGuidePost({ locale = "en" }: { locale?: Locale }) {
  const arabic = locale === "ar";
  const [, params] = useRoute(arabic ? "/ar/blog/:slug" : "/en/blog/:slug");
  const slug = params?.slug ?? "";
  const guideQuery = trpc.publicContent.guidePostBySlug.useQuery({ slug }, { enabled: Boolean(slug) });
  const guide = guideQuery.data as GuidePost | null | undefined;
  const [copied, setCopied] = useState(false);
  const hasArabic = Boolean(guide?.titleAr?.trim() && (guide.contentAr?.trim() || guide.summaryAr?.trim()));
  const headline: string = guide ? ((arabic ? guide.titleAr || guide.titleEn : guide.titleEn) || "") : arabic ? "المقال غير منشور حاليًا" : "Article not currently published";
  const pageTitle: string = guide ? ((arabic ? guide.titleAr || guide.titleEn : guide.seoTitle || guide.titleEn) || headline) : headline;
  const description: string = guide ? ((arabic ? guide.summaryAr || guide.summaryEn || guide.metaDescription : guide.metaDescription || guide.summaryEn) || "") : arabic ? "هذا المقال غير متاح حاليًا." : "This article is not currently available.";
  const body: string = guide ? ((arabic ? guide.contentAr || guide.summaryAr || guide.contentEn || guide.summaryEn : guide.contentEn || guide.summaryEn) || "") : "";
  const canonicalPath = `/${arabic ? "ar" : "en"}/blog/${slug || "article"}`;
  const shareUrl = publicUrl(canonicalPath);
  const tags = guide?.tags?.split(",").map(tag => tag.trim()).filter(Boolean) ?? [];
  const imageAlt = guide ? (arabic ? guide.featuredImageAltAr || guide.featuredImageAltEn || headline : guide.featuredImageAltEn || guide.featuredImageAltAr || headline) : headline;
  const socialCaption = guide ? (arabic ? guide.socialCaptionAr || guide.socialCaptionEn : guide.socialCaptionEn || guide.socialCaptionAr) : null;
  const shareText = `${socialCaption || `${headline} — ${description}`}${guide?.socialHashtags ? `\n\n${guide.socialHashtags}` : ""}`.trim();

  useEffect(() => {
    if (!guide || (arabic && !hasArabic)) {
      const robots = document.querySelector('meta[name="robots"]') || document.head.appendChild(document.createElement("meta"));
      robots.setAttribute("name", "robots");
      robots.setAttribute("content", "noindex, follow, noarchive");
      return;
    }
    setDocumentMetadata(`${pageTitle} | ${arabic ? "جيمس ليزر" : "James Laser"}`, description, canonicalPath, locale, guide.socialImageUrl || guide.featuredImageUrl, imageAlt, guide.publishedAt, guide.updatedAt, guide.category);
  }, [arabic, canonicalPath, description, guide, hasArabic, imageAlt, locale, pageTitle]);

  const published = useMemo(() => guide?.publishedAt ? new Intl.DateTimeFormat(arabic ? "ar-SA" : "en-SA", { day: "numeric", month: "long", year: "numeric", timeZone: "Asia/Riyadh" }).format(new Date(guide.publishedAt)) : arabic ? "مراجَع من العيادة" : "Clinic reviewed", [arabic, guide?.publishedAt]);
  const copyLink = async () => {
    await navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };
  const nativeShare = async () => {
    if (navigator.share) await navigator.share({ title: headline, text: socialCaption || description, url: shareUrl });
    else await copyLink();
  };
  const openShare = (url: string) => window.open(url, "_blank", "noopener,noreferrer,width=720,height=620");

  if (guideQuery.isLoading) return <main className="grid min-h-screen place-items-center bg-[#F7F3EC] p-6 text-sm text-[#52606B]">{arabic ? "جارٍ تحميل المقال…" : "Loading article…"}</main>;
  if (!guide || (arabic && !hasArabic)) return <main lang={arabic ? "ar" : "en"} dir={arabic ? "rtl" : "ltr"} className="grid min-h-screen place-items-center bg-[#F7F3EC] p-6 text-[#102032]"><section className="max-w-xl border border-[#102032]/10 bg-white p-8 text-center"><ShieldCheck className="mx-auto size-8 text-[#B85E3C]" /><h1 className="mt-5 font-display text-4xl">{arabic ? "هذا المقال غير متاح" : "This article is not available"}</h1><p className="mt-3 text-sm leading-6 text-[#52606B]">{arabic ? "ارجع إلى المدونة لعرض المعلومات المنشورة حاليًا." : "Return to the blog to view currently published information."}</p><Link href={arabic ? "/ar/blog" : "/en/blog"} className="mt-6 inline-flex items-center gap-2 bg-[#102032] px-4 py-3 text-xs font-bold uppercase tracking-[0.12em] text-white">{arabic ? <ArrowRight className="size-4" /> : <ArrowLeft className="size-4" />}{arabic ? "العودة إلى المدونة" : "Back to blog"}</Link></section></main>;

  const blogHub = arabic ? "/ar/blog" : "/en/blog";
  const appointmentPath = arabic ? "/ar/appointment" : "/appointment";
  const alternatePath = hasArabic ? (arabic ? `/en/blog/${guide.slug}` : `/ar/blog/${guide.slug}`) : null;
  return <main lang={arabic ? "ar" : "en"} dir={arabic ? "rtl" : "ltr"} className="min-h-screen bg-[#F7F3EC] text-[#102032]"><PublicSiteHeader locale={locale} active="blog" /><article><header className="border-b border-[#102032]/10 bg-[#EDE5D8]"><div className="mx-auto max-w-5xl px-4 py-12 sm:px-6 sm:py-16"><nav aria-label={arabic ? "مسار الصفحة" : "Breadcrumb"} className="flex flex-wrap items-center gap-2 text-[11px] font-bold uppercase tracking-[0.12em] text-[#66727A]"><Link href={arabic ? "/ar" : "/"}>{arabic ? "الرئيسية" : "Home"}</Link><span aria-hidden="true">/</span><Link href={blogHub}>{arabic ? "المدونة" : "Blog"}</Link></nav><p className="mt-8 text-[10px] font-extrabold uppercase tracking-[0.2em] text-[#B85E3C]">{guide.category || (guide.postType === "video" ? (arabic ? "فيديو إرشادي" : "Video guide") : (arabic ? "تثقيف المرضى" : "Patient education"))}</p><h1 className={`mt-4 max-w-4xl text-5xl tracking-[-0.055em] sm:text-6xl lg:text-7xl ${arabic ? "font-sans font-extrabold leading-[1.18]" : "font-display leading-[0.94]"}`}>{headline}</h1><p className="mt-6 max-w-3xl text-lg leading-8 text-[#52606B]">{arabic ? guide.summaryAr || guide.summaryEn : guide.summaryEn || guide.summaryAr}</p><div className="mt-7 flex flex-wrap items-center gap-x-5 gap-y-3 text-xs text-[#66727A]"><span className="font-bold text-[#102032]">{guide.authorName || (arabic ? "فريق جيمس ليزر" : "James Laser editorial team")}</span><span className="inline-flex items-center gap-2"><CalendarDays className="size-4 text-[#B85E3C]" />{published}</span><span className="inline-flex items-center gap-2"><Clock3 className="size-4 text-[#B85E3C]" />{readingMinutes(body, arabic)}</span><span className="inline-flex items-center gap-2"><ShieldCheck className="size-4 text-[#B85E3C]" />{guide.isClinicallyReviewed ? (arabic ? "مراجَع قبل النشر" : "Reviewed before publication") : (arabic ? "مقال تثقيفي منشور" : "Published educational article")}</span></div></div></header>{guide.featuredImageUrl ? <div className="mx-auto max-w-6xl px-4 pt-10 sm:px-6"><img src={guide.featuredImageUrl} alt={imageAlt} className="max-h-[620px] w-full border border-[#102032]/10 object-cover" /></div> : null}<div className="mx-auto grid max-w-5xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[minmax(0,1fr)_190px] lg:py-16"><div><ArticleBody content={body} />{guide.videoUrl ? <a href={guide.videoUrl} target="_blank" rel="noreferrer" className="mt-8 inline-flex min-h-11 items-center gap-2 border border-[#102032]/20 px-4 text-xs font-bold uppercase tracking-[0.12em] text-[#102032]">{arabic ? "مشاهدة الفيديو" : "Watch video"}<ExternalLink className="size-4 text-[#B85E3C]" /></a> : null}{tags.length ? <div className="mt-10 flex flex-wrap gap-2" aria-label={arabic ? "وسوم المقال" : "Article tags"}>{tags.map(tag => <span key={tag} className="border border-[#102032]/10 bg-white px-3 py-1.5 text-xs text-[#52606B]">{tag}</span>)}</div> : null}<section className="mt-14 border-t border-[#102032]/10 pt-8"><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#B85E3C]">{arabic ? "معلومة مهمة" : "Important note"}</p><p className="mt-3 text-sm leading-7 text-[#52606B]">{arabic ? "هذه المقالة للتثقيف العام ولا تستبدل التقييم الفردي. تختلف الاستجابة للعلاج، وتؤكد العيادة الملاءمة والإعدادات والتعليمات لكل حالة." : "This article is for general education and does not replace an individual assessment. Treatment response varies, and the clinic confirms suitability, settings, and instructions for each person."}</p></section><section className="mt-12 border-t border-[#102032]/10 pt-8"><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#B85E3C]">{arabic ? "الخطوة التالية" : "Next step"}</p><h2 className={`mt-3 text-3xl ${arabic ? "font-sans font-extrabold" : "font-display"}`}>{arabic ? "اطلب موعدك المفضل" : "Request your preferred appointment"}</h2><p className="mt-3 max-w-xl text-sm leading-6 text-[#52606B]">{arabic ? "تؤكد العيادة التوفر والخطوة التالية بشكل منفصل." : "The clinic confirms availability and the next step separately."}</p><div className="mt-5 flex flex-wrap gap-3"><Link href={appointmentPath} className="inline-flex items-center gap-2 bg-[#B85E3C] px-4 py-3 text-xs font-bold uppercase tracking-[0.12em] text-white">{arabic ? "طلب موعد" : "Request appointment"}<CalendarDays className="size-4" /></Link>{alternatePath ? <Link href={alternatePath} lang={arabic ? "en" : "ar"} className="inline-flex items-center gap-2 border border-[#102032]/20 px-4 py-3 text-xs font-bold">{arabic ? "English" : "العربية"}<ArrowUpRight className="size-4" /></Link> : null}</div></section></div><aside className="lg:sticky lg:top-24 lg:self-start"><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#66727A]">{arabic ? "شارك المقال" : "Share article"}</p><div className="mt-3 grid grid-cols-2 gap-2 lg:grid-cols-1"><button type="button" onClick={nativeShare} className="blog-share-button"><Share2 className="size-4" />{arabic ? "مشاركة" : "Share"}</button><button type="button" onClick={() => openShare(`https://wa.me/?text=${encodeURIComponent(`${shareText}\n${shareUrl}`)}`)} className="blog-share-button"><Send className="size-4" />WhatsApp</button><button type="button" onClick={() => openShare(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`)} className="blog-share-button"><Facebook className="size-4" />Facebook</button><button type="button" onClick={() => openShare(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`)} className="blog-share-button"><Linkedin className="size-4" />LinkedIn</button><button type="button" onClick={() => openShare(`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText.slice(0, 240))}&url=${encodeURIComponent(shareUrl)}`)} className="blog-share-button"><span className="w-4 text-center font-black">X</span>X</button><button type="button" onClick={copyLink} className="blog-share-button"><Copy className="size-4" />{copied ? (arabic ? "تم النسخ" : "Copied") : (arabic ? "نسخ الرابط" : "Copy link")}</button></div></aside></div></article></main>;
}
