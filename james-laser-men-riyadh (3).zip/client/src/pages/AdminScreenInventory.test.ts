import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

const read = (file: string) => fs.readFileSync(path.resolve(process.cwd(), file), "utf8");
const portal = read("client/src/pages/AdminPortal.tsx");
const operations = read("client/src/pages/AdminOperations.tsx");
const requests = read("client/src/pages/AdminRequestsWorkspace.tsx");
const revenue = read("client/src/pages/RevenueWorkspace.tsx");
const whatsapp = read("client/src/pages/WhatsAppWorkspace.tsx");
const cms = read("client/src/pages/CmsManager.tsx");
const catalogues = read("client/src/pages/CmsCatalogues.tsx");
const education = read("client/src/pages/CmsEducation.tsx");
const calendar = read("client/src/pages/ContentCalendar.tsx");

describe("authenticated screen inventory", () => {
  it("covers dashboard, requests, appointments, waiting list, patients, machines, and attention tasks", () => {
    for (const marker of ["function AdminDashboard(", "function Appointments(", "function WaitingList(", "function Patients(", "function Machines(", "AdminAttentionAgent", "HmsImportPanel", "ManualAppointmentPanel", "ManualPatientPanel"]) expect(portal).toContain(marker);
    for (const query of ["trpc.admin.dashboard", "trpc.admin.appointments", "trpc.admin.waitingList", "trpc.admin.patients", "trpc.admin.machines"]) expect(portal).toContain(query);
    expect(portal).toContain("export function Appointments()");
    expect(portal).toContain('AdminLoadingState label="Loading waiting list…"');
    expect(portal).toContain("Waiting list unavailable");
    expect(requests).toContain("AdminFilterBar");
    expect(requests).toContain("transferPayload");
    expect(requests).toContain("Review & approve");
  });

  it("covers revenue, analytics, data export, redirects, and reporting boundaries", () => {
    for (const marker of ["revenuePreview", "revenueImport", "revenueWorkspace", "HMS TOTAL RECONCILIATION FAILED", "HMS remains the source of truth"]) expect(revenue).toContain(marker);
    for (const marker of ["function Analytics(", "function DataAndBackup(", "function Redirects(", "Anonymous event totals", "Task Data Backup", "server-enforced permanent 301 redirects"]) expect(operations).toContain(marker);
  });

  it("covers CMS, notifications, staff security, audit, settings, and editorial tasks", () => {
    for (const marker of ["function Security(", "SettingsControlCenter", "function Notifications(", "function Library(", "staffUsers", "recentActivity", "seoSettings", "mediaItems", "policies"]) expect(cms).toContain(marker);
    for (const marker of ["TreatmentCatalogue", "AdminPageHeader"]) expect(catalogues).toContain(marker);
    for (const marker of ["GuideWorkspace", "FaqWorkspace", "AdminPageHeader"]) expect(education).toContain(marker);
    for (const marker of ["contentCalendarItems", "External-action safeguard", "owner-authorized access", "Planning status never makes public or external content live"]) expect(calendar).toContain(marker);
  });

  it("covers protected WhatsApp integration, webhook, template, and service-window controls", () => {
    for (const marker of ["serviceWindowOpen", "approved template", "webhookEvents", "renderWebhookLogs", "renderSettings", "Provider-ready architecture", "Enable verified automation"]) expect(whatsapp).toContain(marker);
  });
});

describe("remaining management async-state branches", () => {
  it("keeps machine loading, error, empty-or-loaded, and save branches", () => {
    expect(portal).toContain("inventory.isLoading");
    expect(portal).toContain("inventory.isError");
    expect(portal).toContain("inventory.data?.map");
    expect(portal).toContain("update.mutate");
  });

  it("keeps notification loading, error, empty, loaded, and action branches", () => {
    expect(cms).toContain("if (inbox.isLoading)");
    expect(cms).toContain("if (inbox.isError)");
    expect(cms).toContain("No staff notifications yet");
    expect(cms).toContain("inbox.data.map");
    expect(cms).toContain("markNotificationRead");
  });

  it("keeps staff-security loading, error, empty, loaded, and owner-role branches", () => {
    expect(cms).toContain("users.isLoading");
    expect(cms).toContain("users.isError");
    expect(cms).toContain("users.data?.length === 0");
    expect(cms).toContain("users.data?.map");
    expect(cms).toContain('user.role === "owner"');
    expect(cms).toContain("updateStaffRole");
  });

  it("keeps activity, SEO, language, media, and policy query-state branches", () => {
    expect(cms).toContain("activeQuery.isLoading");
    expect(cms).toContain("activeQuery.isError");
    expect(cms).toContain("records?.length");
    expect(cms).toContain("No records exist yet");
    for (const page of ['page === "activity"', 'page === "seo"', 'page === "languages"', 'page === "media"', 'page === "policies"']) expect(cms).toContain(page);
  });
});
