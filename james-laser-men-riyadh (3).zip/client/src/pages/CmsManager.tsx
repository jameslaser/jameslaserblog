import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Check, Copy, Link2, Loader2, MapPinned, Plus, RefreshCw, Save, ShieldCheck, Trash2, X } from "lucide-react";
import React, { FormEvent, useEffect, useState } from "react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { TreatmentCatalogue } from "./CmsCatalogues";
import { PromotionCatalogue } from "./PromotionCatalogueUpload";
import { ResultCases } from "./ResultCasesUpload";
import { FaqWorkspace, GuideWorkspace } from "./CmsEducation";
import ContentCalendar from "./ContentCalendar";
import { SeoHealthDashboard } from "./SeoHealthDashboard";
import { AdminEmptyState, AdminErrorState, AdminLoadingState, AdminPageHeader } from "@/components/AdminUi";
import { translateAdminText, useAdminLocale } from "@/contexts/AdminLocaleContext";
import { SettingsControlCenter } from "@/components/SettingsControlCenter";
import { InstantDraftButton } from "@/components/InstantDraftButton";
import { fillHomepageDraft, fillSeoDraft } from "@/lib/instantDrafts";
import { getGoogleBusinessSyncFeedback } from "@/lib/googleBusinessSyncFeedback";
import { HomepageAppearance } from "./HomepageAppearance";

export type CmsPage = "clinic" | "appearance" | "content" | "treatments" | "promotions" | "reviews" | "results" | "guide" | "calendar" | "faqs" | "media" | "policies" | "seo" | "languages" | "activity" | "security" | "notifications" | "settings";

const blankToNull = (value: string) => value.trim() || null;
const numericToNull = (value: string) => value.trim() || null;

function SeoConfigurationOverview() {
  const seo = trpc.cms.seoSettings.useQuery();
  if (seo.isLoading || seo.isError) return null;
  const records = seo.data ?? [];
  const summary = {
    locales: records.length,
    indexable: records.filter(item => item.robotsIndex).length,
    missingTitles: records.filter(item => !item.title.trim()).length,
    missingDescriptions: records.filter(item => !item.metaDescription?.trim()).length,
  };
  return <section className="mt-6 space-y-4 border border-[#102032]/10 bg-white p-5"><div><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">SEO configuration overview</p><p className="mt-2 text-sm leading-6 text-[#52606B]">These are local configuration checks only. Search impressions, clicks, CTR, position, and indexing require owner-authorized Search Console access and are never estimated here.</p></div><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4"><div className="border border-[#102032]/10 bg-[#F7F3EC] p-3"><p className="text-2xl font-bold text-[#102032]">{summary.locales}</p><p className="mt-1 text-xs font-semibold text-[#52606B]">Configured locales</p></div><div className="border border-[#102032]/10 bg-[#F7F3EC] p-3"><p className="text-2xl font-bold text-[#102032]">{summary.indexable}</p><p className="mt-1 text-xs font-semibold text-[#52606B]">Indexable locales</p></div><div className="border border-[#102032]/10 bg-[#F7F3EC] p-3"><p className="text-2xl font-bold text-[#102032]">{summary.missingTitles}</p><p className="mt-1 text-xs font-semibold text-[#52606B]">Missing titles</p></div><div className="border border-[#102032]/10 bg-[#F7F3EC] p-3"><p className="text-2xl font-bold text-[#102032]">{summary.missingDescriptions}</p><p className="mt-1 text-xs font-semibold text-[#52606B]">Missing descriptions</p></div></div><div className="grid gap-2 text-sm text-[#52606B]"><p><strong className="text-[#102032]">Sitemap:</strong> configured for the production canonical domain.</p><p><strong className="text-[#102032]">Protected routes:</strong> `/admin` remains excluded from crawl configuration and requires authentication.</p><p><strong className="text-[#102032]">Search Console import:</strong> requires owner access; no Google metric is stored in this portal until that connection is authorized.</p></div></section>;
}

function Header({ eyebrow, title, description }: { eyebrow: string; title: string; description: string }) {
  return <><AdminPageHeader eyebrow={eyebrow} title={title} description={description} />{title === "SEO controls" ? <><SeoConfigurationOverview /><SeoHealthDashboard /></> : null}</>;
}
function QueryFailure({ label, onRetry }: { label: string; onRetry: () => void }) { return <AdminErrorState title={`${label} unavailable`} description={`${label} could not be loaded from the secure CMS.`} onRetry={onRetry} />; }

function Field({ label, children }: { label: string; children: React.ReactNode }) { return <label className="grid gap-1.5 text-xs font-bold text-[#102032]"><span>{label}</span>{children}</label>; }
function Area({ value, onChange, placeholder }: { value: string; onChange: (value: string) => void; placeholder?: string }) { return <textarea value={value} onChange={event => onChange(event.target.value)} placeholder={placeholder} className="min-h-24 w-full resize-y border border-[#102032]/20 bg-white px-3 py-2 text-sm outline-none transition focus:ring-2 focus:ring-[#a85438]" />; }
function DraftPreview({ title, description, arabicTitle }: { title: string; description?: string; arabicTitle?: string }) { const [open, setOpen] = useState(false); return <div className="space-y-3"><Button type="button" variant="outline" onClick={() => setOpen(!open)}>Preview draft</Button>{open ? <aside className="border border-[#B85E3C]/35 bg-[#102032] p-4 text-white"><p className="text-[10px] font-extrabold uppercase tracking-[0.14em] text-[#EAB394]">Private draft preview</p><p className="mt-3 font-display text-2xl">{title || "Untitled content"}</p>{description ? <p className="mt-2 text-sm leading-6 text-white/70">{description}</p> : null}{arabicTitle ? <p lang="ar" dir="rtl" className="mt-3 text-right text-lg text-white/85">{arabicTitle}</p> : null}</aside> : null}</div>; }

function ClinicInformation() {
  const settings = trpc.cms.clinicSettings.useQuery();
  const utils = trpc.useUtils();
  const [form, setForm] = useState<Record<string, string | boolean>>({});
  useEffect(() => { if (settings.data) setForm({ businessName: settings.data.businessName, specialistName: settings.data.specialistName, professionalTitle: settings.data.professionalTitle ?? "", clinicName: settings.data.clinicName, addressEn: settings.data.addressEn ?? "", addressAr: settings.data.addressAr ?? "", mapsUrl: settings.data.mapsUrl ?? "", whatsapp: settings.data.whatsapp, telephone: settings.data.telephone ?? "", email: settings.data.email ?? "", workingHours: settings.data.workingHours, instagramUrl: settings.data.instagramUrl ?? "", tiktokUrl: settings.data.tiktokUrl ?? "", snapchatUrl: settings.data.snapchatUrl ?? "", facebookUrl: settings.data.facebookUrl ?? "", youtubeUrl: settings.data.youtubeUrl ?? "", xUrl: settings.data.xUrl ?? "", googleBusinessUrl: settings.data.googleBusinessUrl ?? "", appointmentFormEnabled: settings.data.appointmentFormEnabled, preferredTimes: settings.data.preferredTimes ?? "" }); }, [settings.data]);
  const save = trpc.cms.updateClinicSettings.useMutation({ onSuccess: async () => { toast.success("Clinic information saved."); await utils.cms.clinicSettings.invalidate(); }, onError: error => toast.error(error.message) });
  if (settings.isLoading) return <div className="grid min-h-64 place-items-center"><Loader2 className="animate-spin text-[#a85438]" /></div>;
  if (settings.isError) return <div className="mx-auto max-w-5xl"><Header eyebrow="Central website details" title="Clinic information" description="Edit business contact details once. Approved public website sections use these central values instead of duplicated contact copy." /><QueryFailure label="Clinic information" onRetry={() => settings.refetch()} /></div>;
  const set = (key: string, value: string | boolean) => setForm(previous => ({ ...previous, [key]: value }));
  const submit = (event: FormEvent) => { event.preventDefault(); save.mutate({ businessName: String(form.businessName ?? ""), specialistName: String(form.specialistName ?? ""), professionalTitle: blankToNull(String(form.professionalTitle ?? "")), clinicName: String(form.clinicName ?? ""), addressEn: blankToNull(String(form.addressEn ?? "")), addressAr: blankToNull(String(form.addressAr ?? "")), mapsUrl: blankToNull(String(form.mapsUrl ?? "")), whatsapp: String(form.whatsapp ?? ""), telephone: blankToNull(String(form.telephone ?? "")), email: blankToNull(String(form.email ?? "")), workingHours: String(form.workingHours ?? ""), instagramUrl: blankToNull(String(form.instagramUrl ?? "")), tiktokUrl: blankToNull(String(form.tiktokUrl ?? "")), snapchatUrl: blankToNull(String(form.snapchatUrl ?? "")), facebookUrl: blankToNull(String(form.facebookUrl ?? "")), youtubeUrl: blankToNull(String(form.youtubeUrl ?? "")), xUrl: blankToNull(String(form.xUrl ?? "")), googleBusinessUrl: blankToNull(String(form.googleBusinessUrl ?? "")), appointmentFormEnabled: Boolean(form.appointmentFormEnabled), preferredTimes: blankToNull(String(form.preferredTimes ?? "")) }); };
  return <div className="mx-auto max-w-5xl"><Header eyebrow="Central website details" title="Clinic information" description="Edit business contact details once. Approved public website sections will use these central values instead of duplicated contact copy." /><form onSubmit={submit} className="space-y-6"><section className="grid gap-4 border border-[#102032]/10 bg-white p-5 sm:grid-cols-2"><Field label="Business name"><Input required value={String(form.businessName ?? "")} onChange={event => set("businessName", event.target.value)} /></Field><Field label="Clinic name"><Input required value={String(form.clinicName ?? "")} onChange={event => set("clinicName", event.target.value)} /></Field><Field label="Specialist name"><Input required value={String(form.specialistName ?? "")} onChange={event => set("specialistName", event.target.value)} /></Field><Field label="Professional title"><Input value={String(form.professionalTitle ?? "")} onChange={event => set("professionalTitle", event.target.value)} /></Field><Field label="Primary WhatsApp"><Input required value={String(form.whatsapp ?? "")} onChange={event => set("whatsapp", event.target.value)} /></Field><Field label="Telephone"><Input value={String(form.telephone ?? "")} onChange={event => set("telephone", event.target.value)} /></Field><Field label="Email"><Input type="email" value={String(form.email ?? "")} onChange={event => set("email", event.target.value)} /></Field><Field label="Working hours"><Input required value={String(form.workingHours ?? "")} onChange={event => set("workingHours", event.target.value)} /></Field><Field label="Google Maps URL"><Input value={String(form.mapsUrl ?? "")} onChange={event => set("mapsUrl", event.target.value)} /></Field><Field label="Google Business URL"><Input value={String(form.googleBusinessUrl ?? "")} onChange={event => set("googleBusinessUrl", event.target.value)} /></Field><Field label="Address — English"><Area value={String(form.addressEn ?? "")} onChange={value => set("addressEn", value)} /></Field><Field label="Address — Arabic"><Area value={String(form.addressAr ?? "")} onChange={value => set("addressAr", value)} /></Field></section><section className="grid gap-4 border border-[#102032]/10 bg-white p-5 sm:grid-cols-2"><Field label="Instagram URL"><Input value={String(form.instagramUrl ?? "")} onChange={event => set("instagramUrl", event.target.value)} /></Field><Field label="TikTok URL"><Input value={String(form.tiktokUrl ?? "")} onChange={event => set("tiktokUrl", event.target.value)} /></Field><Field label="Snapchat URL"><Input value={String(form.snapchatUrl ?? "")} onChange={event => set("snapchatUrl", event.target.value)} /></Field><Field label="Facebook URL"><Input value={String(form.facebookUrl ?? "")} onChange={event => set("facebookUrl", event.target.value)} /></Field><Field label="YouTube URL"><Input value={String(form.youtubeUrl ?? "")} onChange={event => set("youtubeUrl", event.target.value)} /></Field><Field label="X URL"><Input value={String(form.xUrl ?? "")} onChange={event => set("xUrl", event.target.value)} /></Field><Field label="Preferred appointment times"><Area value={String(form.preferredTimes ?? "")} onChange={value => set("preferredTimes", value)} placeholder="One time window per line" /></Field><label className="flex items-center gap-3 self-end pb-4 text-sm font-semibold text-[#102032]"><input type="checkbox" checked={Boolean(form.appointmentFormEnabled)} onChange={event => set("appointmentFormEnabled", event.target.checked)} />Enable public appointment request form</label></section><Button type="submit" disabled={save.isPending}>{save.isPending ? <Loader2 className="mr-2 size-4 animate-spin" /> : <Save className="mr-2 size-4" />}Save clinic information</Button></form></div>;
}

function HomepageContent() {
  const sections = trpc.cms.homepageSections.useQuery();
  const utils = trpc.useUtils();
  const [form, setForm] = useState({ sectionKey: "", titleEn: "", subtitleEn: "", descriptionEn: "", titleAr: "", subtitleAr: "", descriptionAr: "", ctaText: "", ctaLink: "", imageUrl: "", videoUrl: "", isVisible: true, displayOrder: "0", status: "draft" as "draft" | "published" });
  const [showPreview, setShowPreview] = useState(false);
  const save = trpc.cms.saveHomepageSection.useMutation({ onSuccess: async () => { toast.success("Homepage section saved."); setForm(previous => ({ ...previous, sectionKey: "" })); await utils.cms.homepageSections.invalidate(); }, onError: error => toast.error(error.message) });
  const set = (key: keyof typeof form, value: string | boolean) => setForm(previous => ({ ...previous, [key]: value }));
  const generateDraft = () => setForm(current => fillHomepageDraft(current));
  const submit = (event: FormEvent) => { event.preventDefault(); save.mutate({ sectionKey: form.sectionKey, titleEn: blankToNull(form.titleEn), subtitleEn: blankToNull(form.subtitleEn), descriptionEn: blankToNull(form.descriptionEn), titleAr: blankToNull(form.titleAr), subtitleAr: blankToNull(form.subtitleAr), descriptionAr: blankToNull(form.descriptionAr), ctaText: blankToNull(form.ctaText), ctaLink: blankToNull(form.ctaLink), imageUrl: blankToNull(form.imageUrl), videoUrl: blankToNull(form.videoUrl), isVisible: form.isVisible, displayOrder: Number(form.displayOrder) || 0, status: form.status }); };
  if (sections.isError) return <div className="mx-auto max-w-6xl"><Header eyebrow="Public website CMS" title="Homepage content" description="Save a draft to keep it private. Preview its copy before publishing; empty sections do not change the live homepage." /><QueryFailure label="Homepage content" onRetry={() => sections.refetch()} /></div>;
  return <div className="mx-auto max-w-6xl"><Header eyebrow="Public website CMS" title="Homepage content" description="Save a draft to keep it private. Preview its copy before publishing; empty sections do not change the live homepage." /><div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]"><form onSubmit={submit} className="grid gap-4 border border-[#102032]/10 bg-white p-5 sm:grid-cols-2"><InstantDraftButton className="sm:col-span-2" onGenerate={generateDraft} /><Field label="Section key"><Input required value={form.sectionKey} onChange={event => set("sectionKey", event.target.value)} placeholder="hero, about, final-cta" /></Field><Field label="Display order"><Input type="number" min="0" value={form.displayOrder} onChange={event => set("displayOrder", event.target.value)} /></Field><Field label="English title"><Input value={form.titleEn} onChange={event => set("titleEn", event.target.value)} /></Field><Field label="Arabic title"><Input dir="rtl" value={form.titleAr} onChange={event => set("titleAr", event.target.value)} /></Field><Field label="English subtitle"><Input value={form.subtitleEn} onChange={event => set("subtitleEn", event.target.value)} /></Field><Field label="Arabic subtitle"><Input dir="rtl" value={form.subtitleAr} onChange={event => set("subtitleAr", event.target.value)} /></Field><div className="sm:col-span-2"><Field label="English description"><Area value={form.descriptionEn} onChange={value => set("descriptionEn", value)} /></Field></div><div className="sm:col-span-2"><Field label="Arabic description"><Area value={form.descriptionAr} onChange={value => set("descriptionAr", value)} /></Field></div><Field label="CTA text"><Input value={form.ctaText} onChange={event => set("ctaText", event.target.value)} /></Field><Field label="CTA link"><Input value={form.ctaLink} onChange={event => set("ctaLink", event.target.value)} /></Field><Field label="Image URL"><Input value={form.imageUrl} onChange={event => set("imageUrl", event.target.value)} /></Field><Field label="Video URL"><Input value={form.videoUrl} onChange={event => set("videoUrl", event.target.value)} /></Field><label className="flex items-center gap-2 text-sm font-semibold"><input type="checkbox" checked={form.isVisible} onChange={event => set("isVisible", event.target.checked)} />Show section</label><Field label="Publish state"><select value={form.status} onChange={event => set("status", event.target.value)} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm"><option value="draft">Save draft</option><option value="published">Publish</option></select></Field><div className="flex flex-wrap gap-3 sm:col-span-2"><Button type="button" variant="outline" onClick={() => setShowPreview(!showPreview)}>Preview draft</Button><Button type="submit" disabled={save.isPending}>{save.isPending ? <Loader2 className="mr-2 size-4 animate-spin" /> : <Save className="mr-2 size-4" />}Save section</Button></div></form><section className="space-y-3">{showPreview ? <article className="border border-[#B85E3C]/40 bg-[#102032] p-5 text-white"><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#EAB394]">Draft preview · {form.sectionKey || "section"}</p><h2 className="mt-4 font-display text-3xl">{form.titleEn || "English title preview"}</h2><p className="mt-3 text-sm leading-6 text-white/70">{form.descriptionEn || "English description preview"}</p>{form.titleAr || form.descriptionAr ? <div lang="ar" dir="rtl" className="mt-5 border-t border-white/20 pt-4 text-right"><p className="font-display text-2xl">{form.titleAr}</p><p className="mt-2 text-sm leading-6 text-white/70">{form.descriptionAr}</p></div> : null}{form.ctaText ? <span className="mt-5 inline-block border border-white/40 px-3 py-2 text-[10px] font-extrabold uppercase tracking-[0.14em]">{form.ctaText}</span> : null}</article> : null}{sections.isLoading ? <Loader2 className="animate-spin text-[#a85438]" /> : sections.data?.length === 0 ? <p className="border border-dashed border-[#102032]/20 bg-white p-6 text-sm text-[#52606B]">No CMS sections saved yet. Create a draft when you are ready to manage a public section.</p> : sections.data?.map(section => <article key={section.id} className="border border-[#102032]/10 bg-white p-4"><div className="flex items-center justify-between gap-3"><div><p className="font-semibold text-[#102032]">{section.sectionKey}</p><p className="mt-1 text-xs text-[#52606B]">{section.titleEn || "No English title"}</p></div><Badge variant={section.status === "published" ? "default" : "outline"}>{section.status}</Badge></div></article>)}</section></div></div>;
}

function Treatments() {
  const treatments = trpc.cms.treatments.useQuery(); const utils = trpc.useUtils(); const [form, setForm] = useState({ slug: "", nameEn: "", nameAr: "", shortDescriptionEn: "", shortDescriptionAr: "", startingPrice: "", regularPrice: "", promotionalPrice: "", durationMinutes: "", isActive: false, isFeatured: false, displayOrder: "0" });
  const save = trpc.cms.saveTreatment.useMutation({ onSuccess: async () => { toast.success("Treatment saved."); setForm({ slug: "", nameEn: "", nameAr: "", shortDescriptionEn: "", shortDescriptionAr: "", startingPrice: "", regularPrice: "", promotionalPrice: "", durationMinutes: "", isActive: false, isFeatured: false, displayOrder: "0" }); await utils.cms.treatments.invalidate(); }, onError: error => toast.error(error.message) }); const remove = trpc.cms.deleteTreatment.useMutation({ onSuccess: () => utils.cms.treatments.invalidate(), onError: error => toast.error(error.message) }); const set = (key: keyof typeof form, value: string | boolean) => setForm(previous => ({ ...previous, [key]: value }));
  const submit = (event: FormEvent) => { event.preventDefault(); save.mutate({ slug: form.slug, nameEn: form.nameEn, nameAr: blankToNull(form.nameAr), shortDescriptionEn: blankToNull(form.shortDescriptionEn), shortDescriptionAr: blankToNull(form.shortDescriptionAr), descriptionEn: null, descriptionAr: null, imageUrl: null, startingPrice: numericToNull(form.startingPrice), regularPrice: numericToNull(form.regularPrice), promotionalPrice: numericToNull(form.promotionalPrice), durationMinutes: form.durationMinutes ? Number(form.durationMinutes) : null, preparationEn: null, preparationAr: null, aftercareEn: null, aftercareAr: null, seoTitle: null, seoDescription: null, isActive: form.isActive, isFeatured: form.isFeatured, displayOrder: Number(form.displayOrder) || 0 }); };
  return <div className="mx-auto max-w-6xl"><Header eyebrow="Service catalogue" title="Treatments" description="Create treatment entries in draft state. Prices stay blank unless you explicitly enter them; only active treatments may be displayed publicly later." /><div className="grid gap-6 xl:grid-cols-[1fr_1fr]"><form onSubmit={submit} className="grid gap-4 border border-[#102032]/10 bg-white p-5 sm:grid-cols-2"><Field label="URL slug"><Input required value={form.slug} onChange={event => set("slug", event.target.value)} placeholder="full-face" /></Field><Field label="Treatment name — English"><Input required value={form.nameEn} onChange={event => set("nameEn", event.target.value)} /></Field><Field label="Treatment name — Arabic"><Input dir="rtl" value={form.nameAr} onChange={event => set("nameAr", event.target.value)} /></Field><Field label="Duration (minutes)"><Input type="number" min="1" value={form.durationMinutes} onChange={event => set("durationMinutes", event.target.value)} /></Field><Field label="Starting price"><Input inputMode="decimal" value={form.startingPrice} onChange={event => set("startingPrice", event.target.value)} /></Field><Field label="Regular price"><Input inputMode="decimal" value={form.regularPrice} onChange={event => set("regularPrice", event.target.value)} /></Field><div className="sm:col-span-2"><Field label="Short description — English"><Area value={form.shortDescriptionEn} onChange={value => set("shortDescriptionEn", value)} /></Field></div><div className="sm:col-span-2"><Field label="Short description — Arabic"><Area value={form.shortDescriptionAr} onChange={value => set("shortDescriptionAr", value)} /></Field></div><label className="flex items-center gap-2 text-sm font-semibold"><input type="checkbox" checked={form.isActive} onChange={event => set("isActive", event.target.checked)} />Active for publishing</label><label className="flex items-center gap-2 text-sm font-semibold"><input type="checkbox" checked={form.isFeatured} onChange={event => set("isFeatured", event.target.checked)} />Featured</label><Button className="sm:col-span-2" type="submit" disabled={save.isPending}><Plus className="mr-2 size-4" />Save treatment</Button></form><section className="space-y-3">{treatments.data?.map(treatment => <article key={treatment.id} className="flex items-center justify-between gap-3 border border-[#102032]/10 bg-white p-4"><div><p className="font-semibold text-[#102032]">{treatment.nameEn}</p><p className="mt-1 text-xs text-[#52606B]">/{treatment.slug} · {treatment.isActive ? "Active" : "Draft"}</p></div><Button size="icon" variant="ghost" aria-label={`Delete ${treatment.nameEn}`} onClick={() => { if (window.confirm(`Delete ${treatment.nameEn}?`)) remove.mutate({ id: treatment.id }); }}><Trash2 className="size-4 text-red-700" /></Button></article>)}</section></div></div>;
}

function Promotions() {
  const promotions = trpc.cms.promotions.useQuery(); const utils = trpc.useUtils(); const [form, setForm] = useState({ slug: "", name: "", titleEn: "", titleAr: "", descriptionEn: "", originalPrice: "", promotionalPrice: "", sessions: "", status: "draft" as "draft" | "published" | "paused" | "archived", featured: false }); const save = trpc.cms.savePromotion.useMutation({ onSuccess: async () => { toast.success("Promotion saved."); await utils.cms.promotions.invalidate(); }, onError: error => toast.error(error.message) }); const remove = trpc.cms.deletePromotion.useMutation({ onSuccess: () => utils.cms.promotions.invalidate(), onError: error => toast.error(error.message) }); const set = (key: keyof typeof form, value: string | boolean) => setForm(previous => ({ ...previous, [key]: value }));
  const submit = (event: FormEvent) => { event.preventDefault(); save.mutate({ slug: form.slug, name: form.name, titleEn: form.titleEn, titleAr: blankToNull(form.titleAr), descriptionEn: blankToNull(form.descriptionEn), descriptionAr: null, originalPrice: numericToNull(form.originalPrice), promotionalPrice: numericToNull(form.promotionalPrice), includedTreatments: null, sessionCount: form.sessions ? Number(form.sessions) : null, retouchIncluded: false, startsAt: null, endsAt: null, imageUrl: null, termsEn: null, termsAr: null, isFeatured: form.featured, status: form.status, displayOrder: 0 }); };
  return <div className="mx-auto max-w-6xl"><Header eyebrow="Current offers" title="Prices & promotions" description="Promotions are private until published. A published promotion automatically stops appearing publicly when its end date passes; no previous promotion is substituted." /><div className="grid gap-6 xl:grid-cols-[1fr_1fr]"><form onSubmit={submit} className="grid gap-4 border border-[#102032]/10 bg-white p-5 sm:grid-cols-2"><Field label="Promotion slug"><Input required value={form.slug} onChange={event => set("slug", event.target.value)} /></Field><Field label="Internal promotion name"><Input required value={form.name} onChange={event => set("name", event.target.value)} /></Field><Field label="English title"><Input required value={form.titleEn} onChange={event => set("titleEn", event.target.value)} /></Field><Field label="Arabic title"><Input dir="rtl" value={form.titleAr} onChange={event => set("titleAr", event.target.value)} /></Field><Field label="Original price"><Input inputMode="decimal" value={form.originalPrice} onChange={event => set("originalPrice", event.target.value)} /></Field><Field label="Promotional price"><Input inputMode="decimal" value={form.promotionalPrice} onChange={event => set("promotionalPrice", event.target.value)} /></Field><Field label="Sessions"><Input type="number" min="1" value={form.sessions} onChange={event => set("sessions", event.target.value)} /></Field><Field label="State"><select value={form.status} onChange={event => set("status", event.target.value)} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm"><option value="draft">Draft</option><option value="published">Publish</option><option value="paused">Paused</option><option value="archived">Archived</option></select></Field><div className="sm:col-span-2"><Field label="English description"><Area value={form.descriptionEn} onChange={value => set("descriptionEn", value)} /></Field></div><label className="flex items-center gap-2 text-sm font-semibold"><input type="checkbox" checked={form.featured} onChange={event => set("featured", event.target.checked)} />Featured</label><Button type="submit" disabled={save.isPending}><Save className="mr-2 size-4" />Save promotion</Button></form><section className="space-y-3">{promotions.data?.map(promotion => <article key={promotion.id} className="flex items-center justify-between gap-3 border border-[#102032]/10 bg-white p-4"><div><p className="font-semibold text-[#102032]">{promotion.titleEn}</p><p className="mt-1 text-xs text-[#52606B]">{promotion.status} · {promotion.promotionalPrice ? `SAR ${promotion.promotionalPrice}` : "Price not entered"}</p></div><Button size="icon" variant="ghost" aria-label={`Delete ${promotion.titleEn}`} onClick={() => { if (window.confirm(`Delete ${promotion.titleEn}?`)) remove.mutate({ id: promotion.id }); }}><Trash2 className="size-4 text-red-700" /></Button></article>)}</section></div></div>;
}

function GoogleBusinessReviewSync() {
  const { user } = useAuth();
  const utils = trpc.useUtils();
  const isOwner = user?.role === "owner";
  const [syncErrorMessage, setSyncErrorMessage] = useState<string | null>(
    null
  );
  const status = trpc.cms.googleBusinessStatus.useQuery(undefined, {
    enabled: isOwner,
    retry: false,
  });
  const connection = status.data?.connection;
  const locations = trpc.cms.googleBusinessLocations.useQuery(undefined, {
    enabled: isOwner && connection?.status === "awaiting_location",
    retry: false,
  });
  const beginAuthorization =
    trpc.cms.beginGoogleBusinessAuthorization.useMutation({
      onSuccess: result => window.location.assign(result.authorizationUrl),
      onError: error => toast.error(error.message),
    });
  const selectLocation = trpc.cms.selectGoogleBusinessLocation.useMutation({
    onSuccess: async () => {
      toast.success(
        "Google Business clinic location selected. Review sync is ready."
      );
      await Promise.all([
        utils.cms.googleBusinessStatus.invalidate(),
        utils.cms.googleBusinessLocations.invalidate(),
      ]);
    },
    onError: error => toast.error(error.message),
  });
  const sync = trpc.cms.syncGoogleBusinessReviews.useMutation({
    onMutate: () => setSyncErrorMessage(null),
    onSuccess: async result => {
      setSyncErrorMessage(null);
      toast.success(
        String(result.imported) +
          " Google review" +
          (result.imported === 1 ? "" : "s") +
          " synced for moderation."
      );
      await Promise.all([
        utils.cms.googleBusinessStatus.invalidate(),
        utils.cms.reviews.invalidate(),
      ]);
    },
    onError: error => {
      setSyncErrorMessage(error.message);
      toast.error(
        "Review sync did not finish. Review the recovery guidance below."
      );
    },
  });

  useEffect(() => {
    const outcome = new URLSearchParams(window.location.search).get(
      "googleBusiness"
    );
    if (!outcome) return;
    if (outcome === "connected")
      toast.success(
        "Google Business account connected. Select the clinic location to continue."
      );
    if (outcome === "cancelled")
      toast.error("Google Business connection was cancelled.");
    if (outcome === "error")
      toast.error(
        "Google Business connection could not be completed. Check the Google Cloud redirect URI and try again."
      );
    const url = new URL(window.location.href);
    url.searchParams.delete("googleBusiness");
    window.history.replaceState({}, "", url.pathname + url.search + url.hash);
  }, []);

  if (!isOwner) return null;
  if (status.isLoading) {
    return (
      <section className="grid min-h-32 place-items-center border border-[#102032]/10 bg-white p-5">
        <Loader2 className="size-5 animate-spin text-[#a85438]" />
      </section>
    );
  }
  if (status.isError) {
    return (
      <section className="border border-[#102032]/10 bg-white p-5">
        <p className="text-sm text-[#52606B]">
          Google Business connection status is temporarily unavailable.
        </p>
      </section>
    );
  }

  const selectedLocation = locations.data?.find(
    location =>
      location.locationResourceName === connection?.locationResourceName
  );
  const configured = status.data?.configured ?? false;
  const displayedSyncError = syncErrorMessage ?? connection?.lastSyncError;
  const syncFeedback = displayedSyncError
    ? getGoogleBusinessSyncFeedback(displayedSyncError)
    : null;
  const reconnectRequired =
    syncFeedback?.retryLabel === "Reconnect Google Business";

  return (
    <section
      className="border border-[#102032]/10 bg-[#F7F3EC] p-5"
      aria-label="Google Business Profile review synchronization"
    >
      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div className="max-w-3xl">
          <div className="flex items-center gap-2 text-[#102032]">
            <ShieldCheck className="size-4 text-[#a85438]" />
            <p className="text-xs font-extrabold uppercase tracking-[0.16em]">
              Owner-controlled integration
            </p>
          </div>
          <h2 className="mt-2 font-display text-2xl text-[#102032]">
            Google Business Profile reviews
          </h2>
          <p className="mt-2 text-sm leading-6 text-[#52606B]">
            Import real Google reviews into this private moderation queue.
            Syncing never publishes reviews, changes Google content, or sends
            replies. Reviewer display names and review text remain protected in
            this authenticated portal until an authorized administrator approves
            public use.
          </p>
        </div>
        {configured && !connection ? (
          <Button
            onClick={() => beginAuthorization.mutate()}
            disabled={beginAuthorization.isPending}
          >
            <Link2 className="mr-2 size-4" />
            {beginAuthorization.isPending
              ? "Opening Google…"
              : "Connect Google Business"}
          </Button>
        ) : null}
        {configured && connection?.status === "active" ? (
          <Button
            onClick={() => sync.mutate()}
            disabled={sync.isPending || beginAuthorization.isPending}
            aria-busy={sync.isPending}
          >
            <RefreshCw
              className={
                "mr-2 size-4 " + (sync.isPending ? "animate-spin" : "")
              }
            />
            {sync.isPending ? "Syncing…" : "Sync reviews now"}
          </Button>
        ) : null}
      </div>

      {sync.isPending ? (
        <div
          className="mt-4 flex gap-3 border border-[#a85438]/30 bg-white p-4 text-sm text-[#102032]"
          role="status"
          aria-live="polite"
        >
          <Loader2 className="mt-0.5 size-5 shrink-0 animate-spin text-[#a85438]" />
          <div>
            <p className="font-semibold">Syncing reviews securely</p>
            <p className="mt-1 leading-6 text-[#52606B]">
              Retrieving the latest Google reviews for the selected clinic
              location. Keep this page open; nothing is published or changed
              on Google while the private moderation queue refreshes.
            </p>
          </div>
        </div>
      ) : null}

      {syncFeedback ? (
        <div
          className="mt-4 border border-red-200 bg-red-50 p-4 text-sm text-red-950"
          role="alert"
          aria-live="assertive"
        >
          <p className="font-semibold">{syncFeedback.title}</p>
          <p className="mt-1 leading-6 text-red-900">
            {syncFeedback.description}
          </p>
          {configured && connection?.status === "active" ? (
            <Button
              type="button"
              variant="outline"
              className="mt-3 border-red-300 text-red-900 hover:bg-red-100"
              onClick={() => {
                if (reconnectRequired) beginAuthorization.mutate();
                else sync.mutate();
              }}
              disabled={sync.isPending || beginAuthorization.isPending}
            >
              {sync.isPending || beginAuthorization.isPending ? (
                <Loader2 className="mr-2 size-4 animate-spin" />
              ) : <RefreshCw className="mr-2 size-4" />}
              {beginAuthorization.isPending
                ? "Opening Google…"
                : sync.isPending
                  ? "Retrying sync…"
                  : syncFeedback.retryLabel}
            </Button>
          ) : null}
        </div>
      ) : null}

      {!configured ? (
        <div className="mt-4 border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
          <p className="font-semibold">
            Google credentials are not configured yet.
          </p>
          <p className="mt-1 leading-6">
            Add the required server-side credentials before connecting. They are
            never displayed in this portal or delivered to the browser.
          </p>
          <p className="mt-2 text-xs font-semibold">
            Required: {(status.data?.missingConfiguration ?? []).join(", ")}
          </p>
        </div>
      ) : null}

      {configured && !connection ? (
        <p className="mt-4 text-sm text-[#52606B]">
          Connect only the Google account that is authorized to manage the
          clinic’s verified Business Profile.
        </p>
      ) : null}

      {configured && connection?.status === "awaiting_location" ? (
        <div className="mt-4 border border-[#102032]/10 bg-white p-4">
          <div className="flex items-center gap-2">
            <MapPinned className="size-4 text-[#a85438]" />
            <p className="font-semibold text-[#102032]">
              Choose the verified clinic location
            </p>
          </div>
          <p className="mt-1 text-sm text-[#52606B]">
            The profile is connected. Select one accessible location before
            importing reviews.
          </p>
          {locations.isLoading ? (
            <div className="mt-3 flex items-center gap-2 text-sm text-[#52606B]">
              <Loader2 className="size-4 animate-spin" />
              Loading accessible locations…
            </div>
          ) : null}
          {locations.isError ? (
            <p className="mt-3 text-sm text-red-700">
              Locations could not be loaded. Confirm that the connected Google
              account manages the verified clinic profile.
            </p>
          ) : null}
          {locations.data?.length ? (
            <div className="mt-3 grid gap-2">
              {locations.data.map(location => (
                <button
                  key={location.locationResourceName}
                  type="button"
                  disabled={selectLocation.isPending}
                  onClick={() => selectLocation.mutate(location)}
                  className="flex items-center justify-between gap-3 border border-[#102032]/10 bg-white p-3 text-left transition hover:border-[#a85438] disabled:cursor-not-allowed disabled:opacity-60"
                >
                  <span>
                    <span className="block font-semibold text-[#102032]">
                      {location.locationName}
                    </span>
                    <span className="mt-0.5 block text-xs text-[#66727A]">
                      {location.accountName}
                    </span>
                  </span>
                  <span className="text-xs font-bold text-[#a85438]">
                    Select
                  </span>
                </button>
              ))}
            </div>
          ) : null}
        </div>
      ) : null}

      {configured && connection?.status === "active" ? (
        <div className="mt-4 grid gap-3 border border-[#102032]/10 bg-white p-4 sm:grid-cols-2">
          <div>
            <p className="text-xs font-semibold text-[#66727A]">
              Connected location
            </p>
            <p className="mt-1 font-semibold text-[#102032]">
              {connection.locationName ??
                selectedLocation?.locationName ??
                "Selected Google Business location"}
            </p>
            {connection.accountName ? (
              <p className="mt-1 text-xs text-[#66727A]">
                {connection.accountName}
              </p>
            ) : null}
          </div>
          <div>
            <p className="text-xs font-semibold text-[#66727A]">
              Last synchronization
            </p>
            <p className="mt-1 font-semibold text-[#102032]">
              {connection.lastSyncedAt
                ? new Date(connection.lastSyncedAt).toLocaleString()
                : "Not yet synced"}
            </p>
            <p className="mt-1 text-xs text-[#66727A]">
              Status: {connection.lastSyncStatus}
            </p>
          </div>
          {connection.lastSyncError ? (
            <p className="sm:col-span-2 text-sm text-red-700">
              {connection.lastSyncError}
            </p>
          ) : null}
        </div>
      ) : null}
    </section>
  );
}

function Reviews() {
  const reviews = trpc.cms.reviews.useQuery();
  const utils = trpc.useUtils();
  const [form, setForm] = useState({
    displayName: "",
    rating: "5",
    reviewText: "",
    treatment: "",
    language: "en" as "en" | "ar",
    isAnonymous: false,
    isFeatured: false,
  });
  const save = trpc.cms.saveReview.useMutation({
    onSuccess: async () => {
      toast.success("Review saved for approval.");
      setForm({
        displayName: "",
        rating: "5",
        reviewText: "",
        treatment: "",
        language: "en",
        isAnonymous: false,
        isFeatured: false,
      });
      await utils.cms.reviews.invalidate();
    },
    onError: error => toast.error(error.message),
  });
  const status = trpc.cms.setReviewStatus.useMutation({
    onSuccess: () => utils.cms.reviews.invalidate(),
    onError: error => toast.error(error.message),
  });
  if (reviews.isError)
    return (
      <div className="mx-auto max-w-6xl">
        <Header
          eyebrow="Moderated social proof"
          title="Reviews"
          description="Use only real reviews with permission. New entries remain private until an owner or administrator approves them."
        />
        <QueryFailure label="Reviews" onRetry={() => reviews.refetch()} />
      </div>
    );
  const reviewList = reviews.isLoading ? (
    <div className="grid min-h-44 place-items-center border border-[#102032]/10 bg-white">
      <Loader2 className="size-5 animate-spin text-[#a85438]" />
    </div>
  ) : reviews.data?.length ? (
    reviews.data.map(review => (
      <article
        key={review.id}
        className="border border-[#102032]/10 bg-white p-4"
      >
        <div className="flex justify-between gap-3">
          <div>
            <p className="font-semibold text-[#102032]">
              {review.isAnonymous ? "Anonymous client" : review.displayName} ·{" "}
              {review.rating}/5
            </p>
            <p className="mt-1 text-sm text-[#52606B]">{review.reviewText}</p>
            {review.source === "google_business" ? (
              <p className="mt-2 text-xs font-semibold uppercase tracking-wide text-[#66727A]">
                Imported from Google Business
              </p>
            ) : null}
          </div>
          <Badge variant={review.status === "approved" ? "default" : "outline"}>
            {review.status}
          </Badge>
        </div>
        {review.status === "pending" ? (
          <div className="mt-3 flex gap-2">
            <Button
              size="sm"
              onClick={() =>
                status.mutate({ id: review.id, status: "approved" })
              }
            >
              <Check className="mr-1 size-4" />
              Approve
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() =>
                status.mutate({ id: review.id, status: "rejected" })
              }
            >
              <X className="mr-1 size-4" />
              Reject
            </Button>
          </div>
        ) : null}
      </article>
    ))
  ) : (
    <div className="border border-dashed border-[#102032]/20 bg-white p-6 text-sm text-[#52606B]">
      No real reviews are awaiting moderation. Add one only when the clinic has
      a permitted, verifiable client review.
    </div>
  );
  return (
    <div className="mx-auto max-w-6xl">
      <Header
        eyebrow="Moderated social proof"
        title="Reviews"
        description="Use only real reviews with permission. New entries remain private until an owner or administrator approves them."
      />
      <div className="mt-6 space-y-6">
        <GoogleBusinessReviewSync />
        <div className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
          <form
            className="space-y-4 border border-[#102032]/10 bg-white p-5"
            onSubmit={event => {
              event.preventDefault();
              save.mutate({
                displayName: form.displayName,
                rating: Number(form.rating),
                reviewText: form.reviewText,
                treatment: blankToNull(form.treatment),
                language: form.language,
                isAnonymous: form.isAnonymous,
                isFeatured: form.isFeatured,
              });
            }}
          >
            <div>
              <p className="text-xs font-extrabold uppercase tracking-[0.16em] text-[#a85438]">
                Manual entry
              </p>
              <h2 className="mt-1 font-display text-2xl text-[#102032]">
                Add a verified review
              </h2>
            </div>
            <Field label="Display name">
              <Input
                value={form.displayName}
                onChange={event =>
                  setForm({ ...form, displayName: event.target.value })
                }
                required
              />
            </Field>
            <Field label="Rating">
              <select
                className="h-10 w-full border border-input bg-background px-3 text-sm"
                value={form.rating}
                onChange={event =>
                  setForm({ ...form, rating: event.target.value })
                }
              >
                {[5, 4, 3, 2, 1].map(value => (
                  <option key={value} value={value}>
                    {value}/5
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Treatment (optional)">
              <Input
                value={form.treatment}
                onChange={event =>
                  setForm({ ...form, treatment: event.target.value })
                }
              />
            </Field>
            <Field label="Review text">
              <Area
                value={form.reviewText}
                onChange={reviewText => setForm({ ...form, reviewText })}
              />
            </Field>
            <label className="flex gap-2 text-sm font-semibold">
              <input
                type="checkbox"
                checked={form.isAnonymous}
                onChange={event =>
                  setForm({ ...form, isAnonymous: event.target.checked })
                }
              />
              Display anonymously
            </label>
            <Button type="submit" disabled={save.isPending}>
              <Plus className="mr-2 size-4" />
              Save for approval
            </Button>
          </form>
          <section className="space-y-3">{reviewList}</section>
        </div>
      </div>
    </div>
  );
}
function LegacyResultCases() {
  const cases = trpc.cms.resultCases.useQuery(); const utils = trpc.useUtils();
  const [form, setForm] = useState({ title: "", treatmentArea: "", beforeImageUrl: "", afterImageUrl: "", consent: false, isActive: false });
  const save = trpc.cms.saveResultCase.useMutation({ onSuccess: async () => { toast.success("Result case saved with a consent record."); await utils.cms.resultCases.invalidate(); }, onError: error => toast.error(error.message) });
  if (cases.isError) return <div className="mx-auto max-w-6xl"><Header eyebrow="Consent-controlled evidence" title="Before & after cases" description="Never enter patient names, contact details, or identifying information. A recorded authorization acknowledgment is mandatory before a case can be active." /><QueryFailure label="Result cases" onRetry={() => cases.refetch()} /></div>;
  const caseList = cases.isLoading ? <div className="grid min-h-44 place-items-center border border-[#102032]/10 bg-white"><Loader2 className="size-5 animate-spin text-[#a85438]" /></div> : cases.data?.length ? cases.data.map(item => <article key={item.id} className="border border-[#102032]/10 bg-white p-4"><p className="font-semibold text-[#102032]">{item.title}</p><p className="mt-1 text-xs text-[#52606B]">{item.treatmentArea} · {item.isActive ? "Active" : "Private"} · consent {item.consentConfirmed ? "recorded" : "missing"}</p></article>) : <div className="border border-dashed border-[#102032]/20 bg-white p-6 text-sm text-[#52606B]">No consented result cases are saved. Do not create one unless documented authorization and de-identified media are available.</div>;
  return <div className="mx-auto max-w-6xl"><Header eyebrow="Consent-controlled evidence" title="Before & after cases" description="Never enter patient names, contact details, or identifying information. A recorded authorization acknowledgment is mandatory before a case can be active." /><div className="grid gap-6 lg:grid-cols-2"><form onSubmit={event => { event.preventDefault(); save.mutate({ title: form.title, treatmentArea: form.treatmentArea, beforeImageUrl: form.beforeImageUrl, afterImageUrl: form.afterImageUrl, additionalImages: null, sessionCount: null, descriptionEn: null, descriptionAr: null, disclaimerEn: null, disclaimerAr: null, consentConfirmed: true, isFeatured: false, isActive: form.isActive, displayOrder: 0 }); }} className="grid gap-4 border border-[#102032]/10 bg-white p-5"><Field label="Neutral case title"><Input required value={form.title} onChange={event => setForm({ ...form, title: event.target.value })} /></Field><Field label="Treatment area"><Input required value={form.treatmentArea} onChange={event => setForm({ ...form, treatmentArea: event.target.value })} /></Field><Field label="Before image URL"><Input required type="url" value={form.beforeImageUrl} onChange={event => setForm({ ...form, beforeImageUrl: event.target.value })} /></Field><Field label="After image URL"><Input required type="url" value={form.afterImageUrl} onChange={event => setForm({ ...form, afterImageUrl: event.target.value })} /></Field><label className="flex gap-2 text-sm font-semibold"><input required type="checkbox" checked={form.consent} onChange={event => setForm({ ...form, consent: event.target.checked })} />I confirm authorization is recorded and the media contains no patient identifiers.</label><label className="flex gap-2 text-sm font-semibold"><input type="checkbox" checked={form.isActive} onChange={event => setForm({ ...form, isActive: event.target.checked })} />Make active publicly</label><Button type="submit"><Save className="mr-2 size-4" />Save result case</Button></form><section className="space-y-3">{caseList}</section></div></div>;
}

function GuideAndFaq({ page }: { page: "guide" | "faqs" }) {
  const posts = trpc.cms.guidePosts.useQuery(undefined, { enabled: page === "guide" }); const faqs = trpc.cms.faqs.useQuery(undefined, { enabled: page === "faqs" }); const utils = trpc.useUtils();
  const [guide, setGuide] = useState({ slug: "", titleEn: "", summaryEn: "", status: "draft" as "draft" | "published" }); const [faq, setFaq] = useState({ questionEn: "", answerEn: "", isActive: false });
  const saveGuide = trpc.cms.saveGuidePost.useMutation({ onSuccess: () => utils.cms.guidePosts.invalidate(), onError: error => toast.error(error.message) }); const saveFaq = trpc.cms.saveFaq.useMutation({ onSuccess: () => utils.cms.faqs.invalidate(), onError: error => toast.error(error.message) });
  const title = page === "guide" ? "Men’s laser guide" : "Frequently asked questions";
  return <div className="mx-auto max-w-6xl"><Header eyebrow="Reviewed public education" title={title} description={page === "guide" ? "Create a private draft first, then publish checked educational content with no treatment guarantees." : "Keep answers clinically cautious. Only active FAQs are available to the public website."} /><div className="grid gap-6 lg:grid-cols-2">{page === "guide" ? <form onSubmit={event => { event.preventDefault(); saveGuide.mutate({ slug: guide.slug, postType: "blog", titleEn: guide.titleEn, titleAr: null, summaryEn: blankToNull(guide.summaryEn), summaryAr: null, contentEn: null, contentAr: null, category: null, tags: null, featuredImageUrl: null, videoUrl: null, seoTitle: null, metaDescription: null, canonicalUrl: null, socialImageUrl: null, status: guide.status, isFeatured: false, publishedAt: null }); }} className="grid gap-4 border border-[#102032]/10 bg-white p-5"><Field label="Slug"><Input required value={guide.slug} onChange={event => setGuide({ ...guide, slug: event.target.value })} /></Field><Field label="English title"><Input required value={guide.titleEn} onChange={event => setGuide({ ...guide, titleEn: event.target.value })} /></Field><Field label="Summary"><Area value={guide.summaryEn} onChange={summaryEn => setGuide({ ...guide, summaryEn })} /></Field><Field label="State"><select value={guide.status} onChange={event => setGuide({ ...guide, status: event.target.value as "draft" | "published" })} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm"><option value="draft">Draft</option><option value="published">Publish</option></select></Field><Button type="submit"><Save className="mr-2 size-4" />Save guide post</Button></form> : <form onSubmit={event => { event.preventDefault(); saveFaq.mutate({ questionEn: faq.questionEn, answerEn: faq.answerEn, questionAr: null, answerAr: null, category: null, isFeatured: false, isActive: faq.isActive, displayOrder: 0 }); }} className="grid gap-4 border border-[#102032]/10 bg-white p-5"><Field label="English question"><Input required value={faq.questionEn} onChange={event => setFaq({ ...faq, questionEn: event.target.value })} /></Field><Field label="English answer"><Area value={faq.answerEn} onChange={answerEn => setFaq({ ...faq, answerEn })} /></Field><label className="flex gap-2 text-sm font-semibold"><input type="checkbox" checked={faq.isActive} onChange={event => setFaq({ ...faq, isActive: event.target.checked })} />Make active publicly</label><Button type="submit"><Save className="mr-2 size-4" />Save FAQ</Button></form>}<section className="space-y-3">{page === "guide" ? posts.data?.map(post => <article key={post.id} className="border border-[#102032]/10 bg-white p-4"><p className="font-semibold text-[#102032]">{post.titleEn}</p><p className="mt-1 text-xs text-[#52606B]">/{post.slug} · {post.status}</p></article>) : faqs.data?.map(item => <article key={item.id} className="border border-[#102032]/10 bg-white p-4"><p className="font-semibold text-[#102032]">{item.questionEn}</p><p className="mt-1 text-sm text-[#52606B]">{item.answerEn}</p><Badge className="mt-3" variant={item.isActive ? "default" : "outline"}>{item.isActive ? "Active" : "Draft"}</Badge></article>)}</section></div></div>;
}

export function Library({ page }: { page: "media" | "policies" | "seo" | "languages" | "activity" }) {
  const media = trpc.cms.mediaItems.useQuery(undefined, { enabled: page === "media" }); const policies = trpc.cms.policies.useQuery(undefined, { enabled: page === "policies" }); const seo = trpc.cms.seoSettings.useQuery(undefined, { enabled: page === "seo" || page === "languages" }); const activity = trpc.cms.recentActivity.useQuery(undefined, { enabled: page === "activity" });
  const utils = trpc.useUtils(); const [altEn, setAltEn] = useState(""); const [altAr, setAltAr] = useState(""); const [mediaSearch, setMediaSearch] = useState(""); const [mediaEdits, setMediaEdits] = useState<Record<number, { fileName: string; altEn: string; altAr: string }>>({});
  const [policyForm, setPolicyForm] = useState({ slug: "", titleEn: "", titleAr: "", contentEn: "", contentAr: "", status: "draft" as "draft" | "published" }); const [seoForm, setSeoForm] = useState({ locale: "en" as "en" | "ar-SA", title: "", metaDescription: "", robotsIndex: true });
  useEffect(() => { if (page !== "policies" || !policies.data) return; const existing = policies.data.find(item => item.slug === "privacy-policy"); if (existing) setPolicyForm({ slug: existing.slug, titleEn: existing.titleEn, titleAr: existing.titleAr ?? "", contentEn: existing.contentEn ?? "", contentAr: existing.contentAr ?? "", status: existing.status }); }, [page, policies.data]);
  const upload = trpc.cms.uploadMedia.useMutation({ onSuccess: async () => { toast.success("Media uploaded to the protected library."); setAltEn(""); setAltAr(""); await utils.cms.mediaItems.invalidate(); }, onError: error => toast.error(error.message) }); const updateMedia = trpc.cms.updateMediaItem.useMutation({ onSuccess: async () => { toast.success("Media metadata saved."); await utils.cms.mediaItems.invalidate(); }, onError: error => toast.error(error.message) }); const deleteMedia = trpc.cms.deleteMediaItem.useMutation({ onSuccess: async () => { toast.success("Media reference removed."); await utils.cms.mediaItems.invalidate(); }, onError: error => toast.error(error.message) });
  const savePolicy = trpc.cms.savePolicy.useMutation({ onSuccess: async () => { toast.success("Policy saved."); await utils.cms.policies.invalidate(); }, onError: error => toast.error(error.message) }); const saveSeo = trpc.cms.saveSeoSettings.useMutation({ onSuccess: async () => { toast.success("SEO settings saved."); await utils.cms.seoSettings.invalidate(); }, onError: error => toast.error(error.message) });
  const label = page === "media" ? "Media library" : page === "policies" ? "Policies & consent pages" : page === "seo" ? "SEO controls" : page === "languages" ? "Language readiness" : "Activity log";
  const description = page === "media" ? "Register public-safe media metadata after storing the original file through the protected media workflow. Files are not saved in the database." : page === "policies" ? "Manage draft and published policy pages without exposing clinical records." : page === "seo" ? "Bilingual settings are held separately from patient data. The static public SEO fallback remains in place until server-side rendering is adopted." : page === "languages" ? "Arabic copy is always author-entered and reviewed; no automatic translation is published." : "Recent privileged CMS actions are logged for clinic oversight.";
  const activeQuery = page === "media" ? media : page === "policies" ? policies : page === "seo" || page === "languages" ? seo : activity;
  if (activeQuery.isLoading) return <div className="mx-auto max-w-5xl"><Header eyebrow="CMS oversight" title={label} description={description} /><AdminLoadingState label={`Loading ${label.toLowerCase()}…`} /></div>;
  if (activeQuery.isError) return <div className="mx-auto max-w-5xl"><Header eyebrow="CMS oversight" title={label} description={description} /><AdminErrorState title={`${label} unavailable`} description={`${label} could not be loaded from the secure CMS.`} onRetry={() => activeQuery.refetch()} /></div>;
  const filteredMedia = media.data?.filter(item => `${item.fileName} ${item.altEn ?? ""} ${item.altAr ?? ""} ${item.mimeType}`.toLowerCase().includes(mediaSearch.toLowerCase()));
  const records = page === "media" ? filteredMedia?.map(item => ({ id: item.id, title: item.fileName, detail: item.altEn || item.mimeType })) : page === "policies" ? policies.data?.map(item => ({ id: item.id, title: item.titleEn, detail: item.status })) : page === "seo" || page === "languages" ? seo.data?.map(item => ({ id: item.id, title: item.locale, detail: item.title })) : activity.data?.map(item => ({ id: item.id, title: item.action, detail: `${item.actorName ?? "System"} · ${new Date(item.createdAt).toLocaleString()}` }));
  return <div className="mx-auto max-w-5xl"><Header eyebrow="CMS oversight" title={label} description={description} />{page === "media" && <section className="mb-6 grid gap-3 border border-[#102032]/10 bg-white p-5 sm:grid-cols-2"><Field label="English alt text"><Input value={altEn} onChange={event => setAltEn(event.target.value)} placeholder="Describe the media accurately" /></Field><Field label="Arabic alt text"><Input dir="rtl" value={altAr} onChange={event => setAltAr(event.target.value)} /></Field><label className="grid gap-1.5 text-xs font-bold text-[#102032] sm:col-span-2"><span>Image or video file (max. 10 MB)</span><input type="file" accept="image/jpeg,image/png,image/webp,image/avif,video/mp4,video/webm" disabled={upload.isPending} onChange={event => { const file = event.target.files?.[0]; if (!file) return; if (file.size > 10_000_000) { toast.error("Choose a file smaller than 10 MB."); event.target.value = ""; return; } const reader = new FileReader(); reader.onload = () => { const raw = typeof reader.result === "string" ? reader.result.split(",")[1] : ""; if (!raw) { toast.error("The file could not be read."); return; } upload.mutate({ fileName: file.name, mimeType: file.type as "image/jpeg" | "image/png" | "image/webp" | "image/avif" | "video/mp4" | "video/webm", dataBase64: raw, altEn: blankToNull(altEn), altAr: blankToNull(altAr) }); }; reader.readAsDataURL(file); }} className="border border-[#102032]/20 bg-[#F7F3EC] px-3 py-3 text-sm" /></label><p className="text-xs leading-5 text-[#52606B] sm:col-span-2">Only upload media you own or are authorized to publish. Do not upload patient-identifying material without documented authorization.</p></section>}{page === "media" && <Input className="mb-4" value={mediaSearch} onChange={event => setMediaSearch(event.target.value)} placeholder="Search filename, alt text, or type" />}{page === "policies" && <form onSubmit={event => { event.preventDefault(); savePolicy.mutate({ slug: policyForm.slug, titleEn: policyForm.titleEn, titleAr: blankToNull(policyForm.titleAr), contentEn: blankToNull(policyForm.contentEn), contentAr: blankToNull(policyForm.contentAr), status: policyForm.status, publishedAt: null }); }} className="mb-6 grid gap-3 border border-[#102032]/10 bg-white p-5"><Field label="Policy slug"><Input required value={policyForm.slug} onChange={event => setPolicyForm({ ...policyForm, slug: event.target.value })} placeholder="privacy-policy" /></Field><Field label="English title"><Input required value={policyForm.titleEn} onChange={event => setPolicyForm({ ...policyForm, titleEn: event.target.value })} /></Field><Field label="Arabic title"><Input dir="rtl" value={policyForm.titleAr} onChange={event => setPolicyForm({ ...policyForm, titleAr: event.target.value })} /></Field><Field label="Policy content — English"><Area value={policyForm.contentEn} onChange={contentEn => setPolicyForm({ ...policyForm, contentEn })} /></Field><Field label="Policy content — Arabic"><Area value={policyForm.contentAr} onChange={contentAr => setPolicyForm({ ...policyForm, contentAr })} /></Field><Field label="State"><select value={policyForm.status} onChange={event => setPolicyForm({ ...policyForm, status: event.target.value as "draft" | "published" })} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm"><option value="draft">Draft</option><option value="published">Publish</option></select></Field><Button type="submit"><Save className="mr-2 size-4" />Save policy</Button></form>}{page === "seo" && <form onSubmit={event => { event.preventDefault(); saveSeo.mutate({ locale: seoForm.locale, title: seoForm.title, metaDescription: seoForm.metaDescription, canonicalUrl: null, openGraphTitle: null, openGraphDescription: null, openGraphImageUrl: null, robotsIndex: seoForm.robotsIndex, structuredData: null }); }} className="mb-6 grid gap-3 border border-[#102032]/10 bg-white p-5"><InstantDraftButton onGenerate={() => setSeoForm(current => fillSeoDraft(current))} /><Field label="Locale"><select value={seoForm.locale} onChange={event => setSeoForm({ ...seoForm, locale: event.target.value as "en" | "ar-SA" })} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm"><option value="en">English</option><option value="ar-SA">Arabic (Saudi Arabia)</option></select></Field><Field label="SEO title"><Input required value={seoForm.title} onChange={event => setSeoForm({ ...seoForm, title: event.target.value })} /></Field><Field label="Meta description"><Area value={seoForm.metaDescription} onChange={metaDescription => setSeoForm({ ...seoForm, metaDescription })} /></Field><label className="flex gap-2 text-sm font-semibold"><input type="checkbox" checked={seoForm.robotsIndex} onChange={event => setSeoForm({ ...seoForm, robotsIndex: event.target.checked })} />Allow public indexing for this locale</label><Button type="submit"><Save className="mr-2 size-4" />Save SEO settings</Button></form>}<section className="space-y-3">{records?.length ? records.map(record => { const item = page === "media" ? filteredMedia?.find(mediaItem => mediaItem.id === record.id) : null; const draft = item ? mediaEdits[item.id] ?? { fileName: item.fileName, altEn: item.altEn ?? "", altAr: item.altAr ?? "" } : null; return <article key={record.id} className="border border-[#102032]/10 bg-white p-4"><p className="font-semibold text-[#102032]">{record.title}</p><p className="mt-1 text-sm text-[#52606B]">{record.detail}</p>{item && draft ? <div className="mt-4 grid gap-3 border-t border-[#102032]/10 pt-4 sm:grid-cols-2"><div className="sm:col-span-2">{item.mimeType.startsWith("video/") ? <video controls src={item.url} className="max-h-52 w-full bg-[#102032]" /> : <img src={item.url} alt={draft.altEn || item.fileName} className="max-h-52 w-full object-contain bg-[#F7F3EC]" />}</div><Field label="Filename"><Input value={draft.fileName} onChange={event => setMediaEdits(current => ({ ...current, [item.id]: { ...draft, fileName: event.target.value } }))} /></Field><Field label="Alt text — English"><Input value={draft.altEn} onChange={event => setMediaEdits(current => ({ ...current, [item.id]: { ...draft, altEn: event.target.value } }))} /></Field><div className="sm:col-span-2"><Field label="Alt text — Arabic"><Input dir="rtl" value={draft.altAr} onChange={event => setMediaEdits(current => ({ ...current, [item.id]: { ...draft, altAr: event.target.value } }))} /></Field></div><div className="flex flex-wrap gap-2 sm:col-span-2"><Button size="sm" variant="outline" onClick={() => navigator.clipboard.writeText(item.url).then(() => toast.success("Media URL copied.")).catch(() => toast.error("Copy is unavailable in this browser."))}><Copy className="mr-1 size-4" />Copy URL</Button><Button size="sm" disabled={updateMedia.isPending} onClick={() => updateMedia.mutate({ id: item.id, fileName: draft.fileName, altEn: blankToNull(draft.altEn), altAr: blankToNull(draft.altAr) })}><Save className="mr-1 size-4" />Save metadata</Button><Button size="sm" variant="outline" className="text-red-700" disabled={deleteMedia.isPending} onClick={() => { if (window.confirm(`Remove ${item.fileName} from the library? This does not delete the stored source file.`)) deleteMedia.mutate({ id: item.id }); }}><Trash2 className="mr-1 size-4" />Remove reference</Button></div></div> : null}</article>; }) : <p className="border border-dashed border-[#102032]/20 bg-white p-6 text-sm text-[#52606B]">No records exist yet. The public site stays unchanged until reviewed content is intentionally created.</p>}</section></div>;
}

export function Security() {
  const { locale } = useAdminLocale();
  const users = trpc.cms.staffUsers.useQuery(); const utils = trpc.useUtils();
  const updateRole = trpc.cms.updateStaffRole.useMutation({ onSuccess: async () => { toast.success("Staff role updated."); await utils.cms.staffUsers.invalidate(); }, onError: error => toast.error(error.message) });
  if (users.isError) return <div className="mx-auto max-w-5xl"><Header eyebrow="Owner-only access control" title="Users & security" description="Review authenticated staff accounts and assign only the operational role required. Patient information remains inaccessible to content editors, and role changes are restricted to the clinic owner." /><QueryFailure label="Staff security" onRetry={() => users.refetch()} /></div>;
  if (!users.isLoading && users.data?.length === 0) return <div className="mx-auto max-w-5xl"><Header eyebrow="Owner-only access control" title="Users & security" description="Review authenticated staff accounts and assign only the operational role required. Patient information remains inaccessible to content editors, and role changes are restricted to the clinic owner." /><AdminEmptyState title="No staff accounts available" description="No authenticated staff accounts are available to manage in this portal session." /></div>;
  return <div className="mx-auto max-w-5xl"><Header eyebrow="Owner-only access control" title="Users & security" description="Review authenticated staff accounts and assign only the operational role required. Patient information remains inaccessible to content editors, and role changes are restricted to the clinic owner." /><section className="space-y-3">{users.isLoading ? <AdminLoadingState label="Loading staff accounts…" /> : users.data?.map(user => <article key={user.id} className="grid gap-3 border border-[#102032]/10 bg-white p-4 sm:grid-cols-[1fr_180px] sm:items-center"><div><p className="font-semibold text-[#102032]" data-admin-no-translate>{user.name || "Unnamed account"}</p><p className="mt-1 text-sm text-[#52606B]"><span data-admin-no-translate>{user.email || "No email available"}</span> · {translateAdminText("Last sign-in", locale)} <span data-admin-no-translate>{user.lastSignedIn ? new Date(user.lastSignedIn).toLocaleString() : "not recorded"}</span></p></div><select value={user.role} disabled={user.role === "owner" || updateRole.isPending} onChange={event => updateRole.mutate({ userId: user.id, role: event.target.value as "admin" | "content_editor" | "reception" | "user" })} className="h-10 border border-[#102032]/20 bg-white px-3 text-sm disabled:cursor-not-allowed disabled:bg-[#F7F3EC]"><option value="owner">Owner</option><option value="admin">Admin</option><option value="content_editor">Content editor</option><option value="reception">Reception</option><option value="user">No staff access</option></select></article>)}</section></div>;
}

export const AppointmentSettings = SettingsControlCenter;

export function Notifications() {
  const inbox = trpc.admin.notifications.useQuery(); const utils = trpc.useUtils();
  const markRead = trpc.admin.markNotificationRead.useMutation({ onSuccess: () => utils.admin.notifications.invalidate(), onError: error => toast.error(error.message) });
  const markAll = trpc.admin.markAllNotificationsRead.useMutation({ onSuccess: () => utils.admin.notifications.invalidate(), onError: error => toast.error(error.message) });
  if (inbox.isLoading) return <div className="mx-auto max-w-4xl"><Header eyebrow="Private staff inbox" title="Notifications" description="Operational alerts omit customer details. Follow protected links to review request or enquiry information." /><AdminLoadingState label="Loading staff notifications…" /></div>;
  if (inbox.isError) return <div className="mx-auto max-w-4xl"><Header eyebrow="Private staff inbox" title="Notifications" description="Operational alerts omit customer details. Follow protected links to review request or enquiry information." /><QueryFailure label="Notifications" onRetry={() => inbox.refetch()} /></div>;
  const unread = inbox.data?.filter(item => !item.isRead).length ?? 0;
  return <div className="mx-auto max-w-4xl"><Header eyebrow="Private staff inbox" title="Notifications" description="Operational alerts omit customer names, mobile numbers, notes, and consent records. Open the protected workspace to review details." /><div className="mb-5 flex flex-wrap items-center justify-between gap-3 border border-[#102032]/10 bg-white p-4"><p className="text-sm font-semibold text-[#102032]">{unread} unread notification{unread === 1 ? "" : "s"}</p><Button variant="outline" size="sm" disabled={!unread || markAll.isPending} onClick={() => markAll.mutate()}>Mark all as read</Button></div><section className="space-y-3">{inbox.data?.length ? inbox.data.map(item => <article key={item.id} className={`border p-4 ${item.isRead ? "border-[#102032]/10 bg-white" : "border-[#B85E3C]/40 bg-[#FFF8F2]"}`}><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="font-semibold text-[#102032]">{item.title}</p><p className="mt-1 text-sm leading-6 text-[#52606B]">{item.message}</p><p className="mt-2 text-xs text-[#66727A]">{new Date(item.createdAt).toLocaleString("en-SA", { timeZone: "Asia/Riyadh" })}</p></div><div className="flex gap-2">{item.linkPath ? <a href={item.linkPath} className="inline-flex h-9 items-center border border-[#102032]/20 px-3 text-xs font-bold">Open</a> : null}{!item.isRead ? <Button size="sm" variant="outline" disabled={markRead.isPending} onClick={() => markRead.mutate({ id: item.id })}>Mark read</Button> : null}</div></div></article>) : <div className="border border-dashed border-[#102032]/20 bg-white p-6 text-sm text-[#52606B]">No staff notifications yet. New website requests, enquiries, private review moderation, and published promotions will appear here.</div>}</section></div>;
}

export default function CmsManager({ page }: { page: CmsPage }) { if (page === "clinic") return <ClinicInformation />; if (page === "appearance") return <HomepageAppearance />; if (page === "settings") return <SettingsControlCenter />; if (page === "content") return <HomepageContent />; if (page === "treatments") return <TreatmentCatalogue />; if (page === "promotions") return <PromotionCatalogue />; if (page === "reviews") return <Reviews />; if (page === "results") return <ResultCases />; if (page === "guide") return <GuideWorkspace />; if (page === "calendar") return <ContentCalendar />; if (page === "faqs") return <FaqWorkspace />; if (page === "security") return <Security />; if (page === "notifications") return <Notifications />; return <Library page={page} />; }
