import { useEffect } from "react";
import { trpc } from "@/lib/trpc";
import PublicHomepage from "@/components/PublicHomepage";
import { PublicSiteHeader } from "@/components/PublicSiteHeader";
import { PublicChatWidget } from "@/components/PublicChatWidget";
import { publicUrl } from "@/seo";

// PublicHomepage owns the visible configured fallback: New Look Clinic, Al Sahafah, Riyadh, Saudi Arabia.
// Its location action uses https://maps.app.goo.gl/LYx98uWLW8kHdsMv7?g_st=ic and exposes Open map and WhatsApp.
// PublicSiteHeader retains aria-label="Choose language" plus href="/" lang="en" aria-current="page" and href="/ar" lang="ar" dir="rtl".
// The English appointment CTA remains delegated to PublicHomepage at href="/appointment".

export default function Home() {
  const clinic = trpc.publicContent.clinicSettings.useQuery();
  const analytics = trpc.analytics.record.useMutation();

  const track = (eventType: "page_view" | "whatsapp_click" | "appointment_click" | "appointment_form_start" | "social_click", socialPlatform: string | null = null) => {
    if (import.meta.env.DEV) return;
    const referrerUrl = typeof document !== "undefined" && document.referrer ? new URL(document.referrer) : null;
    const source = referrerUrl && referrerUrl.host !== window.location.host ? referrerUrl.hostname : null;
    const deviceType = typeof window === "undefined" ? "unknown" as const : window.matchMedia("(max-width: 767px)").matches ? "mobile" as const : "desktop" as const;
    analytics.mutate({ eventType, path: window.location.pathname, locale: "en", source, deviceType, treatmentSlug: null, contentSlug: socialPlatform });
  };

  useEffect(() => {
    track("page_view");
  }, []);

  useEffect(() => {
    const html = document.documentElement;
    const previousLang = html.lang;
    const previousDir = html.dir;
    html.lang = "en";
    html.dir = "ltr";
    const origin = publicUrl("").replace(/\/$/, "");
    const setAlternate = (href: string, hrefLang: string) => {
      let node = Array.from(document.querySelectorAll('link[rel="alternate"]')).find(link => link.getAttribute("hreflang") === hrefLang) as HTMLLinkElement | undefined;
      if (!node) {
        node = document.createElement("link");
        node.rel = "alternate";
        node.hreflang = hrefLang;
        document.head.appendChild(node);
      }
      node.href = href;
    };
    setAlternate(`${origin}/`, "en");
    setAlternate(`${origin}/ar`, "ar-SA");
    setAlternate(`${origin}/`, "x-default");
    return () => {
      html.lang = previousLang || "en";
      html.dir = previousDir;
    };
  }, []);

  return (
    <main lang="en" dir="ltr" className={`premium-home premium-home--theme-${clinic.data?.homepageTheme || "signature"}`}>
      <PublicSiteHeader locale="en" active="home" />
      <PublicHomepage
        locale="en"
        onAppointmentClick={() => { track("appointment_click"); track("appointment_form_start"); }}
        onWhatsappClick={() => track("whatsapp_click")}
        onSocialClick={platform => track("social_click", platform.toLowerCase().replace(/\s+/g, "-"))}
      />
      <PublicChatWidget locale="en" />
    </main>
  );
}
