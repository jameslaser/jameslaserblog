import { ArrowLeft, ArrowRight, ShieldCheck } from "lucide-react";
import { useEffect } from "react";
import { Link, useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { publicUrl } from "@/seo";

type Locale = "en" | "ar";

function setMetadata(title: string, description: string, canonicalPath: string) {
  document.title = title;
  const descriptionTag = document.querySelector('meta[name="description"]') || document.head.appendChild(document.createElement("meta"));
  descriptionTag.setAttribute("name", "description");
  descriptionTag.setAttribute("content", description);
  const robotsTag = document.querySelector('meta[name="robots"]') || document.head.appendChild(document.createElement("meta"));
  robotsTag.setAttribute("name", "robots");
  robotsTag.setAttribute("content", "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1");
  const canonicalTag = document.querySelector('link[rel="canonical"]') || document.head.appendChild(document.createElement("link"));
  canonicalTag.setAttribute("rel", "canonical");
  canonicalTag.setAttribute("href", publicUrl(canonicalPath));
}

export default function PublicPolicy({ locale = "en" }: { locale?: Locale }) {
  const rtl = locale === "ar";
  const routePattern = rtl ? "/ar/policies/:slug" : "/policies/:slug";
  const [, params] = useRoute(routePattern);
  const policies = trpc.publicContent.policies.useQuery();
  const policy = policies.data?.find(item => item.slug === params?.slug);
  const title = policy ? (rtl ? policy.titleAr || policy.titleEn : policy.titleEn) : rtl ? "السياسة غير منشورة حاليًا" : "Policy not currently published";
  const content = policy ? (rtl ? policy.contentAr || policy.contentEn : policy.contentEn) : null;
  const usesEnglishFallback = Boolean(rtl && policy && !policy.contentAr);
  const updatedAt = policy?.updatedAt ? new Intl.DateTimeFormat(rtl ? "ar-SA" : "en-GB", { dateStyle: "long" }).format(new Date(policy.updatedAt)) : null;

  useEffect(() => {
    const robots = document.querySelector('meta[name="robots"]') || document.head.appendChild(document.createElement("meta"));
    robots.setAttribute("name", "robots");
    if (!policy) {
      robots.setAttribute("content", "noindex, follow, noarchive");
      return;
    }
    const description = policy ? (rtl ? "سياسة منشورة من جيمس ليزر للرجال في الرياض." : "Published policy from James Laser Hair Removal for Men in Riyadh.") : (rtl ? "صفحة سياسة جيمس ليزر للرجال في الرياض." : "James Laser Hair Removal for Men policy page in Riyadh.");
    setMetadata(`${title} | ${rtl ? "جيمس ليزر" : "James Laser"}`, description, `${rtl ? "/ar" : ""}/policies/${params?.slug || "policy"}`);
  }, [params?.slug, policy, rtl, title]);

  return <main dir={rtl ? "rtl" : "ltr"} className="min-h-screen bg-[#f5f1e9] text-[#102032]"><header className="border-b border-white/10 bg-[#102032] text-white"><div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-4 sm:px-6"><Link href="/" className="font-display text-xl">{rtl ? "جيمس ليزر" : "James Laser"} <span className="font-sans text-[9px] font-bold uppercase tracking-[0.2em] text-[#e7b99e]">Riyadh</span></Link><Link href={rtl ? "/ar/appointment" : "/appointment"} className="flex items-center gap-1 text-sm text-white/75">{rtl ? <ArrowRight className="size-4" /> : <ArrowLeft className="size-4" />}{rtl ? "طلب موعد" : "Appointment request"}</Link></div></header><article className="mx-auto max-w-3xl px-4 py-12 sm:px-6"><div className="border border-[#102032]/10 bg-white p-7 shadow-xl shadow-[#102032]/5 sm:p-10">{policies.isLoading ? <p className="text-sm text-[#52606B]">{rtl ? "جارٍ تحميل السياسة…" : "Loading policy…"}</p> : policy ? <><div className="flex items-center gap-3"><ShieldCheck className="size-6 text-[#a85438]" /><p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#a85438]">{rtl ? "جيمس ليزر · سياسة" : "James Laser · Policy"}</p></div><h1 className="mt-5 font-display text-4xl tracking-[-0.05em]">{title}</h1>{updatedAt ? <p className="mt-3 text-xs font-semibold text-[#66727A]">{rtl ? `آخر تحديث: ${updatedAt}` : `Last updated: ${updatedAt}`}</p> : null}{usesEnglishFallback ? <p className="mt-4 border-s-2 border-[#a85438] bg-[#fff8f2] p-3 text-sm leading-6 text-[#52606B]">النص الإنجليزي هو النسخة المنشورة حاليًا لهذه السياسة.</p> : null}<div className="mt-6 whitespace-pre-wrap text-sm leading-7 text-[#52606B]">{content || (rtl ? "تم نشر هذه السياسة دون نص إضافي." : "This policy has been published without additional body text.")}</div></> : <><ShieldCheck className="size-7 text-[#a85438]" /><h1 className="mt-5 font-display text-4xl tracking-[-0.05em]">{title}</h1><p className="mt-4 text-sm leading-7 text-[#52606B]">{rtl ? "ستظهر هذه الصفحة بعد أن ينشر مالك العيادة محتوى السياسة المراجع." : "This policy page will appear once the clinic owner publishes the reviewed policy content."}</p></>}</div></article></main>;
}
