import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("AppointmentRequestsWorkspace original consent review", () => {
  it("shows only persisted consent-set metadata and document links inside the protected request workspace", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/AdminRequestsWorkspace.tsx"), "utf8");

    expect(source).toContain("Original consent set");
    expect(source).toContain("request.originalConsentSetReference");
    expect(source).toContain("request.originalConsentAcknowledgedAt");
    expect(source).toContain("request.consentSignatureStatus");
    expect(source).toContain("View Original Consent");
    expect(source).toContain("storedConsentDocuments(request)");
    expect(source).toContain("E-signature evidence");
    expect(source).toContain("Public request screening");
    expect(source).toContain("Medication Last Taken");
    expect(source).toContain("Skin Condition Description");
    expect(source).toContain("Consent Version");
    expect(source).toContain("request.informationAccuracyAcknowledgedAt");
    expect(source).toContain("consentSignature.staffCreate");
    expect(source).toContain("consentSignature.staffRevoke");
    expect(source).toContain("consentSignature.staffEvidence");
    expect(source).toContain("/sign-consent#token=");
    expect(source).toContain("Send it manually through your approved channel");
    expect(source).not.toContain("globalThis.fetch");
    expect(source).not.toContain("window.fetch");
  });
});
