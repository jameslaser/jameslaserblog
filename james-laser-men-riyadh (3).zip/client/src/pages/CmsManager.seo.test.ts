import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const source = readFileSync(resolve(process.cwd(), "client/src/pages/CmsManager.tsx"), "utf8");

describe("CMS SEO overview", () => {
  it("reports configuration-derived checks without fabricating Google performance data", () => {
    expect(source).toContain("SEO configuration overview");
    expect(source).toContain("Missing titles");
    expect(source).toContain("Missing descriptions");
    expect(source).toContain("Search Console import:");
    expect(source).toContain("requires owner access");
    expect(source).not.toContain("SEO ranking score");
  });
});
