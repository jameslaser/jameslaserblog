import { AdminErrorState, AdminLoadingState, AdminPageHeader } from "@/components/AdminUi";
import { CmsImageUploadField } from "@/components/CmsImageUploadField";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Check, ImageUp, Loader2, Save, ShieldCheck } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";

const themes = [
  {
    value: "signature",
    label: "Signature navy",
    description: "The existing dark-navy and copper clinic identity.",
    swatches: ["#0d1d2b", "#f7f3ec", "#bd6747"],
  },
  {
    value: "graphite",
    label: "Graphite",
    description: "A sharper charcoal, stone, and amber interpretation for a more architectural feel.",
    swatches: ["#1d2024", "#f4f1eb", "#b67a3e"],
  },
  {
    value: "sage",
    label: "Clinical sage",
    description: "A calm deep-green, warm ivory, and muted copper palette that remains professional.",
    swatches: ["#17312d", "#f4f2ea", "#ab7659"],
  },
] as const;

type ThemeValue = (typeof themes)[number]["value"];
type AppearanceForm = {
  homepageTheme: ThemeValue;
  homepageHeroImageUrl: string;
  homepageSpecialistImageUrl: string;
  homepageClinicImageUrl: string;
};

function toForm(settings: { homepageTheme?: ThemeValue | null; homepageHeroImageUrl?: string | null; homepageSpecialistImageUrl?: string | null; homepageClinicImageUrl?: string | null } | undefined): AppearanceForm {
  return {
    homepageTheme: settings?.homepageTheme ?? "signature",
    homepageHeroImageUrl: settings?.homepageHeroImageUrl ?? "",
    homepageSpecialistImageUrl: settings?.homepageSpecialistImageUrl ?? "",
    homepageClinicImageUrl: settings?.homepageClinicImageUrl ?? "",
  };
}

function ImageControl({ label, helper, value, onChange, altEn }: { label: string; helper: string; value: string; onChange: (value: string) => void; altEn: string }) {
  return <div className="space-y-2"><CmsImageUploadField label={label} value={value} onChange={onChange} altEn={altEn} /><p className="text-xs leading-5 text-[#66727A]">{helper}</p></div>;
}

export function HomepageAppearance() {
  const settings = trpc.cms.clinicSettings.useQuery();
  const utils = trpc.useUtils();
  const [form, setForm] = useState<AppearanceForm>(() => toForm(undefined));
  const serverBaselineRef = useRef<string | null>(null);

  useEffect(() => {
    if (!settings.data) return;
    const next = toForm(settings.data);
    const nextFingerprint = JSON.stringify(next);
    setForm(current => {
      const currentFingerprint = JSON.stringify(current);
      const hasUnsavedChanges = serverBaselineRef.current !== null && currentFingerprint !== serverBaselineRef.current;

      // Preserve a freshly uploaded image while a background query refetches.
      // Once the server returns the same values after a save, advance the local
      // baseline so later external changes can still be reflected safely.
      if (currentFingerprint === nextFingerprint) {
        serverBaselineRef.current = nextFingerprint;
        return current;
      }
      if (hasUnsavedChanges) return current;

      serverBaselineRef.current = nextFingerprint;
      return next;
    });
  }, [settings.data]);

  const dirty = useMemo(() => JSON.stringify(form) !== JSON.stringify(toForm(settings.data)), [form, settings.data]);
  const save = trpc.cms.updateClinicSettings.useMutation({
    onSuccess: async () => {
      toast.success("Homepage appearance saved and recorded in the settings history.");
      await Promise.all([
        utils.cms.clinicSettings.invalidate(),
        utils.cms.settingsControl.invalidate(),
        utils.cms.settingsChangeAudit.invalidate(),
        utils.publicContent.clinicSettings.invalidate(),
      ]);
    },
    onError: error => toast.error(error.message),
  });

  if (settings.isLoading) return <div className="mx-auto max-w-6xl"><AdminPageHeader eyebrow="Public website control" title="Homepage appearance" description="Loading the saved public website appearance." /><AdminLoadingState label="Loading homepage appearance…" /></div>;
  if (settings.isError || !settings.data) return <div className="mx-auto max-w-6xl"><AdminPageHeader eyebrow="Public website control" title="Homepage appearance" description="Homepage media and themes remain protected until the CMS is available." /><AdminErrorState title="Appearance settings unavailable" description="No appearance setting has been changed." onRetry={() => settings.refetch()} /></div>;

  const submit = () => save.mutate({
    homepageTheme: form.homepageTheme,
    homepageHeroImageUrl: form.homepageHeroImageUrl || null,
    homepageSpecialistImageUrl: form.homepageSpecialistImageUrl || null,
    homepageClinicImageUrl: form.homepageClinicImageUrl || null,
  });

  return <div className="mx-auto max-w-6xl space-y-6">
    <AdminPageHeader
      eyebrow="Public website control"
      title="Homepage appearance"
      description="Choose a vetted clinic theme and upload the three public homepage images. Uploads use the protected media library; image references are saved with an audit trail."
      action={<Badge variant="outline" className="border-[#a85438]/30 bg-[#fff4ed] text-[#8d4027]"><ShieldCheck className="mr-1.5 size-3.5" />Server-authorized</Badge>}
    />

    <section className="border border-[#102032]/10 bg-white p-5 sm:p-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">Theme</p><h2 className="mt-2 font-display text-3xl text-[#102032]">Choose a controlled visual system</h2><p className="mt-2 max-w-3xl text-sm leading-6 text-[#52606B]">Only approved themes are available to protect contrast, readability, mobile behavior, and the clinic’s professional identity.</p></div><span className="text-xs font-semibold text-[#66727A]">Public site only</span></div>
      <fieldset className="mt-6 grid gap-4 md:grid-cols-3"><legend className="sr-only">Homepage theme</legend>{themes.map(theme => {
        const selected = form.homepageTheme === theme.value;
        return <label key={theme.value} className={`cursor-pointer border p-4 transition ${selected ? "border-[#a85438] bg-[#fff8f2] ring-1 ring-[#a85438]/30" : "border-[#102032]/15 bg-[#fdfbf7] hover:border-[#a85438]/45"}`}>
          <input className="sr-only" type="radio" name="homepage-theme" value={theme.value} checked={selected} onChange={() => setForm(current => ({ ...current, homepageTheme: theme.value }))} />
          <span className="flex items-start justify-between gap-3"><span className="font-semibold text-[#102032]">{theme.label}</span>{selected ? <Check className="size-4 text-[#a85438]" aria-label="Selected" /> : null}</span>
          <span className="mt-3 flex gap-2" aria-hidden="true">{theme.swatches.map(color => <span key={color} className="h-7 flex-1 border border-black/10" style={{ backgroundColor: color }} />)}</span>
          <span className="mt-3 block text-xs leading-5 text-[#52606B]">{theme.description}</span>
        </label>;
      })}</fieldset>
    </section>

    <section className="border border-[#102032]/10 bg-white p-5 sm:p-6">
      <div><p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#a85438]">Public imagery</p><h2 className="mt-2 font-display text-3xl text-[#102032]">Upload homepage images</h2><p className="mt-2 max-w-3xl text-sm leading-6 text-[#52606B]">Existing images stay live until you save a replacement. Do not upload patient images, identifying details, or treatment media without documented authorization.</p></div>
      <div className="mt-6 grid gap-5 lg:grid-cols-3">
        <ImageControl label="Hero background" value={form.homepageHeroImageUrl} onChange={homepageHeroImageUrl => setForm(current => ({ ...current, homepageHeroImageUrl }))} altEn="James Laser homepage hero background" helper="A wide landscape image. It appears as a decorative, darkened hero background behind the homepage headline." />
        <ImageControl label="Specialist image" value={form.homepageSpecialistImageUrl} onChange={homepageSpecialistImageUrl => setForm(current => ({ ...current, homepageSpecialistImageUrl }))} altEn="Nurse James in the clinic setting" helper="A portrait or vertical clinic image for the specialist section. The public alt text remains clinic-approved and non-identifying." />
        <ImageControl label="Clinic image" value={form.homepageClinicImageUrl} onChange={homepageClinicImageUrl => setForm(current => ({ ...current, homepageClinicImageUrl }))} altEn="James Laser clinic environment" helper="A landscape environment or treatment-detail image for the clinic section. Keep patients and personal information out of frame." />
      </div>
    </section>

    <section className="border border-amber-300 bg-amber-50 p-5 text-sm text-amber-950"><div className="flex gap-3"><ImageUp className="mt-0.5 size-5 shrink-0 text-amber-800" /><div><p className="font-semibold">Publication safeguard</p><p className="mt-1 leading-6 text-amber-900">Removing an image restores the existing approved fallback after you save. Uploading a file alone does not change the homepage; the change becomes public only when you select the image and save this appearance configuration.</p></div></div></section>

    <div className="flex flex-wrap items-center gap-3"><Button type="button" disabled={!dirty || save.isPending} onClick={submit}>{save.isPending ? <Loader2 className="mr-2 size-4 animate-spin" /> : <Save className="mr-2 size-4" />}Save homepage appearance</Button><Button type="button" variant="outline" disabled={!dirty || save.isPending} onClick={() => { const saved = toForm(settings.data); serverBaselineRef.current = JSON.stringify(saved); setForm(saved); }}>Cancel</Button>{dirty ? <span className="text-xs font-semibold text-amber-800">Unsaved appearance changes</span> : <span className="text-xs text-[#66727A]">All appearance settings saved</span>}</div>
  </div>;
}

export default HomepageAppearance;
