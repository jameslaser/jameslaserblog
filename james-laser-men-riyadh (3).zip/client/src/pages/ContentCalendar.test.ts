import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const calendar = readFileSync(resolve(process.cwd(), "client/src/pages/ContentCalendar.tsx"), "utf8");
const app = readFileSync(resolve(process.cwd(), "client/src/App.tsx"), "utf8");
const portal = readFileSync(resolve(process.cwd(), "client/src/pages/AdminPortal.tsx"), "utf8");

describe("Content Calendar workspace", () => {
  it("is registered as a protected admin route and exposes the requested calendar fields", () => {
    expect(app).toContain('path={"/admin/calendar"}');
    expect(portal).toContain('label: "Content calendar"');
    expect(calendar).toContain("Planning date");
    expect(calendar).toContain("Content type");
    expect(calendar).toContain("Search intent");
    expect(calendar).toContain("CTA");
    expect(calendar).toContain("Editorial status");
  });

  it("makes external actions explicitly manual and never equates calendar status with publication", () => {
    expect(calendar).toContain("Calendar statuses document editorial progress only.");
    expect(calendar).toContain("This switch does not publish anything.");
    expect(calendar).toContain("require owner-authorized access");
    expect(calendar).not.toContain("window.open(");
    expect(calendar).not.toContain("window.fetch(");
  });
});
