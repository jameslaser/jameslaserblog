import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const html = readFileSync(resolve(process.cwd(), "client/index.html"), "utf8");
const manifest = JSON.parse(readFileSync(resolve(process.cwd(), "client/public/manifest.webmanifest"), "utf8")) as Record<string, unknown>;

describe("PWA shell", () => {
  it("offers install metadata without registering a service worker or caching protected routes", () => {
    expect(html).toContain('rel="manifest" href="/manifest.webmanifest"');
    expect(html).not.toContain("serviceWorker");
    expect(manifest.start_url).toBe("/");
    expect(manifest.display).toBe("standalone");
    expect(manifest.icons).toEqual([expect.objectContaining({ src: "/manus-storage/james-laser-pwa-icon_3ad614b0.svg", purpose: "any maskable" })]);
  });
});
