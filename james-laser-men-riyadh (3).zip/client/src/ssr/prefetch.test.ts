import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const prefetchSource = readFileSync(new URL("./prefetch.ts", import.meta.url), "utf8");

describe("public privacy-rights SSR metadata", () => {
  it("keeps English and Arabic privacy-rights routes out of the SSR not-found path", () => {
    expect(prefetchSource).toContain('cleanPath === "/privacy-rights" || cleanPath === "/ar/privacy-rights"');
    expect(prefetchSource).toContain('canonicalPath: cleanPath');
    expect(prefetchSource).toContain('englishAlternates("/privacy-rights", "/ar/privacy-rights")');
  });
});
