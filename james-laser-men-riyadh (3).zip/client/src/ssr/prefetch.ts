import type { QueryClient } from "@tanstack/react-query";
import { getQueryKey } from "@trpc/react-query";
import { trpc } from "@/lib/trpc";
import { publicUrl } from "@/seo";

export type Locale = "en" | "ar";

export type AlternateLink = {
  hrefLang: "en" | "ar-SA" | "x-default";
  path: string;
};

export type FaqSchemaItem = {
  question: string;
  answer: string;
};

export type HeadMeta = {
  title: string;
  description: string;
  canonicalPath?: string;
  locale?: "en_SA" | "ar_SA";
  documentLanguage?: Locale;
  ogType?: "website" | "article";
  ogImage?: string;
  ogImageAlt?: string;
  alternates?: AlternateLink[];
  breadcrumbs?: Array<{ name: string; path: string }>;
  faqItems?: FaqSchemaItem[];
  contentSchema?: Record<string, unknown>;
  articlePublishedTime?: string;
  articleModifiedTime?: string;
  articleSection?: string;
  articleTags?: string[];
  noindex?: boolean;
  notFound?: boolean;
};

/**
 * Deliberately allowlists viewer-independent public procedures available to SSR.
 * Mutations and protected procedures are never included in server-rendered HTML.
 */
export type SsrPrefetch = {
  clinicSettings: () => Promise<unknown>;
  homepageSections: () => Promise<unknown>;
  policies: () => Promise<unknown>;
  treatments: () => Promise<unknown>;
  promotions: () => Promise<unknown>;
  reviews: () => Promise<unknown>;
  resultCases: () => Promise<unknown>;
  guidePosts: () => Promise<unknown>;
  guidePostBySlug: (slug: string) => Promise<unknown>;
  faqs: () => Promise<unknown>;
};

type FaqRecord = {
  questionEn?: string | null;
  answerEn?: string | null;
  questionAr?: string | null;
  answerAr?: string | null;
};

const SITE = "James Laser Hair Removal for Men Riyadh @ New Look Clinic";
const DEFAULT_IMAGE = "/manus-storage/laser-treatment-male-clinic_c5465b0d.jpeg";

const homeFaqs: FaqSchemaItem[] = [
  {
    question: "How does laser hair removal for men in Riyadh begin?",
    answer: "It begins with a consultation request and an assessment of the treatment area, skin profile, hair profile and timing considerations.",
  },
  {
    question: "Which treatment areas can men request for laser hair removal?",
    answer: "The request form supports face and neck, chest and abdomen, back and shoulders, arms and hands, legs, mini full body, full body and multiple-area requests.",
  },
  {
    question: "Why does treatment timing matter for laser hair removal?",
    answer: "Treatment planning considers the hair-growth cycle and practical session timing as part of a clear, consistent plan.",
  },
];

function englishAlternates(path: string, arabicPath: string): AlternateLink[] {
  return [
    { hrefLang: "en", path },
    { hrefLang: "ar-SA", path: arabicPath },
    { hrefLang: "x-default", path },
  ];
}

function localizedFaqs(data: unknown, locale: Locale): FaqSchemaItem[] {
  if (!Array.isArray(data)) return homeFaqs;
  const items = (data as FaqRecord[])
    .map(item => ({
      question: locale === "ar" ? item.questionAr || item.questionEn || "" : item.questionEn || item.questionAr || "",
      answer: locale === "ar" ? item.answerAr || item.answerEn || "" : item.answerEn || item.answerAr || "",
    }))
    .filter(item => item.question.trim() && item.answer.trim());
  return items.length ? items : homeFaqs;
}

async function seed(queryClient: QueryClient, key: unknown, data: unknown) {
  queryClient.setQueryData(key as any, data as any);
}

async function loadSharedPublicData(queryClient: QueryClient, prefetch: SsrPrefetch) {
  const [clinicSettings, homepageSections, policies, treatments, promotions, reviews, resultCases, guidePosts, faqs] = await Promise.all([
    prefetch.clinicSettings(),
    prefetch.homepageSections(),
    prefetch.policies(),
    prefetch.treatments(),
    prefetch.promotions(),
    prefetch.reviews(),
    prefetch.resultCases(),
    prefetch.guidePosts(),
    prefetch.faqs(),
  ]);

  await Promise.all([
    seed(queryClient, getQueryKey(trpc.publicContent.clinicSettings, undefined, "query"), clinicSettings),
    seed(queryClient, getQueryKey(trpc.publicContent.homepageSections, undefined, "query"), homepageSections),
    seed(queryClient, getQueryKey(trpc.publicContent.policies, undefined, "query"), policies),
    seed(queryClient, getQueryKey(trpc.publicContent.treatments, undefined, "query"), treatments),
    seed(queryClient, getQueryKey(trpc.publicContent.promotions, undefined, "query"), promotions),
    seed(queryClient, getQueryKey(trpc.publicContent.reviews, undefined, "query"), reviews),
    seed(queryClient, getQueryKey(trpc.publicContent.resultCases, undefined, "query"), resultCases),
    seed(queryClient, getQueryKey(trpc.publicContent.guidePosts, undefined, "query"), guidePosts),
    seed(queryClient, getQueryKey(trpc.publicContent.faqs, undefined, "query"), faqs),
  ]);

  return { faqs };
}

async function loadClinicSettings(queryClient: QueryClient, prefetch: SsrPrefetch) {
  const clinicSettings = await prefetch.clinicSettings();
  await seed(queryClient, getQueryKey(trpc.publicContent.clinicSettings, undefined, "query"), clinicSettings);
}

async function loadPolicies(queryClient: QueryClient, prefetch: SsrPrefetch) {
  const [clinicSettings, policies] = await Promise.all([prefetch.clinicSettings(), prefetch.policies()]);
  await Promise.all([
    seed(queryClient, getQueryKey(trpc.publicContent.clinicSettings, undefined, "query"), clinicSettings),
    seed(queryClient, getQueryKey(trpc.publicContent.policies, undefined, "query"), policies),
  ]);
  return policies;
}

async function loadWhatsAppData(queryClient: QueryClient, prefetch: SsrPrefetch) {
  const [clinicSettings, treatments] = await Promise.all([prefetch.clinicSettings(), prefetch.treatments()]);
  await Promise.all([
    seed(queryClient, getQueryKey(trpc.publicContent.clinicSettings, undefined, "query"), clinicSettings),
    seed(queryClient, getQueryKey(trpc.publicContent.treatments, undefined, "query"), treatments),
  ]);
}

async function loadGuidePosts(queryClient: QueryClient, prefetch: SsrPrefetch) {
  const [clinicSettings, guidePosts] = await Promise.all([prefetch.clinicSettings(), prefetch.guidePosts()]);
  await Promise.all([
    seed(queryClient, getQueryKey(trpc.publicContent.clinicSettings, undefined, "query"), clinicSettings),
    seed(queryClient, getQueryKey(trpc.publicContent.guidePosts, undefined, "query"), guidePosts),
  ]);
  return guidePosts;
}

async function loadGuidePost(queryClient: QueryClient, prefetch: SsrPrefetch, slug: string) {
  const [clinicSettings, guidePost] = await Promise.all([prefetch.clinicSettings(), prefetch.guidePostBySlug(slug)]);
  await Promise.all([
    seed(queryClient, getQueryKey(trpc.publicContent.clinicSettings, undefined, "query"), clinicSettings),
    seed(queryClient, getQueryKey(trpc.publicContent.guidePostBySlug, { slug }, "query"), guidePost),
  ]);
  return guidePost;
}

function contentMeta(kind: "treatments" | "offers" | "results" | "faq" | "guide" | "blog", locale: Locale): HeadMeta {
  const arabic = locale === "ar";
  const path = `/${arabic ? "ar" : "en"}/${kind}`;
  const arabicPath = `/ar/${kind}`;
  const englishPath = `/en/${kind}`;
  const labels = {
    treatments: {
      en: ["Men’s Laser Hair Removal Treatments Riyadh | James Laser", "Explore clinic-approved men’s laser hair removal treatment areas in Riyadh, including preparation and aftercare guidance, then request an appointment."],
      ar: ["علاجات إزالة الشعر بالليزر للرجال في الرياض | جيمس ليزر", "تعرّف على مناطق علاج إزالة الشعر بالليزر للرجال في الرياض وإرشادات التحضير والعناية اللاحقة، ثم أرسل طلب موعدك."],
    },
    offers: {
      en: ["Men’s Laser Hair Removal Offers Riyadh | James Laser", "View current clinic-approved offers for men’s laser hair removal in Riyadh. Availability and treatment suitability are confirmed by the clinic."],
      ar: ["عروض إزالة الشعر بالليزر للرجال في الرياض | جيمس ليزر", "اطّلع على العروض الحالية المعتمدة لإزالة الشعر بالليزر للرجال في الرياض. تؤكد العيادة التوفر وملاءمة العلاج بشكل منفصل."],
    },
    results: {
      en: ["Men’s Laser Hair Removal Results Riyadh | James Laser", "View clinic-approved, consent-controlled laser hair removal result cases for men in Riyadh. Individual treatment outcomes can vary."],
      ar: ["نتائج إزالة الشعر بالليزر للرجال في الرياض | جيمس ليزر", "اطّلع على حالات نتائج إزالة الشعر بالليزر للرجال المعتمدة من العيادة والخاضعة للموافقة في الرياض. تختلف النتائج بين الأفراد."],
    },
    faq: {
      en: ["Men’s Laser Hair Removal FAQ Riyadh | James Laser", "Read clear answers about men’s laser hair removal in Riyadh, appointment requests, treatment preparation, aftercare, and timing."],
      ar: ["أسئلة إزالة الشعر بالليزر للرجال في الرياض | جيمس ليزر", "اقرأ إجابات واضحة عن إزالة الشعر بالليزر للرجال في الرياض وطلبات المواعيد والتحضير للجلسات والعناية اللاحقة والتوقيت."],
    },
    guide: {
      en: ["Men’s Laser Hair Removal Guide Riyadh | James Laser", "Read clinic-reviewed guidance for men’s laser hair removal in Riyadh, including preparation, aftercare, treatment areas, and appointment planning."],
      ar: ["دليل إزالة الشعر بالليزر للرجال في الرياض | جيمس ليزر", "اقرأ إرشادات مراجعة من العيادة لإزالة الشعر بالليزر للرجال في الرياض، بما يشمل التحضير والعناية اللاحقة ومناطق العلاج وطلب الموعد."],
    },
    blog: {
      en: ["Men’s Laser Hair Removal Blog Riyadh | James Laser", "Read clinic-reviewed articles about men’s laser hair removal in Riyadh, including preparation, aftercare, treatment areas, and realistic expectations."],
      ar: ["مدونة إزالة الشعر بالليزر للرجال في الرياض | جيمس ليزر", "اقرأ مقالات مراجعة من العيادة عن إزالة الشعر بالليزر للرجال في الرياض، تشمل التحضير والعناية اللاحقة ومناطق العلاج والتوقعات الواقعية."],
    },
  } as const;
  const [title, description] = labels[kind][arabic ? "ar" : "en"];
  return {
    title,
    description,
    canonicalPath: path,
    locale: arabic ? "ar_SA" : "en_SA",
    documentLanguage: locale,
    ogImage: DEFAULT_IMAGE,
    ogImageAlt: arabic ? "عيادة جيمس ليزر في الرياض" : "James Laser clinic in Riyadh",
    alternates: englishAlternates(englishPath, arabicPath),
    breadcrumbs: [
      { name: arabic ? "الرئيسية" : "Home", path: arabic ? "/ar" : "/" },
      { name: title.split("|")[0].trim(), path },
    ],
  };
}

function publicPolicyMatch(path: string) {
  return path.match(/^\/(ar\/)?policies\/([^/]+)$/);
}

export async function prefetchForPath(url: string, queryClient: QueryClient, prefetch: SsrPrefetch): Promise<HeadMeta> {
  let pathOnly = url.split("?")[0];
  try {
    pathOnly = decodeURI(pathOnly);
  } catch {
    // Keep malformed paths as-is so they resolve to the normal not-found response.
  }
  const cleanPath = pathOnly.replace(/\/+$/, "") || "/";

  if (cleanPath.startsWith("/admin") || cleanPath.startsWith("/api") || cleanPath === "/sign-consent" || cleanPath.startsWith("/login") || cleanPath.startsWith("/auth")) {
    return {
      title: `Secure area | ${SITE}`,
      description: "Private clinic workspace.",
      noindex: true,
    };
  }

  if (cleanPath === "/") {
    const { faqs } = await loadSharedPublicData(queryClient, prefetch);
    return {
      title: "Men’s Laser Hair Removal in Riyadh | New Look Clinic",
      description: "Professional men’s laser hair removal in Al Sahafah, Riyadh at New Look Clinic. Explore treatment areas and request a private consultation online.",
      canonicalPath: "/",
      locale: "en_SA",
      documentLanguage: "en",
      ogImage: DEFAULT_IMAGE,
      ogImageAlt: "Men’s laser hair removal at James Laser in Riyadh",
      alternates: englishAlternates("/", "/ar"),
      faqItems: localizedFaqs(faqs, "en"),
    };
  }

  if (cleanPath === "/ar") {
    const { faqs } = await loadSharedPublicData(queryClient, prefetch);
    return {
      title: "إزالة الشعر بالليزر للرجال في الرياض | جيمس ليزر",
      description: "إزالة شعر بالليزر للرجال في حي الصحافة، الرياض، في نيو لوك كلينيك. تعرّف على مناطق العلاج وأرسل طلب استشارة خاص عبر الإنترنت.",
      canonicalPath: "/ar",
      locale: "ar_SA",
      documentLanguage: "ar",
      ogImage: DEFAULT_IMAGE,
      ogImageAlt: "إزالة الشعر بالليزر للرجال في جيمس ليزر بالرياض",
      alternates: englishAlternates("/", "/ar"),
      faqItems: localizedFaqs(faqs, "ar"),
    };
  }

  const guideMatch = cleanPath.match(/^\/(en|ar)\/blog\/([^/]+)$/);
  if (guideMatch) {
    const locale = guideMatch[1] as Locale;
    const slug = guideMatch[2];
    const guide = await loadGuidePost(queryClient, prefetch, slug) as { slug?: string; postType?: "blog" | "video"; titleEn?: string | null; titleAr?: string | null; summaryEn?: string | null; summaryAr?: string | null; contentEn?: string | null; contentAr?: string | null; category?: string | null; tags?: string | null; authorName?: string | null; seoTitle?: string | null; metaDescription?: string | null; featuredImageUrl?: string | null; socialImageUrl?: string | null; videoUrl?: string | null; publishedAt?: Date | null; updatedAt?: Date | null } | null;
    const hasArabic = Boolean(guide?.titleAr?.trim() && (guide.summaryAr?.trim() || guide.contentAr?.trim()));
    if (!guide || (locale === "ar" && !hasArabic)) return { title: `Page not found | ${SITE}`, description: "The requested guide is not available.", noindex: true, notFound: true };
    const pageTitle = locale === "ar" ? guide.titleAr || guide.titleEn || "Guide" : guide.seoTitle || guide.titleEn || guide.titleAr || "Guide";
    const description = locale === "ar" ? guide.summaryAr || guide.contentAr || guide.summaryEn || guide.contentEn || "Clinic-reviewed guidance." : guide.metaDescription || guide.summaryEn || guide.contentEn || "Clinic-reviewed guidance.";
    const image = guide.socialImageUrl || guide.featuredImageUrl || DEFAULT_IMAGE;
    const englishPath = `/en/blog/${encodeURIComponent(slug)}`;
    const localizedPath = `/${locale}/blog/${encodeURIComponent(slug)}`;
    const contentSchema = guide.postType === "video" && guide.videoUrl
      ? { "@context": "https://schema.org", "@type": "VideoObject", name: pageTitle, description, thumbnailUrl: image, contentUrl: guide.videoUrl, uploadDate: guide.publishedAt?.toISOString() }
      : { "@context": "https://schema.org", "@type": "BlogPosting", headline: pageTitle, description, image, datePublished: guide.publishedAt?.toISOString(), dateModified: guide.updatedAt?.toISOString(), author: { "@type": "Person", name: guide.authorName || "Nurse James" }, publisher: { "@type": "Organization", name: SITE }, articleSection: guide.category || "Men’s laser hair removal", keywords: guide.tags || undefined, mainEntityOfPage: { "@type": "WebPage", "@id": publicUrl(localizedPath) } };
    return {
      title: `${pageTitle} | ${locale === "ar" ? "جيمس ليزر" : "James Laser"}`,
      description,
      canonicalPath: localizedPath,
      locale: locale === "ar" ? "ar_SA" : "en_SA",
      documentLanguage: locale,
      ogType: guide.postType === "blog" ? "article" : "website",
      ogImage: image,
      ogImageAlt: pageTitle,
      alternates: hasArabic ? englishAlternates(englishPath, `/ar/blog/${encodeURIComponent(slug)}`) : undefined,
      breadcrumbs: [
        { name: locale === "ar" ? "الرئيسية" : "Home", path: locale === "ar" ? "/ar" : "/" },
        { name: locale === "ar" ? "المدونة" : "Blog", path: locale === "ar" ? "/ar/blog" : "/en/blog" },
        { name: pageTitle, path: localizedPath },
      ],
      contentSchema,
      articlePublishedTime: guide.publishedAt?.toISOString(),
      articleModifiedTime: guide.updatedAt?.toISOString(),
      articleSection: guide.category || undefined,
      articleTags: guide.tags?.split(",").map(tag => tag.trim()).filter(Boolean),
    };
  }

  const contentMatch = cleanPath.match(/^\/(en|ar)\/(treatments|offers|results|faq|blog)$/);
  if (contentMatch) {
    const locale = contentMatch[1] as Locale;
    const kind = contentMatch[2] as "treatments" | "offers" | "results" | "faq" | "blog";
    if (kind === "blog") await loadGuidePosts(queryClient, prefetch);
    const { faqs } = kind === "blog" ? { faqs: [] } : await loadSharedPublicData(queryClient, prefetch);
    const meta = contentMeta(kind, locale);
    if (kind === "faq") meta.faqItems = localizedFaqs(faqs, locale);
    return meta;
  }

  if (cleanPath === "/appointment" || cleanPath === "/ar/appointment") {
    const arabic = cleanPath.startsWith("/ar/");
    await loadClinicSettings(queryClient, prefetch);
    return {
      title: arabic ? "طلب موعد ليزر للرجال الرياض | جيمس ليزر" : "Men’s Laser Hair Removal Appointment Riyadh | James Laser",
      description: arabic ? "أرسل طلب موعد خاص لإزالة الشعر بالليزر للرجال في الرياض. ستؤكد العيادة التوفر والخطوة التالية بشكل منفصل." : "Send a private men’s laser hair removal appointment request in Riyadh. The clinic confirms availability and the next step separately.",
      canonicalPath: arabic ? "/ar/appointment" : "/appointment",
      locale: arabic ? "ar_SA" : "en_SA",
      documentLanguage: arabic ? "ar" : "en",
      ogImage: DEFAULT_IMAGE,
      ogImageAlt: arabic ? "طلب موعد جيمس ليزر في الرياض" : "Request a James Laser appointment in Riyadh",
      alternates: englishAlternates("/appointment", "/ar/appointment"),
      breadcrumbs: [
        { name: arabic ? "الرئيسية" : "Home", path: arabic ? "/ar" : "/" },
        { name: arabic ? "طلب موعد" : "Appointment request", path: cleanPath },
      ],
    };
  }

  if (cleanPath === "/privacy-rights" || cleanPath === "/ar/privacy-rights") {
    const arabic = cleanPath.startsWith("/ar/");
    await loadClinicSettings(queryClient, prefetch);
    return {
      title: arabic ? "حقوق المريض والخصوصية | جيمس ليزر الرياض" : "Patient Rights & Privacy | James Laser Riyadh",
      description: arabic ? "معلومات عن حقوق المريض والخصوصية وطلب البيانات لدى جيمس ليزر في الرياض." : "Patient-rights, privacy, and personal-data request information for James Laser in Riyadh.",
      canonicalPath: cleanPath,
      locale: arabic ? "ar_SA" : "en_SA",
      documentLanguage: arabic ? "ar" : "en",
      ogImage: DEFAULT_IMAGE,
      ogImageAlt: arabic ? "حقوق المريض والخصوصية في جيمس ليزر" : "Patient rights and privacy at James Laser",
      alternates: englishAlternates("/privacy-rights", "/ar/privacy-rights"),
      breadcrumbs: [
        { name: arabic ? "الرئيسية" : "Home", path: arabic ? "/ar" : "/" },
        { name: arabic ? "حقوق المريض والخصوصية" : "Patient Rights & Privacy", path: cleanPath },
      ],
    };
  }

  if (cleanPath === "/whatsapp" || cleanPath === "/ar/whatsapp") {
    const arabic = cleanPath.startsWith("/ar/");
    await loadWhatsAppData(queryClient, prefetch);
    return {
      title: arabic ? "واتساب جيمس ليزر | تواصل مع العيادة في الرياض" : "WhatsApp James Laser | Contact the Clinic in Riyadh",
      description: arabic ? "تواصل مع جيمس ليزر في الرياض عبر واتساب للاستفسار عن الخدمات وطلب موعدك المفضل بصورة خاصة." : "Contact James Laser in Riyadh by WhatsApp for services, availability, and a private appointment request.",
      canonicalPath: cleanPath,
      locale: arabic ? "ar_SA" : "en_SA",
      documentLanguage: arabic ? "ar" : "en",
      ogImage: DEFAULT_IMAGE,
      ogImageAlt: arabic ? "تواصل عبر واتساب مع جيمس ليزر" : "Contact James Laser on WhatsApp",
      alternates: englishAlternates("/whatsapp", "/ar/whatsapp"),
      breadcrumbs: [
        { name: arabic ? "الرئيسية" : "Home", path: arabic ? "/ar" : "/" },
        { name: "WhatsApp", path: cleanPath },
      ],
    };
  }

  const policyMatch = publicPolicyMatch(cleanPath);
  if (policyMatch) {
    const arabic = Boolean(policyMatch[1]);
    const slug = policyMatch[2];
    const policies = await loadPolicies(queryClient, prefetch) as Array<{ slug?: string; titleEn?: string | null; titleAr?: string | null }>;
    const policy = Array.isArray(policies) ? policies.find(item => item.slug === slug) : undefined;
    if (!policy) {
      return {
        title: `Page not found | ${SITE}`,
        description: "The requested policy is not available.",
        noindex: true,
        notFound: true,
      };
    }
    const localizedTitle = (arabic ? policy.titleAr || policy.titleEn : policy.titleEn || policy.titleAr || "Policy")?.trim() || "Policy";
    return {
      title: `${localizedTitle} | ${arabic ? "جيمس ليزر" : "James Laser"}`,
      description: arabic ? "سياسة منشورة من جيمس ليزر للرجال في الرياض." : "Published policy from James Laser Hair Removal for Men in Riyadh.",
      canonicalPath: cleanPath,
      locale: arabic ? "ar_SA" : "en_SA",
      documentLanguage: arabic ? "ar" : "en",
      ogImage: DEFAULT_IMAGE,
      ogImageAlt: arabic ? "سياسة جيمس ليزر" : "James Laser policy",
      alternates: englishAlternates(`/policies/${slug}`, `/ar/policies/${slug}`),
      breadcrumbs: [
        { name: arabic ? "الرئيسية" : "Home", path: arabic ? "/ar" : "/" },
        { name: arabic ? "السياسات" : "Policies", path: cleanPath },
      ],
    };
  }

  return {
    title: `Page not found | ${SITE}`,
    description: "The requested page is not available.",
    noindex: true,
    notFound: true,
  };
}

export const SEO_DEFAULTS = {
  siteName: SITE,
  defaultImage: DEFAULT_IMAGE,
};
