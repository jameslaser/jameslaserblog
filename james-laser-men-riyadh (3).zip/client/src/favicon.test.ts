import { existsSync, readFileSync, statSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const publicPath = resolve(process.cwd(), "client/public");
const html = readFileSync(resolve(process.cwd(), "client/index.html"), "utf8");

describe("Nurse James favicon assets", () => {
  it("uses local favicon and Apple touch icon assets", () => {
    expect(html).toContain('<link rel="icon" href="/favicon.ico" sizes="any" />');
    expect(html).toContain('<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />');
    expect(html).toContain('<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />');
  });

  it("ships compact icon files with the public application", () => {
    for (const name of ["favicon.ico", "favicon-32x32.png", "apple-touch-icon.png"]) {
      const iconPath = resolve(publicPath, name);
      expect(existsSync(iconPath)).toBe(true);
      expect(statSync(iconPath).size).toBeGreaterThan(0);
    }
  });
});
