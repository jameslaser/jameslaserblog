import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
import { buildSitemapXml } from "../../server/sitemap";

const robots = readFileSync(resolve(process.cwd(), "client/public/robots.txt"), "utf8");
const index = readFileSync(resolve(process.cwd(), "client/index.html"), "utf8");
const prefetch = readFileSync(resolve(process.cwd(), "client/src/ssr/prefetch.ts"), "utf8");
const server = readFileSync(resolve(process.cwd(), "server/_core/vite.ts"), "utf8");

describe("public crawl configuration", () => {
  it("builds canonical English and Arabic public routes without portal URLs", () => {
    const sitemap = buildSitemapXml({ origin: "https://www.jameslaserformen.com", guidePosts: [], policies: [] });
    expect(sitemap).toContain("https://www.jameslaserformen.com/en/treatments");
    expect(sitemap).toContain("https://www.jameslaserformen.com/ar/treatments");
    expect(sitemap).toContain("https://www.jameslaserformen.com/appointment");
    expect(sitemap).toContain("https://www.jameslaserformen.com/ar/appointment");
    expect(sitemap).not.toMatch(/<loc>[^<]*\/(admin|api|sign-consent)/i);
  });

  it("adds only published blog and Arabic-detail URLs to the sitemap", () => {
    const sitemap = buildSitemapXml({
      origin: "https://www.jameslaserformen.com",
      guidePosts: [{ slug: "laser-preparation", publishedAt: new Date("2026-09-01"), titleAr: "التحضير", summaryAr: "إرشادات" }],
      policies: [{ slug: "privacy", publishedAt: new Date("2026-09-02"), titleAr: "الخصوصية", contentAr: "سياسة" }],
    });
    expect(sitemap).toContain("/en/blog/laser-preparation");
    expect(sitemap).toContain("/ar/blog/laser-preparation");
    expect(sitemap).not.toContain("/guide/");
    expect(sitemap).toContain("/policies/privacy");
    expect(sitemap).toContain("/ar/policies/privacy");
  });

  it("keeps explicit crawl restrictions for private routes and removes static SPA metadata", () => {
    expect(robots).toContain("Disallow: /admin");
    expect(robots).toContain("Disallow: /api/");
    expect(robots).toContain("Disallow: /sign-consent");
    expect(robots).toContain("Sitemap: https://www.jameslaserformen.com/sitemap.xml");
    expect(index).toContain("<!--app-head-->");
    expect(index).toContain("<!--app-html-->");
  });

  it("renders validated LocalBusiness and FAQ schema from the SSR layer without fabricated ratings", () => {
    expect(server).toContain('"@type": "LocalBusiness"');
    expect(server).toContain('telephone: "+966557401562"');
    expect(server).toContain('streetAddress: "New Look Clinic, Al Sahafah"');
    expect(server).not.toContain("aggregateRating");
    expect(server).not.toContain("openingHoursSpecification");
    expect(prefetch).toContain("faqItems: localizedFaqs");
  });

  it("adds only configured, HTTPS social profiles to LocalBusiness structured data", () => {
    expect(server).toContain("verifiedSocialProfiles");
    expect(server).toContain("sameAs: socialProfiles");
    expect(server).toContain('parsed.protocol === "https:"');
    expect(server).toContain('"youtube.com"');
    expect(server).toContain('"x.com"');
  });

  it("renders canonical Open Graph and Twitter card URLs for social crawlers", () => {
    expect(server).toContain('<meta property="og:title"');
    expect(server).toContain('<meta property="og:description"');
    expect(server).toContain('<meta property="og:url"');
    expect(server).toContain('<meta name="twitter:url"');
    expect(server).toContain('<meta name="twitter:card"');
    expect(server).toContain('<meta property="article:tag"');
  });
});
