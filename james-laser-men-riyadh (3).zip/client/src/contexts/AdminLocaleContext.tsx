import React, { createContext, useContext, useEffect, useMemo, useRef, useState } from "react";

export type AdminLocale = "en" | "ar";

type AdminLocaleValue = {
  locale: AdminLocale;
  isArabic: boolean;
  setLocale: (locale: AdminLocale) => void;
};

const STORAGE_KEY = "james-laser-admin-locale";
const AdminLocaleContext = createContext<AdminLocaleValue | null>(null);

export const adminNavLabelsAr: Record<string, string> = {
  Dashboard: "لوحة التحكم",
  "Attention Agent": "مركز التنبيهات",
  "Attention agent": "مركز التنبيهات",
  "Patient Requests": "طلبات المرضى",
  "Appointment requests": "طلبات المواعيد",
  Appointments: "المواعيد",
  "HMS Workspace": "مساحة HMS",
  "HMS access": "الوصول إلى HMS",
  "Waiting List": "قائمة الانتظار",
  "Waiting list": "قائمة الانتظار",
  Patients: "المرضى",
  Machines: "الأجهزة",
  Revenue: "الإيرادات",
  "Follow-ups": "المتابعات",
  "Session & retouch reminders": "تذكيرات الجلسات والرتوش",
  WhatsApp: "واتساب",
  Enquiries: "الاستفسارات",
  "Clinic Information": "معلومات العيادة",
  "Clinic info": "معلومات العيادة",
  "Homepage Content": "محتوى الصفحة الرئيسية",
  Homepage: "الصفحة الرئيسية",
  Treatments: "الخدمات",
  Promotions: "العروض",
  "Prices & promotions": "الأسعار والعروض",
  Reviews: "التقييمات",
  "Before & After": "قبل وبعد",
  "Before & after": "قبل وبعد",
  "Men’s Laser Guide": "دليل ليزر الرجال",
  "Content Calendar": "تقويم المحتوى",
  "Content calendar": "تقويم المحتوى",
  FAQs: "الأسئلة الشائعة",
  FAQ: "الأسئلة الشائعة",
  "Media Library": "مكتبة الوسائط",
  "Policies & Consent": "السياسات والموافقات",
  Policies: "السياسات",
  SEO: "تحسين محركات البحث",
  "Language Readiness": "جاهزية اللغة",
  "SEO overview": "نظرة SEO",
  Analytics: "التحليلات",
  "Data & Backup": "البيانات والنسخ الاحتياطي",
  "Data & backup": "البيانات والنسخ الاحتياطي",
  Redirects: "إعادة التوجيه",
  Notifications: "الإشعارات",
  "Activity Log": "سجل النشاط",
  "Activity log": "سجل النشاط",
  "Users & Security": "المستخدمون والأمان",
  "Users & roles": "المستخدمون والأدوار",
  Settings: "الإعدادات",
};

export const adminGroupLabelsAr: Record<string, string> = {
  Overview: "نظرة عامة",
  Clinic: "العيادة",
  Communication: "التواصل",
  Content: "المحتوى",
  Management: "الإدارة",
  Workspace: "مساحة العمل",
};

const adminTextAr: Record<string, string> = {
  "James Laser · owner portal": "جيمس ليزر · بوابة المالك",
  "Clinic control centre": "مركز إدارة العيادة",
  "Review new consultation requests, approve suitable clients, and keep confirmed appointments separate from the incoming request queue.": "راجع طلبات الاستشارة الجديدة، واعتمد الحالات المناسبة، وحافظ على فصل المواعيد المؤكدة عن قائمة الطلبات الواردة.",
  "Clinic inbox · private": "صندوق العيادة · خاص",
  "Patient requests": "طلبات المرضى",
  "Review the original public request, finalize protected appointment details, then explicitly approve and transfer it to Appointments. A request never appears in Appointments by itself.": "راجع الطلب العام الأصلي، ثم أكمل تفاصيل الموعد المحمية واعتمده وانقله صراحةً إلى المواعيد. لا يظهر أي طلب في المواعيد تلقائيًا.",
  "Protected financial reporting": "تقارير مالية محمية",
  Revenue: "الإيرادات",
  "Import the HMS Detail Revenue By Patient report, reconcile every service row against the HMS Grand Total, and review daily, patient, and service performance without rebuilding HMS accounting.": "استورد تقرير الإيرادات التفصيلي حسب المريض من HMS، وطابق كل صف خدمة مع الإجمالي العام، ثم راجع الأداء اليومي وأداء المرضى والخدمات دون إعادة بناء محاسبة HMS.",
  "HMS remains the source of truth. Print Date is stored as source metadata and is never used as a revenue date.": "يبقى HMS هو مصدر الحقيقة. يُحفظ تاريخ الطباعة كبيانات مصدر ولا يُستخدم كتاريخ للإيراد.",
  "Protected revenue · commission tracking": "إيرادات محمية · تتبع العمولة",
  "Monthly commission": "العمولة الشهرية",
  "A clear monthly view of the clinic’s imported HMS income and Nurse James’ commission. The 25% deduction is always applied before the 3% commission calculation.": "عرض شهري واضح لدخل العيادة المستورد من HMS وعمولة الممرض جيمس. يُطبق خصم 25٪ دائمًا قبل احتساب عمولة 3٪.",
  "Nurse James commission": "عمولة الممرض جيمس",
  "Select month": "اختر الشهر",
  "Current month": "الشهر الحالي",
  "Previous month": "الشهر السابق",
  "Commission calculations use the selected calendar month in": "تستخدم حسابات العمولة الشهر التقويمي المحدد في",
  "3% of commissionable income": "3٪ من الدخل الخاضع للعمولة",
  "Total income": "إجمالي الدخل",
  "25% deduction": "خصم 25٪",
  "Commissionable income": "الدخل الخاضع للعمولة",
  "My commission": "عمولتي",
  "Calculation flow": "تسلسل الاحتساب",
  "See exactly how the commission is calculated": "اطلع بوضوح على طريقة احتساب العمولة",
  "How is my commission calculated?": "كيف تُحتسب عمولتي؟",
  "Monthly summary": "الملخص الشهري",
  "Commission history": "سجل العمولة",
  "Only calendar months with existing imported HMS revenue are listed. No values are estimated or created manually.": "تُدرج فقط الأشهر التقويمية التي تحتوي على إيرادات HMS مستوردة. لا تُقدّر أي قيم أو تُنشأ يدويًا.",
  "HMS source records": "سجلات مصدر HMS",
  "Revenue import and reporting detail": "تفاصيل استيراد الإيرادات والتقارير",
  "Open only when importing a reconciled HMS report or reviewing the selected month’s protected service-level records.": "افتح هذا القسم فقط عند استيراد تقرير HMS تمت مطابقته أو عند مراجعة سجلات الخدمات المحمية للشهر المحدد.",
  "Open details": "فتح التفاصيل",
  "James Laser · operational communication": "جيمس ليزر · التواصل التشغيلي",
  WhatsApp: "واتساب",
  "A protected conversation workspace for customer messages, provider-ready reminder queues, and staff-controlled follow-up. Appointments remain clinic-confirmed records; no autonomous booking is enabled.": "مساحة محمية لرسائل العملاء وقوائم التذكير الجاهزة للمزود والمتابعة التي يتحكم بها الموظفون. تبقى المواعيد سجلات تؤكدها العيادة، ولا يوجد حجز تلقائي.",
  "Provider-ready architecture": "بنية جاهزة للربط بالمزود",
  "Private contact inbox": "صندوق التواصل الخاص",
  Enquiries: "الاستفسارات",
  Appointments: "المواعيد",
  "Finalized schedule": "الجدول المعتمد",
  "Appointments for the day": "مواعيد اليوم",
  "This page contains transferred appointments and separately sourced HMS appointments. Unreviewed public requests remain in Patient Requests and cannot appear here automatically.": "تحتوي هذه الصفحة على المواعيد المنقولة ومواعيد HMS ذات المصدر المنفصل. تبقى الطلبات العامة غير المراجعة في طلبات المرضى ولا تظهر هنا تلقائيًا.",
  "Add appointment": "إضافة موعد",
  "Upload Appointments": "رفع المواعيد",
  Today: "اليوم",
  "Status filter": "تصفية الحالة",
  Pending: "معلق",
  Cancelled: "ملغي",
  "Open Patient Requests": "فتح طلبات المرضى",
  "HMS appointment workspace": "مساحة مواعيد HMS",
  "Waiting list": "قائمة الانتظار",
  "Today · Riyadh": "اليوم · الرياض",
  "Selected date · Riyadh": "التاريخ المحدد · الرياض",
  "No appointments in today’s record": "لا توجد مواعيد في سجل اليوم",
  "Confirmed appointments for today will appear here in time order.": "ستظهر مواعيد اليوم المؤكدة هنا حسب الوقت.",
  Patients: "المرضى",
  "Clinic records": "سجلات العيادة",
  "Add patient": "إضافة مريض",
  "Search name or WhatsApp": "ابحث بالاسم أو واتساب",
  "Open a patient file": "افتح ملف مريض",
  "Select an approved patient to view the complete clinic record and appointment history.": "اختر مريضًا معتمدًا لعرض سجل العيادة الكامل وسجل المواعيد.",
  "No patient files yet": "لا توجد ملفات مرضى حتى الآن",
  Machines: "الأجهزة",
  "Machine records": "سجلات الأجهزة",
  "Clinic follow-up · private": "متابعة العيادة · خاص",
  "Session & retouch reminders": "تذكيرات الجلسات والرتوش",
  "Clinic information": "معلومات العيادة",
  "Homepage content": "محتوى الصفحة الرئيسية",
  Treatments: "الخدمات",
  "Prices & promotions": "الأسعار والعروض",
  Reviews: "التقييمات",
  "Before & after": "قبل وبعد",
  "Men’s laser guide": "دليل ليزر الرجال",
  "Content calendar": "تقويم المحتوى",
  "Frequently asked questions": "الأسئلة الشائعة",
  "Media library": "مكتبة الوسائط",
  "Policies & consent": "السياسات والموافقات",
  "SEO controls": "إعدادات تحسين محركات البحث",
  "Language readiness": "جاهزية اللغة",
  Notifications: "الإشعارات",
  "Activity log": "سجل النشاط",
  "Users & roles": "المستخدمون والأدوار",
  "Users & security": "المستخدمون والأمان",
  "Owner-only access control": "تحكم وصول خاص بالمالك",
  "Review authenticated staff accounts and assign only the operational role required. Patient information remains inaccessible to content editors, and role changes are restricted to the clinic owner.": "راجع حسابات الموظفين الموثقة وامنح كل مستخدم الدور التشغيلي المطلوب فقط. تبقى معلومات المرضى غير متاحة لمحرري المحتوى، وتقتصر تغييرات الأدوار على مالك العيادة.",
  Owner: "المالك",
  "Clinic equipment": "أجهزة العيادة",
  "Maintain a unique internal machine ID for each clinic machine. These are manual clinic identifiers and do not replace the manufacturer serial number.": "حافظ على معرّف داخلي فريد لكل جهاز في العيادة. هذه معرّفات تشغيلية يدوية ولا تحل محل الرقم التسلسلي للشركة المصنّعة.",
  "Use the internal machine ID consistently in operational records and printouts.": "استخدم معرّف الجهاز الداخلي بصورة متسقة في السجلات التشغيلية والمطبوعات.",
  "Internal machine ID": "معرّف الجهاز الداخلي",
  "Save ID": "حفظ المعرّف",
  "Appointment configuration": "إعدادات المواعيد",
  "Manage request configuration without promising real-time availability.": "أدر إعدادات الطلبات دون تقديم وعود بتوفر المواعيد في الوقت الفعلي.",
  "These central controls are stored with clinic settings. They shape request preferences only; the clinic still reviews every request before confirming availability.": "تُحفظ عناصر التحكم المركزية هذه ضمن إعدادات العيادة. وهي تحدد تفضيلات الطلب فقط؛ وتستمر العيادة في مراجعة كل طلب قبل تأكيد التوفر.",
  "Available request days": "أيام الطلب المتاحة",
  "Preferred time choices": "خيارات الوقت المفضل",
  "Request treatment choices": "خيارات منطقة العلاج",
  "Visit-type choices": "خيارات نوع الزيارة",
  "Default public language": "اللغة الافتراضية للموقع العام",
  "Enable public appointment requests": "تمكين طلبات المواعيد العامة",
  "Maintenance mode (pauses public appointment requests)": "وضع الصيانة (يوقف طلبات المواعيد العامة)",
  "Save appointment settings": "حفظ إعدادات المواعيد",
  "Optional: Monday, Tuesday, Wednesday": "اختياري: الاثنين، الثلاثاء، الأربعاء",
  "Optional: Full Face, Chest, Full Body": "اختياري: الوجه بالكامل، الصدر، الجسم بالكامل",
  "Optional: 13:00, 13:15, 13:30": "اختياري: 13:00، 13:15، 13:30",
  "session, retouch": "جلسة، رتوش",
  "Last sign-in": "آخر تسجيل دخول",
  Admin: "مسؤول",
  "Content editor": "محرر المحتوى",
  Reception: "الاستقبال",
  "No staff access": "دون وصول للموظفين",
  "Automation workspace unavailable": "مساحة عمل الأتمتة غير متاحة",
  "The protected queue could not be loaded. Refresh this page; no message has been sent or changed.": "تعذر تحميل قائمة الانتظار المحمية. حدّث هذه الصفحة؛ لم تُرسل أو تُغيّر أي رسالة.",
  Settings: "الإعدادات",
  Analytics: "التحليلات",
  "Data & backup": "البيانات والنسخ الاحتياطي",
  Redirects: "إعادة التوجيه",
  "Website operations": "عمليات الموقع",
  "Content & moderation": "المحتوى والمراجعة",
  "Attention queue": "قائمة التنبيهات",
  "Recent appointment requests": "طلبات المواعيد الأخيرة",
  "View requests": "عرض الطلبات",
  "No new appointment requests are waiting for review.": "لا توجد طلبات مواعيد جديدة بانتظار المراجعة.",
  Request: "طلب",
  "New request": "طلب جديد",
  View: "عرض",
  "Quick actions": "إجراءات سريعة",
  "Recent activity": "النشاط الأخير",
  "Preview website": "معاينة الموقع",
  "Workflow safeguard": "ضابط سير العمل",
  "A request becomes an appointment only after approval.": "لا يتحول الطلب إلى موعد إلا بعد الاعتماد.",
  "Patient requests, cancelled requests, and confirmed appointments are deliberately held in separate views to keep the daily schedule accurate.": "تُعرض طلبات المرضى والطلبات الملغاة والمواعيد المؤكدة في قوائم منفصلة للحفاظ على دقة الجدول اليومي.",
  "Review requests": "مراجعة الطلبات",
  "Review patient requests": "مراجعة طلبات المرضى",
  "Open appointments": "فتح المواعيد",
  "Manage treatments": "إدارة الخدمات",
  "Review promotions": "مراجعة العروض",
  "Activity history is available to owner and administrator roles.": "سجل النشاط متاح لأدوار المالك والمدير.",
  "No privileged activity has been recorded yet.": "لم يتم تسجيل نشاط إداري حتى الآن.",
  System: "النظام",
  "Pending requests": "الطلبات المعلقة",
  "Awaiting clinic review": "بانتظار مراجعة العيادة",
  "Confirmed today": "المؤكد اليوم",
  "Approved appointment records": "سجلات المواعيد المعتمدة",
  "Transferred requests": "الطلبات المنقولة",
  "Linked to appointments": "مرتبطة بالمواعيد",
  "Cancelled requests": "الطلبات الملغاة",
  "Retained for audit context": "محفوظة لسياق التدقيق",
  "Pending reviews": "تقييمات معلقة",
  "Awaiting approval": "بانتظار الاعتماد",
  "Active promotions": "عروض نشطة",
  "Published offers": "عروض منشورة",
  "Published guide posts": "مقالات دليل منشورة",
  "Live education content": "محتوى تثقيفي منشور",
  "Published reviews": "تقييمات منشورة",
  "Approved public reviews": "تقييمات عامة معتمدة",
  "No appointment requests found": "لا توجد طلبات مواعيد",
  "No matching follow-ups": "لا توجد متابعات مطابقة",
  "Loading protected workspace…": "جارٍ تحميل مساحة العمل المحمية…",
  "Loading patient requests…": "جارٍ تحميل طلبات المرضى…",
  "Loading staff accounts…": "جارٍ تحميل حسابات الموظفين…",
  "Loading appointment settings…": "جارٍ تحميل إعدادات المواعيد…",
  "Loading staff notifications…": "جارٍ تحميل إشعارات الموظفين…",
  "Loading machine records…": "جارٍ تحميل سجلات الأجهزة…",
  "Machines unavailable": "تعذر تحميل الأجهزة",
  "Machine inventory could not be loaded from the protected clinic database.": "تعذر تحميل مخزون الأجهزة من قاعدة بيانات العيادة المحمية.",
  "No machine records": "لا توجد سجلات أجهزة",
  "No clinic machine records are currently available.": "لا توجد حاليًا سجلات أجهزة متاحة للعيادة.",
  "Loading waiting list…": "جارٍ تحميل قائمة الانتظار…",
  "Waiting list unavailable": "قائمة الانتظار غير متاحة",
  "The waiting list could not be loaded from the protected clinic database.": "تعذر تحميل قائمة الانتظار من قاعدة بيانات العيادة المحمية.",
  "No staff accounts available": "لا توجد حسابات موظفين",
  "No authenticated staff accounts are available to manage in this portal session.": "لا توجد حسابات موظفين موثقة متاحة للإدارة في جلسة البوابة الحالية.",
  "Try again": "حاول مرة أخرى",
  "New requests from the public website will appear here for private clinic review.": "ستظهر الطلبات الجديدة من الموقع العام هنا لمراجعة العيادة الخاصة.",
  "View public appointment page": "عرض صفحة المواعيد العامة",
  shown: "معروض",
  "Search request ID, name, or mobile": "ابحث برقم الطلب أو الاسم أو الجوال",
  "All statuses": "كل الحالات",
  "All visit types": "كل أنواع الزيارة",
  Session: "جلسة",
  Retouch: "رتوش",
  "All languages": "كل اللغات",
  English: "الإنجليزية",
  Arabic: "العربية",
  "Reset filters": "إعادة ضبط الفلاتر",
  "Any preferred date": "أي تاريخ مفضل",
  Tomorrow: "غدًا",
  "This week": "هذا الأسبوع",
  "Custom date": "تاريخ مخصص",
  "Filter treatment area": "تصفية منطقة العلاج",
  Overview: "نظرة عامة",
  "Session reminders": "تذكيرات الجلسات",
  "Retouch reminders": "تذكيرات الرتوش",
  "Awaiting reply": "بانتظار الرد",
  Confirmed: "مؤكد",
  "Cannot attend": "لا يستطيع الحضور",
  "Retouch requests": "طلبات الرتوش",
  "Awaiting clinic": "بانتظار العيادة",
  Failed: "فشل",
  "Message history": "سجل الرسائل",
  Inbox: "الوارد",
  Conversations: "المحادثات",
  Contacts: "جهات الاتصال",
  Templates: "القوالب",
  Automations: "الأتمتة",
  Webhooks: "سجلات الربط",
  "Import Detail Revenue By Patient": "استيراد تقرير الإيرادات التفصيلي حسب المريض",
  "Upload first to parse patient groups and service rows. Patient subtotals and Grand Total are used for reconciliation only and are never stored as transactions.": "ارفع الملف أولًا لتحليل مجموعات المرضى وصفوف الخدمات. تُستخدم المجاميع الفرعية والإجمالي العام للمطابقة فقط ولا تُحفظ كمعاملات.",
  "CSV only · maximum 1 MB · selecting a file does not import or create patient data.": "ملف CSV فقط · الحد الأقصى 1 ميجابايت · اختيار الملف لا يستورد بيانات مرضى ولا ينشئها.",
  "Choose HMS CSV": "اختيار ملف HMS CSV",
  "Governed HMS intake": "استقبال HMS منضبط",
  "Today net revenue": "صافي إيراد اليوم",
  "Month net revenue": "صافي إيراد الشهر",
  "Gross revenue": "إجمالي الإيراد",
  Discounts: "الخصومات",
  Deductions: "الاستقطاعات",
  "Net revenue": "صافي الإيراد",
  Quantity: "الكمية",
  "HMS report period today": "فترة تقرير HMS لليوم",
  "HMS report period this month": "فترة تقرير HMS لهذا الشهر",
  "Current filtered view": "العرض المصفّى الحالي",
  "HMS values preserved": "قيم HMS محفوظة",
  "Primary income metric": "مؤشر الدخل الأساسي",
  "HMS service quantity": "كمية خدمات HMS",
};

export function translateAdminText(value: string, locale: AdminLocale) {
  return locale === "ar" ? adminTextAr[value] ?? value : value;
}

const originalText = new WeakMap<Text, string>();
const translatedAttributes = ["placeholder", "aria-label", "title"] as const;

function translateTextNode(node: Text, locale: AdminLocale) {
  const original = originalText.get(node) ?? node.nodeValue ?? "";
  if (!originalText.has(node)) originalText.set(node, original);
  if (locale === "en") {
    if (node.nodeValue !== original) node.nodeValue = original;
    return;
  }
  const trimmed = original.trim();
  const translated = translateAdminText(trimmed, locale);
  if (translated === trimmed) return;
  const leading = original.match(/^\s*/)?.[0] ?? "";
  const trailing = original.match(/\s*$/)?.[0] ?? "";
  const next = `${leading}${translated}${trailing}`;
  if (node.nodeValue !== next) node.nodeValue = next;
}

function translateElement(element: Element, locale: AdminLocale) {
  if (element.matches("script, style, [data-admin-no-translate]") || element.closest("[data-admin-no-translate]")) return;
  const elements = [element, ...Array.from(element.querySelectorAll("*"))];
  for (const target of elements) {
    if (target.matches("script, style, [data-admin-no-translate]") || target.closest("[data-admin-no-translate]")) continue;
    for (const attribute of translatedAttributes) {
      const value = target.getAttribute(attribute);
      const dataKey = `adminOriginal${attribute.replace(/(^|-)([a-z])/g, (_, _separator, letter: string) => letter.toUpperCase())}`;
      const host = target as HTMLElement;
      const original = host.dataset[dataKey] ?? value;
      if (!original) continue;
      host.dataset[dataKey] = original;
      target.setAttribute(attribute, locale === "ar" ? translateAdminText(original, locale) : original);
    }
  }
  const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
  let node = walker.nextNode();
  while (node) {
    if (!node.parentElement?.closest("[data-admin-no-translate]")) translateTextNode(node as Text, locale);
    node = walker.nextNode();
  }
}

function AdminDocumentLocalizer({ locale }: { locale: AdminLocale }) {
  useEffect(() => {
    const apply = (node: Node) => {
      if (node.nodeType === Node.TEXT_NODE) {
        const parent = node.parentElement;
        if (parent && (parent.closest(".admin-portal") || document.body.classList.contains("admin-shell-active"))) translateTextNode(node as Text, locale);
        return;
      }
      if (!(node instanceof Element)) return;
      if (node.closest(".admin-portal") || node.matches(".admin-portal") || document.body.classList.contains("admin-shell-active")) translateElement(node, locale);
    };
    const frame = requestAnimationFrame(() => document.querySelectorAll(".admin-portal").forEach(root => translateElement(root, locale)));
    const observer = new MutationObserver(records => records.forEach(record => {
      if (record.type === "characterData") apply(record.target);
      record.addedNodes.forEach(apply);
    }));
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
    return () => { cancelAnimationFrame(frame); observer.disconnect(); };
  }, [locale]);
  return null;
}

export const adminShellCopy = {
  en: {
    adminPortal: "Admin portal",
    secureWorkspace: "Secure clinic workspace",
    collapseNavigation: "Collapse navigation",
    globalSearch: "Search requests, patients, appointments, content…",
    mobileSearch: "Search authorized records",
    searching: "Searching authorized records…",
    searchError: "Search could not be completed. Try again.",
    noMatches: "No authorized matches found.",
    clearSearch: "Clear global search",
    notifications: "Notifications",
    viewWebsite: "View website",
    accountSettings: "Account & settings",
    signOut: "Sign out",
    clinicUser: "Clinic user",
    primaryNavigation: "Primary mobile navigation",
    openAllSections: "Open all admin sections",
    more: "More",
    requests: "Requests",
    signInEyebrow: "James Laser · secure access",
    signInTitle: "Sign in to continue",
    signInBody: "Use an authorized clinic account to open the protected portal.",
    signInAction: "Sign in securely",
  },
  ar: {
    adminPortal: "بوابة الإدارة",
    secureWorkspace: "مساحة عمل العيادة الآمنة",
    collapseNavigation: "طي قائمة التنقل",
    globalSearch: "ابحث في الطلبات والمرضى والمواعيد والمحتوى…",
    mobileSearch: "ابحث في السجلات المصرح بها",
    searching: "جارٍ البحث في السجلات المصرح بها…",
    searchError: "تعذر إكمال البحث. حاول مرة أخرى.",
    noMatches: "لا توجد نتائج مصرح بها.",
    clearSearch: "مسح البحث العام",
    notifications: "الإشعارات",
    viewWebsite: "عرض الموقع",
    accountSettings: "الحساب والإعدادات",
    signOut: "تسجيل الخروج",
    clinicUser: "مستخدم العيادة",
    primaryNavigation: "التنقل الرئيسي للجوال",
    openAllSections: "فتح جميع أقسام الإدارة",
    more: "المزيد",
    requests: "الطلبات",
    signInEyebrow: "جيمس ليزر · دخول آمن",
    signInTitle: "سجّل الدخول للمتابعة",
    signInBody: "استخدم حساب عيادة مصرحًا به لفتح البوابة المحمية.",
    signInAction: "تسجيل الدخول الآمن",
  },
} as const;

export function localizeAdminLabel(label: string, locale: AdminLocale) {
  return locale === "ar" ? adminNavLabelsAr[label] ?? label : label;
}

export function localizeAdminGroup(label: string, locale: AdminLocale) {
  return locale === "ar" ? adminGroupLabelsAr[label] ?? label : label;
}

export function AdminLocaleProvider({ children }: { children: React.ReactNode }) {
  const previousDocument = useRef<{ lang: string; dir: string } | null>(null);
  const [locale, setLocale] = useState<AdminLocale>(() => {
    const requestedLocale = new URLSearchParams(window.location.search).get("lang");
    if (requestedLocale === "ar" || requestedLocale === "en") return requestedLocale;
    return localStorage.getItem(STORAGE_KEY) === "ar" ? "ar" : "en";
  });

  useEffect(() => {
    previousDocument.current = {
      lang: document.documentElement.lang || "en",
      dir: document.documentElement.dir || "ltr",
    };
    document.body.classList.add("admin-shell-active");
    return () => {
      document.body.classList.remove("admin-shell-active");
      const previous = previousDocument.current;
      if (previous) {
        document.documentElement.lang = previous.lang;
        document.documentElement.dir = previous.dir;
      }
    };
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, locale);
    document.documentElement.lang = locale === "ar" ? "ar" : "en";
    document.documentElement.dir = locale === "ar" ? "rtl" : "ltr";
  }, [locale]);

  const value = useMemo<AdminLocaleValue>(() => ({ locale, isArabic: locale === "ar", setLocale }), [locale]);
  return <AdminLocaleContext.Provider value={value}><AdminDocumentLocalizer locale={locale} />{children}</AdminLocaleContext.Provider>;
}

export function useAdminLocale() {
  const value = useContext(AdminLocaleContext);
  if (!value) throw new Error("useAdminLocale must be used within AdminLocaleProvider");
  return value;
}
