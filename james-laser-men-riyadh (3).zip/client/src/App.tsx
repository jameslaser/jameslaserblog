import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useEffect } from "react";
import { PwaInstallPrompt } from "@/components/PwaInstallPrompt";
import { AnalyticsEmbed } from "@/components/AnalyticsEmbed";
import NotFound from "@/pages/NotFound";
import { Route, Switch, useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import AdminPortal from "./pages/AdminPortal";
import AppointmentRequest from "./pages/AppointmentRequest";
import BlogIndex from "./pages/BlogIndex";
import ConsentSignature from "./pages/ConsentSignature";
import Home from "./pages/Home";
import PublicContent, { type PublicContentKind } from "./pages/PublicContent";
import PublicGuidePost from "./pages/PublicGuidePost";
import PublicLanding from "./pages/PublicLanding";
import PublicPolicy from "./pages/PublicPolicy";
import PrivacyRights from "./pages/PrivacyRights";
import WhatsAppPage from "./pages/WhatsAppPage";

function PublicCrawlDirective() {
  const [path] = useLocation();
  const indexable = path === "/" || path === "/ar" || path === "/appointment" || path === "/ar/appointment" || path === "/whatsapp" || path === "/ar/whatsapp" || path === "/privacy-rights" || path === "/ar/privacy-rights" || /^\/(en|ar)\/(treatments|offers|results|faq|blog)$/.test(path) || /^\/(en|ar)\/blog\/[^/]+$/.test(path);
  useEffect(() => {
    if (!indexable) return;
    const robots = document.querySelector('meta[name="robots"]') || document.head.appendChild(document.createElement("meta"));
    robots.setAttribute("name", "robots");
    robots.setAttribute("content", "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1");
  }, [indexable, path]);
  return null;
}

function Router() {
  const publicRoute = (kind: PublicContentKind, locale: "en" | "ar") => () => <PublicContent kind={kind} locale={locale} />;
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/sign-consent"} component={ConsentSignature} />
      <Route path={"/whatsapp"}>{() => <WhatsAppPage locale="en" />}</Route>
      <Route path={"/en/whatsapp"}>{() => <WhatsAppPage locale="en" />}</Route>
      <Route path={"/ar/whatsapp"}>{() => <WhatsAppPage locale="ar" />}</Route>
      <Route path={"/appointment"}>{() => <AppointmentRequest locale="en" />}</Route>
      <Route path={"/en/appointment"}>{() => <AppointmentRequest locale="en" />}</Route>
      <Route path={"/ar/appointment"}>{() => <AppointmentRequest locale="ar" />}</Route>
      <Route path={"/privacy-rights"}>{() => <PrivacyRights locale="en" />}</Route>
      <Route path={"/ar/privacy-rights"}>{() => <PrivacyRights locale="ar" />}</Route>
      <Route path={"/ar/policies/:slug"}>{() => <PublicPolicy locale="ar" />}</Route>
      <Route path={"/policies/:slug"}>{() => <PublicPolicy />}</Route>
      <Route path={"/en/blog/:slug"}>{() => <PublicGuidePost locale="en" />}</Route>
      <Route path={"/ar/blog/:slug"}>{() => <PublicGuidePost locale="ar" />}</Route>
      <Route path={"/en/guide/:slug"}>{() => <PublicGuidePost locale="en" />}</Route>
      <Route path={"/ar/guide/:slug"}>{() => <PublicGuidePost locale="ar" />}</Route>
      <Route path={"/en/treatments"}>{publicRoute("treatments", "en")}</Route>
      <Route path={"/ar/treatments"}>{publicRoute("treatments", "ar")}</Route>
      <Route path={"/treatments"}>{publicRoute("treatments", "en")}</Route>
      <Route path={"/en/offers"}>{publicRoute("offers", "en")}</Route>
      <Route path={"/ar/offers"}>{publicRoute("offers", "ar")}</Route>
      <Route path={"/offers"}>{publicRoute("offers", "en")}</Route>
      <Route path={"/en/results"}>{publicRoute("results", "en")}</Route>
      <Route path={"/ar/results"}>{publicRoute("results", "ar")}</Route>
      <Route path={"/results"}>{publicRoute("results", "en")}</Route>
      <Route path={"/en/faq"}>{publicRoute("faq", "en")}</Route>
      <Route path={"/ar/faq"}>{publicRoute("faq", "ar")}</Route>
      <Route path={"/faq"}>{publicRoute("faq", "en")}</Route>
      <Route path={"/en/blog"}>{() => <BlogIndex locale="en" />}</Route>
      <Route path={"/ar/blog"}>{() => <BlogIndex locale="ar" />}</Route>
      <Route path={"/blog"}>{() => <BlogIndex locale="en" />}</Route>
      <Route path={"/en/guide"}>{publicRoute("guide", "en")}</Route>
      <Route path={"/ar/guide"}>{publicRoute("guide", "ar")}</Route>
      <Route path={"/guide"}>{publicRoute("guide", "en")}</Route>
      <Route path={"/en"} component={Home} />
      <Route path={"/ar"}>{() => <PublicLanding locale="ar" />}</Route>
      <Route path={"/"} component={Home} />
      <Route path={"/admin"}>{() => <AdminPortal page="dashboard" />}</Route>
      <Route path={"/admin/requests"}>{() => <AdminPortal page="requests" />}</Route>
      <Route path={"/admin/appointments"}>{() => <AdminPortal page="appointments" />}</Route>
      <Route path={"/admin/sessions"}>{() => <AdminPortal page="sessions" />}</Route>
      <Route path={"/admin/follow-ups"}>{() => <AdminPortal page="followups" />}</Route>
      <Route path={"/admin/hms"}>{() => <AdminPortal page="hms" />}</Route>
      <Route path={"/admin/attention"}>{() => <AdminPortal page="attention" />}</Route>
      <Route path={"/admin/waiting-list"}>{() => <AdminPortal page="waiting" />}</Route>
      <Route path={"/admin/reminders"}>{() => <AdminPortal page="followups" />}</Route>
      <Route path={"/admin/patients"}>{() => <AdminPortal page="patients" />}</Route>
      <Route path={"/admin/machines"}>{() => <AdminPortal page="machines" />}</Route>
      <Route path={"/admin/content"}>{() => <AdminPortal page="content" />}</Route>
      <Route path={"/admin/clinic"}>{() => <AdminPortal page="clinic" />}</Route>
      <Route path={"/admin/appearance"}>{() => <AdminPortal page="appearance" />}</Route>
      <Route path={"/admin/treatments"}>{() => <AdminPortal page="treatments" />}</Route>
      <Route path={"/admin/promotions"}>{() => <AdminPortal page="promotions" />}</Route>
      <Route path={"/admin/reviews"}>{() => <AdminPortal page="reviews" />}</Route>
      <Route path={"/admin/results"}>{() => <AdminPortal page="results" />}</Route>
      <Route path={"/admin/guide"}>{() => <AdminPortal page="guide" />}</Route>
      <Route path={"/admin/calendar"}>{() => <AdminPortal page="calendar" />}</Route>
      <Route path={"/admin/faqs"}>{() => <AdminPortal page="faqs" />}</Route>
      <Route path={"/admin/media"}>{() => <AdminPortal page="media" />}</Route>
      <Route path={"/admin/policies"}>{() => <AdminPortal page="policies" />}</Route>
      <Route path={"/admin/seo"}>{() => <AdminPortal page="seo" />}</Route>
      <Route path={"/admin/languages"}>{() => <AdminPortal page="languages" />}</Route>
      <Route path={"/admin/activity"}>{() => <AdminPortal page="activity" />}</Route>
      <Route path={"/admin/security"}>{() => <AdminPortal page="security" />}</Route>
      <Route path={"/admin/notifications"}>{() => <AdminPortal page="notifications" />}</Route>
      <Route path={"/admin/settings"}>{() => <AdminPortal page="settings" />}</Route>
      <Route path={"/admin/enquiries"}>{() => <AdminPortal page="enquiries" />}</Route>
      <Route path={"/admin/web-chat"}>{() => <AdminPortal page="webchat" />}</Route>
      <Route path={"/admin/whatsapp"}>{() => <AdminPortal page="whatsapp" />}</Route>
      <Route path={"/admin/analytics"}>{() => <AdminPortal page="analytics" />}</Route>
      <Route path={"/admin/data"}>{() => <AdminPortal page="data" />}</Route>
      <Route path={"/admin/revenue"}>{() => <AdminPortal page="revenue" />}</Route>
      <Route path={"/admin/redirects"}>{() => <AdminPortal page="redirects" />}</Route>
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <AnalyticsEmbed />
          <PublicCrawlDirective />
          <Router />
          <PwaInstallPrompt />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
