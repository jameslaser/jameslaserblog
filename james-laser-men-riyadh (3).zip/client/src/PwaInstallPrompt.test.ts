import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const promptSource = readFileSync(new URL("./components/PwaInstallPrompt.tsx", import.meta.url), "utf8");
const appSource = readFileSync(new URL("./App.tsx", import.meta.url), "utf8");
const documentSource = readFileSync(new URL("../index.html", import.meta.url), "utf8");
const manifestSource = readFileSync(new URL("../public/manifest.webmanifest", import.meta.url), "utf8");

describe("safe PWA install readiness", () => {
  it("keeps the install prompt public-only and does not introduce a service worker", () => {
    expect(promptSource).toContain('!path.startsWith("/admin")');
    expect(promptSource).toContain('!path.startsWith("/sign-consent")');
    expect(promptSource).toContain("Private clinic data is not cached for offline use.");
    expect(promptSource).not.toContain("serviceWorker");
  });

  it("mounts the install prompt and retains mobile zoom plus install metadata", () => {
    expect(appSource).toContain("<PwaInstallPrompt />");
    expect(documentSource).toContain('content="width=device-width, initial-scale=1.0"');
    expect(documentSource).toContain("apple-mobile-web-app-title");
    expect(manifestSource).toContain('"id": "/"');
    expect(manifestSource).toContain('"scope": "/"');
    expect(manifestSource).not.toContain("service_worker");
  });
});
