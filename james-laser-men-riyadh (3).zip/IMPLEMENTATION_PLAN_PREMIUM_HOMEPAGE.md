# Premium Public Homepage and Appointment Request — Implementation Plan

## Existing system confirmed

The current React/Express/tRPC application already has one English public homepage at `/` and `/en`, an Arabic public landing at `/ar`, one appointment request route at `/appointment` and `/ar/appointment`, one `consultationRequests` table, one protected `Admin Portal → Appointment requests` workspace, one staff-controlled consent-signature service, one WhatsApp integration, one clinic-settings record for the map/contact/social configuration, public treatment CMS data, the four controlled machines, bilingual routing, SSR SEO, sitemap, robots, PWA, authentication, and role-based server procedures.

## Minimal-change implementation

1. Replace the shorter English/Arabic landing implementations with one reusable bilingual premium homepage component while keeping the same routes and backend.
2. Reuse only existing branded media and configured clinic contact, map, social, treatment, homepage, and logo values. No generated or unverified model images will be introduced.
3. Add the requested concise homepage order: hero; introduction; areas; skin/hair education; machines; treatment process; Nurse James; clinic; map; appointment process; appointment CTA; footer.
4. Keep the appointment form on its existing route to avoid duplicating the request workflow, while making the journey continuous through anchored CTAs and matching design.
5. Extend the existing appointment request payload and `consultationRequests` entity with conditional clinical-review fields already represented by the legacy model: last session, medication details/dates/dosage, recent exposure/treatment date, and skin-condition description. Existing rows remain valid through nullable additive fields.
6. Reuse the immutable original consent set reference and documents. Keep original PDFs unchanged. Require the existing document-opening acknowledgement, an accuracy acknowledgement, and an on-form touchscreen signature before submission. Store only protected signature evidence references against the exact created request.
7. Preserve server-side validation, rate controls, one public request → one protected queue record, explicit staff-only transfer to Appointments, and existing RBAC.
8. Extend the existing protected Appointment Requests details with every newly collected screening and consent/signature field. No new admin page will be created.
9. Add focused regression tests, run full TypeScript/tests/build, run the HMS publication gate repeatedly, and perform desktop/mobile/RTL browser review without submitting live public data.

## Safety boundaries

No production database reset, seed, delete, deployment, DNS change, external publication, real customer submission, live WhatsApp send, or paid generation will occur. Any schema migration will be additive and reviewed; deployment/database application remains separate from this code change unless explicitly authorized.
