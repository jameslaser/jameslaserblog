# WhatsApp Appointment Automation Centre

## Purpose and implementation boundary

The **WhatsApp Appointment Automation Centre** extends the existing protected Admin Portal and official Meta WhatsApp Cloud API integration. It creates reviewable message jobs for the appointment lifecycle without creating, moving, cancelling, or making clinical decisions about appointments. All appointment creation, rescheduling, cancellation, attendance, and treatment decisions remain protected staff actions in the current clinic workflow.

The implementation uses the existing application database and existing WhatsApp entities. It does **not** introduce a separate CRM, WhatsApp Web/browser automation, a public API, a new database, or a replacement booking system. Meta webhook events remain the sole source of the provider-observed `sent`, `delivered`, `read`, and `failed` message states.[1]

## Supported message workflows

| Workflow | Default state | Trigger | Scheduling rule | Required send safeguards |
| --- | --- | --- | --- | --- |
| Appointment confirmation | Enabled | A newly created staff-approved, manual, or staff-confirmed retouch appointment | Immediately after the controlled rollout marker is set | Verified opt-in, configured provider, approved mapped template, automation enabled |
| First appointment reminder | Enabled | Eligible confirmed appointment | **24 hours** before appointment by default; configurable from 1–168 hours | Same safeguards |
| Final appointment reminder | Enabled | Eligible confirmed appointment | **3 hours** before appointment by default; configurable from 1–48 hours and must be closer than the first reminder | Same safeguards |
| Reschedule confirmation | Enabled | Staff changes the finalized date or time | Immediately after the protected staff update | Same safeguards |
| Cancellation acknowledgement | Enabled | Staff records the appointment as cancelled | Immediately after the protected staff update | Same safeguards |
| Completed-visit follow-up | Disabled | Staff records completion | Immediately after the protected staff update | Same safeguards |
| No-show follow-up | Disabled | Staff records a no-show | Immediately after the protected staff update | Same safeguards |

The cancellation and follow-up workflows are intentionally non-clinical. Their language requests clinic contact or offers a non-urgent staff review; it does not give medical advice, diagnose, prescribe, or independently book a new appointment.

## Consent, templates, and status evidence

The system sends no automated message unless the selected appointment has a documented WhatsApp `opted_in` record and has not been opted out. A staff member must record the consent source and, when available, its policy/version reference in the existing protected portal. An opt-out cancels active queued automation jobs for the relevant appointment.

Each English and Arabic workflow template is registered as a **local definition only**. It cannot authorize a message independently. An owner or administrator must first synchronize Meta template metadata and map the exact provider-approved template. This maintains the existing policy that the customer-service window and Meta approval state are enforced server-side.

A local job moves through `scheduled`, `queued`, `claimed`, and `provider_accepted` states. `provider_accepted` means only that Meta accepted the submission. The job is shown as `sent`, `delivered`, or `read` only after the authenticated provider webhook reports that status. Failed jobs store safe provider code, type, HTTP status, and message metadata. Retry classification considers Meta’s documented error code semantics together with HTTP status; an outcome without an authoritative provider response remains terminal pending reconciliation, preventing unsafe duplicate sending. Jobs with an irreversible delivery state cannot be manually re-queued.

## Duplicate and reschedule safeguards

Every new appointment created after rollout receives a timestamped automation marker and version `1`. When authorized staff change its finalized date or time, the version increases. Appointment lifecycle jobs use a deterministic schedule key composed of the message type, appointment ID, version, and language. This prevents duplicate submissions for the same appointment event while still allowing a new reschedule confirmation and revised reminder set after a staff-approved schedule change.

Appointments created before this controlled rollout retain a blank marker. They are preserved unchanged and cannot receive a late confirmation or any legacy automated reminder merely because the feature is later activated. The legacy `session_reminder` and `session_reminder_2h` job types remain preserved for audit/history but are ineligible for dispatch.

### Language precedence and activation gate

Before any lifecycle job is scheduled, the system selects **explicit appointment/request language** (`en` or `ar`) first, then an existing verified WhatsApp contact language, then the clinic default language. A missing preference is never invented.

Outbound automation is held behind fourteen owner-evidenced prerequisites: migration confirmation, Meta Business configuration, server-side credential configuration, approved template mapping, webhook configuration and verified receipt, test-number setup, controlled test message, confirmation/reminder/reschedule/cancellation/consent tests, and owner activation approval. Every prerequisite records pending/verified status, evidence reference, timestamp, and responsible actor. The server independently rechecks provider configuration, approved language-matched mappings, webhook receipt, and scheduler callback before it can enable automation.

## Admin Portal operation

In **Admin → Appointments**, each non-HMS appointment now shows a protected WhatsApp panel. The panel displays provider availability, global automation state, consent state, job schedule, version, current provider-observed status, and a staff-confirmed **Queue now** action. That action requires a written staff reason and a browser confirmation; it never edits the appointment.

In **Admin → WhatsApp → Provider setup**, owner or administrator users can configure workflow flags and the first/final reminder offsets. These values alter internal queues only. The existing owner-only activation gate still controls whether the protected scheduler may submit any message.

## Required deployment and test sequence

Apply the additive migration `drizzle/migrations/0026_add_appointment_automation_center.sql` through the approved application-database change process. The migration adds columns and expands enum values only; it does not reset, delete, reseed, or overwrite patient, appointment, consent, or audit records.

Before enabling production sending, configure the existing server-only Meta credentials through the approved deployment secret mechanism, ensure the callback is verified, subscribe to `messages`, synchronize approved templates, and map all required English and Arabic definitions. Use a Meta test number or sandbox/staging environment first. Exercise at least one controlled appointment through confirmation, a reminder, status webhook transitions, a staff reschedule, a staff cancellation, an opt-out, and a retryable delivery failure. Confirm the Appointment panel and WhatsApp workspace display the provider’s actual events rather than inferred delivery states.

Do not use WhatsApp browser automation or place Meta access tokens, verification secrets, patient contact details, or raw webhook payloads in frontend code, Git history, public logs, or public routes.

## Validation completed in this branch

The feature branch passed TypeScript checking, targeted automation regression tests, and whitespace validation. The target built-in application database was not connected in this development environment, so no migration or live message was executed. No Meta credential, sandbox, production phone number, or external account setting was changed.

## Reference

[1]: https://developers.facebook.com/documentation/business-messaging/whatsapp/webhooks/overview "Meta for Developers — WhatsApp webhooks overview"
