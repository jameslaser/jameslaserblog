# Session Todo — Chat Experience Enhancements

- [x] Inspect the current public chat, admin workspace, router, persistence model, and live LLM catalog.
- [x] Obtain explicit zero-credit authorization; no LLM invocation is permitted for this change.
- [ ] Add template-grounded smart reply suggestions for staff review.
- [ ] Add typing indicators and read-receipt timestamps to public chat.
- [ ] Add inbox filter and sort controls with server-side filtering.
- [ ] Run migration, tests, type checks, and visual verification.
- [ ] Save a WebDev checkpoint.
