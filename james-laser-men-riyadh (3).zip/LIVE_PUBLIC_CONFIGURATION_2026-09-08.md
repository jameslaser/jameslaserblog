# Live Public Configuration — Verified 8 September 2026

Source: <https://jameslaserhairremovall.com/api/trpc/publicContent.clinicSettings>

The live public application returned one clinic-settings record with the business name **James Laser Hair Removal for Men Riyadh @ New Look Clinic**, specialist **Nurse James**, professional title **Laser Specialist**, clinic **New Look Clinic**, address **New Look Clinic, Al Sahafah / As Sahafah, Riyadh, Saudi Arabia**, map destination <https://maps.app.goo.gl/LYx98uWLW8kHdsMv7?g_st=ic>, WhatsApp **+966 55 740 1562**, telephone **+966 9200 13676**, email **jameslaserhairremoval@gmail.com**, and opening hours **1:00 PM–10:00 PM**.

Existing social destinations were verified for Instagram, TikTok, Snapchat, Facebook, YouTube, and Google Business. The appointment form is enabled, all seven days are configured, preferred times are configured in 15-minute increments from 13:00 through 21:00, and the configured public treatment choices include the face, beard, neck, ears, underarms, chest, abdomen, back, shoulders, hands, feet, bikini, buttocks, thighs, legs, mini full body, and full body. Both session and retouch are enabled.

The live page and repository already reference existing branded media for Nurse James, a male back-treatment image, a men’s facial-treatment video, the site logo, the default social image, and the PWA icon. No paid or newly generated media is required for this change.

The live custom domain returned HTTP 200 during the preceding review, and the managed Manus URL redirected to it. No live form was submitted and no live data was changed.
