# Protected WhatsApp Productivity Design

## Scope and safety boundary

This enhancement adds **draft assistance** and **local message-history filtering** inside the existing protected WhatsApp inbox. It does not create messages, persist a new record type, change Meta Cloud API configuration, alter service-window enforcement, bypass approved templates, change role authorization, or automate a staff decision.

> Selecting a quick reply changes only the local textarea draft. A staff member must review the full draft and press the existing send button. The server remains responsible for enforcing the open 24-hour customer-service window.

## Quick-reply catalogue

The catalogue contains operational, non-clinical replies in reviewed English and Arabic. The conversation language selects the reply language; when a contact language is unknown, the authenticated interface language is the fallback.

| Category | Intent | Safety boundary |
|---|---|---|
| Welcome | Acknowledge the customer and ask how staff can assist. | No response-time promise. |
| Request reference | Ask for the existing appointment-request reference. | Does not request national ID, health records, or other unnecessary identifiers. |
| Under review | State that staff are reviewing the message. | No guaranteed response time. |
| Availability | Confirm receipt of a preferred date/time for staff review. | Explicitly says it is not a confirmed appointment. |
| Clinic hours | Share the verified clinic operating window. | Uses the existing published 1:00 PM–10:00 PM hours. |
| Closing | Thank the customer and confirm staff will continue through the official channel. | No clinical outcome, discount, or attendance guarantee. |

Staff can search by quick-reply title and category. An explicit **Replace draft / Add to draft** selector controls insertion. The catalogue is unavailable whenever free-form messaging is unavailable; approved Meta templates remain the only existing option outside the service window.

## Message-history filters

The message filter operates entirely on the already authorized conversation response in browser memory. It does not issue a new query, send search terms to the server, or change stored content.

| Filter | Supported values |
|---|---|
| Text | Case-insensitive match against persisted body, template name, message type, and status. |
| Direction | All, inbound, outbound, or system. |
| Message type | All or the existing schema types: text, image, document, audio, template, interactive, status, unsupported. |
| Delivery status | All or the existing schema statuses: received, sending, sent, delivered, read, failed. |

The interface shows the number of visible messages compared with the conversation total, exposes one clear-all action, and presents an honest empty state when no persisted message matches. Message bodies, contact identity, phone numbers, and timestamps retain `data-admin-no-translate` protection.

## Responsive behavior

On desktop, filters appear as a compact four-column surface above the history and quick replies sit above the composer. On mobile, filter fields stack, quick replies scroll horizontally or wrap, and the existing conversation back action, textarea, send button, and template button remain reachable with 44-pixel touch targets.

## Test contract

Pure exported helpers will verify reply-language selection, search/category matching, replace/append draft behavior, direction/type/status/text filtering, filter counts, and reset semantics. Source and runtime regressions will verify that quick replies never call a send mutation, the existing send button remains staff-controlled, service-window disabling remains intact, persisted content keeps no-translation protection, and protected WhatsApp RBAC/server tests continue to pass.
