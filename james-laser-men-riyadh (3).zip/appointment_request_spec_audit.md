# Bilingual Appointment Request Specification Audit

This audit records the implementation status of the public appointment-request specification in `Pasted_content_45.txt`. It describes the current local clinic workflow only; it does **not** represent an HMS integration or automatic appointment confirmation.

| Requirement area | Status | Implemented evidence / limitation |
|---|---|---|
| Routes and language | Complete | Public routes: `/appointment`, `/en/appointment`, and `/ar/appointment`; Arabic form uses `dir="rtl"` and natural Saudi-oriented wording. |
| Premium mobile form | Complete | Responsive two-column desktop form and single-column iPhone layout reviewed at 375 px. |
| Contact and preferences | Complete | Name, mobile, optional nationality, date, 15-minute time preferences from 1:00 PM through 10:00 PM Riyadh, session/retouch, and multi-area selection. |
| Additional context | Complete | Optional previous-laser indicator and capped free-text notes; the page explicitly discourages confidential medical history. |
| Consent | Complete | Mandatory availability-only acknowledgement and privacy/appointment-policy acceptance; independent optional WhatsApp marketing consent. |
| Policy links | Complete | `/policies/:slug` reads only published public policy records and shows no unpublished/private content. |
| Submission security | Complete | Public-only validated endpoint, hidden honeypot, HMAC-derived throttling, normalized mobile number, safe sanitization, and likely-duplicate flagging without silently discarding a request. |
| Request identity and confirmation | Complete | The server returns a non-sensitive `JR-YYYY-######` public request ID. Confirmation states that availability is not confirmed and provides optional WhatsApp follow-up. |
| Failure recovery | Complete | English and Arabic client-side required-field and request errors include Try Again and WhatsApp fallback actions. |
| Private administration | Complete | Request remains pending/private. Admin/reception request queue shows public ID, selected areas, visit type, potential duplicate marker, call and prefilled WhatsApp follow-up, plus private internal notes and lifecycle actions. |
| Appointment separation | Complete | Public request creation does not create a patient or confirmed appointment. Only protected staff approval performs the existing local confirmation workflow. |
| Verification | Complete | Endpoint/security regression tests use mocks only; no customer or patient record was created for validation. Tests cover a safe success reference, the 10:00 PM boundary, Arabic validation failures, rejected invalid input, honeypot rejection, and duplicate/rate helper contracts. English and Arabic desktop/mobile render checks were completed. The client success and error views are state-only and preserve entered form state because neither handler resets customer inputs. |
| Private workflow contract | Complete | A mocked non-production contract follows one safe public reference into the owner-only request queue and a `contacted` lifecycle update. The public response contains no name or mobile; the test does not call approval, create a patient, or create a confirmed appointment. |
| Search metadata | Partial | The page sets a locale-specific browser title. The application is client-rendered, so route-specific title/description is not guaranteed to be visible to non-JavaScript crawlers without a future SSR conversion. |

## Explicit non-goals

The request form does not claim real-time availability, does not automatically book, and does not claim a hospital/HMS synchronization. WhatsApp remains optional after a successful database submission and is never required to save a request.

## Optional live exercise

No artificial live request was created. If the owner wants to exercise the full live workflow, they should submit one genuine appointment request with their own contact details, then review it under **Admin → Patient Requests** and either mark it as contacted/complete or delete it. Approval should be used only when the request is genuinely ready to become a local confirmed appointment.
