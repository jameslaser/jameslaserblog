export const ORIGINAL_CONSENT_SET_REFERENCE = "new-look-original-consent-set-v1-2026-08-26";

export const ORIGINAL_CONSENT_DOCUMENTS = [
  {
    id: "waiver",
    titleEn: "Original waiver",
    titleAr: "الإقرار الأصلي",
    url: "/manus-storage/FILENO3(1)_9dee31e1.pdf",
    sha256: "dc820722e64c2a857a41dd005ff8f561060318127f24febd9566a473113fbd36",
  },
  {
    id: "adoption-policy",
    titleEn: "Original adoption and policy form",
    titleAr: "نموذج الإقرار والسياسة الأصلي",
    url: "/manus-storage/NewLookDentalandDermatologyClinicsComplex3(1)_efa925ca.pdf",
    sha256: "ec0026052ad658dd01ef503b7ac9f825a4e8e3a4ebc5e27dffb4221d5c6d7c8c",
  },
  {
    id: "clinic-policy",
    titleEn: "Original clinic policy agreement",
    titleAr: "اتفاقية سياسة العيادة الأصلية",
    url: "/manus-storage/CLINICPOLICYAGREEMENT3(1)_33966bc3.pdf",
    sha256: "6cc22bfd5b3075f59a66cdf3d45fb214acf7c71d9bb9fcbf712a0ce59981d071",
  },
] as const;

export type OriginalConsentDocument = (typeof ORIGINAL_CONSENT_DOCUMENTS)[number];
