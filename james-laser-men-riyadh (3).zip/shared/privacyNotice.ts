export const PUBLIC_PRIVACY_NOTICE_VERSION = "privacy-notice-v1-2026-09-19";

/**
 * Stable public routes referenced by the sensitive-data acknowledgement and
 * staff audit trail. Content remains managed as published CMS policy text.
 */
export const PUBLIC_PRIVACY_NOTICE_PATH = "/policies/privacy-policy";
export const PUBLIC_PRIVACY_NOTICE_AR_PATH = "/ar/policies/privacy-policy";
