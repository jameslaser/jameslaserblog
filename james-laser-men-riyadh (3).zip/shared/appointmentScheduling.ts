export type ClinicVisitType = "session" | "retouch";

export type AppointmentScheduleRecord = {
  id: number;
  appointmentTime: string;
  appointmentEndTime: string | null;
  durationMinutes: number | null;
  whatsapp: string | null;
  machine: string | null;
};

export const CLINIC_OPENING_MINUTES = 13 * 60;
export const CLINIC_CLOSING_MINUTES = 22 * 60;
export const SCHEDULING_INCREMENT_MINUTES = 15;

const durationByArea: Record<string, number> = {
  "full face": 15,
  face: 15,
  "beard lining": 15,
  "lower beard lining": 15,
  neck: 15,
  nape: 15,
  ears: 15,
  "external nose": 15,
  underarm: 15,
  underarms: 15,
  "bikini / boxer": 15,
  bikini: 15,
  hands: 15,
  feet: 15,
  chest: 30,
  abdomen: 30,
  shoulders: 30,
  thighs: 30,
  legs: 30,
  arms: 30,
  "full arms": 30,
  buttocks: 30,
  back: 45,
  "full back": 45,
};

function normalizedArea(area: string) {
  return area.trim().toLocaleLowerCase();
}

/** Returns the conservative clinic duration for the selected treatment areas. */
export function clinicDurationMinutes(treatmentAreas: readonly string[], visitType: ClinicVisitType): number {
  const selectedAreas = Array.from(new Set(treatmentAreas.map(normalizedArea).filter(Boolean)));
  if (!selectedAreas.length) throw new Error("Select at least one treatment area.");

  if (selectedAreas.includes("full body")) return visitType === "retouch" ? 90 : 120;
  if (selectedAreas.includes("mini full body")) return visitType === "retouch" ? 60 : 105;

  const unsupported = selectedAreas.find(area => durationByArea[area] === undefined);
  if (unsupported) throw new Error("The selected treatment area does not have a configured scheduling duration.");
  return selectedAreas.reduce((total, area) => total + durationByArea[area]!, 0);
}

export function timeToMinutes(value: string): number {
  const match = value.match(/^(?:[01]\d|2[0-3]):[0-5]\d$/);
  if (!match) throw new Error("Use a time in HH:MM format.");
  const [hours, minutes] = value.split(":").map(Number);
  return hours * 60 + minutes;
}

export function minutesToTime(value: number): string {
  const hours = Math.floor(value / 60);
  const minutes = value % 60;
  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
}

/** Validates a finalized appointment against Riyadh clinic operating hours. */
export function appointmentEndTime(startTime: string, durationMinutes: number): string {
  const start = timeToMinutes(startTime);
  if (!Number.isInteger(durationMinutes) || durationMinutes < 1) throw new Error("A valid appointment duration is required.");
  if (start % SCHEDULING_INCREMENT_MINUTES !== 0 || start < CLINIC_OPENING_MINUTES || start >= CLINIC_CLOSING_MINUTES) {
    throw new Error("Choose a 15-minute appointment time between 1:00 PM and 10:00 PM.");
  }
  const end = start + durationMinutes;
  if (end > CLINIC_CLOSING_MINUTES) throw new Error("The selected treatment duration extends beyond the 10:00 PM clinic closing time.");
  return minutesToTime(end);
}

export function appointmentRangesOverlap(startA: string, endA: string, startB: string, endB: string) {
  return timeToMinutes(startA) < timeToMinutes(endB) && timeToMinutes(startB) < timeToMinutes(endA);
}

/** Uses retained end-time data when present, with a conservative 15-minute legacy fallback. */
export function retainedAppointmentEndTime(record: Pick<AppointmentScheduleRecord, "appointmentTime" | "appointmentEndTime" | "durationMinutes">): string {
  if (record.appointmentEndTime) return record.appointmentEndTime;
  const duration = record.durationMinutes && record.durationMinutes > 0 ? record.durationMinutes : SCHEDULING_INCREMENT_MINUTES;
  return minutesToTime(timeToMinutes(record.appointmentTime) + duration);
}

export function hasAppointmentConflict(
  candidate: { appointmentTime: string; appointmentEndTime: string; whatsapp: string; machine: string },
  record: AppointmentScheduleRecord,
) {
  const existingEnd = retainedAppointmentEndTime(record);
  if (!appointmentRangesOverlap(candidate.appointmentTime, candidate.appointmentEndTime, record.appointmentTime, existingEnd)) return { mobile: false, machine: false };
  return { mobile: record.whatsapp === candidate.whatsapp, machine: record.machine === candidate.machine };
}
