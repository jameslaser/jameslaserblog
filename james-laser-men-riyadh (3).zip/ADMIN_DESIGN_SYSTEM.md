# New Look Clinics Admin Design System

## Design principles

The authenticated application uses a **calm clinical editorial** design language: warm ivory canvas, white operational surfaces, dark ink navigation, muted slate supporting text, and restrained copper accents. Status colors are reserved for state and risk communication. The visual system must feel premium and medically credible without hiding dense operational information or weakening existing safeguards.

> **The interface may become clearer and more coherent; the underlying workflow must remain identical.**

## Foundation tokens

| Token | Value and role |
|---|---|
| Canvas | Warm ivory `#F4F1EB`; persistent authenticated background. |
| Surface | White `#FFFFFF`; cards, tables, drawers, and forms. |
| Ink | Dark navy `#13293A`; sidebar, headings, primary actions. |
| Muted ink | Slate `#667681`; explanatory copy and secondary metadata. |
| Accent | Copper `#B46749`; active navigation, focus, key links, and selected filters. |
| Border | Ink at 10–14% opacity; quiet structure without heavy boxes. |
| Radius | 12px controls, 16px cards, 20px feature panels; pills only for statuses and compact filters. |
| Shadow | Soft low-opacity navy shadows; stronger elevation only for overlays. |
| Typography | Manrope for interface copy, DM Serif Display for short English display headings, and Noto Sans Arabic for Arabic UI. |

## Application shell

Desktop keeps the existing collapsible and resizable sidebar, but standardizes its group labels, selected state, profile footer, and top header. Mobile keeps the existing fixed safe-area bottom navigation with four role-filtered primary destinations plus **More**, while the full section list remains available through the sidebar drawer. The top bar contains the active screen identity, protected search, language control, notifications, and public-site link.

The language preference is a presentation-layer value stored locally as `en` or `ar`. It updates the authenticated document `lang` and `dir`, mirrors shell alignment, flips directional interface icons where appropriate, and localizes shared navigation and shell copy. It must not translate database content, mutate server data, change API inputs, or automatically publish Arabic content.

## Navigation architecture

| Group | Existing destinations retained |
|---|---|
| Overview | Dashboard, Attention Agent |
| Clinic | Patient Requests, Appointments, HMS Workspace, Waiting List, Patients, Machines, Revenue, Follow-ups |
| Communication | WhatsApp, Enquiries, Notifications |
| Content | Clinic Information, Homepage Content, Treatments, Promotions, Reviews, Before & After, Guide, Content Calendar, FAQs, Media Library, Policies, SEO, Language Readiness |
| Management | Analytics, Data & Backup, Redirects, Activity Log, Users & Security, Settings |

No new route is introduced by the redesign. Visibility remains governed by the existing role arrays and backend procedures.

## Shared component language

| Primitive | Required behavior |
|---|---|
| Page header | Compact eyebrow, responsive title/description, optional actions, and no duplicated shell title. |
| Surface card | White background, quiet border, 16px radius, consistent padding, and optional soft shadow. |
| Metric card | Label, real value, concise note, restrained icon, and optional verified-status accent. |
| Status badge | Text plus color; never color alone. Blue=confirmed/information, amber=pending/waiting, green=arrived/completed/active, red=cancelled/failed/blocked, slate=neutral/archived. |
| Filter bar | Responsive grid on desktop, stacked controls on mobile, visible labels or accessible names, and a clear reset action. |
| Data table | Sticky or clear headers where useful, readable 14–15px rows, horizontal scrolling only when a tested mobile-card alternative is not viable. |
| Mobile record card | Exposes the same primary identity, status, date/time, and highest-priority actions as the desktop row. Secondary metadata moves into details or the expanded panel. |
| Form section | Grouped fields with 14px labels, helper text, explicit required state, consistent focus, disabled, error, and success feedback. |
| Inline panel | Used by current add/edit/import/arrival flows; remains in document flow and must not cover controls or detach workflow context. |
| Dialog or drawer | Reserved for focused tasks and mobile navigation; labelled, keyboard accessible, escape-dismissable where safe, and protected from background interaction. |
| Loading state | Skeletons that approximate final layout; no global blocking spinner for a single component. |
| Empty state | Quiet icon, factual title, explanatory sentence, and only a valid existing action. |
| Error state | Clear error copy, retry where supported, no leakage of server internals or sensitive data. |

## Responsive and RTL acceptance criteria

At mobile widths, the application must use one primary content column, keep tap targets at least 44px, preserve bottom safe-area padding, move dense actions into wrapped rows or an existing details pattern, and prevent unintended horizontal viewport overflow. At tablet and desktop widths, layouts may use split panes and operational grids while retaining readable line lengths.

When Arabic is active, the shell uses `dir="rtl"`; sidebar and header alignment mirror, directional chevrons flip, form labels and shared text align correctly, and numeric/date/phone values may use isolated left-to-right spans where needed. Content entered only in English remains visible rather than being machine-translated or replaced with invented Arabic text.

## Implementation sequence

The implementation proceeds in three layers. First, add authenticated design tokens and shared utility classes. Second, update `DashboardLayout` with bilingual shell presentation while retaining its original auth, role, search, route, resize, and mobile-navigation behavior. Third, progressively apply shared classes to existing page headers, cards, filters, tables, inline panels, status elements, loading states, and empty states without modifying queries or mutations.

## Verification contract

The redesign is complete only when TypeScript, the full Vitest suite, production build, and authenticated visual checks pass. The visual review must include representative desktop and mobile views, the shell in English and Arabic, no unexpected horizontal overflow, and a comparison of requests, appointments, waiting list, patients, revenue, WhatsApp, CMS, and management surfaces. Existing route, role, import, approval, consent, appointment-transfer, and provider-activation tests must remain passing.

## Implementation verification log

The first authenticated-shell implementation passed TypeScript validation. At **1440 × 900**, the desktop shell retained the full role-filtered sidebar, active-state hierarchy, protected search, language control, notification access, public-site action, and resizable navigation boundary. At **390 × 844**, the shell presented one content column, a compact header, mobile protected search, reachable English/Arabic control, and the existing safe-area bottom navigation without visible viewport overflow. Data cards loaded from the real dashboard query; the mobile capture showed current protected counts rather than sample values.

The Arabic desktop verification at **1440 × 900** confirmed that the sidebar moved to the right, navigation groups and route labels were localized, header actions and protected search mirrored, and the real metric-card order followed RTL direction without visible viewport overflow. This check also identified that shared page headings and metric labels required a common translation layer; that layer was subsequently added to `AdminUi` so adopted page headers, metric cards, empty states, and loading states localize without translating database records or changing API contracts.

The representative authenticated English desktop check covered the dashboard, request queue, WhatsApp workspace, and revenue workspace at **1440 × 900**. It confirmed consistent page hierarchy, filter surfaces, status treatments, data-table readability, horizontal WhatsApp tabs, governed financial intake, and real protected records. The Arabic mobile check covered the same high-risk workspaces at **390 × 844**. It confirmed correct RTL shell placement, safe-area navigation, single-column request filters, localized WhatsApp safety context, and stacked financial controls without viewport overflow. The check exposed untranslated descendant placeholders in legacy markup; the static-interface localizer was then updated to translate descendant `placeholder`, `aria-label`, and `title` attributes while leaving database-backed text unchanged.

The final shell-level pass replaced the request workspace’s legacy filter, loading, empty, and table wrappers with `AdminFilterBar`, `AdminLoadingState`, `AdminEmptyState`, and the shared `admin-surface`, while retaining `transferPayload`, approval, consent, status, and WhatsApp actions. The protected WhatsApp workspace now uses `AdminPageHeader` and a touch-safe shared tab surface while retaining the service-window guard and provider activation controls. Focused tests passed after these direct adoptions. A final authenticated Arabic mobile capture confirmed the real request filters and WhatsApp tabs loaded inside the protected shell, used localized labels and placeholders, respected safe-area navigation, and showed no viewport overflow or sign-in screen.

The page-specific authenticated desktop review covered appointments, waiting list, patients, machines, homepage CMS, notifications, users/security, and settings. The loaded appointment view retained its seven-day status calendar, explicit add/upload actions, and separation from unreviewed requests while gaining the shared shell hierarchy. The homepage CMS loaded real published section records inside consistent form and list surfaces. Waiting list and patient screens retained their real query-driven skeletons and protected empty/detail structure; machines, notifications, security, and settings were captured during transient query loading and therefore remain subject to loaded-state verification rather than being treated as visually complete. No route exposed public data or crossed the existing role boundary during this review.

Page-specific refinements added rounded, keyboard-visible seven-day calendar cards, compact mobile day cards, stronger selected-patient surfaces, resilient detail grids, and overflow-safe appointment metadata. Exact Arabic labels were added for appointment controls and statuses, waiting-list states, patient actions, machine records, and owner-only security headings. CMS, catalogue, education, analytics, revenue, requests, and WhatsApp now share the same page-header hierarchy; the scoped admin styles standardize existing forms, list cards, tables, badges, alerts, skeletons, empty states, and inline panels without changing the DOM contracts used by their mutations.

The second authenticated management review confirmed loaded real-state layouts for appointment settings, authorized CSV export and backup guidance, server-enforced redirects with a verified empty state, and the 90-day content calendar with existing review records and owner-authorization safeguards. Notifications, users/security, activity, and SEO rendered their new shared loading surfaces inside the authenticated shell rather than a blank page or sign-in screen. Their post-query content contracts remain covered by existing query branches and source-level regression checks; network and test validation are required before treating these transient captures as final loaded-state evidence.

The protected management tRPC batch completed with HTTP **200** during authenticated review. Regression coverage now verifies that notifications, staff/security, activity, SEO, analytics, and redirects retain explicit loading, empty, error, and retry branches; the content calendar retains its owner-authorized external-action safeguard; WhatsApp retains its service-window and approved-template boundary; and revenue retains its HMS source and provider fields. These checks validate the branches that the screenshot harness captured before query completion without exposing protected response data in release evidence.

Full-page authenticated captures then verified the resolved loaded states for all previously outstanding management views. Machines displayed the four existing clinic devices and internal ID controls; notifications displayed the protected operational inbox and unread controls; users/security displayed the existing owner accounts and role selectors; activity displayed retained privileged actions; SEO displayed the two configured locales and owner-access notice; language readiness displayed both reviewed locale records; media displayed the protected library metadata and existing files; and policies displayed the existing draft policy records. No sign-in screen or transient skeleton was counted as loaded-state evidence. Existing record values were observed only inside the protected preview and were not copied into the redesign or release report.

Deterministic component-level state coverage now renders the actual shared loaded heading/metric, loading status, empty state, and error/retry state through React server rendering. These four state tests run under the project’s real Vitest include pattern and pass alongside the shell and workspace preservation suites. The shared `AdminErrorState` is used by CMS query failures, while the existing management source tests confirm that query-specific loading, empty, error, and retry branches remain connected to the redesigned components.

An exhaustive executable screen inventory now maps every named authenticated area to its existing implementation and workflow markers. It covers dashboard, attention tasks, requests, appointments, HMS intake, waiting list, patients, machines, revenue, analytics, backup/export, redirects, CMS catalogues and education, notifications, staff security, activity, settings, content-calendar tasks, WhatsApp provider settings, templates, service-window controls, and webhook logs. Separate executable assertions verify the machine, notification, security, activity, SEO, language, media, and policy loading/error/empty-or-loaded branches and their protected actions.

The exhaustive verification suite passed **27 tests across four focused files**: deterministic shared management states, shell/navigation/RBAC, cross-workspace preservation, and the complete screen inventory. TypeScript completed without errors in the same run.

The final deterministic management suite imports and renders the actual `Machines`, `Notifications`, `Security`, and `Library` screen components with controlled tRPC states. It exercises loading, error, empty, and loaded branches for machines, notifications, staff/security, activity, SEO, language readiness, media, and policies. The complete focused redesign result is now **35 passed tests across five files**, with TypeScript passing in the same run. Machine errors and empty states were moved to the shared accessible components; CMS library errors now use the same retryable error surface.

The final shared interaction layer standardizes disabled and invalid controls, table headers and row readability, accessible details focus, bounded modal scrolling, mobile 44-pixel touch targets, touch-safe horizontal tab snapping, and isolated left-to-right treatment of phone, email, date, time, and numeric fields within Arabic layouts. These changes remain scoped to `.admin-portal` and do not affect the public website or server contracts.

The final Arabic mobile correction pass confirmed that the users/security description and role labels, appointment-settings description and field labels, working-hour and treatment placeholders, and WhatsApp error-state messaging render in Arabic while names, emails, timestamps, machine names, and stored settings remain unmodified. A separate sandbox-browser check reached the expected secure sign-in boundary because that browser did not share the authenticated WebDev preview session; it was not counted as protected loaded-state evidence and no login was attempted.

The final visual pass covered English dashboard, appointments, requests, and waiting-list views plus Arabic WhatsApp, machines, security, and settings views on desktop and mobile. The shell remained authenticated, role-filtered, responsive, and free of viewport overflow. English request filters and dashboard metrics resolved; Arabic security records and settings forms resolved with localized presentation while protected record values remained verbatim. Waiting-list loading now uses the shared accessible state, and the actual waiting-list component’s loading, error, empty, and confirmed-record branches passed deterministic runtime tests together with five server workflow tests. Fresh post-fix browser logs contained no client errors, and the protected staff query returned HTTP 200.

The final release validation passed **68 test files and 266 tests**, followed by a successful TypeScript check and production build. The build emitted only the existing bundle-size advisory; no build error occurred.

Code-verifiable responsive evidence now directly checks approved English and Arabic UI strings, role-filtered mobile navigation, safe-area spacing, 44-pixel touch targets, overflow containment, RTL sidebar placement, isolated directional fields, dialog/form/status behavior, and `data-admin-no-translate` protection for names, emails, machine identities, and WhatsApp record content. Actual runtime tests additionally render appointments, waiting list, machines, appointment settings, notifications, staff security, activity, SEO, language readiness, media, and policies through their resolved, empty, loading, or error branches.

The final visual-evidence suite passed **44 tests across six focused files**. It includes actual component rendering for appointments and appointment settings, the waiting list, machines, notifications, staff security, activity, SEO, language readiness, media, and policies; it also directly verifies the approved Arabic labels, mobile navigation, touch targets, RTL structure, responsive overflow behavior, and protected-record no-translation boundaries. Persisted WhatsApp names, numbers, timestamps, and message bodies now carry the same explicit no-translation protection used for other protected records.

Two inspectable contact sheets were generated from the saved authenticated preview captures and reviewed directly. Their filenames, dimensions, SHA-256 hashes, route coverage, and resolved-versus-loading limitations are recorded in `ADMIN_VISUAL_EVIDENCE.md`. Screenshot-harness loading frames are explicitly separated from deterministic resolved-state evidence.

The targeted preservation run passed **110 tests across 19 files**. It covers authentication logout, session cookies, security headers, admin role access, reception restrictions, public-request clinical boundaries, appointment transfer, original consent retention, patient identity, request retention, strict HMS CSV filtering and normalization, waiting-list behavior, WhatsApp access, shared backend contracts, the bilingual shell, screen inventory, actual management async states, responsive design rules, and UI-only workflow preservation.

A development-only locale-provider error was traced to stale Vite hot-reload module state after incompatible export changes. The provider composition itself was correct. After a clean managed server restart, the authenticated Arabic mobile dashboard rendered with real protected metrics and the expected RTL shell. Fresh browser-console and network logs contained no locale-context errors, uncaught exceptions, failed requests, or HTTP 4xx/5xx responses.
