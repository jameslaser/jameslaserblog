# Official Meta Findings for Phase 2

The official Meta WhatsApp Business Platform webhook overview states that WhatsApp uses JSON webhooks to deliver incoming messages, outgoing-message status changes, call events, account events, and template-quality updates to a configured server endpoint. The `messages` webhook carries both inbound user messages and status changes for business-sent messages. Meta retries webhooks that do not receive HTTP 200, with retries potentially continuing for up to seven days. The implementation must therefore persist events and messages idempotently before returning success, and it must safely ignore unsupported events.

The official service-message guidance states that free-form service messages may be sent during a customer-service window. When that window is closed, only pre-approved template messages may be sent. The implementation will calculate this window from the latest inbound customer message, prohibit free-form sending when closed, and require an approved template rather than attempting a policy bypass.

| Decision | Phase 2 implementation consequence |
| --- | --- |
| Meta uses webhooks for inbound messages and outgoing status updates. | Add a public, signature-validated `GET` and `POST` `/api/webhooks/whatsapp` endpoint in the existing Cloud Run Express service. |
| Meta retries non-200 deliveries. | Use a uniquely constrained webhook-event/messaging identity and transactional deduplication. |
| `messages` includes inbound messages and outbound delivery statuses. | Store chronology and map sent/delivered/read/failed updates to the unique Meta message ID. |
| Free-form messages are limited to the customer-service window. | Enforce service-window checks on server-side sending; require approved templates outside the window. |

## References

[1]: https://developers.facebook.com/documentation/business-messaging/whatsapp/webhooks/overview "Meta WhatsApp Business Platform — Webhooks"
[2]: https://developers.facebook.com/documentation/business-messaging/whatsapp/messages/send-messages "Meta WhatsApp Business Platform — Service messages"

## Cloud Run public-access finding for hardening

Google Cloud’s current Cloud Run documentation identifies disabling the Invoker IAM check as the recommended method for making a Cloud Run service public. The current `gcloud run deploy` reference exposes the paired `--invoker-iam-check` and `--no-invoker-iam-check` flags. The Phase 2 hardening pass will therefore replace the older `--allow-unauthenticated` deploy argument with `--no-invoker-iam-check`, avoiding an `allUsers` IAM binding path that may be blocked by organization policy.

[3]: https://docs.cloud.google.com/run/docs/authenticating/public "Cloud Run — Allowing public (unauthenticated) access"
[4]: https://docs.cloud.google.com/sdk/gcloud/reference/run/deploy "gcloud run deploy reference"
