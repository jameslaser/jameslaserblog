# Google Business Profile API Notes

Sources reviewed on 2026-09-07:

1. https://developers.google.com/my-business/content/basic-setup
   - Business Profile API access requires project approval and enabling the associated Business Profile APIs.
   - Protected location data requires OAuth 2.0.
   - The required scope for current integrations is `https://www.googleapis.com/auth/business.manage`.
   - Google documents no sandbox environment; some calls support `validateOnly=true` for non-mutating validation.
   - Workspace accounts may return permission errors if Business Profile is disabled for the organization.

2. https://developers.google.com/my-business/content/implement-oauth
   - OAuth authorization is required for requests that access or modify Business Profile data.
   - Offline access uses a securely stored refresh token; tokens must remain server-side.
   - The flow can support account/location management and creation of posts on the owner's behalf.

3. https://developers.google.com/my-business/reference/rest/v4/accounts.locations.localPosts
   - Local Posts support summary text, call-to-action, media, event/offer fields, scheduledTime, and lifecycle operations including create, get, list, patch, delete, and reportInsights.
   - Google resource identifiers include account, location, and local post IDs.

Current project audit summary:

- Existing CMS, bilingual content, owner/admin approval, media library, protected admin routing, RBAC, audit logs, notifications, built-in MySQL/TiDB, and heartbeat infrastructure are present.
- Direct Google Business Profile OAuth/API client, token exchange, account/location selection, publication records, idempotent publishing, and external error/retry workflow are missing.
- No Google Business-specific connector is enabled in the current connector configuration; Google Workspace is disabled and is not a substitute for the Business Profile API.
- Owner-controlled prerequisites remain: Google Cloud project/API access approval, OAuth client/consent setup, redirect URI, `business.manage` scope approval, verified profile access, and authorization of the target location.
- No external account, connector, credential, database record, or Google post was changed during this audit.
