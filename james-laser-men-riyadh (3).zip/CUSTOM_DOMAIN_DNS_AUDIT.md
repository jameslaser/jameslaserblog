# Custom-Domain and Registrar DNS Audit

**Application baseline:** managed checkpoint `1a5d9e75`  
**Audit date:** 2026-09-03  
**Scope:** `jameslaserhairremovall.com` and `www.jameslaserhairremovall.com` only

## Executive finding

Both the apex and `www` hostnames currently resolve to the live managed application and load the public website successfully over HTTPS. The apex hostname is the **canonical production hostname** because the live homepage, sitemap, canonical tags, Open Graph URL, and hreflang URLs all reference `https://jameslaserhairremovall.com/`.

The current configuration does **not** redirect `www` to the apex: both HTTPS hostnames return HTTP 200 and remain on their original hostnames. This is not a DNS failure. If a single-host redirect policy is required, it must be configured in the active hosting/edge control plane, not by replacing the website DNS records. No DNS record is recommended for deletion or replacement based on this audit.

## Current website DNS records

| Record | Host / name | Current answer | Observed TTL | Website relevance | Recommended action |
|---|---|---|---:|---|---|
| NS | `@` | `ns0.wixdns.net.` and `ns1.wixdns.net.` | 86400 | Authoritative DNS is Wix DNS | Do not change for this audit. |
| A | `@` | `104.18.27.246` | 3600 | Apex currently reaches the proxied live site | Do not replace; the answer is a proxied edge address. |
| CNAME | `www` | `cname.manus.space.` | 3600 | `www` reaches the managed Manus custom-domain edge | Keep unchanged. |
| A/AAAA | `www` target | `104.19.168.112`, `104.19.169.112`, `2606:4700::6813:a870`, `2606:4700::6813:a970` | 300 at target | Resolved target addresses for the Manus edge CNAME | Do not manage these as registrar records. |
| MX | `@` | Not queried or changed | — | Email service | Explicitly untouched. |

The apex A answer is an edge/proxy address rather than a safe origin address to hardcode. The `www` CNAME target is already the platform-confirmed managed-domain target. Any registrar change should be made only from the active platform’s domain instructions and after reviewing unrelated records, especially MX records.

## Host and HTTPS verification

| Check | Apex | `www` |
|---|---|---|
| `https://` homepage | HTTP 200 | HTTP 200 |
| `http://` behavior | 301 to same-host HTTPS | 301 to same-host HTTPS |
| TLS certificate subject | `jameslaserhairremovall.com` | `www.jameslaserhairremovall.com` |
| TLS issuer | Google Trust Services WE1 | Google Trust Services WE1 |
| Certificate validity observed | 2026-09-02 through 2026-12-01 GMT | 2026-09-02 through 2026-12-01 GMT |
| Mixed-content indication | None observed in public route review | None observed in public route review |
| Redirect loop | None observed | None observed |
| Hostname canonical redirect | Not applicable | Not configured; remains on `www` |

The browser loaded both HTTPS hostnames as the public site. The HTTP-to-HTTPS redirect is present for both. The browser did not observe a redirect loop.

## Public route and SEO verification

The following paths returned HTTP 200 on both hostnames: `/`, `/en`, `/ar`, `/appointment`, `/ar/appointment`, `/robots.txt`, and `/sitemap.xml`.

The public homepage reported the following production-domain metadata on both hosts:

| Metadata | Verified value |
|---|---|
| Canonical | `https://jameslaserhairremovall.com/` |
| English alternate | `https://jameslaserhairremovall.com/en` |
| Arabic Saudi alternate | `https://jameslaserhairremovall.com/ar` |
| x-default alternate | `https://jameslaserhairremovall.com/en` |
| Open Graph URL | `https://jameslaserhairremovall.com/` |
| Robots sitemap | `https://jameslaserhairremovall.com/sitemap.xml` |
| Robots private path | `/admin` disallowed |
| Sitemap public host | Apex hostname only |

The custom-domain public website loads with the existing English/Arabic selector, public appointment request, public treatment content, and no protected Admin Portal content. The sitemap and robots resources are reachable over HTTPS and consistently reference the apex production hostname.

## Required registrar or owner action

**No DNS record must be changed to keep the website reachable.** The current apex A record and `www` CNAME are serving the site, and no obsolete website record was confirmed. MX/email records were not touched.

There is one optional-but-recommended canonicalization action: configure a permanent redirect from `https://www.jameslaserhairremovall.com/*` to the matching `https://jameslaserhairremovall.com/*` path in the active hosting or edge control plane. This is an application/edge redirect policy, not a DNS replacement. It should be done only after the owner confirms the desired canonical redirect policy and the active platform exposes a safe rule for the custom domain. Do not replace the working `www` CNAME with an unverified A record.

## Remaining limitation

This audit verified live public behavior and public DNS answers but did not log in to the registrar or change any record. The current platform/domain mapping already serves both hosts. Because both hosts currently return 200, the `www`-to-apex canonical redirect is not yet implemented; this remains an owner-approved hosting/edge configuration decision rather than a confirmed registrar DNS change.

## Historical finding retained from the prior audit

An earlier audit against checkpoint `285c73cb` recorded a prior state in which the apex did not resolve and `www` appeared to use GitHub Pages addresses. The current 2026-09-03 DNS, browser, TLS, and HTTP evidence supersedes that earlier observation for the present domain state. No historical DNS record was deleted or overwritten during this audit.

## References

[1]: https://jameslaserhairremovall.com/ "Live apex homepage"
[2]: https://www.jameslaserhairremovall.com/ "Live www homepage"
[3]: https://jameslaserhairremovall.com/robots.txt "Apex robots configuration"
[4]: https://jameslaserhairremovall.com/sitemap.xml "Apex sitemap"
[5]: https://www.jameslaserhairremovall.com/robots.txt "www robots configuration"
[6]: https://www.jameslaserhairremovall.com/sitemap.xml "www sitemap"
[7]: https://manus.im/docs/website-builder/custom-domains "Manus Documentation — Custom Domains"
[8]: https://help.manus.im/en/articles/11711203-how-can-i-connect-the-website-created-by-manus-to-my-custom-domain "Manus Help Center — Custom Domains"
