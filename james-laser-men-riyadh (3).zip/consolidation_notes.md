# Consolidation Notes — Verified Source Clauses

## Source A: `NewLookDentalandDermatologyClinicsComplex3.pdf`

The one-page bilingual “Adoption” form states that the client has learned the side effects of laser treatment. Its English-side clauses require a medical consultation before treatment, booking a retouch in advance, and keeping retouch appointments within the stated 10–14-day interval. It says not to remove hair between the primary session and the retouch, not to use a sauna for seven days before or after the session, and clarifies that retouch is a secondary session for areas with hair growth over the two-week period rather than a replacement for a standard session.

The form instructs the client to seek medical review for redness or severe itching lasting more than three days. It asks clients to avoid chemical peeling or lightening creams for two weeks before or after a laser session, avoid moisturising creams the day before a laser or retouch session, shave one day before the session, and wait three months after tanning before laser treatment. It states that payments are non-refundable but may be used for other services or departments; on cancellation, the basic price is deducted from an offer and the balance may be transferred to another service. It concludes that the medical complex is not responsible for outcomes when the terms are violated. The signature area contains Name, Signature, and File No.

## Source B: `CLINICPOLICYAGREEMENT3.pdf`

The one-page bilingual “Clinic Policy Agreement” confirms that the client is aware of clinic policy for laser treatment. It repeats the need to consult the doctor and obtain a test spot or initial treatment, especially for first-time laser; clients should shave appropriately without cuts or infection. It instructs the client to request retouch through the call centre after each session and states the general retouch period is not less than 10 days and not more than 14 days. The document also includes specific, management-approved late-retouch rules and charges, including SAR 50 for full-body retouch requests after 16 days and up to 24 days, and SAR 30 for laser bleaching or small-area retouch requests after 15 days and up to 24 days, where the clinic accepts the reason.

The agreement says clients should not remove hair before the scheduled retouch and that retouch is focused on areas with regrowth only. It lists preparation restrictions: certain medication, including vitamin D, antibiotics and Roaccutane, at least seven days before treatment; Moroccan bath, scrubs, whitening or peeling creams at least seven days before treatment; and lotions, body cream, oils, scrubs and deodorants before treatment. It records a one-month tanning restriction and says normal skin colour should return before treatment.

The agreement directs clients to use prescribed post-laser creams and consult the doctor for excessive unresolved redness or itching after three days. It notes white hair is not effectively treated with laser. It says payment is non-refundable but transferable to other services in the same department under the stated conditions, packages are generally valid for one year from payment subject to pregnancy or a health condition being reported, a full-body client should arrive shaved or pay SAR 50, and a self-bikini service carries an additional SAR 50 and is performed only on Gentle Pro machine. It states a requested specific nurse is not always available, a paid package may be used within its year of validity except during Ramadan season, and clients should arrive 10–15 minutes early; late arrivals may be moved to a waiting list.

The final pregnancy clause says laser is not permitted during pregnancy, except for face and eyebrows, and that a client who has given birth may not receive laser for 40 days after delivery. The signature area contains Name, Signature, File No., and Date.

## Verification note

These are consolidation notes from the legible English clauses on the two scanned originals. Ambiguous scan fragments should be compared with the originals before any policy wording is finalized.

## Source C: `FILENO3.pdf`

The one-page bilingual waiver contains Date and File No. fields, followed by a statement that the client signs with complete information and understanding of possible effects of a laser session or retouch requested against medical staff advice. The statement lists potential consequences including hyperpigmentation, skin allergy, hypersensitivity reactions, increased hair growth, and burns.

The waiver provides selectable acknowledgment boxes for a client-requested session without doctor consultation; a session without a spot test; treatment of fine-hair areas on Gentle Pro machine; an early session less than 30 days or retouch less than 10 days; a session during pregnancy; a session against medical advice because of contraindicated medication, skin treatment within the prior 10 days, or a skin condition not suitable for laser; and a requested change to the machine or fluence advised by the doctor or medical staff. The form has a free-text line for relevant detail, then Name and Signature fields.
