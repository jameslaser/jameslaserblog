# Duplicate Patient Prevention

## Scope

This targeted change is limited to the approved-request-to-appointment flow in the authoritative James Laser application. Baseline: `41702f9c`. No deployment, authentication architecture, database architecture, external infrastructure, or production clinic data was changed.

## Matching contract

Before the approval transaction writes a patient row, it looks up the normalized WhatsApp/phone identifier and, when supplied, the manual MRN. The existing `resolveSinglePatientFile` identity guard applies the following rules:

| Incoming identifiers | Result |
|---|---|
| Neither identifier matches | Create one new patient file and link the appointment. |
| MRN matches | Reuse the MRN patient file, even when the incoming phone is new. |
| Phone/WhatsApp matches | Reuse the phone patient file, even when the incoming MRN is new. |
| Both match the same patient | Reuse the existing patient file. |
| MRN and phone resolve to different patients | Reject the operation; do not create or relink a record. |

Existing patient fields are preserved when an existing file is reused. The appointment is linked through `appointments.patientId`, and the router returns `existingPatientFound` plus `matchedBy` (`mrn`, `whatsapp`, `both`, or `null`) so the protected request workspace can show an explicit Existing Patient Found notice.

## Validation

Focused identity and admin-router coverage passed. The full suite passed with 60 test files and 208 tests. TypeScript and production build passed. Coverage includes new-patient, MRN-only reuse, phone-only reuse, both-match reuse, divergent-identity rejection, existing appointment-link preservation, protected approval routing, and the existing-patient UI result contract. No real clinic record was inserted, updated, deleted, or migrated during testing.

## Retained boundaries

Manual appointment creation, manual patient creation, Waiting List arrival, HMS NR011 filtering, public requests, authentication, RBAC, and the built-in MySQL/TiDB database remain on their existing contracts. No PostgreSQL, Cloud SQL, Cloud Run, Firebase, DNS, or external deployment work was performed.
