import { boolean, decimal, index, int, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

export const roleEnum = mysqlEnum("role", ["owner", "admin", "content_editor", "reception", "user"]);
export const preferredContactEnum = mysqlEnum("preferredContact", ["WhatsApp", "Phone", "Email"]);
export const consultationRequestVisitTypeEnum = mysqlEnum("consultationRequestVisitType", ["session", "retouch"]);
export const originalConsentLanguageEnum = mysqlEnum("originalConsentLanguage", ["en", "ar"]);
export const consentSignatureStatusEnum = mysqlEnum("consentSignatureStatus", ["required", "received"]);
export const finalizedMachineEnum = mysqlEnum("finalizedMachine", ["DEKA AGAIN", "CLARITY 2", "GENTLE PROMAX", "DUETTO MACHINE"]);
export const finalizedVisitTypeEnum = mysqlEnum("finalizedVisitType", ["session", "retouch"]);
export const statusEnum = mysqlEnum("status", ["pending", "contacted", "clarification_requested", "approved", "rejected", "transferred", "completed", "cancelled"]);
export const consultationRequestLanguageEnum = mysqlEnum("consultationRequestLanguage", ["en", "ar"]);
export const consentSignatureSessionStatusEnum = mysqlEnum("consentSignatureSessionStatus", ["pending", "signed", "revoked", "expired"]);
export const consentSignatureSessionLanguageEnum = mysqlEnum("consentSignatureSessionLanguage", ["en", "ar"]);
export const machineEnum = mysqlEnum("machine", ["DEKA AGAIN", "CLARITY 2", "GENTLE PROMAX", "DUETTO MACHINE"]);
export const appointmentVisitTypeEnum = mysqlEnum("appointmentVisitType", ["session", "retouch", "unknown"]);
export const appointmentFollowUpTypeEnum = mysqlEnum("appointmentFollowUpType", ["session", "retouch"]);
export const appointmentOriginalConsentLanguageEnum = mysqlEnum("appointmentOriginalConsentLanguage", ["en", "ar"]);
export const appointmentConsentSignatureStatusEnum = mysqlEnum("appointmentConsentSignatureStatus", ["not_applicable", "required", "received"]);
export const appointmentStatusEnum = mysqlEnum("appointmentStatus", ["confirmed", "waiting", "arrived", "completed", "cancelled", "no-show"]);
export const sessionRecordVisitTypeEnum = mysqlEnum("sessionRecordVisitType", ["session", "retouch"]);
export const sessionRecordStatusEnum = mysqlEnum("sessionRecordStatus", ["draft", "completed", "cancelled"]);
export const followUpTypeEnum = mysqlEnum("followUpType", ["session", "retouch"]);
export const followUpStatusEnum = mysqlEnum("followUpStatus", ["pending", "contacted", "completed", "cancelled"]);
export const followUpSourceEnum = mysqlEnum("followUpSource", ["session", "appointment", "manual"]);
export const providerCodeEnum = mysqlEnum("providerCode", ["NR011"]);
export const patientPreferredContactEnum = mysqlEnum("patientPreferredContact", ["WhatsApp", "Phone", "Email"]);
export const machineNameEnum = mysqlEnum("machineName", ["DEKA AGAIN", "CLARITY 2", "GENTLE PROMAX", "DUETTO MACHINE"]);
export const clinicDefaultLanguageEnum = mysqlEnum("clinicDefaultLanguage", ["en", "ar"]);
export const homepageSectionStatusEnum = mysqlEnum("homepageSectionStatus", ["draft", "published"]);
export const homepageThemeEnum = mysqlEnum("homepageTheme", ["signature", "graphite", "sage"]);
export const promotionStatusEnum = mysqlEnum("promotionStatus", ["draft", "published", "paused", "archived"]);
export const reviewLanguageEnum = mysqlEnum("reviewLanguage", ["en", "ar"]);
export const reviewStatusEnum = mysqlEnum("reviewStatus", ["pending", "approved", "rejected", "hidden"]);
export const reviewSourceEnum = mysqlEnum("reviewSource", ["manual", "google_business"]);
export const googleBusinessConnectionStatusEnum = mysqlEnum("googleBusinessConnectionStatus", ["awaiting_location", "active", "error", "disconnected"]);
export const googleBusinessSyncStatusEnum = mysqlEnum("googleBusinessSyncStatus", ["never", "success", "failed"]);
export const guidePostTypeEnum = mysqlEnum("guidePostType", ["blog", "video"]);
export const guidePostStatusEnum = mysqlEnum("guidePostStatus", ["draft", "published"]);
export const seoLocaleEnum = mysqlEnum("seoLocale", ["en", "ar-SA"]);
export const contentCalendarTypeEnum = mysqlEnum("contentCalendarType", ["guide_article", "gbp_update", "social_repurpose", "seo_task", "content_update"]);
export const contentCalendarLanguageEnum = mysqlEnum("contentCalendarLanguage", ["en", "ar", "both"]);
export const contentCalendarStatusEnum = mysqlEnum("contentCalendarStatus", ["idea", "draft", "review", "scheduled", "published", "update_needed"]);
export const notificationTypeEnum = mysqlEnum("notificationType", ["appointment_request", "enquiry", "review", "promotion", "system"]);
export const enquiryLanguageEnum = mysqlEnum("enquiryLanguage", ["en", "ar"]);
export const enquiryStatusEnum = mysqlEnum("enquiryStatus", ["new", "read", "replied", "archived"]);
export const analyticsEventTypeEnum = mysqlEnum("analyticsEventType", ["page_view", "whatsapp_click", "appointment_click", "appointment_form_start", "appointment_form_submit", "treatment_view", "guide_view", "social_click"]);
export const analyticsLocaleEnum = mysqlEnum("analyticsLocale", ["en", "ar-SA"]);
export const analyticsDeviceEnum = mysqlEnum("analyticsDevice", ["desktop", "mobile", "tablet", "unknown"]);
export const publicFormTypeEnum = mysqlEnum("publicFormType", ["consultation_request", "enquiry", "web_chat"]);
export const webChatConversationStatusEnum = mysqlEnum("webChatConversationStatus", ["open", "resolved", "archived"]);
export const webChatMessageDirectionEnum = mysqlEnum("webChatMessageDirection", ["visitor", "staff"]);
export const webChatMessageSourceEnum = mysqlEnum("webChatMessageSource", ["manual", "template", "ai_draft"]);
export const webChatTemplateLanguageEnum = mysqlEnum("webChatTemplateLanguage", ["en", "ar"]);

// Meta WhatsApp Business Platform operational state. These values model only
// server-observed facts and staff-controlled workflow status; they do not
// introduce autonomous scheduling, clinical decisions, or appointment changes.
export const whatsappContactLanguageEnum = mysqlEnum("whatsappContactLanguage", ["en", "ar", "unknown"]);
export const whatsappConversationStatusEnum = mysqlEnum("whatsappConversationStatus", ["open", "pending", "resolved", "archived"]);
export const whatsappMessageDirectionEnum = mysqlEnum("whatsappMessageDirection", ["inbound", "outbound", "system"]);
export const whatsappMessageTypeEnum = mysqlEnum("whatsappMessageType", ["text", "image", "document", "audio", "template", "interactive", "status", "unsupported"]);
export const whatsappMessageStatusEnum = mysqlEnum("whatsappMessageStatus", ["received", "sending", "sent", "delivered", "read", "failed"]);
export const whatsappTemplateStatusEnum = mysqlEnum("whatsappTemplateStatus", ["approved", "pending", "rejected", "paused", "disabled", "unknown"]);
export const whatsappWebhookProcessingStatusEnum = mysqlEnum("whatsappWebhookProcessingStatus", ["received", "processing", "processed", "ignored", "failed"]);
export const whatsappAutomationTypeEnum = mysqlEnum("whatsappAutomationType", ["inbound_message", "request_linked", "reschedule_flagged", "cancellation_flagged", "outbound_retry", "session_reminder_scheduled", "retouch_reminder_scheduled", "automation_claimed", "automation_provider_required", "attendance_confirmed", "cannot_attend", "retouch_interest", "retouch_request_created", "retouch_request_reviewed", "automation_cancelled", "consent_updated", "manual_reminder_queued", "appointment_automation_scheduled", "appointment_automation_cancelled", "appointment_automation_failed"]);
export const whatsappAutomationJobTypeEnum = mysqlEnum("whatsappAutomationJobType", ["session_reminder", "session_reminder_2h", "retouch_invitation", "retouch_date_options", "retouch_time_options", "retouch_request_received", "retouch_confirmation", "cannot_attend_acknowledgement", "appointment_confirmation", "appointment_reminder_24h", "appointment_final_reminder", "appointment_rescheduled", "appointment_cancellation", "appointment_completed_follow_up", "appointment_no_show_follow_up"]);
export const whatsappAutomationJobStatusEnum = mysqlEnum("whatsappAutomationJobStatus", ["scheduled", "queued", "claimed", "provider_not_connected", "blocked_consent", "blocked_template", "provider_accepted", "sent", "delivered", "read", "failed", "cancelled", "skipped"]);
export const whatsappConsentStatusEnum = mysqlEnum("whatsappConsentStatus", ["unknown", "opted_in", "opted_out"]);
export const whatsappAttendanceConfirmationEnum = mysqlEnum("whatsappAttendanceConfirmation", ["awaiting_response", "confirmed", "cannot_attend"]);
export const whatsappRetouchRequestStatusEnum = mysqlEnum("whatsappRetouchRequestStatus", ["awaiting_patient_preference", "awaiting_patient_time", "awaiting_clinic_confirmation", "confirmed", "alternative_time_suggested", "declined", "patient_declined"]);

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: roleEnum.default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

/** Public consultation enquiries submitted through the James Laser homepage. */
export const consultationRequests = mysqlTable("consultationRequests", {
  id: int("id").autoincrement().primaryKey(),
  /** Client-generated idempotency key prevents a double tap from creating two requests. */
  clientSubmissionId: varchar("clientSubmissionId", { length: 64 }).unique(),
  fullName: varchar("fullName", { length: 120 }).notNull(),
  nationality: varchar("nationality", { length: 80 }).notNull(),
  whatsapp: varchar("whatsapp", { length: 32 }).notNull(),
  normalizedWhatsapp: varchar("normalizedWhatsapp", { length: 20 }),
  email: varchar("email", { length: 320 }),
  treatmentArea: varchar("treatmentArea", { length: 120 }).notNull(),
  treatmentAreas: text("treatmentAreas"),
  preferredContact: preferredContactEnum.notNull(),
  preferredDate: varchar("preferredDate", { length: 10 }).notNull(),
  preferredTime: varchar("preferredTime", { length: 160 }),
  visitType: consultationRequestVisitTypeEnum.default("session").notNull(),
  firstTime: boolean("firstTime").notNull(),
  lastLaserSession: varchar("lastLaserSession", { length: 160 }),
  takingMedication: boolean("takingMedication"),
  medicationDetails: varchar("medicationDetails", { length: 500 }),
  medicationTypes: text("medicationTypes"),
  medicationLastTaken: varchar("medicationLastTaken", { length: 10 }),
  medicationDosage: varchar("medicationDosage", { length: 160 }),
  tookVitaminD: boolean("tookVitaminD"),
  vitaminDLastTaken: varchar("vitaminDLastTaken", { length: 160 }),
  takingIron: boolean("takingIron"),
  ironLastTaken: varchar("ironLastTaken", { length: 160 }),
  tannedPastThreeMonths: boolean("tannedPastThreeMonths"),
  hadMoroccanBathLastSevenDays: boolean("hadMoroccanBathLastSevenDays"),
  hadSkinTreatment: boolean("hadSkinTreatment"),
  skinTreatmentDetails: varchar("skinTreatmentDetails", { length: 500 }),
  hadSevereSunExposure: boolean("hadSevereSunExposure"),
  recentExposureDate: varchar("recentExposureDate", { length: 10 }),
  hasSkinCondition: boolean("hasSkinCondition"),
  skinConditionDetails: text("skinConditionDetails"),
  notes: text("notes"),
  consentRead: boolean("consentRead").notNull(),
  privacyConsent: boolean("privacyConsent").notNull(),
  /** Versioned notice evidence for the data-processing acknowledgement shown at collection. */
  privacyNoticeVersion: varchar("privacyNoticeVersion", { length: 120 }).notNull().default("privacy-notice-v1-2026-09-19"),
  /** Explicit acknowledgement limited to the online health-screening review purpose. */
  healthScreeningConsent: boolean("healthScreeningConsent").default(false).notNull(),
  healthScreeningConsentAt: timestamp("healthScreeningConsentAt"),
  appointmentAcknowledgement: boolean("appointmentAcknowledgement").default(false).notNull(),
  informationAccuracyAcknowledgedAt: timestamp("informationAccuracyAcknowledgedAt"),
  originalConsentSetReference: varchar("originalConsentSetReference", { length: 180 }),
  originalConsentDocuments: text("originalConsentDocuments"),
  originalConsentAcknowledgedAt: timestamp("originalConsentAcknowledgedAt"),
  originalConsentLanguage: originalConsentLanguageEnum,
  consentSignatureStatus: consentSignatureStatusEnum.default("required").notNull(),
  consentSignatureReference: varchar("consentSignatureReference", { length: 500 }),
  consentSignatureEvidenceKey: varchar("consentSignatureEvidenceKey", { length: 500 }),
  finalizedFullName: varchar("finalizedFullName", { length: 120 }),
  finalizedWhatsapp: varchar("finalizedWhatsapp", { length: 32 }),
  finalizedNationality: varchar("finalizedNationality", { length: 80 }),
  finalizedMrn: varchar("finalizedMrn", { length: 64 }),
  finalizedAppointmentDate: varchar("finalizedAppointmentDate", { length: 10 }),
  finalizedAppointmentTime: varchar("finalizedAppointmentTime", { length: 160 }),
  finalizedTreatmentAreas: text("finalizedTreatmentAreas"),
  finalizedMachine: finalizedMachineEnum,
  finalizedVisitType: finalizedVisitTypeEnum,
  finalizedNotes: text("finalizedNotes"),
  assignedStaff: varchar("assignedStaff", { length: 120 }),
  appointmentDurationMinutes: int("appointmentDurationMinutes"),
  finalizedBy: varchar("finalizedBy", { length: 120 }),
  finalizedAt: timestamp("finalizedAt"),
  marketingConsent: boolean("marketingConsent").default(false).notNull(),
  source: varchar("source", { length: 120 }).default("website").notNull(),
  isPotentialDuplicate: boolean("isPotentialDuplicate").default(false).notNull(),
  publicRequestId: varchar("publicRequestId", { length: 32 }).unique(),
  status: statusEnum.default("pending").notNull(),
  language: consultationRequestLanguageEnum.default("en").notNull(),
  internalNotes: text("internalNotes"),
  reviewedBy: varchar("reviewedBy", { length: 120 }),
  reviewedAt: timestamp("reviewedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/**
 * Private e-signature sessions bind a pending appointment request to the exact
 * original consent set. They store only references to a separate signature-evidence
 * derivative; source PDFs remain immutable and are never replaced.
 */
export const consentSignatureSessions = mysqlTable("consentSignatureSessions", {
  id: int("id").autoincrement().primaryKey(),
  consultationRequestId: int("consultationRequestId").notNull().unique().references(() => consultationRequests.id, { onDelete: "restrict" }),
  tokenHash: varchar("tokenHash", { length: 128 }).notNull().unique(),
  status: consentSignatureSessionStatusEnum.default("pending").notNull(),
  consentSetReference: varchar("consentSetReference", { length: 180 }).notNull(),
  sourceConsentDocuments: text("sourceConsentDocuments").notNull(),
  recipientLanguage: consentSignatureSessionLanguageEnum.notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  signerName: varchar("signerName", { length: 120 }),
  signedAt: timestamp("signedAt"),
  signatureEvidenceKey: varchar("signatureEvidenceKey", { length: 500 }),
  signatureEvidenceUrl: varchar("signatureEvidenceUrl", { length: 500 }),
  signatureReference: varchar("signatureReference", { length: 180 }),
  createdByUserId: int("createdByUserId").notNull().references(() => users.id, { onDelete: "restrict" }),
  revokedByUserId: int("revokedByUserId").references(() => users.id, { onDelete: "restrict" }),
  revokedAt: timestamp("revokedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Confirmed appointments created only after an admin approves a consultation request. */
export const appointments = mysqlTable("appointments", {
  id: int("id").autoincrement().primaryKey(),
  consultationRequestId: int("consultationRequestId").unique().references(() => consultationRequests.id, { onDelete: "restrict" }),
  patientId: int("patientId").references(() => patients.id, { onDelete: "restrict" }),
  patientName: varchar("patientName", { length: 120 }).notNull(),
  contactNumber: varchar("contactNumber", { length: 32 }),
  whatsapp: varchar("whatsapp", { length: 32 }),
  email: varchar("email", { length: 320 }),
  mrn: varchar("mrn", { length: 64 }),
  appointmentDate: varchar("appointmentDate", { length: 10 }).notNull(),
  appointmentTime: varchar("appointmentTime", { length: 160 }).notNull(),
  appointmentEndTime: varchar("appointmentEndTime", { length: 160 }),
  treatmentArea: varchar("treatmentArea", { length: 120 }),
  treatmentAreas: text("treatmentAreas"),
  machine: machineEnum,
  visitType: appointmentVisitTypeEnum.default("unknown").notNull(),
  whatsappConsentStatus: whatsappConsentStatusEnum.default("unknown").notNull(),
  whatsappConsentSource: varchar("whatsappConsentSource", { length: 160 }),
  whatsappConsentAt: timestamp("whatsappConsentAt"),
  whatsappConsentVersion: varchar("whatsappConsentVersion", { length: 120 }),
  whatsappOptedOutAt: timestamp("whatsappOptedOutAt"),
  whatsappAttendanceConfirmation: whatsappAttendanceConfirmationEnum.default("awaiting_response").notNull(),
  whatsappAttendanceConfirmedAt: timestamp("whatsappAttendanceConfirmedAt"),
  whatsappCannotAttendAt: timestamp("whatsappCannotAttendAt"),
  /** Set only for appointments created after the controlled automation rollout. */
  whatsappAutomationInitializedAt: timestamp("whatsappAutomationInitializedAt"),
  /** Incremented only when the clinic changes the finalized appointment date or time. */
  whatsappAutomationVersion: int("whatsappAutomationVersion").default(1).notNull(),
  nextFollowUpDate: varchar("nextFollowUpDate", { length: 10 }),
  nextFollowUpType: appointmentFollowUpTypeEnum,
  internalNotes: text("internalNotes"),
  assignedStaff: varchar("assignedStaff", { length: 120 }),
  durationMinutes: int("durationMinutes"),
  originalConsentSetReference: varchar("originalConsentSetReference", { length: 180 }),
  originalConsentAcknowledgedAt: timestamp("originalConsentAcknowledgedAt"),
  originalConsentLanguage: appointmentOriginalConsentLanguageEnum,
  consentSignatureStatus: appointmentConsentSignatureStatusEnum.default("not_applicable").notNull(),
  consentSignatureReference: varchar("consentSignatureReference", { length: 500 }),
  source: varchar("source", { length: 40 }).default("website_transfer").notNull(),
  sourceRowNumber: int("sourceRowNumber"),
  importBatchId: int("importBatchId").references(() => hmsImportBatches.id, { onDelete: "restrict" }),
  importFingerprint: varchar("importFingerprint", { length: 128 }).unique(),
  hmsImportIdentityKey: varchar("hmsImportIdentityKey", { length: 128 }).unique(),
  originalAppointmentDate: varchar("originalAppointmentDate", { length: 32 }),
  originalAppointmentStartTime: varchar("originalAppointmentStartTime", { length: 32 }),
  originalAppointmentEndTime: varchar("originalAppointmentEndTime", { length: 32 }),
  originalTelephone: varchar("originalTelephone", { length: 80 }),
  originalSex: varchar("originalSex", { length: 32 }),
  normalizedSex: varchar("normalizedSex", { length: 32 }),
  originalAge: varchar("originalAge", { length: 32 }),
  normalizedAge: int("normalizedAge"),
  nationality: varchar("nationality", { length: 80 }),
  remarks: text("remarks"),
  originalRowData: text("originalRowData"),
  status: appointmentStatusEnum.default("confirmed").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Immutable audit metadata for a completed HMS CSV import; parsed source values remain on each appointment row. */
export const hmsImportBatches = mysqlTable("hmsImportBatches", {
  id: int("id").autoincrement().primaryKey(),
  source: varchar("source", { length: 40 }).default("hms_csv").notNull(),
  originalFileName: varchar("originalFileName", { length: 255 }).notNull(),
  fileSha256: varchar("fileSha256", { length: 128 }).notNull().unique(),
  sourceFileKey: varchar("sourceFileKey", { length: 500 }),
  providerCode: providerCodeEnum.notNull(),
  providerLabel: varchar("providerLabel", { length: 120 }).notNull(),
  rowCount: int("rowCount").notNull(),
  importedCount: int("importedCount").default(0).notNull(),
  skippedDuplicateCount: int("skippedDuplicateCount").default(0).notNull(),
  warningCount: int("warningCount").default(0).notNull(),
  errorCount: int("errorCount").default(0).notNull(),
  importedByUserId: int("importedByUserId").notNull().references(() => users.id, { onDelete: "restrict" }),
  importedAt: timestamp("importedAt").defaultNow().notNull(),
});

/** Immutable import metadata for the HMS Detail Revenue By Patient report. */
export const revenueImportBatches = mysqlTable("revenueImportBatches", {
  id: int("id").autoincrement().primaryKey(),
  originalFileName: varchar("originalFileName", { length: 255 }).notNull(),
  fileSha256: varchar("fileSha256", { length: 128 }).notNull().unique(),
  reportFromDate: varchar("reportFromDate", { length: 10 }),
  reportToDate: varchar("reportToDate", { length: 10 }),
  account: varchar("account", { length: 180 }),
  printDate: varchar("printDate", { length: 32 }),
  grandGross: decimal("grandGross", { precision: 14, scale: 2 }).notNull(),
  grandQuantity: decimal("grandQuantity", { precision: 14, scale: 3 }).notNull(),
  grandDiscount: decimal("grandDiscount", { precision: 14, scale: 2 }).notNull(),
  grandDeduct: decimal("grandDeduct", { precision: 14, scale: 2 }).notNull(),
  grandNet: decimal("grandNet", { precision: 14, scale: 2 }).notNull(),
  patientCount: int("patientCount").notNull(),
  serviceRowCount: int("serviceRowCount").notNull(),
  importedByUserId: int("importedByUserId").notNull().references(() => users.id, { onDelete: "restrict" }),
  importedByName: varchar("importedByName", { length: 120 }),
  importedAt: timestamp("importedAt").defaultNow().notNull(),
  validationResult: varchar("validationResult", { length: 20 }).notNull(),
});

/** One immutable revenue transaction for each HMS service row; subtotals and grand totals are never stored here. */
export const revenueTransactions = mysqlTable("revenueTransactions", {
  id: int("id").autoincrement().primaryKey(),
  importBatchId: int("importBatchId").notNull().references(() => revenueImportBatches.id, { onDelete: "restrict" }),
  patientId: int("patientId").references(() => patients.id, { onDelete: "restrict" }),
  hmsMrn: varchar("hmsMrn", { length: 64 }),
  patientName: varchar("patientName", { length: 180 }).notNull(),
  serviceCode: varchar("serviceCode", { length: 120 }).notNull(),
  serviceName: varchar("serviceName", { length: 240 }).notNull(),
  gross: decimal("gross", { precision: 14, scale: 2 }).notNull(),
  quantity: decimal("quantity", { precision: 14, scale: 3 }).notNull(),
  discount: decimal("discount", { precision: 14, scale: 2 }).notNull(),
  deduct: decimal("deduct", { precision: 14, scale: 2 }).notNull(),
  net: decimal("net", { precision: 14, scale: 2 }).notNull(),
  reportFromDate: varchar("reportFromDate", { length: 10 }),
  reportToDate: varchar("reportToDate", { length: 10 }),
  printDate: varchar("printDate", { length: 32 }),
  sourceFileName: varchar("sourceFileName", { length: 255 }).notNull(),
  sourceRowNumber: int("sourceRowNumber").notNull(),
  sourceFingerprint: varchar("sourceFingerprint", { length: 128 }).notNull().unique(),
  importedByUserId: int("importedByUserId").notNull().references(() => users.id, { onDelete: "restrict" }),
  importedAt: timestamp("importedAt").defaultNow().notNull(),
});

/** One clinic-owned patient file per WhatsApp number, created when a request is approved. */
export const patients = mysqlTable("patients", {
  id: int("id").autoincrement().primaryKey(),
  fullName: varchar("fullName", { length: 120 }).notNull(),
  mrn: varchar("mrn", { length: 64 }).unique(),
  contactNumber: varchar("contactNumber", { length: 32 }),
  whatsapp: varchar("whatsapp", { length: 32 }).notNull().unique(),
  email: varchar("email", { length: 320 }),
  nationality: varchar("nationality", { length: 80 }).notNull(),
  treatmentArea: varchar("treatmentArea", { length: 120 }).notNull(),
  preferredContact: patientPreferredContactEnum.notNull(),
  source: varchar("source", { length: 40 }).default("request_transfer").notNull(),
  firstTime: boolean("firstTime"),
  lastLaserSession: varchar("lastLaserSession", { length: 160 }),
  takingMedication: boolean("takingMedication"),
  medicationDetails: varchar("medicationDetails", { length: 500 }),
  tookVitaminD: boolean("tookVitaminD"),
  vitaminDLastTaken: varchar("vitaminDLastTaken", { length: 160 }),
  takingIron: boolean("takingIron"),
  ironLastTaken: varchar("ironLastTaken", { length: 160 }),
  tannedPastThreeMonths: boolean("tannedPastThreeMonths"),
  hadMoroccanBathLastSevenDays: boolean("hadMoroccanBathLastSevenDays"),
  hadSkinTreatment: boolean("hadSkinTreatment"),
  skinTreatmentDetails: varchar("skinTreatmentDetails", { length: 500 }),
  hadSevereSunExposure: boolean("hadSevereSunExposure"),
  whatsappConsentStatus: whatsappConsentStatusEnum.default("unknown").notNull(),
  whatsappConsentSource: varchar("whatsappConsentSource", { length: 160 }),
  whatsappConsentAt: timestamp("whatsappConsentAt"),
  whatsappConsentVersion: varchar("whatsappConsentVersion", { length: 120 }),
  whatsappOptedOutAt: timestamp("whatsappOptedOutAt"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Clinic machine inventory; manual IDs are internal labels, not manufacturer serial numbers. */
export const machines = mysqlTable("machines", {
  id: int("id").autoincrement().primaryKey(),
  name: machineNameEnum.notNull().unique(),
  machineNumber: varchar("machineNumber", { length: 64 }).notNull().unique(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Central clinic details; one row keeps public contact information consistent across the CMS. */
export const clinicSettings = mysqlTable("clinicSettings", {
  id: int("id").autoincrement().primaryKey(),
  businessName: varchar("businessName", { length: 180 }).notNull(),
  specialistName: varchar("specialistName", { length: 120 }).notNull(),
  professionalTitle: varchar("professionalTitle", { length: 160 }),
  clinicName: varchar("clinicName", { length: 180 }).notNull(),
  addressEn: text("addressEn"),
  addressAr: text("addressAr"),
  mapsUrl: varchar("mapsUrl", { length: 500 }),
  whatsapp: varchar("whatsapp", { length: 32 }).notNull(),
  telephone: varchar("telephone", { length: 32 }),
  email: varchar("email", { length: 320 }),
  workingHours: varchar("workingHours", { length: 160 }).notNull(),
  instagramUrl: varchar("instagramUrl", { length: 500 }),
  tiktokUrl: varchar("tiktokUrl", { length: 500 }),
  snapchatUrl: varchar("snapchatUrl", { length: 500 }),
  facebookUrl: varchar("facebookUrl", { length: 500 }),
  youtubeUrl: varchar("youtubeUrl", { length: 500 }),
  xUrl: varchar("xUrl", { length: 500 }),
  googleBusinessUrl: varchar("googleBusinessUrl", { length: 500 }),
  appointmentFormEnabled: boolean("appointmentFormEnabled").default(true).notNull(),
  preferredTimes: text("preferredTimes"),
  availableDays: text("availableDays"),
  appointmentTreatmentOptions: text("appointmentTreatmentOptions"),
  visitTypeOptions: text("visitTypeOptions"),
  defaultLanguage: clinicDefaultLanguageEnum.default("en").notNull(),
  maintenanceMode: boolean("maintenanceMode").default(false).notNull(),
  homepageTheme: homepageThemeEnum.default("signature").notNull(),
  homepageHeroImageUrl: varchar("homepageHeroImageUrl", { length: 500 }),
  homepageSpecialistImageUrl: varchar("homepageSpecialistImageUrl", { length: 500 }),
  homepageClinicImageUrl: varchar("homepageClinicImageUrl", { length: 500 }),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/**
 * A narrow, non-destructive audit record for administrative configuration.
 * It stores only safe website and workflow values; secrets, credentials,
 * patient data, and integration payloads are intentionally excluded.
 */
export const settingsChangeAudits = mysqlTable("settingsChangeAudits", {
  id: int("id").autoincrement().primaryKey(),
  actorUserId: int("actorUserId").references(() => users.id, { onDelete: "restrict" }),
  actorName: varchar("actorName", { length: 120 }),
  settingArea: varchar("settingArea", { length: 80 }).notNull(),
  changedFieldsJson: text("changedFieldsJson").notNull(),
  previousValuesJson: text("previousValuesJson"),
  newValuesJson: text("newValuesJson"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("settingsChangeAudits_createdAt_idx").on(table.createdAt),
]);

/** Draft/published blocks that control public homepage copy without code edits. */
export const homepageSections = mysqlTable("homepageSections", {
  id: int("id").autoincrement().primaryKey(),
  sectionKey: varchar("sectionKey", { length: 80 }).notNull().unique(),
  titleEn: text("titleEn"),
  subtitleEn: text("subtitleEn"),
  descriptionEn: text("descriptionEn"),
  titleAr: text("titleAr"),
  subtitleAr: text("subtitleAr"),
  descriptionAr: text("descriptionAr"),
  ctaText: varchar("ctaText", { length: 120 }),
  ctaLink: varchar("ctaLink", { length: 500 }),
  imageUrl: varchar("imageUrl", { length: 500 }),
  videoUrl: varchar("videoUrl", { length: 500 }),
  isVisible: boolean("isVisible").default(true).notNull(),
  displayOrder: int("displayOrder").default(0).notNull(),
  status: homepageSectionStatusEnum.default("draft").notNull(),
  publishedAt: timestamp("publishedAt"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const treatments = mysqlTable("treatments", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  nameEn: varchar("nameEn", { length: 160 }).notNull(),
  nameAr: varchar("nameAr", { length: 160 }),
  shortDescriptionEn: text("shortDescriptionEn"),
  shortDescriptionAr: text("shortDescriptionAr"),
  descriptionEn: text("descriptionEn"),
  descriptionAr: text("descriptionAr"),
  imageUrl: varchar("imageUrl", { length: 500 }),
  startingPrice: decimal("startingPrice", { precision: 10, scale: 2 }),
  regularPrice: decimal("regularPrice", { precision: 10, scale: 2 }),
  promotionalPrice: decimal("promotionalPrice", { precision: 10, scale: 2 }),
  durationMinutes: int("durationMinutes"),
  preparationEn: text("preparationEn"),
  preparationAr: text("preparationAr"),
  aftercareEn: text("aftercareEn"),
  aftercareAr: text("aftercareAr"),
  seoTitle: varchar("seoTitle", { length: 180 }),
  seoDescription: varchar("seoDescription", { length: 320 }),
  isActive: boolean("isActive").default(false).notNull(),
  isFeatured: boolean("isFeatured").default(false).notNull(),
  displayOrder: int("displayOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const promotions = mysqlTable("promotions", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  name: varchar("name", { length: 180 }).notNull(),
  titleEn: varchar("titleEn", { length: 180 }).notNull(),
  titleAr: varchar("titleAr", { length: 180 }),
  descriptionEn: text("descriptionEn"),
  descriptionAr: text("descriptionAr"),
  originalPrice: decimal("originalPrice", { precision: 10, scale: 2 }),
  promotionalPrice: decimal("promotionalPrice", { precision: 10, scale: 2 }),
  includedTreatments: text("includedTreatments"),
  sessionCount: int("sessionCount"),
  retouchIncluded: boolean("retouchIncluded").default(false).notNull(),
  startsAt: timestamp("startsAt"),
  endsAt: timestamp("endsAt"),
  imageUrl: varchar("imageUrl", { length: 500 }),
  termsEn: text("termsEn"),
  termsAr: text("termsAr"),
  isFeatured: boolean("isFeatured").default(false).notNull(),
  status: promotionStatusEnum.default("draft").notNull(),
  displayOrder: int("displayOrder").default(0).notNull(),
  publishedAt: timestamp("publishedAt"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Reviews are owner-entered and stay non-public until explicitly approved. */
export const reviews = mysqlTable("reviews", {
  id: int("id").autoincrement().primaryKey(),
  displayName: varchar("displayName", { length: 120 }).notNull(),
  rating: int("rating").notNull(),
  reviewText: text("reviewText").notNull(),
  treatment: varchar("treatment", { length: 160 }),
  language: reviewLanguageEnum.default("en").notNull(),
  isAnonymous: boolean("isAnonymous").default(false).notNull(),
  isFeatured: boolean("isFeatured").default(false).notNull(),
  status: reviewStatusEnum.default("pending").notNull(),
  source: reviewSourceEnum.default("manual").notNull(),
  sourceReviewId: varchar("sourceReviewId", { length: 320 }).unique(),
  sourceUpdatedAt: timestamp("sourceUpdatedAt"),
  googleReplyText: text("googleReplyText"),
  googleReviewCreatedAt: timestamp("googleReviewCreatedAt"),
  reviewedAt: timestamp("reviewedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/** Server-only Google Business authorization and operational sync metadata. Tokens are encrypted before persistence. */
export const googleBusinessConnections = mysqlTable("googleBusinessConnections", {
  id: int("id").autoincrement().primaryKey(),
  connectionKey: varchar("connectionKey", { length: 40 }).notNull().unique(),
  status: googleBusinessConnectionStatusEnum.notNull(),
  encryptedRefreshToken: text("encryptedRefreshToken").notNull(),
  accountResourceName: varchar("accountResourceName", { length: 160 }),
  accountName: varchar("accountName", { length: 240 }),
  locationResourceName: varchar("locationResourceName", { length: 200 }),
  locationName: varchar("locationName", { length: 240 }),
  lastSyncedAt: timestamp("lastSyncedAt"),
  lastSyncStatus: googleBusinessSyncStatusEnum.default("never").notNull(),
  lastSyncError: varchar("lastSyncError", { length: 500 }),
  createdByUserId: int("createdByUserId").references(() => users.id, { onDelete: "restrict" }),
  createdByName: varchar("createdByName", { length: 120 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
/** One-time anti-CSRF OAuth state records; no access or refresh tokens are stored here. */
export const googleBusinessOAuthStates = mysqlTable("googleBusinessOAuthStates", {
  id: int("id").autoincrement().primaryKey(),
  stateDigest: varchar("stateDigest", { length: 64 }).notNull().unique(),
  createdByUserId: int("createdByUserId").notNull().references(() => users.id, { onDelete: "restrict" }),
  createdByName: varchar("createdByName", { length: 120 }),
  redirectUri: varchar("redirectUri", { length: 500 }).notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  consumedAt: timestamp("consumedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [index("googleBusinessOAuthStates_expiry_idx").on(table.expiresAt)]);
/** Private, administrator-managed image comparison records. Patient names are never stored here. */
export const resultCases = mysqlTable("resultCases", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 180 }).notNull(),
  treatmentArea: varchar("treatmentArea", { length: 160 }).notNull(),
  beforeImageUrl: varchar("beforeImageUrl", { length: 500 }).notNull(),
  afterImageUrl: varchar("afterImageUrl", { length: 500 }).notNull(),
  additionalImages: text("additionalImages"),
  sessionCount: int("sessionCount"),
  descriptionEn: text("descriptionEn"),
  descriptionAr: text("descriptionAr"),
  disclaimerEn: text("disclaimerEn"),
  disclaimerAr: text("disclaimerAr"),
  consentConfirmed: boolean("consentConfirmed").default(false).notNull(),
  consentRecordedAt: timestamp("consentRecordedAt"),
  isFeatured: boolean("isFeatured").default(false).notNull(),
  isActive: boolean("isActive").default(false).notNull(),
  displayOrder: int("displayOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const guidePosts = mysqlTable("guidePosts", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 180 }).notNull().unique(),
  postType: guidePostTypeEnum.default("blog").notNull(),
  titleEn: varchar("titleEn", { length: 220 }).notNull(),
  titleAr: varchar("titleAr", { length: 220 }),
  summaryEn: text("summaryEn"),
  summaryAr: text("summaryAr"),
  contentEn: text("contentEn"),
  contentAr: text("contentAr"),
  category: varchar("category", { length: 120 }),
  tags: text("tags"),
  featuredImageUrl: varchar("featuredImageUrl", { length: 500 }),
  videoUrl: varchar("videoUrl", { length: 500 }),
  seoTitle: varchar("seoTitle", { length: 180 }),
  metaDescription: varchar("metaDescription", { length: 320 }),
  canonicalUrl: varchar("canonicalUrl", { length: 500 }),
  socialImageUrl: varchar("socialImageUrl", { length: 500 }),
  featuredImageAltEn: varchar("featuredImageAltEn", { length: 320 }),
  featuredImageAltAr: varchar("featuredImageAltAr", { length: 320 }),
  focusKeyword: varchar("focusKeyword", { length: 180 }),
  socialCaptionEn: text("socialCaptionEn"),
  socialCaptionAr: text("socialCaptionAr"),
  socialHashtags: varchar("socialHashtags", { length: 500 }),
  authorName: varchar("authorName", { length: 120 }),
  aiGenerated: boolean("aiGenerated").default(false).notNull(),
  clinicalReviewedAt: timestamp("clinicalReviewedAt"),
  clinicalReviewedByUserId: int("clinicalReviewedByUserId").references(() => users.id, { onDelete: "restrict" }),
  status: guidePostStatusEnum.default("draft").notNull(),
  isFeatured: boolean("isFeatured").default(false).notNull(),
  publishedAt: timestamp("publishedAt"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const faqs = mysqlTable("faqs", {
  id: int("id").autoincrement().primaryKey(),
  questionEn: text("questionEn").notNull(),
  answerEn: text("answerEn").notNull(),
  questionAr: text("questionAr"),
  answerAr: text("answerAr"),
  category: varchar("category", { length: 120 }),
  isFeatured: boolean("isFeatured").default(false).notNull(),
  isActive: boolean("isActive").default(false).notNull(),
  displayOrder: int("displayOrder").default(0).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Media metadata only; file bytes live in secure project storage. */
export const mediaItems = mysqlTable("mediaItems", {
  id: int("id").autoincrement().primaryKey(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  storageKey: varchar("storageKey", { length: 500 }).notNull().unique(),
  url: varchar("url", { length: 500 }).notNull(),
  mimeType: varchar("mimeType", { length: 120 }).notNull(),
  altEn: varchar("altEn", { length: 320 }),
  altAr: varchar("altAr", { length: 320 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const policies = mysqlTable("policies", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 120 }).notNull().unique(),
  titleEn: varchar("titleEn", { length: 180 }).notNull(),
  titleAr: varchar("titleAr", { length: 180 }),
  contentEn: text("contentEn"),
  contentAr: text("contentAr"),
  status: mysqlEnum("policyStatus", ["draft", "published"]).default("draft").notNull(),
  publishedAt: timestamp("publishedAt"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const seoSettings = mysqlTable("seoSettings", {
  id: int("id").autoincrement().primaryKey(),
  locale: seoLocaleEnum.notNull().unique(),
  title: varchar("title", { length: 180 }).notNull(),
  metaDescription: varchar("metaDescription", { length: 320 }).notNull(),
  canonicalUrl: varchar("canonicalUrl", { length: 500 }),
  openGraphTitle: varchar("openGraphTitle", { length: 180 }),
  openGraphDescription: varchar("openGraphDescription", { length: 320 }),
  openGraphImageUrl: varchar("openGraphImageUrl", { length: 500 }),
  robotsIndex: boolean("robotsIndex").default(true).notNull(),
  structuredData: text("structuredData"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Private editorial planning records. Calendar status never publishes a guide or posts to an external platform. */
export const contentCalendarItems = mysqlTable("contentCalendarItems", {
  id: int("id").autoincrement().primaryKey(),
  planKey: varchar("planKey", { length: 180 }).notNull().unique(),
  weekNumber: int("weekNumber").notNull(),
  plannedFor: varchar("plannedFor", { length: 10 }).notNull(),
  contentType: contentCalendarTypeEnum.notNull(),
  topic: varchar("topic", { length: 240 }).notNull(),
  language: contentCalendarLanguageEnum.default("en").notNull(),
  status: contentCalendarStatusEnum.default("idea").notNull(),
  targetPage: varchar("targetPage", { length: 500 }),
  searchIntent: varchar("searchIntent", { length: 320 }),
  cta: varchar("cta", { length: 160 }),
  contentBrief: text("contentBrief"),
  internalLinks: text("internalLinks"),
  repurposingBrief: text("repurposingBrief"),
  requiresOwnerAuthorization: boolean("requiresOwnerAuthorization").default(false).notNull(),
  externalPublication: boolean("externalPublication").default(false).notNull(),
  createdByUserId: int("createdByUserId").references(() => users.id, { onDelete: "restrict" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const activityLogs = mysqlTable("activityLogs", {
  id: int("id").autoincrement().primaryKey(),
  actorName: varchar("actorName", { length: 120 }),
  actorUserId: int("actorUserId").references(() => users.id, { onDelete: "restrict" }),
  action: varchar("action", { length: 180 }).notNull(),
  subjectType: varchar("subjectType", { length: 80 }),
  subjectId: int("subjectId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/** Private staff inbox records; titles and messages intentionally omit customer names, mobile numbers, notes, and consent details. */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  type: notificationTypeEnum.notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  message: varchar("message", { length: 320 }).notNull(),
  linkPath: varchar("linkPath", { length: 320 }),
  isRead: boolean("isRead").default(false).notNull(),
  readAt: timestamp("readAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/** General contact messages are deliberately separate from clinical appointment requests. */
export const enquiries = mysqlTable("enquiries", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  mobile: varchar("mobile", { length: 32 }).notNull(),
  email: varchar("email", { length: 320 }),
  subject: varchar("subject", { length: 180 }).notNull(),
  message: text("message").notNull(),
  language: enquiryLanguageEnum.default("en").notNull(),
  source: varchar("source", { length: 120 }).notNull(),
  status: enquiryStatusEnum.default("new").notNull(),
  internalNotes: text("internalNotes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/**
 * Public web-chat conversations intentionally collect no name, phone number,
 * email address, medical history, or appointment details. The opaque session
 * token is generated in the visitor's browser and grants access only to that
 * visitor's own conversation.
 */
export const webChatConversations = mysqlTable("webChatConversations", {
  id: int("id").autoincrement().primaryKey(),
  sessionToken: varchar("sessionToken", { length: 64 }).notNull().unique(),
  language: webChatTemplateLanguageEnum.default("en").notNull(),
  status: webChatConversationStatusEnum.default("open").notNull(),
  unreadForStaff: int("unreadForStaff").default(0).notNull(),
  unreadForVisitor: int("unreadForVisitor").default(0).notNull(),
  lastStaffReadAt: timestamp("lastStaffReadAt"),
  lastVisitorReadAt: timestamp("lastVisitorReadAt"),
  staffTypingAt: timestamp("staffTypingAt"),
  visitorTypingAt: timestamp("visitorTypingAt"),
  lastMessageAt: timestamp("lastMessageAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [
  index("webChatConversations_status_lastMessage_idx").on(table.status, table.lastMessageAt),
]);

/** Public visitor and protected staff messages for the isolated website chat channel. */
export const webChatMessages = mysqlTable("webChatMessages", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: int("conversationId").notNull().references(() => webChatConversations.id, { onDelete: "restrict" }),
  direction: webChatMessageDirectionEnum.notNull(),
  source: webChatMessageSourceEnum.default("manual").notNull(),
  body: text("body").notNull(),
  staffUserId: int("staffUserId").references(() => users.id, { onDelete: "restrict" }),
  staffName: varchar("staffName", { length: 120 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("webChatMessages_conversation_created_idx").on(table.conversationId, table.createdAt),
  index("webChatMessages_direction_created_idx").on(table.direction, table.createdAt),
]);

/** Administrator-managed reply snippets; no template sends a message without staff review and action. */
export const webChatTemplates = mysqlTable("webChatTemplates", {
  id: int("id").autoincrement().primaryKey(),
  label: varchar("label", { length: 120 }).notNull(),
  language: webChatTemplateLanguageEnum.default("en").notNull(),
  body: text("body").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdByUserId: int("createdByUserId").references(() => users.id, { onDelete: "restrict" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [
  index("webChatTemplates_active_language_idx").on(table.isActive, table.language),
]);

/** Anonymous aggregate event inputs; no visitor ID, IP address, or personal data is persisted. */
export const analyticsEvents = mysqlTable("analyticsEvents", {
  id: int("id").autoincrement().primaryKey(),
  eventType: analyticsEventTypeEnum.notNull(),
  path: varchar("path", { length: 320 }),
  locale: analyticsLocaleEnum,
  source: varchar("source", { length: 180 }),
  deviceType: analyticsDeviceEnum.default("unknown").notNull(),
  treatmentSlug: varchar("treatmentSlug", { length: 160 }),
  contentSlug: varchar("contentSlug", { length: 180 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/** Non-reversible submission fingerprints support server-side rate and duplicate protections. */
export const publicFormSecurityEvents = mysqlTable("publicFormSecurityEvents", {
  id: int("id").autoincrement().primaryKey(),
  formType: publicFormTypeEnum.notNull(),
  fingerprint: varchar("fingerprint", { length: 128 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/** Managed permanent redirects are internal records enforced before public frontend routing. */
export const redirects = mysqlTable("redirects", {
  id: int("id").autoincrement().primaryKey(),
  fromPath: varchar("fromPath", { length: 320 }).notNull().unique(),
  toPath: varchar("toPath", { length: 320 }).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Protected longitudinal treatment record linked to one operational appointment. */
export const sessionRecords = mysqlTable("sessionRecords", {
  id: int("id").autoincrement().primaryKey(),
  appointmentId: int("appointmentId").notNull().references(() => appointments.id, { onDelete: "restrict" }),
  patientId: int("patientId").references(() => patients.id, { onDelete: "restrict" }),
  patientName: varchar("patientName", { length: 120 }).notNull(),
  mrn: varchar("mrn", { length: 64 }),
  whatsapp: varchar("whatsapp", { length: 32 }),
  sessionDate: varchar("sessionDate", { length: 10 }).notNull(),
  sessionTime: varchar("sessionTime", { length: 16 }).notNull(),
  visitType: sessionRecordVisitTypeEnum.notNull(),
  treatmentAreas: text("treatmentAreas").notNull(),
  machine: machineEnum.notNull(),
  machineNumber: varchar("machineNumber", { length: 64 }),
  nurseName: varchar("nurseName", { length: 120 }),
  outcome: text("outcome"),
  notes: text("notes"),
  status: sessionRecordStatusEnum.default("draft").notNull(),
  createdByUserId: int("createdByUserId").notNull().references(() => users.id, { onDelete: "restrict" }),
  updatedByUserId: int("updatedByUserId").references(() => users.id, { onDelete: "restrict" }),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [
  uniqueIndex("sessionRecords_appointment_idx").on(table.appointmentId),
  index("sessionRecords_patient_idx").on(table.patientId),
  index("sessionRecords_date_idx").on(table.sessionDate),
]);

/** Staff-controlled follow-up task; no clinical timing or outbound message is inferred automatically. */
export const followUps = mysqlTable("followUps", {
  id: int("id").autoincrement().primaryKey(),
  appointmentId: int("appointmentId").references(() => appointments.id, { onDelete: "restrict" }),
  sessionRecordId: int("sessionRecordId").references(() => sessionRecords.id, { onDelete: "restrict" }),
  patientId: int("patientId").references(() => patients.id, { onDelete: "restrict" }),
  patientName: varchar("patientName", { length: 120 }).notNull(),
  mrn: varchar("mrn", { length: 64 }),
  whatsapp: varchar("whatsapp", { length: 32 }),
  followUpType: followUpTypeEnum.notNull(),
  dueDate: varchar("dueDate", { length: 10 }),
  status: followUpStatusEnum.default("pending").notNull(),
  source: followUpSourceEnum.default("manual").notNull(),
  assignedStaff: varchar("assignedStaff", { length: 120 }),
  outcome: text("outcome"),
  notes: text("notes"),
  createdByUserId: int("createdByUserId").notNull().references(() => users.id, { onDelete: "restrict" }),
  updatedByUserId: int("updatedByUserId").references(() => users.id, { onDelete: "restrict" }),
  contactedAt: timestamp("contactedAt"),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [
  uniqueIndex("followUps_appointment_idx").on(table.appointmentId),
  uniqueIndex("followUps_session_idx").on(table.sessionRecordId),
  index("followUps_patient_idx").on(table.patientId),
  index("followUps_due_status_idx").on(table.dueDate, table.status),
]);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type ConsultationRequest = typeof consultationRequests.$inferSelect;
export type InsertConsultationRequest = typeof consultationRequests.$inferInsert;
export type ConsentSignatureSession = typeof consentSignatureSessions.$inferSelect;
export type Appointment = typeof appointments.$inferSelect;
export type InsertAppointment = typeof appointments.$inferInsert;
export type Patient = typeof patients.$inferSelect;
export type InsertPatient = typeof patients.$inferInsert;
export type Machine = typeof machines.$inferSelect;
export type InsertMachine = typeof machines.$inferInsert;
export type ClinicSettings = typeof clinicSettings.$inferSelect;
export type SettingsChangeAudit = typeof settingsChangeAudits.$inferSelect;
export type HomepageSection = typeof homepageSections.$inferSelect;
export type Treatment = typeof treatments.$inferSelect;
export type Promotion = typeof promotions.$inferSelect;
export type Review = typeof reviews.$inferSelect;
export type GoogleBusinessConnection = typeof googleBusinessConnections.$inferSelect;
export type ResultCase = typeof resultCases.$inferSelect;
export type GuidePost = typeof guidePosts.$inferSelect;
export type Faq = typeof faqs.$inferSelect;
export type MediaItem = typeof mediaItems.$inferSelect;
export type Policy = typeof policies.$inferSelect;
export type SeoSettings = typeof seoSettings.$inferSelect;
export type ContentCalendarItem = typeof contentCalendarItems.$inferSelect;
export type Enquiry = typeof enquiries.$inferSelect;
export type AnalyticsEvent = typeof analyticsEvents.$inferSelect;
export type Redirect = typeof redirects.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type SessionRecord = typeof sessionRecords.$inferSelect;
export type FollowUp = typeof followUps.$inferSelect;
export type WebChatConversation = typeof webChatConversations.$inferSelect;
export type WebChatMessage = typeof webChatMessages.$inferSelect;
export type WebChatTemplate = typeof webChatTemplates.$inferSelect;

/**
 * WhatsApp contacts are linked by a normalized phone number only when the
 * match is deterministic. `waId` remains the original Meta identifier.
 */
export const whatsappContacts = mysqlTable("whatsappContacts", {
  id: int("id").autoincrement().primaryKey(),
  waId: varchar("waId", { length: 32 }).notNull().unique(),
  phoneNumber: varchar("phoneNumber", { length: 32 }).notNull(),
  normalizedPhone: varchar("normalizedPhone", { length: 20 }).unique(),
  displayName: varchar("displayName", { length: 120 }),
  profileName: varchar("profileName", { length: 120 }),
  language: whatsappContactLanguageEnum.default("unknown").notNull(),
  patientRequestId: int("patientRequestId").references(() => consultationRequests.id, { onDelete: "restrict" }),
  patientId: int("patientId").references(() => patients.id, { onDelete: "restrict" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** One durable inbox thread per WhatsApp contact; appointment changes stay staff-mediated. */
export const whatsappConversations = mysqlTable("whatsappConversations", {
  id: int("id").autoincrement().primaryKey(),
  contactId: int("contactId").notNull().unique().references(() => whatsappContacts.id, { onDelete: "restrict" }),
  status: whatsappConversationStatusEnum.default("open").notNull(),
  assignedUserId: int("assignedUserId").references(() => users.id, { onDelete: "restrict" }),
  linkedRequestId: int("linkedRequestId").references(() => consultationRequests.id, { onDelete: "restrict" }),
  linkedPatientId: int("linkedPatientId").references(() => patients.id, { onDelete: "restrict" }),
  linkedAppointmentId: int("linkedAppointmentId").references(() => appointments.id, { onDelete: "restrict" }),
  serviceWindowOpenedAt: timestamp("serviceWindowOpenedAt"),
  serviceWindowExpiresAt: timestamp("serviceWindowExpiresAt"),
  lastInboundAt: timestamp("lastInboundAt"),
  lastOutboundAt: timestamp("lastOutboundAt"),
  lastMessageAt: timestamp("lastMessageAt").defaultNow().notNull(),
  unreadCount: int("unreadCount").default(0).notNull(),
  rescheduleRequestedAt: timestamp("rescheduleRequestedAt"),
  cancellationRequestedAt: timestamp("cancellationRequestedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Original inbound content is preserved; optional translations are intentionally out of scope. */
export const whatsappMessages = mysqlTable("whatsappMessages", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: int("conversationId").notNull().references(() => whatsappConversations.id, { onDelete: "restrict" }),
  metaMessageId: varchar("metaMessageId", { length: 255 }).unique(),
  direction: whatsappMessageDirectionEnum.notNull(),
  messageType: whatsappMessageTypeEnum.notNull(),
  body: text("body"),
  mediaId: varchar("mediaId", { length: 255 }),
  mediaStorageKey: varchar("mediaStorageKey", { length: 500 }),
  mediaMimeType: varchar("mediaMimeType", { length: 120 }),
  templateName: varchar("templateName", { length: 512 }),
  templateLanguage: varchar("templateLanguage", { length: 32 }),
  status: whatsappMessageStatusEnum.default("received").notNull(),
  errorCode: varchar("errorCode", { length: 80 }),
  errorMessage: varchar("errorMessage", { length: 1000 }),
  replyToMetaMessageId: varchar("replyToMetaMessageId", { length: 255 }),
  sentAt: timestamp("sentAt"),
  deliveredAt: timestamp("deliveredAt"),
  readAt: timestamp("readAt"),
  failedAt: timestamp("failedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Server-synchronized metadata only; template content is never treated as an authorization override. */
export const whatsappTemplates = mysqlTable("whatsappTemplates", {
  id: int("id").autoincrement().primaryKey(),
  businessAccountId: varchar("businessAccountId", { length: 64 }).notNull(),
  templateName: varchar("templateName", { length: 512 }).notNull(),
  language: varchar("language", { length: 32 }).notNull(),
  category: varchar("category", { length: 80 }),
  status: whatsappTemplateStatusEnum.default("unknown").notNull(),
  bodyPreview: text("bodyPreview"),
  variables: text("variables"),
  metaTemplateId: varchar("metaTemplateId", { length: 128 }),
  lastSyncedAt: timestamp("lastSyncedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [
  uniqueIndex("whatsappTemplates_business_name_language_idx").on(table.businessAccountId, table.templateName, table.language),
]);

/** Idempotent webhook receipt record containing only a safe operational summary and digest. */
export const whatsappWebhookEvents = mysqlTable("whatsappWebhookEvents", {
  id: int("id").autoincrement().primaryKey(),
  eventFingerprint: varchar("eventFingerprint", { length: 128 }).notNull().unique(),
  metaEventId: varchar("metaEventId", { length: 255 }),
  eventType: varchar("eventType", { length: 120 }).notNull(),
  payloadSummary: varchar("payloadSummary", { length: 1000 }),
  processingStatus: whatsappWebhookProcessingStatusEnum.default("received").notNull(),
  processingStartedAt: timestamp("processingStartedAt"),
  processedAt: timestamp("processedAt"),
  errorMessage: varchar("errorMessage", { length: 1000 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/** Simple, reviewable operational events; never autonomous booking or clinical decisions. */
export const whatsappAutomationLogs = mysqlTable("whatsappAutomationLogs", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: int("conversationId").references(() => whatsappConversations.id, { onDelete: "restrict" }),
  messageId: int("messageId").references(() => whatsappMessages.id, { onDelete: "restrict" }),
  actorUserId: int("actorUserId").references(() => users.id, { onDelete: "restrict" }),
  automationType: whatsappAutomationTypeEnum.notNull(),
  outcome: varchar("outcome", { length: 120 }).notNull(),
  details: varchar("details", { length: 1000 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/** Provider-ready reminder queue. A deterministic schedule key prevents duplicate sends for the same appointment event. */
export const whatsappAutomationJobs = mysqlTable("whatsappAutomationJobs", {
  id: int("id").autoincrement().primaryKey(),
  appointmentId: int("appointmentId").notNull().references(() => appointments.id, { onDelete: "restrict" }),
  conversationId: int("conversationId").references(() => whatsappConversations.id, { onDelete: "restrict" }),
  retouchRequestId: int("retouchRequestId"),
  jobType: whatsappAutomationJobTypeEnum.notNull(),
  scheduleKey: varchar("scheduleKey", { length: 180 }).notNull().unique(),
  scheduledFor: timestamp("scheduledFor").notNull(),
  status: whatsappAutomationJobStatusEnum.default("scheduled").notNull(),
  language: whatsappContactLanguageEnum.default("unknown").notNull(),
  templateKey: varchar("templateKey", { length: 80 }).notNull(),
  providerMessageId: varchar("providerMessageId", { length: 255 }).unique(),
  claimToken: varchar("claimToken", { length: 96 }),
  claimedAt: timestamp("claimedAt"),
  queuedAt: timestamp("queuedAt"),
  providerAcceptedAt: timestamp("providerAcceptedAt"),
  sentAt: timestamp("sentAt"),
  failedAt: timestamp("failedAt"),
  cancelledAt: timestamp("cancelledAt"),
  cancelledReason: varchar("cancelledReason", { length: 500 }),
  manualReason: varchar("manualReason", { length: 500 }),
  attemptCount: int("attemptCount").default(0).notNull(),
  retryable: boolean("retryable").default(true).notNull(),
  lastErrorCode: varchar("lastErrorCode", { length: 80 }),
  lastErrorHttpStatus: int("lastErrorHttpStatus"),
  lastProviderErrorType: varchar("lastProviderErrorType", { length: 160 }),
  lastError: varchar("lastError", { length: 1000 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [
  uniqueIndex("whatsappAutomationJobs_appointment_type_schedule_idx").on(table.appointmentId, table.jobType, table.scheduledFor),
]);

/** A patient-selected retouch preference remains a request until an authorized staff member creates the appointment. */
export const whatsappRetouchRequests = mysqlTable("whatsappRetouchRequests", {
  id: int("id").autoincrement().primaryKey(),
  originalSessionAppointmentId: int("originalSessionAppointmentId").notNull().unique().references(() => appointments.id, { onDelete: "restrict" }),
  patientId: int("patientId").references(() => patients.id, { onDelete: "restrict" }),
  appointmentId: int("appointmentId").references(() => appointments.id, { onDelete: "restrict" }),
  patientName: varchar("patientName", { length: 120 }).notNull(),
  mrn: varchar("mrn", { length: 64 }),
  whatsapp: varchar("whatsapp", { length: 32 }).notNull(),
  treatmentAreas: text("treatmentAreas"),
  originalSessionDate: varchar("originalSessionDate", { length: 10 }).notNull(),
  eligibleStartDate: varchar("eligibleStartDate", { length: 10 }).notNull(),
  eligibleEndDate: varchar("eligibleEndDate", { length: 10 }).notNull(),
  preferredDate: varchar("preferredDate", { length: 10 }),
  preferredTime: varchar("preferredTime", { length: 16 }),
  suggestedDate: varchar("suggestedDate", { length: 10 }),
  suggestedTime: varchar("suggestedTime", { length: 16 }),
  status: whatsappRetouchRequestStatusEnum.default("awaiting_clinic_confirmation").notNull(),
  patientRespondedAt: timestamp("patientRespondedAt"),
  reviewedAt: timestamp("reviewedAt"),
  reviewedByUserId: int("reviewedByUserId").references(() => users.id, { onDelete: "restrict" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Local template specifications are ready for Meta review but never masquerade as provider-approved templates. */
export const whatsappAutomationTemplateDefinitions = mysqlTable("whatsappAutomationTemplateDefinitions", {
  id: int("id").autoincrement().primaryKey(),
  templateKey: varchar("templateKey", { length: 80 }).notNull(),
  language: whatsappContactLanguageEnum.notNull(),
  suggestedName: varchar("suggestedName", { length: 512 }).notNull(),
  category: varchar("category", { length: 80 }).default("utility").notNull(),
  bodyPreview: text("bodyPreview").notNull(),
  interactiveLabels: text("interactiveLabels"),
  providerTemplateName: varchar("providerTemplateName", { length: 512 }),
  providerTemplateId: varchar("providerTemplateId", { length: 128 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [
  uniqueIndex("whatsappAutomationTemplateDefinitions_key_language_idx").on(table.templateKey, table.language),
]);

/** Owner-attested, non-secret activation evidence. Every required prerequisite remains pending until explicitly verified. */
export const whatsappActivationPrerequisites = mysqlTable("whatsappActivationPrerequisites", {
  id: int("id").autoincrement().primaryKey(),
  prerequisiteKey: varchar("prerequisiteKey", { length: 80 }).notNull().unique(),
  status: varchar("status", { length: 20 }).default("pending").notNull(),
  evidenceReference: varchar("evidenceReference", { length: 500 }),
  verifiedAt: timestamp("verifiedAt"),
  verifiedByUserId: int("verifiedByUserId").references(() => users.id, { onDelete: "restrict" }),
  verifiedByName: varchar("verifiedByName", { length: 120 }),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Safe integration health metadata. Meta credentials remain exclusively in Secret Manager. */
export const whatsappSettings = mysqlTable("whatsappSettings", {
  id: int("id").autoincrement().primaryKey(),
  businessAccountId: varchar("businessAccountId", { length: 64 }).unique(),
  phoneNumberId: varchar("phoneNumberId", { length: 64 }).unique(),
  displayPhoneNumber: varchar("displayPhoneNumber", { length: 32 }),
  displayName: varchar("displayName", { length: 120 }),
  apiVersion: varchar("apiVersion", { length: 32 }),
  webhookConfigured: boolean("webhookConfigured").default(false).notNull(),
  lastWebhookReceivedAt: timestamp("lastWebhookReceivedAt"),
  lastWebhookFailureAt: timestamp("lastWebhookFailureAt"),
  lastTemplateSyncAt: timestamp("lastTemplateSyncAt"),
  recentFailureCount: int("recentFailureCount").default(0).notNull(),
  automationEnabled: boolean("automationEnabled").default(false).notNull(),
  appointmentConfirmationEnabled: boolean("appointmentConfirmationEnabled").default(true).notNull(),
  appointmentReminder24hEnabled: boolean("appointmentReminder24hEnabled").default(true).notNull(),
  appointmentFinalReminderEnabled: boolean("appointmentFinalReminderEnabled").default(true).notNull(),
  appointmentRescheduleEnabled: boolean("appointmentRescheduleEnabled").default(true).notNull(),
  appointmentCancellationEnabled: boolean("appointmentCancellationEnabled").default(true).notNull(),
  appointmentCompletionFollowUpEnabled: boolean("appointmentCompletionFollowUpEnabled").default(false).notNull(),
  appointmentNoShowFollowUpEnabled: boolean("appointmentNoShowFollowUpEnabled").default(false).notNull(),
  appointmentReminder24hHours: int("appointmentReminder24hHours").default(24).notNull(),
  appointmentFinalReminderHours: int("appointmentFinalReminderHours").default(3).notNull(),
  reminderSendingTime: varchar("reminderSendingTime", { length: 5 }).default("10:00").notNull(),
  retouchPreparationEn: text("retouchPreparationEn"),
  retouchPreparationAr: text("retouchPreparationAr"),
  schedulerTaskUid: varchar("schedulerTaskUid", { length: 65 }),
  schedulerVerifiedAt: timestamp("schedulerVerifiedAt"),
  consentWorkflowVerifiedAt: timestamp("consentWorkflowVerifiedAt"),
  providerFlowVerifiedAt: timestamp("providerFlowVerifiedAt"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
