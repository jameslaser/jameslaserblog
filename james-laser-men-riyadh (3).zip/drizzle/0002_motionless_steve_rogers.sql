CREATE TABLE `appointments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`consultationRequestId` int NOT NULL,
	`patientName` varchar(120) NOT NULL,
	`whatsapp` varchar(32) NOT NULL,
	`appointmentDate` varchar(10) NOT NULL,
	`appointmentTime` varchar(160) NOT NULL,
	`treatmentArea` varchar(120) NOT NULL,
	`machine` enum('DEKA AGAIN','CLARITY 2','GENTLE PROMAX','DUETTO MACHINE') NOT NULL,
	`appointmentStatus` enum('confirmed','completed','cancelled','no-show') NOT NULL DEFAULT 'confirmed',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `appointments_id` PRIMARY KEY(`id`),
	CONSTRAINT `appointments_consultationRequestId_unique` UNIQUE(`consultationRequestId`)
);
--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `status` enum('pending','approved','cancelled') DEFAULT 'pending' NOT NULL;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `reviewedBy` varchar(120);--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `reviewedAt` timestamp;