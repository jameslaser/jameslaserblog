CREATE TABLE `settingsChangeAudits` (
	`id` int AUTO_INCREMENT NOT NULL,
	`actorUserId` int,
	`actorName` varchar(120),
	`settingArea` varchar(80) NOT NULL,
	`changedFieldsJson` text NOT NULL,
	`previousValuesJson` text,
	`newValuesJson` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `settingsChangeAudits_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `settingsChangeAudits` ADD CONSTRAINT `settingsChangeAudits_actorUserId_users_id_fk` FOREIGN KEY (`actorUserId`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE no action;
--> statement-breakpoint
CREATE INDEX `settingsChangeAudits_createdAt_idx` ON `settingsChangeAudits` (`createdAt`);
