ALTER TABLE `appointments`
  ADD COLUMN `nextFollowUpDate` varchar(10) NULL,
  ADD COLUMN `appointmentFollowUpType` enum('session','retouch') NULL;
