-- Adds an explicit operational waiting state. Existing appointment status values are retained.
ALTER TABLE `appointments`
  MODIFY COLUMN `appointmentStatus` enum('confirmed','waiting','arrived','completed','cancelled','no-show') NOT NULL DEFAULT 'confirmed';
