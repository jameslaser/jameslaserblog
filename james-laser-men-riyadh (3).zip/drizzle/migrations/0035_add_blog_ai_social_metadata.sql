-- Additive blog editorial metadata for the existing guidePosts table.
-- Preserves every current post and introduces no DROP, DELETE, TRUNCATE,
-- UPDATE, or reseed operation.
ALTER TABLE `guidePosts`
  ADD COLUMN IF NOT EXISTS `featuredImageAltEn` varchar(320) NULL,
  ADD COLUMN IF NOT EXISTS `featuredImageAltAr` varchar(320) NULL,
  ADD COLUMN IF NOT EXISTS `focusKeyword` varchar(180) NULL,
  ADD COLUMN IF NOT EXISTS `socialCaptionEn` text NULL,
  ADD COLUMN IF NOT EXISTS `socialCaptionAr` text NULL,
  ADD COLUMN IF NOT EXISTS `socialHashtags` varchar(500) NULL,
  ADD COLUMN IF NOT EXISTS `authorName` varchar(120) NULL,
  ADD COLUMN IF NOT EXISTS `aiGenerated` boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS `clinicalReviewedAt` timestamp NULL,
  ADD COLUMN IF NOT EXISTS `clinicalReviewedByUserId` int NULL;

ALTER TABLE `guidePosts`
  ADD CONSTRAINT `guidePosts_clinicalReviewedByUserId_users_id_fk`
  FOREIGN KEY (`clinicalReviewedByUserId`) REFERENCES `users`(`id`)
  ON DELETE RESTRICT ON UPDATE NO ACTION;
