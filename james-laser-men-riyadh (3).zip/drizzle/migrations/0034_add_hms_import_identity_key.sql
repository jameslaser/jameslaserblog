-- Add a privacy-preserving duplicate guard for HMS appointment imports.
-- The nullable key is populated only when the imported row contains MRN, a normalized
-- mobile number, and a precise schedule; existing records are not modified.
ALTER TABLE `appointments`
  ADD COLUMN IF NOT EXISTS `hmsImportIdentityKey` varchar(128) NULL;
--> statement-breakpoint
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_hmsImportIdentityKey_unique` UNIQUE (`hmsImportIdentityKey`);
