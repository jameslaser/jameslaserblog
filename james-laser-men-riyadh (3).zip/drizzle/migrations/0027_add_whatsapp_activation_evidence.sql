-- Production-readiness remediation: additive WhatsApp safety evidence only.
-- No appointment, patient, revenue, credential, provider, scheduler, or automation state is changed.

ALTER TABLE `whatsappAutomationJobs`
  ADD COLUMN `lastErrorHttpStatus` int NULL,
  ADD COLUMN `lastProviderErrorType` varchar(160) NULL;

ALTER TABLE `whatsappWebhookEvents`
  MODIFY COLUMN `whatsappWebhookProcessingStatus` enum('received','processing','processed','ignored','failed') NOT NULL DEFAULT 'received',
  ADD COLUMN `processingStartedAt` timestamp NULL;

CREATE TABLE `whatsappActivationPrerequisites` (
  `id` int AUTO_INCREMENT NOT NULL,
  `prerequisiteKey` varchar(80) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `evidenceReference` varchar(500) NULL,
  `verifiedAt` timestamp NULL,
  `verifiedByUserId` int NULL,
  `verifiedByName` varchar(120) NULL,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `whatsappActivationPrerequisites_id` PRIMARY KEY (`id`),
  CONSTRAINT `whatsappActivationPrerequisites_prerequisiteKey_unique` UNIQUE (`prerequisiteKey`),
  CONSTRAINT `whatsappActivationPrerequisites_verifiedByUserId_users_id_fk` FOREIGN KEY (`verifiedByUserId`) REFERENCES `users`(`id`) ON DELETE RESTRICT
);
