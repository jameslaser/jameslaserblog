ALTER TABLE `consultationRequests`
  ADD COLUMN `clientSubmissionId` varchar(64),
  ADD COLUMN `medicationTypes` text,
  ADD COLUMN `medicationLastTaken` varchar(10),
  ADD COLUMN `medicationDosage` varchar(160),
  ADD COLUMN `recentExposureDate` varchar(10),
  ADD COLUMN `hasSkinCondition` boolean,
  ADD COLUMN `skinConditionDetails` text,
  ADD COLUMN `informationAccuracyAcknowledgedAt` timestamp,
  ADD COLUMN `consentSignatureEvidenceKey` varchar(500);

ALTER TABLE `consultationRequests`
  ADD CONSTRAINT `consultationRequests_clientSubmissionId_unique` UNIQUE (`clientSubmissionId`);
