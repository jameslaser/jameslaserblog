-- Add public-home appearance settings without modifying existing clinic, patient,
-- appointment, analytics, or media records. Existing approved visuals remain the
-- application fallback until an authorized CMS user saves a managed image reference.
ALTER TABLE `clinicSettings`
  ADD COLUMN IF NOT EXISTS `homepageTheme` enum('signature','graphite','sage') NOT NULL DEFAULT 'signature',
  ADD COLUMN IF NOT EXISTS `homepageHeroImageUrl` varchar(500) NULL,
  ADD COLUMN IF NOT EXISTS `homepageSpecialistImageUrl` varchar(500) NULL,
  ADD COLUMN IF NOT EXISTS `homepageClinicImageUrl` varchar(500) NULL;
