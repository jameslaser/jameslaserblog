-- Adds additive typing-presence timestamps for the isolated website chat channel.
-- Existing chat content and clinic records remain unchanged.

ALTER TABLE `webChatConversations`
  ADD `staffTypingAt` timestamp NULL AFTER `lastVisitorReadAt`;

ALTER TABLE `webChatConversations`
  ADD `visitorTypingAt` timestamp NULL AFTER `staffTypingAt`;
