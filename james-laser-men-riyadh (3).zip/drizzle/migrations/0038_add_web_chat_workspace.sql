-- Adds an isolated public web-chat channel and protected staff reply workspace.
-- This migration is additive: it does not alter, delete, reseed, or expose existing clinic, patient, WhatsApp, or appointment records.

ALTER TABLE `publicFormSecurityEvents`
  MODIFY COLUMN `publicFormType` enum('consultation_request','enquiry','web_chat') NOT NULL;

CREATE TABLE `webChatConversations` (
  `id` int AUTO_INCREMENT NOT NULL,
  `sessionToken` varchar(64) NOT NULL,
  `webChatTemplateLanguage` enum('en','ar') NOT NULL DEFAULT 'en',
  `webChatConversationStatus` enum('open','resolved','archived') NOT NULL DEFAULT 'open',
  `unreadForStaff` int NOT NULL DEFAULT 0,
  `unreadForVisitor` int NOT NULL DEFAULT 0,
  `lastMessageAt` timestamp NOT NULL DEFAULT (now()),
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `webChatConversations_id` PRIMARY KEY(`id`),
  CONSTRAINT `webChatConversations_sessionToken_unique` UNIQUE(`sessionToken`)
);

CREATE TABLE `webChatMessages` (
  `id` int AUTO_INCREMENT NOT NULL,
  `conversationId` int NOT NULL,
  `webChatMessageDirection` enum('visitor','staff') NOT NULL,
  `webChatMessageSource` enum('manual','template','ai_draft') NOT NULL DEFAULT 'manual',
  `body` text NOT NULL,
  `staffUserId` int,
  `staffName` varchar(120),
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `webChatMessages_id` PRIMARY KEY(`id`),
  CONSTRAINT `webChatMessages_conversationId_webChatConversations_id_fk`
    FOREIGN KEY (`conversationId`) REFERENCES `webChatConversations`(`id`) ON DELETE restrict ON UPDATE no action,
  CONSTRAINT `webChatMessages_staffUserId_users_id_fk`
    FOREIGN KEY (`staffUserId`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE no action
);

CREATE TABLE `webChatTemplates` (
  `id` int AUTO_INCREMENT NOT NULL,
  `label` varchar(120) NOT NULL,
  `webChatTemplateLanguage` enum('en','ar') NOT NULL DEFAULT 'en',
  `body` text NOT NULL,
  `isActive` boolean NOT NULL DEFAULT true,
  `createdByUserId` int,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `webChatTemplates_id` PRIMARY KEY(`id`),
  CONSTRAINT `webChatTemplates_createdByUserId_users_id_fk`
    FOREIGN KEY (`createdByUserId`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE no action
);

CREATE INDEX `webChatConversations_status_lastMessage_idx`
  ON `webChatConversations` (`webChatConversationStatus`,`lastMessageAt`);
CREATE INDEX `webChatMessages_conversation_created_idx`
  ON `webChatMessages` (`conversationId`,`createdAt`);
CREATE INDEX `webChatMessages_direction_created_idx`
  ON `webChatMessages` (`webChatMessageDirection`,`createdAt`);
CREATE INDEX `webChatTemplates_active_language_idx`
  ON `webChatTemplates` (`isActive`,`webChatTemplateLanguage`);
