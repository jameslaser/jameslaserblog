-- Additive, non-destructive Google Business Profile review synchronization.
-- Existing clinic reviews remain unchanged and continue to require moderation.

CREATE TABLE `googleBusinessConnections` (
  `id` int AUTO_INCREMENT NOT NULL,
  `connectionKey` varchar(40) NOT NULL,
  `googleBusinessConnectionStatus` enum('awaiting_location','active','error','disconnected') NOT NULL,
  `encryptedRefreshToken` text NOT NULL,
  `accountResourceName` varchar(160),
  `accountName` varchar(240),
  `locationResourceName` varchar(200),
  `locationName` varchar(240),
  `lastSyncedAt` timestamp,
  `googleBusinessSyncStatus` enum('never','success','failed') NOT NULL DEFAULT 'never',
  `lastSyncError` varchar(500),
  `createdByUserId` int,
  `createdByName` varchar(120),
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `googleBusinessConnections_id` PRIMARY KEY (`id`),
  CONSTRAINT `googleBusinessConnections_connectionKey_unique` UNIQUE (`connectionKey`),
  CONSTRAINT `googleBusinessConnections_createdByUserId_users_id_fk`
    FOREIGN KEY (`createdByUserId`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE NO ACTION
);

CREATE TABLE `googleBusinessOAuthStates` (
  `id` int AUTO_INCREMENT NOT NULL,
  `stateDigest` varchar(64) NOT NULL,
  `createdByUserId` int NOT NULL,
  `createdByName` varchar(120),
  `redirectUri` varchar(500) NOT NULL,
  `expiresAt` timestamp NOT NULL,
  `consumedAt` timestamp,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `googleBusinessOAuthStates_id` PRIMARY KEY (`id`),
  CONSTRAINT `googleBusinessOAuthStates_stateDigest_unique` UNIQUE (`stateDigest`),
  CONSTRAINT `googleBusinessOAuthStates_createdByUserId_users_id_fk`
    FOREIGN KEY (`createdByUserId`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE NO ACTION
);

ALTER TABLE `reviews` ADD `reviewSource` enum('manual','google_business') NOT NULL DEFAULT 'manual';
ALTER TABLE `reviews` ADD `sourceReviewId` varchar(320);
ALTER TABLE `reviews` ADD `sourceUpdatedAt` timestamp;
ALTER TABLE `reviews` ADD `googleReplyText` text;
ALTER TABLE `reviews` ADD `googleReviewCreatedAt` timestamp;
ALTER TABLE `reviews` ADD CONSTRAINT `reviews_sourceReviewId_unique` UNIQUE (`sourceReviewId`);

CREATE INDEX `googleBusinessOAuthStates_expiry_idx`
  ON `googleBusinessOAuthStates` (`expiresAt`);
