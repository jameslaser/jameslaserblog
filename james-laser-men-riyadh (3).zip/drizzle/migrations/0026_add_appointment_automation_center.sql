-- Appointment automation centre: additive schema only. Existing appointments remain intact.
-- Legacy appointments have a NULL rollout marker and will not receive late booking confirmations.

ALTER TABLE `appointments`
  ADD COLUMN `whatsappAutomationInitializedAt` timestamp NULL,
  ADD COLUMN `whatsappAutomationVersion` int NOT NULL DEFAULT 1;

ALTER TABLE `whatsappSettings`
  ADD COLUMN `appointmentConfirmationEnabled` boolean NOT NULL DEFAULT true,
  ADD COLUMN `appointmentReminder24hEnabled` boolean NOT NULL DEFAULT true,
  ADD COLUMN `appointmentFinalReminderEnabled` boolean NOT NULL DEFAULT true,
  ADD COLUMN `appointmentRescheduleEnabled` boolean NOT NULL DEFAULT true,
  ADD COLUMN `appointmentCancellationEnabled` boolean NOT NULL DEFAULT true,
  ADD COLUMN `appointmentCompletionFollowUpEnabled` boolean NOT NULL DEFAULT false,
  ADD COLUMN `appointmentNoShowFollowUpEnabled` boolean NOT NULL DEFAULT false,
  ADD COLUMN `appointmentReminder24hHours` int NOT NULL DEFAULT 24,
  ADD COLUMN `appointmentFinalReminderHours` int NOT NULL DEFAULT 3;

ALTER TABLE `whatsappAutomationJobs`
  MODIFY COLUMN `jobType` enum('session_reminder','session_reminder_2h','retouch_invitation','retouch_date_options','retouch_time_options','retouch_request_received','retouch_confirmation','cannot_attend_acknowledgement','appointment_confirmation','appointment_reminder_24h','appointment_final_reminder','appointment_rescheduled','appointment_cancellation','appointment_completed_follow_up','appointment_no_show_follow_up') NOT NULL,
  MODIFY COLUMN `status` enum('scheduled','queued','claimed','provider_not_connected','blocked_consent','blocked_template','provider_accepted','sent','delivered','read','failed','cancelled','skipped') NOT NULL DEFAULT 'scheduled',
  ADD COLUMN `retryable` boolean NOT NULL DEFAULT true,
  ADD COLUMN `lastErrorCode` varchar(80) NULL;

ALTER TABLE `whatsappAutomationLogs`
  MODIFY COLUMN `automationType` enum('inbound_message','request_linked','reschedule_flagged','cancellation_flagged','outbound_retry','session_reminder_scheduled','retouch_reminder_scheduled','automation_claimed','automation_provider_required','attendance_confirmed','cannot_attend','retouch_interest','retouch_request_created','retouch_request_reviewed','automation_cancelled','consent_updated','manual_reminder_queued','appointment_automation_scheduled','appointment_automation_cancelled','appointment_automation_failed') NOT NULL;
