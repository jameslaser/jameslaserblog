-- Adds additive conversation-presence timestamps for the protected website chat channel.
-- Existing conversation and message records remain unchanged.

ALTER TABLE `webChatConversations`
  ADD `lastStaffReadAt` timestamp NULL AFTER `unreadForVisitor`;

ALTER TABLE `webChatConversations`
  ADD `lastVisitorReadAt` timestamp NULL AFTER `lastStaffReadAt`;
