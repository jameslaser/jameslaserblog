-- Additive privacy-notice and health-screening evidence for public appointment requests.
-- Existing requests are preserved. Their new fields receive safe defaults or remain null.

ALTER TABLE `consultationRequests` ADD `privacyNoticeVersion` varchar(120) NOT NULL DEFAULT 'privacy-notice-v1-2026-09-19';
ALTER TABLE `consultationRequests` ADD `healthScreeningConsent` boolean NOT NULL DEFAULT false;
ALTER TABLE `consultationRequests` ADD `healthScreeningConsentAt` timestamp;
