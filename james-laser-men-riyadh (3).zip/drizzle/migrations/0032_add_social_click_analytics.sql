-- Add a privacy-conscious, aggregate-only event type for configured social profile clicks.
-- This is an additive enum change. It does not alter, delete, reseed, or expose existing analytics or clinic records.
ALTER TABLE `analyticsEvents`
  MODIFY COLUMN `analyticsEventType` enum(
    'page_view',
    'whatsapp_click',
    'appointment_click',
    'appointment_form_start',
    'appointment_form_submit',
    'treatment_view',
    'guide_view',
    'social_click'
  ) NOT NULL;
