-- Provider-ready WhatsApp automation. This migration creates local queue and audit
-- structures only; it does not configure Meta credentials, activate a scheduler,
-- submit a message, or change any existing appointment status.

ALTER TABLE `appointments`
  ADD COLUMN `whatsappConsentStatus` enum('unknown','opted_in','opted_out') NOT NULL DEFAULT 'unknown',
  ADD COLUMN `whatsappConsentSource` varchar(160) NULL,
  ADD COLUMN `whatsappConsentAt` timestamp NULL,
  ADD COLUMN `whatsappConsentVersion` varchar(120) NULL,
  ADD COLUMN `whatsappOptedOutAt` timestamp NULL,
  ADD COLUMN `whatsappAttendanceConfirmation` enum('awaiting_response','confirmed','cannot_attend') NOT NULL DEFAULT 'awaiting_response',
  ADD COLUMN `whatsappAttendanceConfirmedAt` timestamp NULL,
  ADD COLUMN `whatsappCannotAttendAt` timestamp NULL;

ALTER TABLE `patients`
  ADD COLUMN `whatsappConsentStatus` enum('unknown','opted_in','opted_out') NOT NULL DEFAULT 'unknown',
  ADD COLUMN `whatsappConsentSource` varchar(160) NULL,
  ADD COLUMN `whatsappConsentAt` timestamp NULL,
  ADD COLUMN `whatsappConsentVersion` varchar(120) NULL,
  ADD COLUMN `whatsappOptedOutAt` timestamp NULL;

ALTER TABLE `whatsappSettings`
  ADD COLUMN `automationEnabled` boolean NOT NULL DEFAULT false,
  ADD COLUMN `reminderSendingTime` varchar(5) NOT NULL DEFAULT '10:00',
  ADD COLUMN `retouchPreparationEn` text NULL,
  ADD COLUMN `retouchPreparationAr` text NULL,
  ADD COLUMN `schedulerTaskUid` varchar(65) NULL,
  ADD COLUMN `schedulerVerifiedAt` timestamp NULL,
  ADD COLUMN `consentWorkflowVerifiedAt` timestamp NULL,
  ADD COLUMN `providerFlowVerifiedAt` timestamp NULL;

ALTER TABLE `whatsappMessages`
  MODIFY COLUMN `messageType` enum('text','image','document','audio','template','interactive','status','unsupported') NOT NULL;

ALTER TABLE `whatsappAutomationLogs`
  MODIFY COLUMN `automationType` enum('inbound_message','request_linked','reschedule_flagged','cancellation_flagged','outbound_retry','session_reminder_scheduled','retouch_reminder_scheduled','automation_claimed','automation_provider_required','attendance_confirmed','cannot_attend','retouch_interest','retouch_request_created','retouch_request_reviewed','automation_cancelled','consent_updated','manual_reminder_queued') NOT NULL;

CREATE TABLE `whatsappAutomationJobs` (
  `id` int AUTO_INCREMENT NOT NULL,
  `appointmentId` int NOT NULL,
  `conversationId` int NULL,
  `retouchRequestId` int NULL,
  `jobType` enum('session_reminder','retouch_invitation','retouch_date_options','retouch_time_options','retouch_request_received','retouch_confirmation','cannot_attend_acknowledgement') NOT NULL,
  `scheduleKey` varchar(180) NOT NULL,
  `scheduledFor` timestamp NOT NULL,
  `status` enum('scheduled','queued','claimed','provider_not_connected','blocked_consent','blocked_template','provider_accepted','sent','failed','cancelled','skipped') NOT NULL DEFAULT 'scheduled',
  `language` enum('en','ar','unknown') NOT NULL DEFAULT 'unknown',
  `templateKey` varchar(80) NOT NULL,
  `providerMessageId` varchar(255) NULL,
  `claimToken` varchar(96) NULL,
  `claimedAt` timestamp NULL,
  `queuedAt` timestamp NULL,
  `providerAcceptedAt` timestamp NULL,
  `sentAt` timestamp NULL,
  `failedAt` timestamp NULL,
  `cancelledAt` timestamp NULL,
  `cancelledReason` varchar(500) NULL,
  `manualReason` varchar(500) NULL,
  `attemptCount` int NOT NULL DEFAULT 0,
  `lastError` varchar(1000) NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `whatsappAutomationJobs_id` PRIMARY KEY (`id`),
  CONSTRAINT `whatsappAutomationJobs_scheduleKey_unique` UNIQUE (`scheduleKey`),
  CONSTRAINT `whatsappAutomationJobs_providerMessageId_unique` UNIQUE (`providerMessageId`),
  CONSTRAINT `whatsappAutomationJobs_appointment_type_schedule_idx` UNIQUE (`appointmentId`,`jobType`,`scheduledFor`),
  CONSTRAINT `whatsappAutomationJobs_appointmentId_appointments_id_fk` FOREIGN KEY (`appointmentId`) REFERENCES `appointments`(`id`) ON DELETE RESTRICT,
  CONSTRAINT `whatsappAutomationJobs_conversationId_whatsappConversations_id_fk` FOREIGN KEY (`conversationId`) REFERENCES `whatsappConversations`(`id`) ON DELETE RESTRICT
);

CREATE TABLE `whatsappRetouchRequests` (
  `id` int AUTO_INCREMENT NOT NULL,
  `originalSessionAppointmentId` int NOT NULL,
  `patientId` int NULL,
  `appointmentId` int NULL,
  `patientName` varchar(120) NOT NULL,
  `mrn` varchar(64) NULL,
  `whatsapp` varchar(32) NOT NULL,
  `treatmentAreas` text NULL,
  `originalSessionDate` varchar(10) NOT NULL,
  `eligibleStartDate` varchar(10) NOT NULL,
  `eligibleEndDate` varchar(10) NOT NULL,
  `preferredDate` varchar(10) NULL,
  `preferredTime` varchar(16) NULL,
  `suggestedDate` varchar(10) NULL,
  `suggestedTime` varchar(16) NULL,
  `status` enum('awaiting_patient_preference','awaiting_patient_time','awaiting_clinic_confirmation','confirmed','alternative_time_suggested','declined','patient_declined') NOT NULL DEFAULT 'awaiting_clinic_confirmation',
  `patientRespondedAt` timestamp NULL,
  `reviewedAt` timestamp NULL,
  `reviewedByUserId` int NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `whatsappRetouchRequests_id` PRIMARY KEY (`id`),
  CONSTRAINT `whatsappRetouchRequests_originalSessionAppointmentId_unique` UNIQUE (`originalSessionAppointmentId`),
  CONSTRAINT `whatsappRetouchRequests_originalSessionAppointmentId_appointments_id_fk` FOREIGN KEY (`originalSessionAppointmentId`) REFERENCES `appointments`(`id`) ON DELETE RESTRICT,
  CONSTRAINT `whatsappRetouchRequests_patientId_patients_id_fk` FOREIGN KEY (`patientId`) REFERENCES `patients`(`id`) ON DELETE RESTRICT,
  CONSTRAINT `whatsappRetouchRequests_appointmentId_appointments_id_fk` FOREIGN KEY (`appointmentId`) REFERENCES `appointments`(`id`) ON DELETE RESTRICT,
  CONSTRAINT `whatsappRetouchRequests_reviewedByUserId_users_id_fk` FOREIGN KEY (`reviewedByUserId`) REFERENCES `users`(`id`) ON DELETE RESTRICT
);

CREATE TABLE `whatsappAutomationTemplateDefinitions` (
  `id` int AUTO_INCREMENT NOT NULL,
  `templateKey` varchar(80) NOT NULL,
  `language` enum('en','ar','unknown') NOT NULL,
  `suggestedName` varchar(512) NOT NULL,
  `category` varchar(80) NOT NULL DEFAULT 'utility',
  `bodyPreview` text NOT NULL,
  `interactiveLabels` text NULL,
  `providerTemplateName` varchar(512) NULL,
  `providerTemplateId` varchar(128) NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `whatsappAutomationTemplateDefinitions_id` PRIMARY KEY (`id`),
  CONSTRAINT `whatsappAutomationTemplateDefinitions_key_language_idx` UNIQUE (`templateKey`,`language`)
);
