-- Built-in database reconciliation for the approved WhatsApp workspace.
-- Additive only: preserves all existing clinic, patient, appointment, consent,
-- settings, and audit records. No DROP, DELETE, TRUNCATE, UPDATE, or reseed.
-- This bridge supplies the MySQL/TiDB equivalents of the original provider
-- workspace tables, which were previously available only in retired PostgreSQL
-- migration history. It intentionally does not configure Meta or enable sending.

ALTER TABLE `appointments`
  ADD COLUMN IF NOT EXISTS `whatsappConsentStatus` enum('unknown','opted_in','opted_out') NOT NULL DEFAULT 'unknown',
  ADD COLUMN IF NOT EXISTS `whatsappConsentSource` varchar(160) NULL,
  ADD COLUMN IF NOT EXISTS `whatsappConsentAt` timestamp NULL,
  ADD COLUMN IF NOT EXISTS `whatsappConsentVersion` varchar(120) NULL,
  ADD COLUMN IF NOT EXISTS `whatsappOptedOutAt` timestamp NULL,
  ADD COLUMN IF NOT EXISTS `whatsappAttendanceConfirmation` enum('awaiting_response','confirmed','cannot_attend') NOT NULL DEFAULT 'awaiting_response',
  ADD COLUMN IF NOT EXISTS `whatsappAttendanceConfirmedAt` timestamp NULL,
  ADD COLUMN IF NOT EXISTS `whatsappCannotAttendAt` timestamp NULL,
  ADD COLUMN IF NOT EXISTS `whatsappAutomationInitializedAt` timestamp NULL,
  ADD COLUMN IF NOT EXISTS `whatsappAutomationVersion` int NOT NULL DEFAULT 1;

ALTER TABLE `patients`
  ADD COLUMN IF NOT EXISTS `whatsappConsentStatus` enum('unknown','opted_in','opted_out') NOT NULL DEFAULT 'unknown',
  ADD COLUMN IF NOT EXISTS `whatsappConsentSource` varchar(160) NULL,
  ADD COLUMN IF NOT EXISTS `whatsappConsentAt` timestamp NULL,
  ADD COLUMN IF NOT EXISTS `whatsappConsentVersion` varchar(120) NULL,
  ADD COLUMN IF NOT EXISTS `whatsappOptedOutAt` timestamp NULL;

CREATE TABLE IF NOT EXISTS `whatsappContacts` (
  `id` int AUTO_INCREMENT NOT NULL,
  `waId` varchar(32) NOT NULL,
  `phoneNumber` varchar(32) NOT NULL,
  `normalizedPhone` varchar(20) NULL,
  `displayName` varchar(120) NULL,
  `profileName` varchar(120) NULL,
  `whatsappContactLanguage` enum('en','ar','unknown') NOT NULL DEFAULT 'unknown',
  `patientRequestId` int NULL,
  `patientId` int NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `whatsappContacts_id` PRIMARY KEY (`id`),
  CONSTRAINT `whatsappContacts_waId_unique` UNIQUE (`waId`),
  CONSTRAINT `whatsappContacts_normalizedPhone_unique` UNIQUE (`normalizedPhone`),
  CONSTRAINT `whatsappContacts_patientRequestId_consultationRequests_id_fk` FOREIGN KEY (`patientRequestId`) REFERENCES `consultationRequests`(`id`) ON DELETE RESTRICT,
  CONSTRAINT `whatsappContacts_patientId_patients_id_fk` FOREIGN KEY (`patientId`) REFERENCES `patients`(`id`) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS `whatsappConversations` (
  `id` int AUTO_INCREMENT NOT NULL,
  `contactId` int NOT NULL,
  `whatsappConversationStatus` enum('open','pending','resolved','archived') NOT NULL DEFAULT 'open',
  `assignedUserId` int NULL,
  `linkedRequestId` int NULL,
  `linkedPatientId` int NULL,
  `linkedAppointmentId` int NULL,
  `serviceWindowOpenedAt` timestamp NULL,
  `serviceWindowExpiresAt` timestamp NULL,
  `lastInboundAt` timestamp NULL,
  `lastOutboundAt` timestamp NULL,
  `lastMessageAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `unreadCount` int NOT NULL DEFAULT 0,
  `rescheduleRequestedAt` timestamp NULL,
  `cancellationRequestedAt` timestamp NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `whatsappConversations_id` PRIMARY KEY (`id`),
  CONSTRAINT `whatsappConversations_contactId_unique` UNIQUE (`contactId`),
  CONSTRAINT `whatsappConversations_contactId_whatsappContacts_id_fk` FOREIGN KEY (`contactId`) REFERENCES `whatsappContacts`(`id`) ON DELETE RESTRICT,
  CONSTRAINT `whatsappConversations_assignedUserId_users_id_fk` FOREIGN KEY (`assignedUserId`) REFERENCES `users`(`id`) ON DELETE RESTRICT,
  CONSTRAINT `whatsappConversations_linkedRequestId_consultationRequests_id_fk` FOREIGN KEY (`linkedRequestId`) REFERENCES `consultationRequests`(`id`) ON DELETE RESTRICT,
  CONSTRAINT `whatsappConversations_linkedPatientId_patients_id_fk` FOREIGN KEY (`linkedPatientId`) REFERENCES `patients`(`id`) ON DELETE RESTRICT,
  CONSTRAINT `whatsappConversations_linkedAppointmentId_appointments_id_fk` FOREIGN KEY (`linkedAppointmentId`) REFERENCES `appointments`(`id`) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS `whatsappMessages` (
  `id` int AUTO_INCREMENT NOT NULL,
  `conversationId` int NOT NULL,
  `metaMessageId` varchar(255) NULL,
  `whatsappMessageDirection` enum('inbound','outbound','system') NOT NULL,
  `whatsappMessageType` enum('text','image','document','audio','template','interactive','status','unsupported') NOT NULL,
  `body` text NULL,
  `mediaId` varchar(255) NULL,
  `mediaStorageKey` varchar(500) NULL,
  `mediaMimeType` varchar(120) NULL,
  `templateName` varchar(512) NULL,
  `templateLanguage` varchar(32) NULL,
  `whatsappMessageStatus` enum('received','sending','sent','delivered','read','failed') NOT NULL DEFAULT 'received',
  `errorCode` varchar(80) NULL,
  `errorMessage` varchar(1000) NULL,
  `replyToMetaMessageId` varchar(255) NULL,
  `sentAt` timestamp NULL,
  `deliveredAt` timestamp NULL,
  `readAt` timestamp NULL,
  `failedAt` timestamp NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `whatsappMessages_id` PRIMARY KEY (`id`),
  CONSTRAINT `whatsappMessages_metaMessageId_unique` UNIQUE (`metaMessageId`),
  CONSTRAINT `whatsappMessages_conversationId_whatsappConversations_id_fk` FOREIGN KEY (`conversationId`) REFERENCES `whatsappConversations`(`id`) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS `whatsappTemplates` (
  `id` int AUTO_INCREMENT NOT NULL,
  `businessAccountId` varchar(64) NOT NULL,
  `templateName` varchar(512) NOT NULL,
  `language` varchar(32) NOT NULL,
  `category` varchar(80) NULL,
  `whatsappTemplateStatus` enum('approved','pending','rejected','paused','disabled','unknown') NOT NULL DEFAULT 'unknown',
  `bodyPreview` text NULL,
  `variables` text NULL,
  `metaTemplateId` varchar(128) NULL,
  `lastSyncedAt` timestamp NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `whatsappTemplates_id` PRIMARY KEY (`id`),
  CONSTRAINT `whatsappTemplates_business_name_language_idx` UNIQUE (`businessAccountId`,`templateName`,`language`)
);

CREATE TABLE IF NOT EXISTS `whatsappWebhookEvents` (
  `id` int AUTO_INCREMENT NOT NULL,
  `eventFingerprint` varchar(128) NOT NULL,
  `metaEventId` varchar(255) NULL,
  `eventType` varchar(120) NOT NULL,
  `payloadSummary` varchar(1000) NULL,
  `whatsappWebhookProcessingStatus` enum('received','processing','processed','ignored','failed') NOT NULL DEFAULT 'received',
  `processingStartedAt` timestamp NULL,
  `processedAt` timestamp NULL,
  `errorMessage` varchar(1000) NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `whatsappWebhookEvents_id` PRIMARY KEY (`id`),
  CONSTRAINT `whatsappWebhookEvents_eventFingerprint_unique` UNIQUE (`eventFingerprint`)
);

CREATE TABLE IF NOT EXISTS `whatsappAutomationLogs` (
  `id` int AUTO_INCREMENT NOT NULL,
  `conversationId` int NULL,
  `messageId` int NULL,
  `actorUserId` int NULL,
  `whatsappAutomationType` enum('inbound_message','request_linked','reschedule_flagged','cancellation_flagged','outbound_retry','session_reminder_scheduled','retouch_reminder_scheduled','automation_claimed','automation_provider_required','attendance_confirmed','cannot_attend','retouch_interest','retouch_request_created','retouch_request_reviewed','automation_cancelled','consent_updated','manual_reminder_queued','appointment_automation_scheduled','appointment_automation_cancelled','appointment_automation_failed') NOT NULL,
  `outcome` varchar(120) NOT NULL,
  `details` varchar(1000) NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `whatsappAutomationLogs_id` PRIMARY KEY (`id`),
  CONSTRAINT `wa_log_conversation_fk` FOREIGN KEY (`conversationId`) REFERENCES `whatsappConversations`(`id`) ON DELETE RESTRICT,
  CONSTRAINT `wa_log_message_fk` FOREIGN KEY (`messageId`) REFERENCES `whatsappMessages`(`id`) ON DELETE RESTRICT,
  CONSTRAINT `wa_log_actor_fk` FOREIGN KEY (`actorUserId`) REFERENCES `users`(`id`) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS `whatsappAutomationJobs` (
  `id` int AUTO_INCREMENT NOT NULL,
  `appointmentId` int NOT NULL,
  `conversationId` int NULL,
  `retouchRequestId` int NULL,
  `whatsappAutomationJobType` enum('session_reminder','session_reminder_2h','retouch_invitation','retouch_date_options','retouch_time_options','retouch_request_received','retouch_confirmation','cannot_attend_acknowledgement','appointment_confirmation','appointment_reminder_24h','appointment_final_reminder','appointment_rescheduled','appointment_cancellation','appointment_completed_follow_up','appointment_no_show_follow_up') NOT NULL,
  `scheduleKey` varchar(180) NOT NULL,
  `scheduledFor` timestamp NOT NULL,
  `whatsappAutomationJobStatus` enum('scheduled','queued','claimed','provider_not_connected','blocked_consent','blocked_template','provider_accepted','sent','delivered','read','failed','cancelled','skipped') NOT NULL DEFAULT 'scheduled',
  `whatsappContactLanguage` enum('en','ar','unknown') NOT NULL DEFAULT 'unknown',
  `templateKey` varchar(80) NOT NULL,
  `providerMessageId` varchar(255) NULL,
  `claimToken` varchar(96) NULL,
  `claimedAt` timestamp NULL,
  `queuedAt` timestamp NULL,
  `providerAcceptedAt` timestamp NULL,
  `sentAt` timestamp NULL,
  `failedAt` timestamp NULL,
  `cancelledAt` timestamp NULL,
  `cancelledReason` varchar(500) NULL,
  `manualReason` varchar(500) NULL,
  `attemptCount` int NOT NULL DEFAULT 0,
  `retryable` boolean NOT NULL DEFAULT true,
  `lastErrorCode` varchar(80) NULL,
  `lastErrorHttpStatus` int NULL,
  `lastProviderErrorType` varchar(160) NULL,
  `lastError` varchar(1000) NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `whatsappAutomationJobs_id` PRIMARY KEY (`id`),
  CONSTRAINT `whatsappAutomationJobs_scheduleKey_unique` UNIQUE (`scheduleKey`),
  CONSTRAINT `whatsappAutomationJobs_providerMessageId_unique` UNIQUE (`providerMessageId`),
  CONSTRAINT `whatsappAutomationJobs_appointment_type_schedule_idx` UNIQUE (`appointmentId`,`whatsappAutomationJobType`,`scheduledFor`),
  CONSTRAINT `wa_job_appointment_fk` FOREIGN KEY (`appointmentId`) REFERENCES `appointments`(`id`) ON DELETE RESTRICT,
  CONSTRAINT `wa_job_conversation_fk` FOREIGN KEY (`conversationId`) REFERENCES `whatsappConversations`(`id`) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS `whatsappRetouchRequests` (
  `id` int AUTO_INCREMENT NOT NULL,
  `originalSessionAppointmentId` int NOT NULL,
  `patientId` int NULL,
  `appointmentId` int NULL,
  `patientName` varchar(120) NOT NULL,
  `mrn` varchar(64) NULL,
  `whatsapp` varchar(32) NOT NULL,
  `treatmentAreas` text NULL,
  `originalSessionDate` varchar(10) NOT NULL,
  `eligibleStartDate` varchar(10) NOT NULL,
  `eligibleEndDate` varchar(10) NOT NULL,
  `preferredDate` varchar(10) NULL,
  `preferredTime` varchar(16) NULL,
  `suggestedDate` varchar(10) NULL,
  `suggestedTime` varchar(16) NULL,
  `whatsappRetouchRequestStatus` enum('awaiting_patient_preference','awaiting_patient_time','awaiting_clinic_confirmation','confirmed','alternative_time_suggested','declined','patient_declined') NOT NULL DEFAULT 'awaiting_clinic_confirmation',
  `patientRespondedAt` timestamp NULL,
  `reviewedAt` timestamp NULL,
  `reviewedByUserId` int NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `whatsappRetouchRequests_id` PRIMARY KEY (`id`),
  CONSTRAINT `whatsappRetouchRequests_originalSessionAppointmentId_unique` UNIQUE (`originalSessionAppointmentId`),
  CONSTRAINT `wa_retouch_original_fk` FOREIGN KEY (`originalSessionAppointmentId`) REFERENCES `appointments`(`id`) ON DELETE RESTRICT,
  CONSTRAINT `wa_retouch_patient_fk` FOREIGN KEY (`patientId`) REFERENCES `patients`(`id`) ON DELETE RESTRICT,
  CONSTRAINT `wa_retouch_appointment_fk` FOREIGN KEY (`appointmentId`) REFERENCES `appointments`(`id`) ON DELETE RESTRICT,
  CONSTRAINT `wa_retouch_reviewer_fk` FOREIGN KEY (`reviewedByUserId`) REFERENCES `users`(`id`) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS `whatsappAutomationTemplateDefinitions` (
  `id` int AUTO_INCREMENT NOT NULL,
  `templateKey` varchar(80) NOT NULL,
  `whatsappContactLanguage` enum('en','ar','unknown') NOT NULL,
  `suggestedName` varchar(512) NOT NULL,
  `category` varchar(80) NOT NULL DEFAULT 'utility',
  `bodyPreview` text NOT NULL,
  `interactiveLabels` text NULL,
  `providerTemplateName` varchar(512) NULL,
  `providerTemplateId` varchar(128) NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `whatsappAutomationTemplateDefinitions_id` PRIMARY KEY (`id`),
  CONSTRAINT `whatsappAutomationTemplateDefinitions_key_language_idx` UNIQUE (`templateKey`,`whatsappContactLanguage`)
);

CREATE TABLE IF NOT EXISTS `whatsappActivationPrerequisites` (
  `id` int AUTO_INCREMENT NOT NULL,
  `prerequisiteKey` varchar(80) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `evidenceReference` varchar(500) NULL,
  `verifiedAt` timestamp NULL,
  `verifiedByUserId` int NULL,
  `verifiedByName` varchar(120) NULL,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `whatsappActivationPrerequisites_id` PRIMARY KEY (`id`),
  CONSTRAINT `whatsappActivationPrerequisites_prerequisiteKey_unique` UNIQUE (`prerequisiteKey`),
  CONSTRAINT `whatsappActivationPrerequisites_verifiedByUserId_users_id_fk` FOREIGN KEY (`verifiedByUserId`) REFERENCES `users`(`id`) ON DELETE RESTRICT
);
