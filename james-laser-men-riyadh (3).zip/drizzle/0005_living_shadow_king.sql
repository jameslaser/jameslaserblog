ALTER TABLE `appointments` ADD `appointmentVisitType` enum('session','retouch') DEFAULT 'session' NOT NULL;--> statement-breakpoint
ALTER TABLE `patients` ADD `mrn` varchar(64);--> statement-breakpoint
ALTER TABLE `patients` ADD CONSTRAINT `patients_mrn_unique` UNIQUE(`mrn`);