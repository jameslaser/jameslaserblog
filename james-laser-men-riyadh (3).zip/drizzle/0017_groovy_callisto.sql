CREATE TABLE `hmsImportBatches` (
	`id` int AUTO_INCREMENT NOT NULL,
	`source` varchar(40) NOT NULL DEFAULT 'hms_csv',
	`originalFileName` varchar(255) NOT NULL,
	`fileSha256` varchar(128) NOT NULL,
	`sourceFileKey` varchar(500) NOT NULL,
	`providerCode` enum('NR011') NOT NULL,
	`providerLabel` varchar(120) NOT NULL,
	`rowCount` int NOT NULL,
	`importedCount` int NOT NULL DEFAULT 0,
	`skippedDuplicateCount` int NOT NULL DEFAULT 0,
	`warningCount` int NOT NULL DEFAULT 0,
	`errorCount` int NOT NULL DEFAULT 0,
	`importedByUserId` int NOT NULL,
	`importedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `hmsImportBatches_id` PRIMARY KEY(`id`),
	CONSTRAINT `hmsImportBatches_fileSha256_unique` UNIQUE(`fileSha256`)
);
--> statement-breakpoint
ALTER TABLE `appointments` MODIFY COLUMN `consultationRequestId` int;--> statement-breakpoint
ALTER TABLE `appointments` MODIFY COLUMN `whatsapp` varchar(32);--> statement-breakpoint
ALTER TABLE `appointments` MODIFY COLUMN `treatmentArea` varchar(120);--> statement-breakpoint
ALTER TABLE `appointments` MODIFY COLUMN `machine` enum('DEKA AGAIN','CLARITY 2','GENTLE PROMAX','DUETTO MACHINE');--> statement-breakpoint
ALTER TABLE `appointments` MODIFY COLUMN `appointmentVisitType` enum('session','retouch','unknown') NOT NULL DEFAULT 'unknown';--> statement-breakpoint
ALTER TABLE `appointments` ADD `appointmentEndTime` varchar(160);--> statement-breakpoint
ALTER TABLE `appointments` ADD `source` varchar(40) DEFAULT 'website_transfer' NOT NULL;--> statement-breakpoint
ALTER TABLE `appointments` ADD `sourceRowNumber` int;--> statement-breakpoint
ALTER TABLE `appointments` ADD `importBatchId` int;--> statement-breakpoint
ALTER TABLE `appointments` ADD `importFingerprint` varchar(128);--> statement-breakpoint
ALTER TABLE `appointments` ADD `originalAppointmentDate` varchar(32);--> statement-breakpoint
ALTER TABLE `appointments` ADD `originalAppointmentStartTime` varchar(32);--> statement-breakpoint
ALTER TABLE `appointments` ADD `originalAppointmentEndTime` varchar(32);--> statement-breakpoint
ALTER TABLE `appointments` ADD `originalTelephone` varchar(80);--> statement-breakpoint
ALTER TABLE `appointments` ADD `originalSex` varchar(32);--> statement-breakpoint
ALTER TABLE `appointments` ADD `normalizedSex` varchar(32);--> statement-breakpoint
ALTER TABLE `appointments` ADD `originalAge` varchar(32);--> statement-breakpoint
ALTER TABLE `appointments` ADD `normalizedAge` int;--> statement-breakpoint
ALTER TABLE `appointments` ADD `nationality` varchar(80);--> statement-breakpoint
ALTER TABLE `appointments` ADD `remarks` text;--> statement-breakpoint
ALTER TABLE `appointments` ADD `originalRowData` text;--> statement-breakpoint
ALTER TABLE `appointments` ADD CONSTRAINT `appointments_importFingerprint_unique` UNIQUE(`importFingerprint`);