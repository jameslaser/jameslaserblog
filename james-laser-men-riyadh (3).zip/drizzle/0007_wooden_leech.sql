CREATE TABLE `activityLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`actorName` varchar(120),
	`actorUserId` int,
	`action` varchar(180) NOT NULL,
	`subjectType` varchar(80),
	`subjectId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `activityLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `clinicSettings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`businessName` varchar(180) NOT NULL,
	`specialistName` varchar(120) NOT NULL,
	`professionalTitle` varchar(160),
	`clinicName` varchar(180) NOT NULL,
	`addressEn` text,
	`addressAr` text,
	`mapsUrl` varchar(500),
	`whatsapp` varchar(32) NOT NULL,
	`telephone` varchar(32),
	`email` varchar(320),
	`workingHours` varchar(160) NOT NULL,
	`instagramUrl` varchar(500),
	`tiktokUrl` varchar(500),
	`snapchatUrl` varchar(500),
	`facebookUrl` varchar(500),
	`youtubeUrl` varchar(500),
	`xUrl` varchar(500),
	`googleBusinessUrl` varchar(500),
	`appointmentFormEnabled` boolean NOT NULL DEFAULT true,
	`preferredTimes` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `clinicSettings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `faqs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`questionEn` text NOT NULL,
	`answerEn` text NOT NULL,
	`questionAr` text,
	`answerAr` text,
	`category` varchar(120),
	`isFeatured` boolean NOT NULL DEFAULT false,
	`isActive` boolean NOT NULL DEFAULT false,
	`displayOrder` int NOT NULL DEFAULT 0,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `faqs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `guidePosts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(180) NOT NULL,
	`guidePostType` enum('blog','video') NOT NULL DEFAULT 'blog',
	`titleEn` varchar(220) NOT NULL,
	`titleAr` varchar(220),
	`summaryEn` text,
	`summaryAr` text,
	`contentEn` text,
	`contentAr` text,
	`category` varchar(120),
	`tags` text,
	`featuredImageUrl` varchar(500),
	`videoUrl` varchar(500),
	`seoTitle` varchar(180),
	`metaDescription` varchar(320),
	`canonicalUrl` varchar(500),
	`socialImageUrl` varchar(500),
	`guidePostStatus` enum('draft','published') NOT NULL DEFAULT 'draft',
	`isFeatured` boolean NOT NULL DEFAULT false,
	`publishedAt` timestamp,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `guidePosts_id` PRIMARY KEY(`id`),
	CONSTRAINT `guidePosts_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `homepageSections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sectionKey` varchar(80) NOT NULL,
	`titleEn` text,
	`subtitleEn` text,
	`descriptionEn` text,
	`titleAr` text,
	`subtitleAr` text,
	`descriptionAr` text,
	`ctaText` varchar(120),
	`ctaLink` varchar(500),
	`imageUrl` varchar(500),
	`videoUrl` varchar(500),
	`isVisible` boolean NOT NULL DEFAULT true,
	`displayOrder` int NOT NULL DEFAULT 0,
	`homepageSectionStatus` enum('draft','published') NOT NULL DEFAULT 'draft',
	`publishedAt` timestamp,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `homepageSections_id` PRIMARY KEY(`id`),
	CONSTRAINT `homepageSections_sectionKey_unique` UNIQUE(`sectionKey`)
);
--> statement-breakpoint
CREATE TABLE `mediaItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`storageKey` varchar(500) NOT NULL,
	`url` varchar(500) NOT NULL,
	`mimeType` varchar(120) NOT NULL,
	`altEn` varchar(320),
	`altAr` varchar(320),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `mediaItems_id` PRIMARY KEY(`id`),
	CONSTRAINT `mediaItems_storageKey_unique` UNIQUE(`storageKey`)
);
--> statement-breakpoint
CREATE TABLE `policies` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(120) NOT NULL,
	`titleEn` varchar(180) NOT NULL,
	`titleAr` varchar(180),
	`contentEn` text,
	`contentAr` text,
	`policyStatus` enum('draft','published') NOT NULL DEFAULT 'draft',
	`publishedAt` timestamp,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `policies_id` PRIMARY KEY(`id`),
	CONSTRAINT `policies_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `promotions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(160) NOT NULL,
	`name` varchar(180) NOT NULL,
	`titleEn` varchar(180) NOT NULL,
	`titleAr` varchar(180),
	`descriptionEn` text,
	`descriptionAr` text,
	`originalPrice` decimal(10,2),
	`promotionalPrice` decimal(10,2),
	`includedTreatments` text,
	`sessionCount` int,
	`retouchIncluded` boolean NOT NULL DEFAULT false,
	`startsAt` timestamp,
	`endsAt` timestamp,
	`imageUrl` varchar(500),
	`termsEn` text,
	`termsAr` text,
	`isFeatured` boolean NOT NULL DEFAULT false,
	`promotionStatus` enum('draft','published','paused','archived') NOT NULL DEFAULT 'draft',
	`displayOrder` int NOT NULL DEFAULT 0,
	`publishedAt` timestamp,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `promotions_id` PRIMARY KEY(`id`),
	CONSTRAINT `promotions_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `resultCases` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(180) NOT NULL,
	`treatmentArea` varchar(160) NOT NULL,
	`beforeImageUrl` varchar(500) NOT NULL,
	`afterImageUrl` varchar(500) NOT NULL,
	`additionalImages` text,
	`sessionCount` int,
	`descriptionEn` text,
	`descriptionAr` text,
	`disclaimerEn` text,
	`disclaimerAr` text,
	`isFeatured` boolean NOT NULL DEFAULT false,
	`isActive` boolean NOT NULL DEFAULT false,
	`displayOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `resultCases_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `reviews` (
	`id` int AUTO_INCREMENT NOT NULL,
	`displayName` varchar(120) NOT NULL,
	`rating` int NOT NULL,
	`reviewText` text NOT NULL,
	`treatment` varchar(160),
	`reviewLanguage` enum('en','ar') NOT NULL DEFAULT 'en',
	`isAnonymous` boolean NOT NULL DEFAULT false,
	`isFeatured` boolean NOT NULL DEFAULT false,
	`reviewStatus` enum('pending','approved','rejected','hidden') NOT NULL DEFAULT 'pending',
	`reviewedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `reviews_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `seoSettings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`seoLocale` enum('en','ar-SA') NOT NULL,
	`title` varchar(180) NOT NULL,
	`metaDescription` varchar(320) NOT NULL,
	`canonicalUrl` varchar(500),
	`openGraphTitle` varchar(180),
	`openGraphDescription` varchar(320),
	`openGraphImageUrl` varchar(500),
	`robotsIndex` boolean NOT NULL DEFAULT true,
	`structuredData` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `seoSettings_id` PRIMARY KEY(`id`),
	CONSTRAINT `seoSettings_seoLocale_unique` UNIQUE(`seoLocale`)
);
--> statement-breakpoint
CREATE TABLE `treatments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(160) NOT NULL,
	`nameEn` varchar(160) NOT NULL,
	`nameAr` varchar(160),
	`shortDescriptionEn` text,
	`shortDescriptionAr` text,
	`descriptionEn` text,
	`descriptionAr` text,
	`imageUrl` varchar(500),
	`startingPrice` decimal(10,2),
	`regularPrice` decimal(10,2),
	`promotionalPrice` decimal(10,2),
	`durationMinutes` int,
	`preparationEn` text,
	`preparationAr` text,
	`aftercareEn` text,
	`aftercareAr` text,
	`seoTitle` varchar(180),
	`seoDescription` varchar(320),
	`isActive` boolean NOT NULL DEFAULT false,
	`isFeatured` boolean NOT NULL DEFAULT false,
	`displayOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `treatments_id` PRIMARY KEY(`id`),
	CONSTRAINT `treatments_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('owner','admin','content_editor','reception','user') NOT NULL DEFAULT 'user';