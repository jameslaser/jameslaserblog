ALTER TABLE `appointments` ADD `mrn` varchar(64);--> statement-breakpoint
ALTER TABLE `appointments` ADD `treatmentAreas` text;--> statement-breakpoint
ALTER TABLE `appointments` ADD `internalNotes` text;--> statement-breakpoint
ALTER TABLE `appointments` ADD `assignedStaff` varchar(120);--> statement-breakpoint
ALTER TABLE `appointments` ADD `durationMinutes` int;--> statement-breakpoint
ALTER TABLE `appointments` ADD `originalConsentSetReference` varchar(180);--> statement-breakpoint
ALTER TABLE `appointments` ADD `originalConsentAcknowledgedAt` timestamp;--> statement-breakpoint
ALTER TABLE `appointments` ADD `appointmentOriginalConsentLanguage` enum('en','ar');--> statement-breakpoint
ALTER TABLE `appointments` ADD `appointmentConsentSignatureStatus` enum('required','received') DEFAULT 'required' NOT NULL;--> statement-breakpoint
ALTER TABLE `appointments` ADD `consentSignatureReference` varchar(500);--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `finalizedFullName` varchar(120);--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `finalizedWhatsapp` varchar(32);--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `finalizedNationality` varchar(80);--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `finalizedMrn` varchar(64);--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `finalizedAppointmentDate` varchar(10);--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `finalizedAppointmentTime` varchar(160);--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `finalizedTreatmentAreas` text;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `finalizedMachine` enum('DEKA AGAIN','CLARITY 2','GENTLE PROMAX','DUETTO MACHINE');--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `finalizedVisitType` enum('session','retouch');--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `finalizedNotes` text;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `assignedStaff` varchar(120);--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `appointmentDurationMinutes` int;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `finalizedBy` varchar(120);--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `finalizedAt` timestamp;