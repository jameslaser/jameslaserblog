ALTER TABLE `consultationRequests` ADD `originalConsentSetReference` varchar(180);--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `originalConsentDocuments` text;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `originalConsentAcknowledgedAt` timestamp;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `originalConsentLanguage` enum('en','ar');--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `consentSignatureStatus` enum('required','received') DEFAULT 'required' NOT NULL;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `consentSignatureReference` varchar(500);