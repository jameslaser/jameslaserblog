ALTER TABLE `consultationRequests` MODIFY COLUMN `takingMedication` boolean;--> statement-breakpoint
ALTER TABLE `consultationRequests` MODIFY COLUMN `tookVitaminD` boolean;--> statement-breakpoint
ALTER TABLE `consultationRequests` MODIFY COLUMN `takingIron` boolean;--> statement-breakpoint
ALTER TABLE `consultationRequests` MODIFY COLUMN `tannedPastThreeMonths` boolean;--> statement-breakpoint
ALTER TABLE `consultationRequests` MODIFY COLUMN `hadMoroccanBathLastSevenDays` boolean;--> statement-breakpoint
ALTER TABLE `consultationRequests` MODIFY COLUMN `hadSkinTreatment` boolean;--> statement-breakpoint
ALTER TABLE `consultationRequests` MODIFY COLUMN `hadSevereSunExposure` boolean;