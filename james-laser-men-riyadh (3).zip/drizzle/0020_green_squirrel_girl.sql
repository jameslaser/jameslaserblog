ALTER TABLE `patients` MODIFY COLUMN `firstTime` boolean;--> statement-breakpoint
ALTER TABLE `patients` MODIFY COLUMN `takingMedication` boolean;--> statement-breakpoint
ALTER TABLE `patients` MODIFY COLUMN `tookVitaminD` boolean;--> statement-breakpoint
ALTER TABLE `patients` MODIFY COLUMN `takingIron` boolean;--> statement-breakpoint
ALTER TABLE `patients` MODIFY COLUMN `tannedPastThreeMonths` boolean;--> statement-breakpoint
ALTER TABLE `patients` MODIFY COLUMN `hadMoroccanBathLastSevenDays` boolean;--> statement-breakpoint
ALTER TABLE `patients` MODIFY COLUMN `hadSkinTreatment` boolean;--> statement-breakpoint
ALTER TABLE `patients` MODIFY COLUMN `hadSevereSunExposure` boolean;--> statement-breakpoint
ALTER TABLE `appointments` ADD `contactNumber` varchar(32);--> statement-breakpoint
ALTER TABLE `appointments` ADD `email` varchar(320);--> statement-breakpoint
ALTER TABLE `patients` ADD `contactNumber` varchar(32);--> statement-breakpoint
ALTER TABLE `patients` ADD `source` varchar(40) DEFAULT 'request_transfer' NOT NULL;