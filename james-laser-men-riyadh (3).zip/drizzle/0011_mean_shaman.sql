ALTER TABLE `consultationRequests` ADD `normalizedWhatsapp` varchar(20);--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `treatmentAreas` text;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `consultationRequestVisitType` enum('session','retouch') DEFAULT 'session' NOT NULL;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `appointmentAcknowledgement` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `marketingConsent` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `source` varchar(120) DEFAULT 'website' NOT NULL;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `isPotentialDuplicate` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `publicRequestId` varchar(32);--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `updatedAt` timestamp DEFAULT (now()) NOT NULL ON UPDATE CURRENT_TIMESTAMP;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD CONSTRAINT `consultationRequests_publicRequestId_unique` UNIQUE(`publicRequestId`);