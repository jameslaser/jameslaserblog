CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`notificationType` enum('appointment_request','enquiry','review','promotion','system') NOT NULL,
	`title` varchar(180) NOT NULL,
	`message` varchar(320) NOT NULL,
	`linkPath` varchar(320),
	`isRead` boolean NOT NULL DEFAULT false,
	`readAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `clinicSettings` ADD `availableDays` text;--> statement-breakpoint
ALTER TABLE `clinicSettings` ADD `appointmentTreatmentOptions` text;--> statement-breakpoint
ALTER TABLE `clinicSettings` ADD `visitTypeOptions` text;--> statement-breakpoint
ALTER TABLE `clinicSettings` ADD `clinicDefaultLanguage` enum('en','ar') DEFAULT 'en' NOT NULL;--> statement-breakpoint
ALTER TABLE `clinicSettings` ADD `maintenanceMode` boolean DEFAULT false NOT NULL;