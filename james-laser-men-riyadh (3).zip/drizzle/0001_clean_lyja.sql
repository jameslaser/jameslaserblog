ALTER TABLE `consultationRequests` ADD `nationality` varchar(80) NOT NULL;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `preferredDate` varchar(10) NOT NULL;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `firstTime` boolean NOT NULL;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `lastLaserSession` varchar(160);--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `takingMedication` boolean NOT NULL;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `medicationDetails` varchar(500);--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `tookVitaminD` boolean NOT NULL;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `vitaminDLastTaken` varchar(160);--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `takingIron` boolean NOT NULL;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `ironLastTaken` varchar(160);--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `tannedPastThreeMonths` boolean NOT NULL;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `hadMoroccanBathLastSevenDays` boolean NOT NULL;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `hadSkinTreatment` boolean NOT NULL;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `skinTreatmentDetails` varchar(500);--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `hadSevereSunExposure` boolean NOT NULL;--> statement-breakpoint
ALTER TABLE `consultationRequests` ADD `consentRead` boolean NOT NULL;