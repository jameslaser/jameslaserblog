ALTER TABLE `resultCases` ADD `consentConfirmed` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `resultCases` ADD `consentConfirmed` boolean NOT NULL DEFAULT false;--> statement-breakpoint
ALTER TABLE `resultCases` ADD `consentRecordedAt` timestamp;
