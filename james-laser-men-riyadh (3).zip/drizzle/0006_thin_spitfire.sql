CREATE TABLE `machines` (
	`id` int AUTO_INCREMENT NOT NULL,
	`machineName` enum('DEKA AGAIN','CLARITY 2','GENTLE PROMAX','DUETTO MACHINE') NOT NULL,
	`machineNumber` varchar(64) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `machines_id` PRIMARY KEY(`id`),
	CONSTRAINT `machines_machineName_unique` UNIQUE(`machineName`),
	CONSTRAINT `machines_machineNumber_unique` UNIQUE(`machineNumber`)
);
