CREATE TABLE `patients` (
	`id` int AUTO_INCREMENT NOT NULL,
	`fullName` varchar(120) NOT NULL,
	`whatsapp` varchar(32) NOT NULL,
	`email` varchar(320),
	`nationality` varchar(80) NOT NULL,
	`treatmentArea` varchar(120) NOT NULL,
	`patientPreferredContact` enum('WhatsApp','Phone','Email') NOT NULL,
	`firstTime` boolean NOT NULL,
	`lastLaserSession` varchar(160),
	`takingMedication` boolean NOT NULL,
	`medicationDetails` varchar(500),
	`tookVitaminD` boolean NOT NULL,
	`vitaminDLastTaken` varchar(160),
	`takingIron` boolean NOT NULL,
	`ironLastTaken` varchar(160),
	`tannedPastThreeMonths` boolean NOT NULL,
	`hadMoroccanBathLastSevenDays` boolean NOT NULL,
	`hadSkinTreatment` boolean NOT NULL,
	`skinTreatmentDetails` varchar(500),
	`hadSevereSunExposure` boolean NOT NULL,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `patients_id` PRIMARY KEY(`id`),
	CONSTRAINT `patients_whatsapp_unique` UNIQUE(`whatsapp`)
);
--> statement-breakpoint
ALTER TABLE `appointments` ADD `patientId` int;