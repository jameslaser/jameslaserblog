CREATE TABLE `analyticsEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`analyticsEventType` enum('page_view','whatsapp_click','appointment_click','appointment_form_start','appointment_form_submit','treatment_view','guide_view') NOT NULL,
	`path` varchar(320),
	`analyticsLocale` enum('en','ar-SA'),
	`source` varchar(180),
	`analyticsDevice` enum('desktop','mobile','tablet','unknown') NOT NULL DEFAULT 'unknown',
	`treatmentSlug` varchar(160),
	`contentSlug` varchar(180),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `analyticsEvents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `enquiries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(120) NOT NULL,
	`mobile` varchar(32) NOT NULL,
	`email` varchar(320),
	`subject` varchar(180) NOT NULL,
	`message` text NOT NULL,
	`enquiryLanguage` enum('en','ar') NOT NULL DEFAULT 'en',
	`source` varchar(120) NOT NULL,
	`enquiryStatus` enum('new','read','replied','archived') NOT NULL DEFAULT 'new',
	`internalNotes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `enquiries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `publicFormSecurityEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`publicFormType` enum('consultation_request','enquiry') NOT NULL,
	`fingerprint` varchar(128) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `publicFormSecurityEvents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `redirects` (
	`id` int AUTO_INCREMENT NOT NULL,
	`fromPath` varchar(320) NOT NULL,
	`toPath` varchar(320) NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `redirects_id` PRIMARY KEY(`id`),
	CONSTRAINT `redirects_fromPath_unique` UNIQUE(`fromPath`)
);
