# External Hosting Variable Reference

Use this checklist to configure the external host’s encrypted Variables panel. **Do not put real values in GitHub.**

| Variable | Placeholder format | Required | Notes |
|---|---|---:|---|
| `NODE_ENV` | `production` | Yes | Set by the production host. |
| `PORT` | host-provided | Yes | Cloud Run supplies this at runtime; do not hardcode a port. |
| `DATABASE_URL` | `postgresql://USER:PASSWORD@localhost:5432/DATABASE` | Yes | PostgreSQL application credential mounted from Secret Manager. In Cloud Run, `DB_SOCKET_PATH` overrides the URL host with the attached Cloud SQL Unix socket. |
| `DB_SOCKET_PATH` | `/cloudsql/PROJECT:REGION:INSTANCE` | Cloud Run | Non-secret Cloud SQL Unix-socket path set from the attached instance connection name. |
| `MYSQL_SOURCE_URL` | `mysql://USER:PASSWORD@HOST:3306/DATABASE` | Migration only | A read-only source credential used only by the offline controlled migration utility; never configure it in the Cloud Run service. |
| `JWT_SECRET` | long random secret | Yes | Keep server-only; rotate only with a session migration plan. |
| `VITE_APP_ID` | OAuth application ID | Yes | Existing OAuth application identifier. |
| `OAUTH_SERVER_URL` | `https://oauth.example.com` | Yes | Existing OAuth backend base URL. |
| `VITE_OAUTH_PORTAL_URL` | `https://oauth-portal.example.com` | Yes | Existing OAuth portal URL. |
| `OWNER_OPEN_ID` | owner identifier | Yes | Existing owner authorization mapping. |
| `BUILT_IN_FORGE_API_URL` | `https://forge.example.com` | Yes | Server-side Forge storage API base URL. |
| `BUILT_IN_FORGE_API_KEY` | server-side Forge key | Yes | Server-only; required by existing storage proxy. |
| `VITE_PUBLIC_MAPS_SCRIPT_URL` | credential-free HTTPS script URL | If used | Optional browser setting. It must contain no private key, bearer token, storage credential, or Forge credential. If absent, the unused map component renders a safe unavailable state. |
| `VITE_PUBLIC_SITE_ORIGIN` | `https://example.com` or the Cloud Run URL | Yes | Provide as a non-secret Cloud Build argument before the Vite build runs. Do not include credentials. |
| `VITE_ANALYTICS_ENDPOINT` | `https://analytics.example.com` | If analytics enabled | Existing optional analytics template value. |
| `VITE_ANALYTICS_WEBSITE_ID` | analytics site ID | If analytics enabled | Existing optional analytics template value. |
| `META_APP_ID` | Meta app identifier | WhatsApp production | Mounted from Secret Manager to Cloud Run only; never expose it in Vite. |
| `META_APP_SECRET` | Meta app secret | WhatsApp production | Mounted from Secret Manager only; used exclusively for webhook HMAC validation. |
| `WHATSAPP_ACCESS_TOKEN` | Meta production system-user token | WhatsApp production | Mounted from Secret Manager only; used only by the server-side Graph API client. |
| `WHATSAPP_PHONE_NUMBER_ID` | Meta phone number ID | WhatsApp production | Mounted from Secret Manager only; used by the server-side Messages API client. |
| `WHATSAPP_BUSINESS_ACCOUNT_ID` | WhatsApp Business Account ID | WhatsApp production | Mounted from Secret Manager only; used for template metadata synchronization. |
| `WHATSAPP_WEBHOOK_VERIFY_TOKEN` | random opaque verification token | WhatsApp production | Mounted from Secret Manager only; configured separately in Meta’s webhook verification form. |
| `META_GRAPH_API_VERSION` | supported Graph API version, for example `vXX.X` | WhatsApp production | Stored as a Secret Manager value to keep all Meta runtime configuration out of source control. |
