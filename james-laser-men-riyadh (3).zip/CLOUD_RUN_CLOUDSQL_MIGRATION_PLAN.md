# Cloud Run-Only and Cloud SQL PostgreSQL Transition Plan

**Document status:** Approved for design and safe repository preparation only. It is **not** authorization to provision cloud resources, export operational data, migrate data, change the active database, deploy a Cloud Run service, or connect DNS.

## 1. Executive decision record

The target production delivery architecture is:

```mermaid
flowchart LR
  GH[GitHub main] --> CB[Cloud Build]
  CB --> AR[Artifact Registry]
  AR --> CR[Cloud Run: james-laser-web\nme-central1 · PORT 8080]
  CR --> CS[Cloud SQL PostgreSQL\nprivate/managed connection]
  CR --> SM[Secret Manager]
  CR --> S3[Existing protected media storage]
  DOMAIN[Custom domain\njameslaserhairremovall.com] -. only after QA .-> CR
```

The service remains a single full-stack Cloud Run process: Vite static files, direct SPA fallback, Express routes, tRPC API, OAuth callback, `/healthz`, `/readyz`, redirects, and the existing public/private storage boundary. No alternative managed hosting, document database, authentication service, storage service, function runtime, or realtime database is part of the target architecture.

> **Source-of-record rule.** The running MySQL/TiDB database remains authoritative until a separate PostgreSQL target has completed every verification gate and the owner has explicitly authorized cutover. No current patient, appointment, request, HMS import, consent, signature, CMS, or audit record may be deleted, overwritten, reset, or re-imported for this transition.

## 2. Verified current state

| Component | Verified state | Decision |
|---|---|---|
| Application runtime | Existing Express/Vite runtime already serves API, OAuth, storage proxy, health/readiness, and SPA direct routes from one process. | Preserve and deploy to Cloud Run. |
| Cloud Run port behavior | Production now requires a valid supplied `PORT` and binds exactly to it; development retains an available-port fallback. | Ready for Cloud Run’s `PORT=8080` contract. |
| Cloud Build | Builds `Dockerfile.cloudrun`, deploys `james-laser-web` to `me-central1`, and uses port `8080`; no legacy front-host assumption remains. | Retain, subject to owner-approved cloud configuration. |
| Legacy managed-service runtime dependency | No alternative SDK or managed-service runtime dependency is used by application code. | No runtime application conversion is required. |
| Legacy hosting configuration | Retired during the Phase 2 pre-activation hardening pass. | Cloud Run serves the full application directly. |
| Active database | MySQL/TiDB via Drizzle MySQL driver and existing operational records. | Preserve as source until cutover authorization. |
| Cloud account gate | Cloud Run API activation was blocked because the linked billing account was not in good standing. No Cloud Run service, Cloud Build trigger, Artifact Registry image, Cloud SQL instance, secret, or DNS record was created. | Owner must resolve billing standing before cloud provisioning. |

## 3. Legacy hosting retirement inventory

| Reference | Current purpose | Final treatment | Preconditions |
|---|---|---|---|
| Legacy rewrites and configuration regression | Superseded hosting path | **Removed** | Cloud Run serves public routes, API, OAuth, storage, health/readiness, and admin routes directly. |
| Legacy deployment, compatibility, local-validation, and owner-status records | Superseded deployment documentation | **Removed** | Active guidance is the Cloud Run-only runbook. |
| `ENVIRONMENT_VARIABLES.md`, `EXTERNAL_DEPLOYMENT.md`, `README.md`, audit notes | Active deployment guidance | **Updated** | Direct Cloud Run temporary URL is used for QA until an owner-authorized custom domain is verified. |
| Client/server runtime packages | No alternative hosted-service imports or installed SDK identified | **No action** | No app package deletion needed. |

## 4. Database conversion inventory

| Verified MySQL/TiDB construct | PostgreSQL target construct | Main risk | Required test/evidence |
|---|---|---|---|
| `mysqlTable(...)` across the active Drizzle schema | A separate `pgTable(...)` schema | Mechanical conversion can alter names, nullability, constraints, or relations. | Table/column/constraint DDL comparison, reviewed per table. |
| `mysqlEnum(...)` workflow/content/request/consent/HMS/analytics values | `pgEnum(...)` created in dependency order | Changing values/defaults breaks historic operational states. | Complete enum label/default report and state-transition regression suite. |
| `int(...).autoincrement().primaryKey()` | PostgreSQL identity primary keys | Reassigned IDs would break all retained links and audit references. | Explicit ID import plan, FK checks, and post-load sequence reset. |
| `timestamp(...).defaultNow().onUpdateNow()` | PostgreSQL timestamp default plus application-managed updates or reviewed triggers | PostgreSQL lacks the same automatic column update behavior. | `updatedAt` mutation tests and source/target timestamp comparison. |
| `drizzle-orm/mysql2` / `mysql2` | PostgreSQL Drizzle adapter plus bounded `pg` pool | Cloud Run connection spikes can exhaust Cloud SQL. | Pool limit, managed/private Cloud SQL connectivity, `/readyz`, and connection-pressure test. |
| `Number(result[0].insertId)` in workflow/CMS/notification/signature helpers | `insert(...).returning({ id: table.id })` | New-record linkage can attach to wrong IDs. | Create-path integration coverage for each helper. |
| `onDuplicateKeyUpdate(...)` in users, machines, requests, CMS, SEO, and redirects | `onConflictDoUpdate({ target, set })` | Wrong conflict targets can overwrite unrelated records. | One conflict/non-conflict test for every helper. |
| Six transaction boundaries in `db.ts` and `consentSignature.ts` | PostgreSQL Drizzle transactions | Partial transfer, HMS, manual-entry, or signature evidence writes must never persist. | Failure-injection tests prove all-or-nothing outcomes. |
| `sql\`SELECT 1\`` readiness probe | Same parameterized PostgreSQL query | Readiness must not be falsely positive. | `/readyz` returns 503 when target DB is unavailable and 200 only when usable. |
| MySQL migration files `0000`–`0021` | New PostgreSQL-only migration history and journal | Existing MySQL SQL cannot be applied to PostgreSQL. | Empty-target migration run, schema inspection, and no use of MySQL migration SQL. |

## 5. Staged implementation model

The active MySQL/TiDB application must **not** be converted in place. The safe implementation is a parallel PostgreSQL adapter and migration workspace, with the current application left runnable until the final gate.

| Stage | Repository/cloud activity | Data safety rule | Exit condition |
|---|---|---|---|
| A. Prepare | Add isolated PostgreSQL schema/config and synthetic-only tests. | No operational data read or written. | PostgreSQL DDL and test adapter are reviewed. |
| B. Provision | Create empty Cloud SQL PostgreSQL with backups/PITR, least-privilege app user, managed/private connectivity, and Secret Manager references. | No source database change. | Empty target passes connection/readiness check. |
| C. Dry-run export/load | Use a controlled source snapshot/copy and a non-destructive migration tool. | No live source mutation; no fake records. | Counts, checksums, FK checks, and workflow tests pass. |
| D. Cutover rehearsal | Practice the exact runbook with a fresh target/snapshot. | Current production still points at MySQL/TiDB. | Measured duration, rollback, and results accepted by owner. |
| E. Authorized cutover | Place public writes into an owner-approved maintenance window, take source backup reference, apply target migrations, run import, and switch only the service DB secret/config. | Do not delete or reset MySQL/TiDB. | All final validation gates pass. |
| F. Retire legacy | Legacy hosting artifacts were removed during pre-activation hardening; keep the MySQL source read-only/retained for the agreed rollback window. | DNS remains unchanged until final QA. | Owner approves custom-domain connection separately. |

## 6. Data migration order and transformations

The migration tool must be designed and tested before live use. It must retain primary keys where referenced, preserve nullable unknown clinical values as `NULL`, preserve raw HMS values, preserve original consent files and private signed-evidence storage keys, and never reconstruct or infer clinical facts.

| Order | Dataset group | Key safeguards |
|---|---|---|
| 1 | Enums, tables, indexes, unique constraints, and non-cyclic relations | Apply PostgreSQL DDL to a new empty target only. |
| 2 | Identity and authorization records | Preserve user IDs, external IDs, roles, and timestamps. |
| 3 | CMS, clinic configuration, policies, media references, SEO, redirects | Preserve publication state; never manufacture reviews, results, promotions, or media. |
| 4 | Requests, consents, signature sessions/manifests, patients, machines, appointments, waiting-list state | Maintain original request-to-appointment and consent/signature links. |
| 5 | HMS batch metadata and HMS appointments | Preserve original raw fields, batch linkage, source-row audit data, provider attestation metadata, and existing null request links. |
| 6 | Enquiries, notifications, activity logs, analytics aggregates, security events | Preserve privacy boundaries and timestamps. |
| 7 | Post-load sequence alignment, indexes, FK validation, and application smoke tests | Set sequences above imported IDs; do not create replacement records. |

## 7. Integrity gates

| Gate | Acceptance criterion | Failure response |
|---|---|---|
| Backup/reference | Owner-approved source backup/reference exists before load. | Stop; do not begin a live migration. |
| Row counts | Every migrated table has a source/target count comparison. | Stop cutover and investigate variance. |
| Checksums | Stable, privacy-safe deterministic checks cover critical rows and raw HMS fields. | Stop cutover; re-run transform diagnosis. |
| Relations | Zero unexpected orphaned foreign keys; all retained source IDs resolve. | Stop cutover and correct mapping. |
| Workflow | Public request, protected review/transfer, HMS isolation, consent/e-signature, patient, appointment, waiting-list, CMS and RBAC regressions pass. | Keep Cloud Run on MySQL/TiDB. |
| Runtime | Cloud Run temporary URL returns 200 for `/healthz`; `/readyz` is 200 only with PostgreSQL reachable. | Roll back service DB configuration to MySQL/TiDB. |
| Privacy/security | Cloud SQL is not public by default; DB secret is in Secret Manager; least-privilege user works; no credential enters Git or chat. | Stop and fix security configuration. |

## 8. Rollback decision

Before DNS is changed, rollback is limited to changing the Cloud Run service configuration back to the retained MySQL/TiDB connection contract and re-deploying the already-tested MySQL-compatible release. PostgreSQL target data may be retained for diagnosis, but it must not be presented as production source-of-record. MySQL/TiDB must not be dropped, reset, or overwritten as part of rollback.

No dual-write is recommended for the current clinical workflow until a separate design validates idempotency, conflict behavior, audit ordering, and private evidence handling. The preferred approach is a short owner-approved write pause during final migration, followed by explicit cutover checks.

## 9. Owner-controlled prerequisites

| Step | Where | Value type | Expected result |
|---|---|---|---|
| 1. Restore cloud billing standing | Google Cloud Billing | Account standing/payment verification | Required service APIs can be enabled. No payment details are requested in chat. |
| 2. Confirm target resources | Google Cloud Console | Region, instance `james-laser-db`, database `james_laser`, backups/PITR, network model | A new empty PostgreSQL target design is approved. |
| 3. Create service accounts/secrets | IAM, Secret Manager, Cloud Run | Least-privilege roles and server-only secret values | Cloud Run has managed DB connectivity without committed secrets. |
| 4. Approve a dry run | Owner change-control decision | Explicit authority to use a controlled source copy/export | A data-migration rehearsal may proceed. |
| 5. Approve final cutover | Owner maintenance decision | Explicit final authorization and rollback window | Live source data may be migrated; MySQL/TiDB stays retained. |
| 6. Approve DNS | Cloud Run domain mapping/DNS provider | Provider-generated DNS values only | Custom domain is connected only after temporary Cloud Run QA. |

## 10. Repository preflight guard

The repository now contains an isolated `drizzle-pg/` workspace marker and `pnpm postgres:preflight`. The preflight accepts only a distinct `POSTGRES_MIGRATION_URL` using `postgres://` or `postgresql://`; it is intentionally non-connecting and does not print connection values. It rejects a MySQL/TiDB URL or a target equal to the active source contract. The active runtime continues to use MySQL/TiDB.

No PostgreSQL Drizzle schema, migration SQL, import utility, Cloud SQL target, operational-data export, or database cutover has been created.

## 11. Current next action

The next safe technical action is to prepare a separate PostgreSQL schema and synthetic-only migration test harness **after** the owner confirms that Cloud SQL provisioning is desired. It must not replace the current MySQL runtime or act on operational records. Cloud provisioning remains blocked until the linked Google billing account is restored to good standing.
