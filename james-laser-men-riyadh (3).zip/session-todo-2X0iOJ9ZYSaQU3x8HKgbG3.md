# Session TODO — Payment-Focused Reconciliation Guidance

- [x] Inspect the existing revenue reconciliation message and red difference panel.
- [x] Replace technical import-blocked language with payment-amount guidance while preserving safety controls.
- [x] Update focused UI coverage for the simplified payment reconciliation message.
- [x] Run focused tests, type check, build, and save a checkpoint.

## Copy Payment Differences

- [x] Define a privacy-safe HMS support summary that excludes patient names and contact details.
- [x] Add the one-click Copy payment differences control to blocked reconciliation previews.
- [x] Test the copy payload, UI control, parser stability, type check, production build, and formatting.
