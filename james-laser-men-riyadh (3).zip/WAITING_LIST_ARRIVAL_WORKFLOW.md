# Waiting List Arrival and Patient Profile Workflow

**Author:** Manus AI  
**Validation date:** 2026-09-01 (Asia/Riyadh)

## Implemented workflow

The protected Waiting List no longer marks a confirmed appointment as arrived immediately when staff select the green check. The check opens an editable **Arrival details** panel for that appointment. Staff review the patient name, MRN, nationality, contact number, WhatsApp number, and email; select **Session** or **Retouch**; select one approved machine; select every applicable treatment area; then enter the required **nurse’s notes**.

The **Save arrival and patient profile** action performs one server-side database transaction. It confirms that the appointment is for the current Riyadh date and still has confirmed status; resolves an existing patient identity using normalized mobile and MRN values; rejects identifiers that point to different patient files; creates a patient profile only when no match exists; links the appointment to that patient; stores the nurse’s note, visit type, approved machine, primary treatment area, and complete treatment-area set on the protected appointment record; changes the status to arrived; and writes an activity-log entry.

| Requirement | Implemented behavior |
|---|---|
| Clicking the check opens details | The green check toggles the protected arrival editor and does not mutate attendance. |
| Editable patient details | Staff can review and edit identity, contact, nationality, and treatment-area fields before saving. |
| Nurse’s notes | A required, maximum 12,000-character protected note is saved to the appointment history. |
| Session / Retouch | A required dropdown saves the structured visit type for sorting and follow-up review. |
| Machine used | A required dropdown accepts only DEKA AGAIN, CLARITY 2, GENTLE PROMAX, or DUETTO MACHINE. |
| Treatment areas | A reusable checklist supports selecting every applicable approved area and saves the full set. |
| Patient profile | The save action creates or links one patient file and makes the linked appointment visible in the Patients workspace. |
| Duplicate prevention | Normalized mobile and MRN matches use the existing single-patient identity resolver; conflicting matches are rejected. |
| Data separation | No public request is created or changed. Original consent and HMS source/audit fields are not modified. |
| Historical dates | Arrival, no-show, cancellation, and completion controls are disabled when the selected date is not today in Riyadh. |

## Source and privacy safeguards

For HMS-imported appointments, the transaction preserves the original HMS appointment values and source evidence. Only clinic-owned linkage, arrival status, nurse notes, and staff attribution are updated. The patient profile receives the staff-confirmed details without rewriting raw HMS source values.

Nurse notes remain protected inside the Admin Portal and are displayed in the patient’s linked appointment history together with the saved visit type, machine, and complete area summary. They are not exposed on the public website, appointment request form, URLs, or public APIs.

## Validation evidence

The protected route was opened with the existing authorized owner session. A real confirmed appointment’s green check was selected, and the in-page editor rendered the expected prefilled fields, Session / Retouch dropdown, approved-machine dropdown, multi-area checklist, required nurse-note control, patient-profile explanation, and disabled save button until all required values are supplied. **No save was submitted and no clinic record was changed during this browser verification.**

TypeScript validation passed. The focused authorization, identity, and UI regression set passed **48 tests**. The complete suite passed **56 test files and 186 tests**, and the production build completed successfully.

Desktop and 390-pixel mobile reviews confirmed that the Waiting List cards, arrival checks, date selector, and Patients workspace remain readable without horizontal overflow. The structured arrival details panel was opened against a real confirmed appointment without submitting the save action. A read-only integrity query confirmed that HMS-imported records remain associated only with provider code NR011. Both `/healthz` and `/readyz` returned HTTP 200 after a clean service restart, and the post-startup runtime, browser-console, and network logs contained no new application error or HTTP 4xx/5xx entries. One transient 502 captured during the restart window was excluded after confirming clean post-startup traffic.

## Remaining operational validation

The write transaction has not been exercised against a real patient record because doing so would change live clinic data. The first authorized staff use should confirm the clinical details and nurse note before selecting save. If the mobile or MRN belongs to another file, the server will stop the operation and require staff review rather than merge records automatically.
