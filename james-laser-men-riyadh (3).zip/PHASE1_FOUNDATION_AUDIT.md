# Phase 1 Foundation Audit

**Scope.** This audit records the repository state on `main` before the Phase 1 production-foundation changes. It assesses the existing React/Vite client, Express/tRPC server, MySQL/TiDB Drizzle implementation, authentication, storage boundaries, appointment and consent workflows, container configuration, Cloud Build configuration, obsolete hosting artifacts, and GitHub Actions workflow. It does not assert that any Google Cloud resource, production database migration, secret, custom-domain DNS record, or live deployment exists.

## Current architecture

The application is an existing full-stack TypeScript application rather than a blank project. Vite builds the React frontend into `dist/public`; an Express process serves the production artifact, tRPC API, OAuth callback, storage proxy, redirect middleware, health endpoint, readiness endpoint, and SPA fallback. The existing frontend includes public English and Arabic routes, the public appointment request flow, consent signing, and a protected administrative portal.

| Layer | Current implementation | Audit result |
| --- | --- | --- |
| Frontend | React 19, Vite 7, Wouter, Tailwind, tRPC client | Preserve and stabilize. Bilingual public routes and admin routes already exist. |
| Backend | Express 4, tRPC 11, server-side OAuth routes and storage proxy | Preserve and stabilize. The production server already accepts the Cloud Run `PORT` contract and has a direct-route static fallback. |
| Authentication and RBAC | Existing server-side OAuth context, users table, owner/admin/reception/content-editor/user roles | Preserve. Verify backend enforcement against every protected procedure during final validation. |
| Persistence | Drizzle ORM using `mysql2`, MySQL-specific schema and migration history | Replace with a PostgreSQL Drizzle schema, driver, migrations, and data-migration tooling. |
| Appointment workflow | Public request → administrative review → atomic patient/appointment transfer with retention controls | Preserve. Existing clinical unknown fields are already nullable in the public-request path. |
| Consent and signature | Original document references, token-hash signature sessions, separate evidence references | Preserve. Verify protected evidence download authorization after the database conversion. |
| Storage | Public/protected route separation through a server proxy | Preserve and test. Do not expose private evidence through a public wildcard route. |
| Container and CI | `Dockerfile.cloudrun`, `cloudbuild.yaml`, and GitHub Actions validation | Replace the legacy database and obsolete hosting assumptions while retaining the image build and test gates. |

## Confirmed current strengths

The existing server has `/healthz` returning a process-alive response and `/readyz` performing a database query. It sets baseline security headers, production CSP, HSTS, and clickjacking protection. In production, the runtime rejects a missing or invalid `PORT` rather than scanning for an alternative port. The public request implementation distinguishes unasked clinical questions from a negative answer by persisting `null`. The appointment transfer implementation is transactional and already checks mobile, MRN, and same-machine/same-time conflicts; linked requests are retained instead of hard-deleted.

The frontend has explicit public routes for `/`, `/en`, `/ar`, appointment pages, public CMS pages, policy pages, consent signing, and protected administrative paths including requests, appointments, waiting list, patients, machines, CMS, notifications, and security. Existing HMS CSV code and its administrative route are present; that work is not being extended under Phase 1 and will remain out of scope unless necessary to preserve data compatibility.

## Phase 1 gaps requiring change

| Area | Current finding | Required Phase 1 change |
| --- | --- | --- |
| Production database | `server/db.ts` imports `drizzle-orm/mysql2`; `drizzle/schema.ts` imports `drizzle-orm/mysql-core`; runtime requires `MYSQL_URL` in production. | Migrate to PostgreSQL using `pg` and `drizzle-orm/node-postgres`; standardize runtime on server-only `DATABASE_URL`. |
| Database schema | The active schema uses `mysqlTable`, `mysqlEnum`, auto-increment assumptions, `onUpdateNow()`, and no explicit Drizzle relation definitions. | Create an independent PostgreSQL schema and non-destructive migration history, using PostgreSQL equivalents, FK constraints, indexes, and nullable imported-appointment references. |
| Database operations | The database layer uses MySQL `onDuplicateKeyUpdate`, `[0].insertId`, and `[0].affectedRows` conventions. | Replace with PostgreSQL conflict clauses and `returning()`-based inserts/updates, retaining atomic transfer behavior. |
| Data migration | The repository has only a non-connecting PostgreSQL target preflight. | Add controlled export, transform, import, and reconciliation tooling; preserve the MySQL/TiDB source and prohibit automatic cutover. |
| Obsolete hosting artifacts | No alternative hosting SDK is present, but prior rewrites, configuration tests, and deployment documents remained. | Retired during the Phase 2 hardening pass; active deployment guidance is Cloud Run-only. |
| Cloud Build | The image build does not pass the Vite public-origin build argument and Cloud Run deploy does not yet configure Cloud SQL attachment or Secret Manager environment mappings. | Add safe build substitutions, Cloud SQL connection configuration, and Secret Manager mappings without committing secret values. |
| Docker | The current Dockerfile builds and runs the server, but copies the full repository before dependency installation and does not document Cloud SQL/runtime expectations. | Retain the production Node server model while improving the build structure and verifying the container behavior. |
| Deployment evidence | No Cloud Run service, Artifact Registry image, Cloud SQL instance, Secret Manager values, or temporary `run.app` URL is evidenced by the repository. | Prepare configuration and perform only authorized non-destructive cloud actions. Report any missing Google Cloud authorization, billing, or secrets as owner actions. |

## Obsolete hosting classification

| Artifact class | Classification | Phase 1 handling |
| --- | --- | --- |
| Alternative runtime SDK and managed database services | Not present in application runtime | No replacement required. |
| Hosting rewrites and deployment configuration test | Retired | Cloud Run directly serves frontend and backend from its temporary URL. |
| Legacy deployment, compatibility, local-validation, and owner-status documents | Retired | Active operations use the Cloud Run-only runbooks. |
| Legacy temporary-origin references | Retired | Use the temporary Cloud Run origin for QA and the custom-domain origin only after verified readiness and explicit DNS authorization. |

## Safe implementation sequence

The implementation will first make the application database-agnostic at its interfaces, then add the PostgreSQL schema and migrations, port MySQL-specific operations, and build data-migration and reconciliation utilities. Existing MySQL/TiDB data will remain untouched and authoritative until a separately reported migration reconciliation passes and an owner explicitly authorizes cutover. The project will then remove obsolete hosting artifacts, harden the Cloud Run and Cloud SQL deployment configuration, run type checks, regression tests, production builds, and a container build, and attempt only authorized cloud deployment steps. WhatsApp and HMS import development are deferred.

> **Current Phase 1 status:** The repository has substantial working application functionality and preliminary Cloud Run artifacts, but it is not yet a verified Cloud Run + Cloud SQL PostgreSQL production deployment. In particular, obsolete hosting artifacts remained at audit time, MySQL was the active production runtime, no PostgreSQL target schema or data migration existed, and no temporary Cloud Run deployment was verified.

## Audited files and areas

The audit covered `package.json`, `pnpm-lock.yaml`, `client/src`, `server`, `shared`, `drizzle`, `drizzle-pg`, migration scripts, `Dockerfile.cloudrun`, `cloudbuild.yaml`, obsolete hosting artifacts, GitHub Actions CI, runtime environment handling, database readiness, public appointment transfer behavior, consent-signature persistence, storage routing, and the tracked deployment documentation.

The next implementation phase will preserve all existing public, administrative, consent, CMS, and appointment capabilities while replacing the platform-specific persistence and deployment dependencies required by the new target architecture.
