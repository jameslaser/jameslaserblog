# Bilingual Public Homepage Audit

The public homepage now presents a visible **English | العربية** selector on both desktop and mobile. The English choice opens `/en`, which renders the complete English homepage, while the Arabic choice opens `/ar`, which renders an Arabic-first public landing experience. Both choices remain inside the same web application.

The Arabic page uses `lang="ar"`, `dir="rtl"`, and matching document-level language and direction attributes. Arabic typography uses Noto Sans Arabic rather than the English display typeface. The visible copy was revised into natural Modern Standard Arabic suitable for a Saudi public audience, including the important availability statement that submitting a request does not confirm an appointment.

| Verification area | Result |
| --- | --- |
| English and Arabic controls visible | PASS |
| Active language identified with `aria-current` | PASS |
| English route `/en` opens the complete English homepage | PASS |
| Arabic route `/ar` opens Arabic content | PASS |
| Arabic page direction and document language | PASS |
| Arabic navigation and appointment links preserve `/ar` | PASS |
| English navigation and appointment links preserve `/en` | PASS |
| Arabic typography on desktop and mobile | PASS |
| Arabic request disclaimer states that the request is not confirmation | PASS |
| Desktop and 390-pixel mobile layout | PASS |

This update changes only public presentation and route behavior. It does not alter the Admin Portal, authentication, HMS provider filtering, appointment/request separation, or clinic database records.
