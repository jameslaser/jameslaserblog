# HMS CSV Import Format Audit

## Scope and safety boundary

This note records a **non-mutating** inspection of the owner-supplied `Report.csv`. No appointment, patient, request, signature, or other operational record was created or changed. The file has **not** been imported.

## Observed file contract

| Observation | Verified result |
|---|---|
| Encoding | UTF-8 with a byte-order mark (BOM) |
| Delimiter | Comma |
| Header count | 11, in the supplied HMS report order |
| Data rows | 9 |
| Field shape | Every inspected data row contains 11 fields |
| Date format | `DD/MM/YYYY` |
| Time format | 12-hour values such as `8:00PM` and `1:00PM` |

The importer accepts only the exact supplied headers, strips a UTF-8 BOM safely, handles RFC-style quoted fields, preserves original values separately from normalized search/scheduling fields, and previews validation before any write operation.

## Observed edge cases

| Edge case | Observed count | Import handling |
|---|---:|---|
| Raw MRN `0` | 2 | Retain raw `0`; do not create MRN `0`; appointment MRN is null |
| Unknown or `U` sex value | 2 | Retain raw value; normalized sex is `Unknown` |
| Raw age `0` | 2 | Retain raw value; normalized age is null; no birth-date calculation |
| Blank nationality | 2 | Preserve as blank/null; do not infer nationality |
| Equal raw start/end values | 2 | Retain both raw values and flag a warning; do not invent a duration |
| Nonblank telephone | 9 | Preserve raw telephone and store a normalized Saudi-mobile value only when valid |
| Unique raw dates | 3 | Convert valid dates to ISO only for scheduling/search operations |

## Provider limitation and required attestation

The supplied report has **no provider or doctor column**. Therefore, source-field filtering for `NR011` cannot be verified from this CSV and the importer does not fabricate provider data. Before an explicit import, an authorized administrator must visibly attest that the file is the approved `NR011 — JAMES FLORES` scope. This attestation is stored only as import-batch audit metadata; it does not change the original row values.

## Operational boundary

An HMS import is designed to create source-labelled `hms_csv` entries in the existing protected **Appointments** system only. It never creates or updates a public appointment request, Patient Requests queue entry, patient file, consent record, or e-signature.
