# Shared Backend Validation Notes

## Public-form boundary

Consultation requests and general enquiries use different persistence paths. General enquiries never create appointments or patient files. Both public procedures validate structured input, reject a non-empty honeypot field, normalize free text server-side, reject matching submissions for twenty minutes, and apply a ten-minute threshold of five submissions per HMAC-protected trusted request signal. The signal is stored only as a non-reversible fingerprint and security records are purged after thirty days.

## Private administration boundary

Only owner and admin roles can access enquiries, analytics, exports, or redirects. Content editors and reception users are rejected by the backend procedures. Exports require an authenticated protected procedure; client-side CSV serialization escapes quotes and dates deterministically.

## Publishing and media boundary

Public content remains limited to existing approved, active, or published CMS helpers. CMS media upload validation accepts only JPEG, PNG, WebP, AVIF, MP4, or WebM. Base64 input is capped before processing and decoded media is rejected above 10 MB. Media bytes are stored through project storage; only metadata is persisted in the database.

## Redirect boundary

Redirects are site-relative only. API, admin, storage, external, self-referential, and looped redirects are rejected. Active records are enforced with an HTTP 301 before public frontend routing, while protected paths bypass redirect lookup.

## Validation record

The release suite includes public-form guard tests, protected-procedure tests, a redirect middleware HTTP test, CSV serialization and browser-download handoff tests, desktop and iPhone workspace screenshots, static type checking, and a production build.

An owner-authorized CSV export was triggered from the protected Data & Backup workspace. The download start was confirmed without opening its contents, and the downloaded file was immediately removed from the sandbox. A temporary protected redirect was created through the Redirects workspace, confirmed to route the old public URL to its destination while preserving a query string, then removed. A direct post-cleanup database check confirmed no temporary redirect record remained. No patient, appointment, enquiry, or customer content was created for validation.
