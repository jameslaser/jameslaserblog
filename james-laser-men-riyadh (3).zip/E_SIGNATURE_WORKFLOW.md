# E-Signature Foundation — James Laser Hair Removal for Men Riyadh

> **Working implementation record — review with qualified legal and clinical governance professionals before relying on it as the final production consent process.**

## Purpose and scope

The e-signature foundation applies only to a **pending appointment request** that already records the immutable three-document original consent set. It does not edit, merge, annotate, replace, or otherwise modify `FILENO3(1).pdf`, `NewLookDentalandDermatologyClinicsComplex3(1).pdf`, or `CLINICPOLICYAGREEMENT3(1).pdf`. It does not create a patient file, confirm an appointment, or publish content.

| Workflow stage | Stored data | Boundary |
|---|---|---|
| Staff creates session | Hashed one-time token, request ID, language, immutable consent-set reference, exact source-document metadata, expiry | Available only to owner, admin, or reception staff through the protected request workspace. |
| Staff sends link | A manually copied `/sign-consent#token=…` link | Token is never stored in plaintext and is not automatically sent through WhatsApp, email, or another external service. |
| Customer reviews forms | The same three unchanged source PDFs | Each form must be explicitly opened before acknowledgement and signature controls unlock. |
| Customer signs | Signer name, separate PNG signature evidence, signed-evidence manifest, signed time, reference | The original PDFs remain untouched. A signed evidence pack is a derivative record, not an altered source consent file. |
| Staff reviews evidence | Session status, timestamps, reference, and a short-lived authorized evidence-download URL | The stored derivative key is not exposed to the public signing page. |

## Safety and privacy controls

The signing token uses 32 random bytes and is stored only as a SHA-256 hash. The token is placed in the URL fragment, which is not sent in ordinary HTTP requests or document referrers. Public session lookup and submission use POST mutations, return no request, patient, staff, telephone, or appointment details, and reject invalid, expired, revoked, signed, or closed-request sessions.

A signing session is valid for seven days. Staff may revoke a pending session or renew it with a new token. A signed session cannot be renewed through the interface. The public signature page has `noindex, nofollow, noarchive` metadata.

## Required owner decisions before live clinical use

The project does not select or connect an external signing provider. The owner must decide, with qualified legal and clinical governance review, the applicable consent validity standard, identity-verification approach, retention period, staff access policy, incident handling, and whether an external signature/audit provider is needed. Any future provider integration must preserve the same immutable original-source hashes and request-only boundary.

No customer signature, test signature, signed evidence pack, patient file, confirmed appointment, or provider account was created while implementing this foundation.
