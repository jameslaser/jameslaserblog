import { describe, expect, it } from "vitest";
import { normalizeMobileNumber } from "./db";
import { isServiceWindowOpen, shouldApplyMetaStatus, shouldReprocessWebhookEvent, templateBodyVariableCount, validateTemplateBodyComponents } from "./whatsappService";

describe("WhatsApp service safeguards", () => {
  it("reuses the central Saudi phone normalization behavior", () => {
    expect(normalizeMobileNumber("0551234567")).toBe("+966551234567");
    expect(normalizeMobileNumber("966551234567")).toBe("+966551234567");
    expect(normalizeMobileNumber("+966551234567")).toBe("+966551234567");
    expect(normalizeMobileNumber("00966551234567")).toBe("+966551234567");
  });

  it("allows free-form messaging only within a future customer service window", () => {
    expect(isServiceWindowOpen({ serviceWindowExpiresAt: new Date(Date.now() + 60_000) })).toBe(true);
    expect(isServiceWindowOpen({ serviceWindowExpiresAt: new Date(Date.now() - 60_000) })).toBe(false);
    expect(isServiceWindowOpen({ serviceWindowExpiresAt: null })).toBe(false);
  });

  it("allows controlled reprocessing only for failed or interrupted webhook events", () => {
    expect(shouldReprocessWebhookEvent("received")).toBe(true);
    expect(shouldReprocessWebhookEvent("failed")).toBe(true);
    expect(shouldReprocessWebhookEvent("processed")).toBe(false);
    expect(shouldReprocessWebhookEvent("ignored")).toBe(false);
  });

  it("accepts only monotonic Meta delivery progression and preserves terminal states", () => {
    expect(shouldApplyMetaStatus("sending", "sent")).toBe(true);
    expect(shouldApplyMetaStatus("sent", "delivered")).toBe(true);
    expect(shouldApplyMetaStatus("delivered", "read")).toBe(true);
    expect(shouldApplyMetaStatus("read", "delivered")).toBe(false);
    expect(shouldApplyMetaStatus("read", "sent")).toBe(false);
    expect(shouldApplyMetaStatus("failed", "sent")).toBe(false);
    expect(shouldApplyMetaStatus("sending", "failed")).toBe(true);
  });

  it("requires every declared text placeholder before sending a variable-bearing template", () => {
    const body = "Hello {{1}}, your appointment is {{2}}.";
    expect(templateBodyVariableCount(body)).toBe(2);
    expect(validateTemplateBodyComponents(body, [{ type: "body", parameters: [{ type: "text", text: "James" }, { type: "text", text: "tomorrow" }] }])).toEqual([{ type: "body", parameters: [{ type: "text", text: "James" }, { type: "text", text: "tomorrow" }] }]);
    expect(() => validateTemplateBodyComponents(body, [{ type: "body", parameters: [{ type: "text", text: "James" }] }])).toThrow("exactly 2 text variables");
    expect(() => validateTemplateBodyComponents("A static template", [{ type: "body", parameters: [{ type: "text", text: "unexpected" }] }])).toThrow("does not declare body variables");
  });
});
