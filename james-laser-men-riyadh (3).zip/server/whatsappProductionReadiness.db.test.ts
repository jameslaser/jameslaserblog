import { createHash } from "node:crypto";
import { and, eq, sql } from "drizzle-orm";
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import {
  activityLogs,
  appointments,
  clinicSettings,
  patients,
  whatsappActivationPrerequisites,
  whatsappAutomationJobs,
  whatsappAutomationTemplateDefinitions,
  whatsappContacts,
  whatsappConversations,
  whatsappMessages,
  whatsappSettings,
  whatsappTemplates,
  whatsappWebhookEvents,
} from "../drizzle/schema";
import { getDb, markAppointmentAttendance, updateAppointmentDetails } from "./db";
import {
  queueWhatsAppAutomationJob,
  reconcileWhatsAppAutomation,
  recordWhatsAppActivationPrerequisite,
  runDueWhatsAppAutomation,
  setWhatsAppAutomationActivation,
  updateWhatsAppConsent,
} from "./whatsappAutomation";
import { ingestMetaWhatsAppWebhook } from "./whatsappService";

const canRun = process.env.WHATSAPP_TEST_DB === "1" && process.env.MYSQL_URL?.includes("whatsapp_lifecycle_test");
const actor = { id: 1, name: "Isolated Test Owner" };
const fetchMock = vi.fn();
let sequence = 0;

function riyadhDatePlus(days: number) {
  const value = new Date();
  value.setUTCDate(value.getUTCDate() + days);
  return new Intl.DateTimeFormat("sv-SE", { timeZone: "Asia/Riyadh", year: "numeric", month: "2-digit", day: "2-digit" }).format(value);
}

async function database() {
  const db = await getDb();
  if (!db) throw new Error("The isolated WhatsApp test database is unavailable.");
  return db;
}

async function resetDatabase() {
  if (!canRun) throw new Error("Refusing to reset outside the isolated WhatsApp lifecycle test database.");
  const db = await database();
  await db.execute(sql.raw("SET FOREIGN_KEY_CHECKS = 0"));
  for (const table of [
    "whatsappActivationPrerequisites",
    "whatsappAutomationLogs",
    "whatsappWebhookEvents",
    "whatsappMessages",
    "whatsappAutomationJobs",
    "whatsappAutomationTemplateDefinitions",
    "whatsappTemplates",
    "whatsappConversations",
    "whatsappContacts",
    "whatsappRetouchRequests",
    "whatsappSettings",
    "activityLogs",
    "appointments",
    "patients",
    "clinicSettings",
    "users",
  ]) await db.execute(sql.raw(`TRUNCATE TABLE \`${table}\``));
  await db.execute(sql.raw("SET FOREIGN_KEY_CHECKS = 1"));
  await db.execute(sql.raw("INSERT INTO `users` (`id`, `openId`, `name`, `role`, `lastSignedIn`) VALUES (1, 'isolated-test-owner', 'Isolated Test Owner', 'owner', NOW())"));
  await db.insert(clinicSettings).values({
    businessName: "Isolated Test Clinic",
    specialistName: "Nurse James",
    clinicName: "Isolated Test Clinic",
    whatsapp: "+966551234567",
    workingHours: "13:00-22:00",
    defaultLanguage: "en",
  });
  await db.insert(whatsappSettings).values({
    automationEnabled: false,
    reminderSendingTime: "10:00",
    appointmentConfirmationEnabled: true,
    appointmentReminder24hEnabled: true,
    appointmentFinalReminderEnabled: true,
    appointmentRescheduleEnabled: true,
    appointmentCancellationEnabled: true,
  });
}

async function createAppointment(input: { language?: "en" | "ar"; rollout?: boolean; consent?: "unknown" | "opted_in" | "opted_out"; status?: "confirmed" | "cancelled"; date?: string; time?: string } = {}) {
  const db = await database();
  const unique = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const whatsapp = `+96655${String(Math.floor(Math.random() * 90_000_000) + 10_000_000)}`;
  const patient = await db.insert(patients).values({
    fullName: `Isolated Patient ${unique}`,
    mrn: `T-${unique}`.slice(0, 60),
    whatsapp,
    nationality: "Saudi Arabian",
    treatmentArea: "Chest",
    preferredContact: "WhatsApp",
  }).$returningId();
  const patientId = Number(patient[0]?.id);
  const appointment = await db.insert(appointments).values({
    patientId,
    patientName: `Isolated Patient ${unique}`,
    contactNumber: whatsapp,
    whatsapp,
    mrn: `T-${unique}`.slice(0, 60),
    appointmentDate: input.date ?? riyadhDatePlus(7),
    appointmentTime: input.time ?? "18:00",
    treatmentArea: "Chest",
    treatmentAreas: JSON.stringify(["Chest"]),
    machine: "DEKA AGAIN",
    visitType: "session",
    whatsappConsentStatus: input.consent ?? "unknown",
    whatsappConsentSource: input.consent === "opted_in" ? "isolated test evidence" : null,
    whatsappConsentAt: input.consent === "opted_in" ? new Date() : null,
    whatsappOptedOutAt: input.consent === "opted_out" ? new Date() : null,
    whatsappAutomationInitializedAt: input.rollout === false ? null : new Date(),
    whatsappAutomationVersion: 1,
    originalConsentLanguage: input.language ?? "en",
    consentSignatureStatus: "received",
    source: "manual_admin",
    status: input.status ?? "confirmed",
  }).$returningId();
  return { appointmentId: Number(appointment[0]?.id), patientId, whatsapp };
}

async function mapTemplateForJob(appointmentId: number, jobType = "appointment_confirmation") {
  const db = await database();
  const [job] = await db.select().from(whatsappAutomationJobs).where(and(eq(whatsappAutomationJobs.appointmentId, appointmentId), eq(whatsappAutomationJobs.jobType, jobType as typeof whatsappAutomationJobs.$inferSelect["jobType"]))).limit(1);
  if (!job) throw new Error(`Expected ${jobType} job.`);
  const language = job.language === "ar" ? "ar" : "en";
  const templateName = `isolated_${jobType}_${language}`;
  await db.insert(whatsappTemplates).values({ businessAccountId: "isolated-test-business", templateName, language: language === "ar" ? "ar_SA" : "en_US", status: "approved" }).onDuplicateKeyUpdate({ set: { status: "approved" } });
  await db.update(whatsappAutomationTemplateDefinitions).set({ providerTemplateName: templateName, providerTemplateId: `template-${templateName}` })
    .where(and(eq(whatsappAutomationTemplateDefinitions.templateKey, job.templateKey), eq(whatsappAutomationTemplateDefinitions.language, language)));
  return job;
}

async function jobFor(appointmentId: number, jobType = "appointment_confirmation") {
  const db = await database();
  const [job] = await db.select().from(whatsappAutomationJobs).where(and(eq(whatsappAutomationJobs.appointmentId, appointmentId), eq(whatsappAutomationJobs.jobType, jobType as typeof whatsappAutomationJobs.$inferSelect["jobType"]))).limit(1);
  if (!job) throw new Error(`Expected ${jobType} job.`);
  return job;
}

async function makeJobReady(appointmentId: number) {
  await reconcileWhatsAppAutomation();
  const job = await mapTemplateForJob(appointmentId);
  return jobFor(appointmentId, job.jobType);
}

describe.skipIf(!canRun)("WhatsApp production readiness lifecycle — isolated database", () => {
  beforeAll(() => {
    process.env.META_APP_ID = "isolated-app";
    process.env.META_APP_SECRET = "isolated-secret";
    process.env.WHATSAPP_ACCESS_TOKEN = "isolated-token";
    process.env.WHATSAPP_PHONE_NUMBER_ID = "isolated-phone";
    process.env.WHATSAPP_BUSINESS_ACCOUNT_ID = "isolated-business";
    process.env.WHATSAPP_WEBHOOK_VERIFY_TOKEN = "isolated-verify";
    process.env.META_GRAPH_API_VERSION = "v99.0";
    vi.stubGlobal("fetch", fetchMock);
  });

  beforeEach(async () => {
    sequence = 0;
    fetchMock.mockReset();
    fetchMock.mockImplementation(async () => new Response(JSON.stringify({ messages: [{ id: `wamid.isolated.${++sequence}` }] }), { status: 200 }));
    await resetDatabase();
  });

  afterAll(() => vi.unstubAllGlobals());

  it("excludes historical appointments and their legacy reminders while enrolling new appointments exactly once", async () => {
    const db = await database();
    const legacy = await createAppointment({ rollout: false, consent: "opted_in" });
    await db.insert(whatsappAutomationJobs).values({
      appointmentId: legacy.appointmentId,
      jobType: "session_reminder",
      scheduleKey: `legacy:${legacy.appointmentId}`,
      scheduledFor: new Date(),
      language: "en",
      templateKey: "session_reminder",
      status: "scheduled",
    });
    const current = await createAppointment({ language: "en", consent: "opted_in" });

    await reconcileWhatsAppAutomation();
    await reconcileWhatsAppAutomation();

    const legacyJobs = await db.select().from(whatsappAutomationJobs).where(eq(whatsappAutomationJobs.appointmentId, legacy.appointmentId));
    const currentJobs = await db.select().from(whatsappAutomationJobs).where(eq(whatsappAutomationJobs.appointmentId, current.appointmentId));
    expect(legacyJobs).toHaveLength(1);
    expect(legacyJobs[0]?.status).toBe("cancelled");
    expect(currentJobs.filter(job => job.jobType === "session_reminder" || job.jobType === "session_reminder_2h")).toHaveLength(0);
    expect(currentJobs.filter(job => job.jobType === "appointment_confirmation")).toHaveLength(1);
  });

  it("uses explicit appointment/request language before contact language and clinic default", async () => {
    const db = await database();
    const arabic = await createAppointment({ language: "ar" });
    const english = await createAppointment({ language: "en" });
    for (const item of [arabic, english]) {
      await db.insert(whatsappContacts).values({ waId: item.whatsapp.replace(/\D/g, ""), phoneNumber: item.whatsapp, normalizedPhone: item.whatsapp, language: item.appointmentId === arabic.appointmentId ? "en" : "ar" });
      const [contact] = await db.select().from(whatsappContacts).where(eq(whatsappContacts.normalizedPhone, item.whatsapp)).limit(1);
      await db.insert(whatsappConversations).values({ contactId: contact!.id, linkedAppointmentId: item.appointmentId });
    }

    await reconcileWhatsAppAutomation();

    expect((await jobFor(arabic.appointmentId)).language).toBe("ar");
    expect((await jobFor(english.appointmentId)).language).toBe("en");
  });

  it("rejects queueing before verified consent and before a language-matched approved template exists", async () => {
    const db = await database();
    const fixture = await createAppointment({ language: "ar", consent: "unknown" });
    await reconcileWhatsAppAutomation();
    const initial = await jobFor(fixture.appointmentId);

    await expect(queueWhatsAppAutomationJob(initial.id, "staff requested controlled queue", actor)).rejects.toThrow("Verified WhatsApp opt-in");
    expect((await jobFor(fixture.appointmentId)).status).toBe("scheduled");

    await db.update(appointments).set({ whatsappConsentStatus: "opted_in", whatsappConsentAt: new Date(), whatsappConsentSource: "isolated test evidence" }).where(eq(appointments.id, fixture.appointmentId));
    await expect(queueWhatsAppAutomationJob(initial.id, "staff requested controlled queue", actor)).rejects.toThrow("approved WhatsApp template for the appointment language");
    expect((await jobFor(fixture.appointmentId)).status).toBe("scheduled");
  });

  it("allows only one valid job when the same Queue Now action is repeated or concurrent", async () => {
    const db = await database();
    const fixture = await createAppointment({ consent: "opted_in" });
    const job = await makeJobReady(fixture.appointmentId);

    await queueWhatsAppAutomationJob(job.id, "first controlled queue request", actor);
    await expect(queueWhatsAppAutomationJob(job.id, "duplicate controlled queue request", actor)).rejects.toThrow("Only an unsent, active reminder");
    await db.update(whatsappAutomationJobs).set({ status: "scheduled" }).where(eq(whatsappAutomationJobs.id, job.id));

    const results = await Promise.allSettled([
      queueWhatsAppAutomationJob(job.id, "concurrent request one", actor),
      queueWhatsAppAutomationJob(job.id, "concurrent request two", actor),
    ]);
    const stored = await jobFor(fixture.appointmentId);
    expect(results.filter(result => result.status === "fulfilled")).toHaveLength(1);
    expect(stored.status).toBe("queued");
    expect((await db.select().from(whatsappAutomationJobs).where(eq(whatsappAutomationJobs.appointmentId, fixture.appointmentId))).filter(item => item.status === "queued")).toHaveLength(1);
  });

  it("prevents a worker or scheduler retry from creating another provider submission", async () => {
    const db = await database();
    const fixture = await createAppointment({ consent: "opted_in" });
    await makeJobReady(fixture.appointmentId);
    await db.update(whatsappSettings).set({ automationEnabled: true }).where(eq(whatsappSettings.id, 1));

    expect((await runDueWhatsAppAutomation()).processed).toBe(1);
    expect((await runDueWhatsAppAutomation()).processed).toBe(0);
    expect(fetchMock).toHaveBeenCalledTimes(1);

    const stored = await jobFor(fixture.appointmentId);
    expect(stored.status).toBe("provider_accepted");
    expect(stored.providerMessageId).toBeTruthy();
  });

  it("invalidates old lifecycle jobs after repeated reschedules and creates one current-version reschedule job", async () => {
    const db = await database();
    const fixture = await createAppointment({ consent: "opted_in", date: riyadhDatePlus(10), time: "18:00" });
    await reconcileWhatsAppAutomation();
    const original = await jobFor(fixture.appointmentId);
    const newDate = riyadhDatePlus(12);
    const update = {
      appointmentId: fixture.appointmentId,
      fullName: "Isolated Patient",
      mrn: `T-${fixture.appointmentId}`,
      nationality: "Saudi Arabian",
      contactNumber: fixture.whatsapp,
      whatsapp: fixture.whatsapp,
      email: null,
      appointmentDate: newDate,
      appointmentTime: "19:00",
      machine: "DEKA AGAIN" as const,
      visitType: "session" as const,
      treatmentAreas: ["Chest"],
      nextFollowUpDate: null,
      nextFollowUpType: null,
      notes: "Isolated reschedule test",
    };

    await updateAppointmentDetails(update, actor.name);
    await reconcileWhatsAppAutomation();
    await updateAppointmentDetails(update, actor.name);
    await reconcileWhatsAppAutomation();

    const [appointment] = await db.select().from(appointments).where(eq(appointments.id, fixture.appointmentId)).limit(1);
    const jobs = await db.select().from(whatsappAutomationJobs).where(eq(whatsappAutomationJobs.appointmentId, fixture.appointmentId));
    expect(appointment?.whatsappAutomationVersion).toBe(2);
    expect(jobs.find(job => job.id === original.id)?.status).toBe("cancelled");
    expect(jobs.filter(job => job.jobType === "appointment_rescheduled" && job.scheduleKey.includes("v2:en"))).toHaveLength(1);
  });

  it("processes a provider status webhook once and leaves its replay idempotent", async () => {
    const db = await database();
    const fixture = await createAppointment({ consent: "opted_in" });
    await makeJobReady(fixture.appointmentId);
    await db.update(whatsappSettings).set({ automationEnabled: true }).where(eq(whatsappSettings.id, 1));
    await runDueWhatsAppAutomation();
    const job = await jobFor(fixture.appointmentId);
    const payload = { object: "whatsapp_business_account", entry: [{ changes: [{ field: "messages", value: { statuses: [{ id: job.providerMessageId!, status: "sent", timestamp: String(Math.floor(Date.now() / 1000)) }] } }] }] };
    const fingerprint = createHash("sha256").update(JSON.stringify(payload)).digest("hex");

    expect((await ingestMetaWhatsAppWebhook({ fingerprint, payload })).updatedStatuses).toBe(1);
    expect((await ingestMetaWhatsAppWebhook({ fingerprint, payload })).duplicate).toBe(true);
    expect((await jobFor(fixture.appointmentId)).status).toBe("sent");
    expect(await db.select().from(whatsappWebhookEvents).where(eq(whatsappWebhookEvents.eventFingerprint, fingerprint))).toHaveLength(1);
  });

  it("processes concurrent copies of the same provider webhook exactly once", async () => {
    const db = await database();
    const fixture = await createAppointment({ consent: "opted_in" });
    await makeJobReady(fixture.appointmentId);
    await db.update(whatsappSettings).set({ automationEnabled: true }).where(eq(whatsappSettings.id, 1));
    await runDueWhatsAppAutomation();
    const job = await jobFor(fixture.appointmentId);
    const payload = { object: "whatsapp_business_account", entry: [{ changes: [{ field: "messages", value: { statuses: [{ id: job.providerMessageId!, status: "sent", timestamp: String(Math.floor(Date.now() / 1000)) }] } }] }] };
    const fingerprint = createHash("sha256").update(JSON.stringify(payload)).digest("hex");

    const results = await Promise.all([
      ingestMetaWhatsAppWebhook({ fingerprint, payload }),
      ingestMetaWhatsAppWebhook({ fingerprint, payload }),
    ]);
    expect(results.filter(result => result.updatedStatuses === 1)).toHaveLength(1);
    expect(results.filter(result => result.duplicate)).toHaveLength(1);
    expect(await db.select().from(whatsappWebhookEvents).where(eq(whatsappWebhookEvents.eventFingerprint, fingerprint))).toHaveLength(1);
  });

  it("reclaims an interrupted webhook receipt only after its processing lease expires", async () => {
    const db = await database();
    const fixture = await createAppointment({ consent: "opted_in" });
    await makeJobReady(fixture.appointmentId);
    await db.update(whatsappSettings).set({ automationEnabled: true }).where(eq(whatsappSettings.id, 1));
    await runDueWhatsAppAutomation();
    const job = await jobFor(fixture.appointmentId);
    const payload = { object: "whatsapp_business_account", entry: [{ changes: [{ field: "messages", value: { statuses: [{ id: job.providerMessageId!, status: "sent", timestamp: String(Math.floor(Date.now() / 1000)) }] } }] }] };
    const fingerprint = createHash("sha256").update(JSON.stringify(payload)).digest("hex");
    await db.insert(whatsappWebhookEvents).values({ eventFingerprint: fingerprint, eventType: "messages", processingStatus: "processing", processingStartedAt: new Date(Date.now() - 6 * 60 * 1000) });

    const outcome = await ingestMetaWhatsAppWebhook({ fingerprint, payload });
    expect(outcome.retried).toBe(true);
    expect(outcome.updatedStatuses).toBe(1);
    expect((await jobFor(fixture.appointmentId)).status).toBe("sent");
  });

  it("creates a cancellation notice only after the protected staff cancellation and cancels active reminders on opt-out", async () => {
    const db = await database();
    const cancellation = await createAppointment({ consent: "opted_in", date: riyadhDatePlus(0) });
    await reconcileWhatsAppAutomation();
    await markAppointmentAttendance(cancellation.appointmentId, "cancelled");
    await reconcileWhatsAppAutomation();
    const cancelledJobs = await db.select().from(whatsappAutomationJobs).where(eq(whatsappAutomationJobs.appointmentId, cancellation.appointmentId));
    expect(cancelledJobs.filter(job => job.jobType === "appointment_cancellation")).toHaveLength(1);
    expect(cancelledJobs.filter(job => job.jobType === "appointment_confirmation")[0]?.status).toBe("cancelled");

    const optOut = await createAppointment({ consent: "opted_in" });
    await reconcileWhatsAppAutomation();
    const job = await jobFor(optOut.appointmentId);
    await updateWhatsAppConsent({ appointmentId: optOut.appointmentId, status: "opted_out", source: "isolated opt-out test", version: "test" }, actor);
    expect((await jobFor(optOut.appointmentId)).status).toBe("cancelled");
    await expect(queueWhatsAppAutomationJob(job.id, "attempted queue after opt out", actor)).rejects.toThrow("Only an unsent, active reminder");
  });

  it("marks a provider-acceptance persistence interruption terminally and does not submit again", async () => {
    const db = await database();
    const fixture = await createAppointment({ consent: "opted_in" });
    await makeJobReady(fixture.appointmentId);
    await db.update(whatsappSettings).set({ automationEnabled: true }).where(eq(whatsappSettings.id, 1));
    const duplicateId = "wamid.isolated.persistence-interruption";
    fetchMock.mockResolvedValueOnce(new Response(JSON.stringify({ messages: [{ id: duplicateId }] }), { status: 200 }));
    await db.insert(whatsappContacts).values({ waId: `collision-${fixture.appointmentId}`, phoneNumber: "+966551111111", normalizedPhone: "+966551111111", language: "en" });
    const [contact] = await db.select().from(whatsappContacts).where(eq(whatsappContacts.waId, `collision-${fixture.appointmentId}`)).limit(1);
    await db.insert(whatsappConversations).values({ contactId: contact!.id });
    const [conversation] = await db.select().from(whatsappConversations).where(eq(whatsappConversations.contactId, contact!.id)).limit(1);
    await db.insert(whatsappMessages).values({ conversationId: conversation!.id, metaMessageId: duplicateId, direction: "outbound", messageType: "template", status: "sending" });

    await runDueWhatsAppAutomation();
    await runDueWhatsAppAutomation();

    const job = await jobFor(fixture.appointmentId);
    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(job.status).toBe("failed");
    expect(job.retryable).toBe(false);
    expect(job.lastErrorCode).toBe("provider_acceptance_persistence_uncertain");
  });

  it("persists permanent 4xx failures as non-retryable and temporary 5xx failures as retryable", async () => {
    const db = await database();
    const permanent = await createAppointment({ consent: "opted_in" });
    await makeJobReady(permanent.appointmentId);
    await db.update(whatsappSettings).set({ automationEnabled: true }).where(eq(whatsappSettings.id, 1));
    fetchMock.mockResolvedValueOnce(new Response(JSON.stringify({ error: { code: 131047, type: "OAuthException", message: "Invalid template" } }), { status: 400 }));
    await runDueWhatsAppAutomation();
    const failedPermanent = await jobFor(permanent.appointmentId);
    expect(failedPermanent.retryable).toBe(false);
    expect(failedPermanent.lastErrorHttpStatus).toBe(400);
    expect(failedPermanent.lastProviderErrorType).toBe("OAuthException");

    const temporary = await createAppointment({ consent: "opted_in" });
    await makeJobReady(temporary.appointmentId);
    fetchMock.mockResolvedValueOnce(new Response(JSON.stringify({ error: { code: 1, type: "ServerException", message: "Temporary provider error" } }), { status: 500 }));
    await runDueWhatsAppAutomation();
    const failedTemporary = await jobFor(temporary.appointmentId);
    expect(failedTemporary.retryable).toBe(true);
    expect(failedTemporary.lastErrorHttpStatus).toBe(500);

    const rateLimited = await createAppointment({ consent: "opted_in" });
    await makeJobReady(rateLimited.appointmentId);
    fetchMock.mockResolvedValueOnce(new Response(JSON.stringify({ error: { code: 130429, type: "OAuthException", message: "Rate limit reached" } }), { status: 429 }));
    await runDueWhatsAppAutomation();
    const failedRateLimit = await jobFor(rateLimited.appointmentId);
    expect(failedRateLimit.retryable).toBe(true);
    expect(failedRateLimit.lastErrorHttpStatus).toBe(429);

    const graphRateLimited = await createAppointment({ consent: "opted_in" });
    await makeJobReady(graphRateLimited.appointmentId);
    fetchMock.mockResolvedValueOnce(new Response(JSON.stringify({ error: { code: 130429, type: "OAuthException", message: "Cloud API message throughput has been reached" } }), { status: 400 }));
    await runDueWhatsAppAutomation();
    const failedGraphRateLimit = await jobFor(graphRateLimited.appointmentId);
    expect(failedGraphRateLimit.retryable).toBe(true);
    expect(failedGraphRateLimit.lastErrorHttpStatus).toBe(400);
    expect(failedGraphRateLimit.lastErrorCode).toContain("130429");
  });

  it("treats a network outcome without an authoritative Meta response as terminal pending reconciliation", async () => {
    const db = await database();
    const fixture = await createAppointment({ consent: "opted_in" });
    await makeJobReady(fixture.appointmentId);
    await db.update(whatsappSettings).set({ automationEnabled: true }).where(eq(whatsappSettings.id, 1));
    fetchMock.mockRejectedValueOnce(new Error("isolated network interruption"));

    await runDueWhatsAppAutomation();

    const failed = await jobFor(fixture.appointmentId);
    expect(failed.status).toBe("failed");
    expect(failed.retryable).toBe(false);
    expect(failed.providerMessageId).toBeNull();
  });

  it("creates fourteen explicit pending activation records and refuses activation while any evidence is missing", async () => {
    const db = await database();
    await setWhatsAppAutomationActivation({ enable: false }, actor);
    const prerequisites = await db.select().from(whatsappActivationPrerequisites);
    expect(prerequisites).toHaveLength(14);
    expect(prerequisites.every(item => item.status === "pending" && !item.evidenceReference && !item.verifiedAt)).toBe(true);

    await recordWhatsAppActivationPrerequisite({ prerequisiteKey: "migration_applied", evidenceReference: "isolated migration verification" }, actor);
    await expect(setWhatsAppAutomationActivation({ enable: true }, actor)).rejects.toThrow("fourteen owner-evidenced activation prerequisites");
    const [settings] = await db.select().from(whatsappSettings).limit(1);
    expect(settings?.automationEnabled).toBe(false);
  });
});
