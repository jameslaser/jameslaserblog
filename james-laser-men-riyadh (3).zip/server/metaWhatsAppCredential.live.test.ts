import { describe, expect, it } from "vitest";
import { fetchMetaWhatsAppTemplates, getMetaWhatsAppConfig } from "./metaWhatsApp";

const describeLive = process.env.RUN_LIVE_META_CREDENTIAL_TESTS === "1" ? describe : describe.skip;

describeLive("live Manus-managed Meta WhatsApp credentials", () => {
  it("uses server-side credentials to retrieve the clinic template inventory", async () => {
    const config = getMetaWhatsAppConfig();
    expect(config).not.toBeNull();

    const inventory = await fetchMetaWhatsAppTemplates();
    expect(Array.isArray(inventory.data)).toBe(true);
  }, 30_000);
});
