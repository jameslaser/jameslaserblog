import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const routerSource = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
const portalSource = readFileSync(new URL("../client/src/pages/AdminPortal.tsx", import.meta.url), "utf8");
const dbSource = readFileSync(new URL("./db.ts", import.meta.url), "utf8");

describe("WhatsApp operational RBAC", () => {
  it("permits reception staff only for defined operational inbox actions", () => {
    for (const procedure of ["conversations", "conversation", "linkCandidates", "markRead", "setStatus", "link", "contacts", "templates", "webhookEvents", "automationLogs", "sendText", "sendTemplate"]) {
      expect(routerSource).toMatch(new RegExp(`${procedure}: receptionProcedure`));
    }
    expect(routerSource).toContain("assign: adminProcedure");
    expect(routerSource).toContain("syncTemplates: adminProcedure");
    expect(routerSource).toContain("settings: adminProcedure");
  });

  it("shows the workspace to reception but excludes it from the content-editor navigation allowlist", () => {
    const contentEditorSection = portalSource.slice(portalSource.indexOf('user.role === "content_editor"'), portalSource.indexOf(': user.role === "reception"'));
    const receptionSection = portalSource.slice(portalSource.indexOf('user.role === "reception"'), portalSource.indexOf(': navWithBadges'));
    expect(receptionSection).toContain('"WhatsApp"');
    expect(contentEditorSection).not.toContain('"WhatsApp"');
  });

  it("keeps manual WhatsApp Business Web launch records administrator-only and content-free", () => {
    const auditFunction = dbSource.slice(dbSource.indexOf("export async function recordManualWhatsAppLaunch"), dbSource.indexOf("export type PublicAppointmentRequest"));
    expect(routerSource).toContain("recordManualWhatsAppLaunch: adminProcedure");
    expect(auditFunction).toContain('action: "Opened manual WhatsApp Business Web chat"');
    expect(auditFunction).toContain("actorUserId: actor.id");
    expect(auditFunction).toContain("subjectType: input.subjectType");
    expect(auditFunction).toContain("subjectId: input.subjectId");
    expect(auditFunction).not.toMatch(/patientName:|phone:|whatsapp:|message:/);
  });
});
