import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const viteServerSource = readFileSync(new URL("./_core/vite.ts", import.meta.url), "utf8");

describe("production SSR routing", () => {
  it("keeps the canonical root request out of static-file handling so it reaches SSR", () => {
    expect(viteServerSource).toContain('req.path === "/" ? next() : staticFiles(req, res, next)');
    expect(viteServerSource).toContain('app.use("*", async (req, res) => {');
    expect(viteServerSource).toContain('ssrModule.render(req.originalUrl, prefetch)');
  });
});
