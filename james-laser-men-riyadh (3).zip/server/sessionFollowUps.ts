import { and, asc, desc, eq, inArray, like, or } from "drizzle-orm";
import {
  activityLogs,
  appointments,
  followUps,
  machines,
  patients,
  sessionRecords,
} from "../drizzle/schema";
import { getDb } from "./db";

export type ClinicMachine = "DEKA AGAIN" | "CLARITY 2" | "GENTLE PROMAX" | "DUETTO MACHINE";
export type ClinicVisitType = "session" | "retouch";
export type SessionRecordStatus = "draft" | "completed" | "cancelled";
export type FollowUpWorkflowStatus = "pending" | "contacted" | "completed" | "cancelled";
export type FollowUpQueueStatus = "due" | "upcoming" | "overdue" | "unscheduled" | "completed" | "cancelled";

type Actor = { id: number; name: string | null };

function riyadhToday() {
  return new Intl.DateTimeFormat("sv-SE", {
    timeZone: "Asia/Riyadh",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
}

export function followUpQueueStatus(dueDate: string | null, status: FollowUpWorkflowStatus): FollowUpQueueStatus {
  if (status === "completed") return "completed";
  if (status === "cancelled") return "cancelled";
  if (!dueDate) return "unscheduled";
  const today = riyadhToday();
  if (dueDate < today) return "overdue";
  if (dueDate === today) return "due";
  return "upcoming";
}

function parseTreatmentAreas(value: string | null) {
  if (!value) return [] as string[];
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.filter((item): item is string => typeof item === "string") : [value];
  } catch {
    return value.split(",").map(item => item.trim()).filter(Boolean);
  }
}

export async function listSessionRecords(filters?: { query?: string; status?: SessionRecordStatus }) {
  const db = await getDb();
  if (!db) throw new Error("The session service is temporarily unavailable.");

  const rows = await db.select().from(sessionRecords)
    .orderBy(desc(sessionRecords.sessionDate), desc(sessionRecords.sessionTime), desc(sessionRecords.updatedAt))
    .limit(250);
  const query = filters?.query?.trim().toLowerCase();

  return rows
    .filter(row => !filters?.status || row.status === filters.status)
    .filter(row => !query || row.patientName.toLowerCase().includes(query) || row.mrn?.toLowerCase().includes(query) || row.sessionDate.includes(query))
    .map(row => ({ ...row, treatmentAreas: parseTreatmentAreas(row.treatmentAreas) }));
}

export async function listEligibleSessionAppointments(search?: string) {
  const db = await getDb();
  if (!db) throw new Error("The session service is temporarily unavailable.");

  const normalized = search?.trim();
  const where = normalized
    ? or(like(appointments.patientName, `%${normalized}%`), like(appointments.mrn, `%${normalized}%`))
    : undefined;
  const rows = await db.select({
    id: appointments.id,
    patientId: appointments.patientId,
    patientName: appointments.patientName,
    mrn: appointments.mrn,
    whatsapp: appointments.whatsapp,
    appointmentDate: appointments.appointmentDate,
    appointmentTime: appointments.appointmentTime,
    visitType: appointments.visitType,
    treatmentArea: appointments.treatmentArea,
    treatmentAreas: appointments.treatmentAreas,
    machine: appointments.machine,
    assignedStaff: appointments.assignedStaff,
    status: appointments.status,
  }).from(appointments)
    .where(where)
    .orderBy(desc(appointments.appointmentDate), desc(appointments.appointmentTime))
    .limit(250);

  const eligible = rows.filter(row => row.status === "arrived" || row.status === "completed");
  if (eligible.length === 0) return [];
  const recorded = await db.select({ appointmentId: sessionRecords.appointmentId }).from(sessionRecords)
    .where(inArray(sessionRecords.appointmentId, eligible.map(row => row.id)));
  const recordedIds = new Set(recorded.map(row => row.appointmentId));

  return eligible.filter(row => !recordedIds.has(row.id)).map(row => ({
    ...row,
    visitType: row.visitType === "retouch" ? "retouch" as const : "session" as const,
    treatmentAreas: parseTreatmentAreas(row.treatmentAreas ?? row.treatmentArea),
  }));
}

export type SaveSessionRecordInput = {
  id?: number;
  appointmentId: number;
  sessionDate: string;
  sessionTime: string;
  visitType: ClinicVisitType;
  treatmentAreas: string[];
  machine: ClinicMachine;
  nurseName: string | null;
  outcome: string | null;
  notes: string | null;
  status: SessionRecordStatus;
  nextFollowUpDate?: string | null;
  nextFollowUpType?: ClinicVisitType | null;
  followUpAssignedStaff?: string | null;
  followUpNotes?: string | null;
};

export async function saveSessionRecord(input: SaveSessionRecordInput, actor: Actor) {
  const db = await getDb();
  if (!db) throw new Error("The session service is temporarily unavailable.");

  return db.transaction(async tx => {
    const appointmentRows = await tx.select().from(appointments).where(eq(appointments.id, input.appointmentId)).limit(1);
    const appointment = appointmentRows[0];
    if (!appointment) throw new Error("The linked appointment was not found.");
    if (!input.id && appointment.status !== "arrived" && appointment.status !== "completed") {
      throw new Error("Mark the appointment arrived or completed before creating its session record.");
    }

    const machineRows = await tx.select({ machineNumber: machines.machineNumber }).from(machines).where(eq(machines.name, input.machine)).limit(1);
    const completedAt = input.status === "completed" ? new Date() : null;
    let sessionRecordId = input.id;
    let notesChanged = false;

    if (input.id) {
      const existingRows = await tx.select({ appointmentId: sessionRecords.appointmentId, notes: sessionRecords.notes }).from(sessionRecords).where(eq(sessionRecords.id, input.id)).limit(1);
      if (!existingRows[0]) throw new Error("The session record was not found.");
      if (existingRows[0].appointmentId !== input.appointmentId) throw new Error("A session record cannot be moved to a different appointment.");
      notesChanged = existingRows[0].notes !== input.notes;
      await tx.update(sessionRecords).set({
        sessionDate: input.sessionDate,
        sessionTime: input.sessionTime,
        visitType: input.visitType,
        treatmentAreas: JSON.stringify(input.treatmentAreas),
        machine: input.machine,
        machineNumber: machineRows[0]?.machineNumber ?? null,
        nurseName: input.nurseName,
        outcome: input.outcome,
        notes: input.notes,
        status: input.status,
        updatedByUserId: actor.id,
        completedAt,
      }).where(eq(sessionRecords.id, input.id));
    } else {
      const inserted = await tx.insert(sessionRecords).values({
        appointmentId: appointment.id,
        patientId: appointment.patientId,
        patientName: appointment.patientName,
        mrn: appointment.mrn,
        whatsapp: appointment.whatsapp,
        sessionDate: input.sessionDate,
        sessionTime: input.sessionTime,
        visitType: input.visitType,
        treatmentAreas: JSON.stringify(input.treatmentAreas),
        machine: input.machine,
        machineNumber: machineRows[0]?.machineNumber ?? null,
        nurseName: input.nurseName || actor.name,
        outcome: input.outcome,
        notes: input.notes,
        status: input.status,
        createdByUserId: actor.id,
        updatedByUserId: actor.id,
        completedAt,
      });
      sessionRecordId = Number(inserted[0].insertId);
    }

    if (!sessionRecordId) throw new Error("The session record could not be saved.");

    if (input.nextFollowUpDate && input.nextFollowUpType) {
      const existingFollowUp = await tx.select({ id: followUps.id, sessionRecordId: followUps.sessionRecordId }).from(followUps)
        .where(or(eq(followUps.sessionRecordId, sessionRecordId), eq(followUps.appointmentId, appointment.id))).limit(1);
      if (existingFollowUp[0]) {
        await tx.update(followUps).set({
          sessionRecordId,
          patientId: appointment.patientId,
          patientName: appointment.patientName,
          mrn: appointment.mrn,
          whatsapp: appointment.whatsapp,
          followUpType: input.nextFollowUpType,
          dueDate: input.nextFollowUpDate,
          assignedStaff: input.followUpAssignedStaff,
          notes: input.followUpNotes,
          updatedByUserId: actor.id,
        }).where(eq(followUps.id, existingFollowUp[0].id));
      } else {
        await tx.insert(followUps).values({
          appointmentId: appointment.id,
          sessionRecordId,
          patientId: appointment.patientId,
          patientName: appointment.patientName,
          mrn: appointment.mrn,
          whatsapp: appointment.whatsapp,
          followUpType: input.nextFollowUpType,
          dueDate: input.nextFollowUpDate,
          source: "session",
          assignedStaff: input.followUpAssignedStaff,
          notes: input.followUpNotes,
          createdByUserId: actor.id,
          updatedByUserId: actor.id,
        });
      }
      await tx.update(appointments).set({
        nextFollowUpDate: input.nextFollowUpDate,
        nextFollowUpType: input.nextFollowUpType,
      }).where(eq(appointments.id, appointment.id));
    }

    await tx.insert(activityLogs).values({
      actorUserId: actor.id,
      actorName: actor.name,
      action: input.id ? notesChanged ? "Updated private nurse's notes on session record" : "Updated session record" : "Created session record",
      subjectType: "session_record",
      subjectId: sessionRecordId,
    });
    return { sessionRecordId };
  });
}

export type FinishAppointmentWithPostSessionNotesInput = {
  appointmentId: number;
  nurseName: string | null;
  outcome: string;
  notes: string;
};

/**
 * Completes an arrived appointment only while recording its protected post-session
 * treatment record. Both updates share one transaction so an appointment cannot
 * be finished without its required outcome and nurse's notes.
 */
export async function finishAppointmentWithPostSessionNotes(input: FinishAppointmentWithPostSessionNotesInput, actor: Actor) {
  const db = await getDb();
  if (!db) throw new Error("The session service is temporarily unavailable.");

  return db.transaction(async tx => {
    const appointmentRows = await tx.select().from(appointments).where(eq(appointments.id, input.appointmentId)).limit(1);
    const appointment = appointmentRows[0];
    if (!appointment) throw new Error("The linked appointment was not found.");
    if (appointment.appointmentDate !== riyadhToday()) throw new Error("Only today's Riyadh arrived appointments can be finished.");
    if (appointment.status !== "arrived") throw new Error("Only an arrived appointment can be finished with post-session notes.");

    const existingRecord = await tx.select({ id: sessionRecords.id }).from(sessionRecords)
      .where(eq(sessionRecords.appointmentId, appointment.id)).limit(1);
    if (existingRecord[0]) throw new Error("A protected session record already exists for this appointment.");

    const visitType: ClinicVisitType | null = appointment.visitType === "retouch"
      ? "retouch"
      : appointment.visitType === "session"
        ? "session"
        : null;
    if (!visitType || !appointment.machine) throw new Error("Record the visit type and clinic machine before finishing the appointment.");

    const treatmentAreas = parseTreatmentAreas(appointment.treatmentAreas ?? appointment.treatmentArea);
    if (treatmentAreas.length === 0) throw new Error("Record at least one treatment area before finishing the appointment.");

    const machineRows = await tx.select({ machineNumber: machines.machineNumber }).from(machines).where(eq(machines.name, appointment.machine)).limit(1);
    const completedAt = new Date();
    const inserted = await tx.insert(sessionRecords).values({
      appointmentId: appointment.id,
      patientId: appointment.patientId,
      patientName: appointment.patientName,
      mrn: appointment.mrn,
      whatsapp: appointment.whatsapp,
      sessionDate: appointment.appointmentDate,
      sessionTime: appointment.appointmentTime,
      visitType,
      treatmentAreas: JSON.stringify(treatmentAreas),
      machine: appointment.machine,
      machineNumber: machineRows[0]?.machineNumber ?? null,
      nurseName: input.nurseName || actor.name,
      outcome: input.outcome,
      notes: input.notes,
      status: "completed",
      createdByUserId: actor.id,
      updatedByUserId: actor.id,
      completedAt,
    });
    const sessionRecordId = Number(inserted[0].insertId);

    const updated = await tx.update(appointments).set({ status: "completed" }).where(and(
      eq(appointments.id, appointment.id),
      eq(appointments.appointmentDate, riyadhToday()),
      eq(appointments.status, "arrived"),
    ));
    if (updated[0].affectedRows !== 1) throw new Error("The appointment changed before it could be finished. Refresh and try again.");

    await tx.insert(activityLogs).values({
      actorUserId: actor.id,
      actorName: actor.name,
      action: "Finished appointment and recorded post-session notes",
      subjectType: "appointment",
      subjectId: appointment.id,
    });
    await tx.insert(activityLogs).values({
      actorUserId: actor.id,
      actorName: actor.name,
      action: "Created session record from post-session notes",
      subjectType: "session_record",
      subjectId: sessionRecordId,
    });
    return { sessionRecordId };
  });
}

export async function listFollowUps() {
  const db = await getDb();
  if (!db) throw new Error("The follow-up service is temporarily unavailable.");

  const [trackedRows, appointmentRows] = await Promise.all([
    db.select().from(followUps).orderBy(asc(followUps.dueDate), desc(followUps.updatedAt)).limit(250),
    db.select({
      id: appointments.id,
      patientId: appointments.patientId,
      patientName: appointments.patientName,
      mrn: appointments.mrn,
      whatsapp: appointments.whatsapp,
      nextFollowUpDate: appointments.nextFollowUpDate,
      nextFollowUpType: appointments.nextFollowUpType,
      visitType: appointments.visitType,
      assignedStaff: appointments.assignedStaff,
      appointmentDate: appointments.appointmentDate,
      appointmentTime: appointments.appointmentTime,
    }).from(appointments).orderBy(asc(appointments.nextFollowUpDate)).limit(500),
  ]);

  const trackedAppointmentIds = new Set(trackedRows.map(row => row.appointmentId).filter((id): id is number => id !== null));
  const tracked = trackedRows.map(row => ({
    kind: "tracked" as const,
    ...row,
    queueStatus: followUpQueueStatus(row.dueDate, row.status),
  }));
  const legacy = appointmentRows
    .filter(row => Boolean(row.nextFollowUpDate) && !trackedAppointmentIds.has(row.id))
    .map(row => ({
      kind: "legacy" as const,
      id: `appointment-${row.id}`,
      appointmentId: row.id,
      sessionRecordId: null,
      patientId: row.patientId,
      patientName: row.patientName,
      mrn: row.mrn,
      whatsapp: row.whatsapp,
      followUpType: row.nextFollowUpType ?? (row.visitType === "retouch" ? "retouch" as const : "session" as const),
      dueDate: row.nextFollowUpDate,
      status: "pending" as const,
      source: "appointment" as const,
      assignedStaff: row.assignedStaff,
      outcome: null,
      notes: `Legacy reminder from appointment ${row.appointmentDate} at ${row.appointmentTime}.`,
      createdByUserId: null,
      updatedByUserId: null,
      contactedAt: null,
      completedAt: null,
      createdAt: null,
      updatedAt: null,
      queueStatus: followUpQueueStatus(row.nextFollowUpDate, "pending"),
    }));

  return [...tracked, ...legacy].sort((a, b) => (a.dueDate ?? "9999-12-31").localeCompare(b.dueDate ?? "9999-12-31"));
}

export async function trackLegacyAppointmentFollowUp(appointmentId: number, actor: Actor) {
  const db = await getDb();
  if (!db) throw new Error("The follow-up service is temporarily unavailable.");

  return db.transaction(async tx => {
    const existing = await tx.select({ id: followUps.id }).from(followUps).where(eq(followUps.appointmentId, appointmentId)).limit(1);
    if (existing[0]) return { followUpId: existing[0].id };
    const rows = await tx.select().from(appointments).where(eq(appointments.id, appointmentId)).limit(1);
    const appointment = rows[0];
    if (!appointment?.nextFollowUpDate) throw new Error("This appointment does not have a legacy follow-up date to track.");
    const inserted = await tx.insert(followUps).values({
      appointmentId: appointment.id,
      patientId: appointment.patientId,
      patientName: appointment.patientName,
      mrn: appointment.mrn,
      whatsapp: appointment.whatsapp,
      followUpType: appointment.nextFollowUpType ?? (appointment.visitType === "retouch" ? "retouch" : "session"),
      dueDate: appointment.nextFollowUpDate,
      source: "appointment",
      assignedStaff: appointment.assignedStaff,
      createdByUserId: actor.id,
      updatedByUserId: actor.id,
    });
    const followUpId = Number(inserted[0].insertId);
    await tx.insert(activityLogs).values({ actorUserId: actor.id, actorName: actor.name, action: "Started tracking legacy follow-up", subjectType: "follow_up", subjectId: followUpId });
    return { followUpId };
  });
}

export async function createManualFollowUp(input: {
  patientId: number;
  followUpType: ClinicVisitType;
  dueDate: string;
  assignedStaff: string | null;
  notes: string | null;
}, actor: Actor) {
  const db = await getDb();
  if (!db) throw new Error("The follow-up service is temporarily unavailable.");

  return db.transaction(async tx => {
    const rows = await tx.select().from(patients).where(eq(patients.id, input.patientId)).limit(1);
    const patient = rows[0];
    if (!patient) throw new Error("The patient file was not found.");
    const inserted = await tx.insert(followUps).values({
      patientId: patient.id,
      patientName: patient.fullName,
      mrn: patient.mrn,
      whatsapp: patient.whatsapp,
      followUpType: input.followUpType,
      dueDate: input.dueDate,
      source: "manual",
      assignedStaff: input.assignedStaff,
      notes: input.notes,
      createdByUserId: actor.id,
      updatedByUserId: actor.id,
    });
    const followUpId = Number(inserted[0].insertId);
    await tx.insert(activityLogs).values({ actorUserId: actor.id, actorName: actor.name, action: "Created manual follow-up", subjectType: "follow_up", subjectId: followUpId });
    return { followUpId };
  });
}

export async function updateFollowUp(input: {
  id: number;
  followUpType: ClinicVisitType;
  dueDate: string | null;
  status: FollowUpWorkflowStatus;
  assignedStaff: string | null;
  outcome: string | null;
  notes: string | null;
}, actor: Actor) {
  const db = await getDb();
  if (!db) throw new Error("The follow-up service is temporarily unavailable.");

  return db.transaction(async tx => {
    const rows = await tx.select().from(followUps).where(eq(followUps.id, input.id)).limit(1);
    const current = rows[0];
    if (!current) throw new Error("The follow-up record was not found.");
    const contactedAt = input.status === "contacted" ? (current.contactedAt ?? new Date()) : current.contactedAt;
    const completedAt = input.status === "completed" ? (current.completedAt ?? new Date()) : null;
    await tx.update(followUps).set({
      followUpType: input.followUpType,
      dueDate: input.dueDate,
      status: input.status,
      assignedStaff: input.assignedStaff,
      outcome: input.outcome,
      notes: input.notes,
      updatedByUserId: actor.id,
      contactedAt,
      completedAt,
    }).where(eq(followUps.id, input.id));
    if (current.appointmentId && input.dueDate) {
      await tx.update(appointments).set({ nextFollowUpDate: input.dueDate, nextFollowUpType: input.followUpType }).where(eq(appointments.id, current.appointmentId));
    }
    await tx.insert(activityLogs).values({ actorUserId: actor.id, actorName: actor.name, action: `Updated follow-up status to ${input.status}`, subjectType: "follow_up", subjectId: input.id });
    return { followUpId: input.id };
  });
}
