import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("private e-signature session boundary", () => {
  it("binds a hashed one-time token to the immutable original consent set without creating appointments or patients", () => {
    const source = readFileSync(resolve(process.cwd(), "server/consentSignature.ts"), "utf8");

    expect(source).toContain('createHash("sha256")');
    expect(source).toContain("randomBytes(32).toString(\"base64url\")");
    expect(source).toContain("ORIGINAL_CONSENT_SET_REFERENCE");
    expect(source).toContain("ORIGINAL_CONSENT_DOCUMENTS");
    expect(source).toContain('status: "signed"');
    expect(source).toContain('consentSignatureStatus: "received"');
    expect(source).not.toContain("appointments).");
    expect(source).not.toContain("patients).");
  });

  it("expires pending sessions and stores a separate signature-evidence pack rather than altering source PDFs", () => {
    const source = readFileSync(resolve(process.cwd(), "server/consentSignature.ts"), "utf8");

    expect(source).toContain('status: "expired"');
    expect(source).toContain("signatureEvidenceKey");
    expect(source).toContain("signatureEvidenceUrl");
    expect(source).toContain("storageGetSignedUrl(session.key)");
    expect(source).toContain("signatureEvidenceUrl: null");
    expect(source).toContain("e-signature-evidence-v1");
    expect(source).toContain("originalDocuments: JSON.parse(session.sourceConsentDocuments)");
  });
});
