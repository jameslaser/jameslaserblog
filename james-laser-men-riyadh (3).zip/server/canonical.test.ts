import express from "express";
import { afterEach, describe, expect, it } from "vitest";
import { registerCanonicalRedirects } from "./canonical";

const servers: Array<ReturnType<ReturnType<typeof express>["listen"]>> = [];
afterEach(async () => { await Promise.all(servers.splice(0).map(server => new Promise<void>(resolve => server.close(() => resolve())))); });

async function serve() {
  const app = express();
  registerCanonicalRedirects(app);
  app.use((_req, res) => res.status(204).end());
  const server = app.listen(0); servers.push(server);
  await new Promise<void>(resolve => server.once("listening", () => resolve()));
  const address = server.address(); if (!address || typeof address === "string") throw new Error("Test server did not bind.");
  return `http://127.0.0.1:${address.port}`;
}

describe("canonical public URL middleware", () => {
  it("consolidates known duplicate English paths in one redirect while preserving queries", async () => {
    const url = await serve();
    const response = await fetch(`${url}/en?source=legacy`, { redirect: "manual" });
    expect(response.status).toBe(301);
    expect(response.headers.get("location")).toBe("/?source=legacy");
  });

  it("consolidates legacy content and appointment paths without affecting private paths", async () => {
    const url = await serve();
    const treatment = await fetch(`${url}/treatments`, { redirect: "manual" });
    const appointment = await fetch(`${url}/en/appointment`, { redirect: "manual" });
    const admin = await fetch(`${url}/admin`, { redirect: "manual" });
    expect(treatment.headers.get("location")).toBe("/en/treatments");
    expect(appointment.headers.get("location")).toBe("/appointment");
    expect(admin.status).toBe(204);
  });

  it("permanently redirects legacy guide hubs and articles to canonical blog URLs", async () => {
    const url = await serve();
    const hub = await fetch(`${url}/guide`, { redirect: "manual" });
    const english = await fetch(`${url}/en/guide/laser-preparation?source=old`, { redirect: "manual" });
    const arabic = await fetch(`${url}/ar/guide/laser-preparation`, { redirect: "manual" });
    expect(hub.headers.get("location")).toBe("/en/blog");
    expect(english.headers.get("location")).toBe("/en/blog/laser-preparation?source=old");
    expect(arabic.headers.get("location")).toBe("/ar/blog/laser-preparation");
  });
});
