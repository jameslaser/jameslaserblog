import { describe, expect, it } from "vitest";

const verificationToken = process.env.WHATSAPP_WEBHOOK_VERIFY_TOKEN;
const baseUrl = process.env.WEBDEV_PREVIEW_URL ?? "http://127.0.0.1:3000";
const canVerifyLiveToken = Boolean(verificationToken && verificationToken.length >= 16);

describe.skipIf(!canVerifyLiveToken)("live WhatsApp webhook verification token", () => {
  it("accepts the server-only token without logging or exposing it", async () => {
    const challenge = "webhook-verification-test";
    const query = new URLSearchParams({
      "hub.mode": "subscribe",
      "hub.verify_token": verificationToken!,
      "hub.challenge": challenge,
    });

    const response = await fetch(`${baseUrl}/api/webhooks/whatsapp?${query}`);

    expect(response.status).toBe(200);
    expect(await response.text()).toBe(challenge);
  });
});
