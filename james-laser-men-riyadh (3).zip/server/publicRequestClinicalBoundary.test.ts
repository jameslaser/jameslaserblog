import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const schemaSource = readFileSync(new URL("../drizzle/schema.ts", import.meta.url), "utf8");
const dbSource = readFileSync(new URL("./db.ts", import.meta.url), "utf8");

describe("public appointment request clinical data boundary", () => {
  it("keeps clinical fields nullable when the public form does not assess them", () => {
    expect(schemaSource).toContain('takingMedication: boolean("takingMedication"),');
    expect(schemaSource).toContain('hadSevereSunExposure: boolean("hadSevereSunExposure"),');
    expect(schemaSource).not.toContain('takingMedication: boolean("takingMedication").notNull()');
  });

  it("writes unknown clinical answers as null instead of unasked false negatives", () => {
    expect(dbSource).toContain("takingMedication: null");
    expect(dbSource).toContain("tookVitaminD: null");
    expect(dbSource).toContain("hadSevereSunExposure: null");
  });
});
