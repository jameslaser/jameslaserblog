import { describe, expect, it } from "vitest";
import { hmsAppointmentIdentityKey, HMS_PROVIDER_SCOPED_REPORT_HEADERS, HMS_REPORT_HEADERS, markHmsPreviewDuplicates, parseHmsReportCsv } from "./hmsCsv";

const legacyHeader = HMS_REPORT_HEADERS.join(",");
const providerScopedHeader = HMS_PROVIDER_SCOPED_REPORT_HEADERS.join(",");
const providerScopedLabels = ["#", "APPTDATE", "From Appointment", "To Appointment", "PATMRN", "PATNAME", "Gender", "Age", "Nationality", "Telephone", "Remarks"].join(",");

function providerScopedCsv(provider: string, row: string[], repeatedRows: string[][] = []) {
  const metadata = ["AppType", "", "NotAttended", "DoctorName", provider, "", "", "", "", "", ""].join(",");
  const spacer = Array.from({ length: 11 }, () => "").join(",");
  const repeatedPage = repeatedRows.length
    ? `\r\n${metadata}\r\n${spacer}\r\n${providerScopedLabels}\r\n${repeatedRows.map(item => item.join(",")).join("\r\n")}\r\n`
    : "";
  return `\uFEFF${providerScopedHeader}\r\n${metadata}\r\n${spacer}\r\n${providerScopedLabels}\r\n${row.join(",")}\r\n${repeatedPage}`;
}

describe("HMS Report.csv parser", () => {
  it("requires the exact provider-scoped 11-column layout and never accepts a substituted spreadsheet layout", () => {
    const parsed = parseHmsReportCsv("Text1,Date\n1,25/08/2026");
    expect(parsed.rows).toHaveLength(0);
    expect(parsed.fatalErrors[0]).toContain("Expected the exact 11-column provider-scoped HMS appointment export");
  });

  it("rejects the provider-less legacy layout instead of relying on manual provider attestation", () => {
    const row = ["1", "25/08/2026", "8:00PM", "8:15PM", "23422", "Example", "M", "25", "Saudi", "0562397420", "Original remarks"];
    const parsed = parseHmsReportCsv(`${legacyHeader}\n${row.join(",")}`);
    expect(parsed.rows).toHaveLength(0);
    expect(parsed.providerAttestationRequired).toBe(false);
    expect(parsed.fatalErrors[0]).toContain("Provider-less HMS appointment exports are not accepted");
  });

  it("preserves raw source values while separately normalizing date, time, mobile, and safe suggestions", () => {
    const row = ["1", "25/08/2026", "8:00PM", "8:00PM", "23422", "Sample  Name  ", "M", "25", "Saudi", "0562397420", "وجه 3 جلسات 199 ريال"];
    const parsed = parseHmsReportCsv(providerScopedCsv("NR011", row));
    const appointment = parsed.rows[0]!;
    expect(parsed.fatalErrors).toEqual([]);
    expect(parsed.providerAttestationRequired).toBe(false);
    expect(parsed.providerVerifiedFromSource).toBe(true);
    expect(appointment.appointmentDate).toBe("2026-08-25");
    expect(appointment.appointmentStartTime).toBe("20:00");
    expect(appointment.appointmentEndTime).toBe("20:00");
    expect(appointment.originalTelephone).toBe("0562397420");
    expect(appointment.normalizedWhatsapp).toBe("+966562397420");
    expect(appointment.patientName).toBe("Sample  Name  ");
    expect(appointment.remarks).toBe("وجه 3 جلسات 199 ريال");
    expect(appointment.suggestedTreatment).toBe("FACE");
    expect(appointment.validation).toBe("WARNING");
    expect(appointment.warnings.some(item => item.includes("Start and end values are identical"))).toBe(true);
  });

  it.each(["NR011", "Mohamed Taha (JF)"])("accepts the exact provider-scoped export for %s and normalizes it to NR011 JAMES FLORES", provider => {
    const row = ["1", "07/09/2026", "9:00PM", "9:15PM", "23422", "Example", "M", "25", "Saudi", "0562397420", "Original remarks"];
    const parsed = parseHmsReportCsv(providerScopedCsv(provider, row));
    expect(parsed.fatalErrors).toEqual([]);
    expect(parsed.rows).toHaveLength(1);
    expect(parsed.rows[0]?.sourceRowNumber).toBe(1);
    expect(parsed.rows[0]?.appointmentStartTime).toBe("21:00");
    expect(parsed.providerAttestationRequired).toBe(false);
    expect(parsed.providerVerifiedFromSource).toBe(true);
    expect(parsed.sourceProvider).toBe(provider);
    expect(parsed.normalizedProviderCode).toBe("NR011");
    expect(parsed.normalizedProviderLabel).toBe("NR011 JAMES FLORES");
  });

  it("skips repeated report preambles between printed pages and retains only appointment rows", () => {
    const first = ["1", "07/09/2026", "7:00PM", "7:15PM", "23422", "First", "M", "25", "Saudi", "0562397420", "ديكا"];
    const second = ["2", "07/09/2026", "8:00PM", "8:15PM", "23423", "Second", "M", "26", "Saudi", "0562397421", "جنتل"];
    const parsed = parseHmsReportCsv(providerScopedCsv("Mohamed Taha (JF)", first, [second]));
    expect(parsed.fatalErrors).toEqual([]);
    expect(parsed.rows).toHaveLength(2);
    expect(parsed.rows.map(row => row.sourceRowNumber)).toEqual([1, 2]);
    expect(parsed.rows.map(row => row.suggestedMachine)).toEqual(["DEKA AGAIN", "GENTLE PROMAX"]);
  });

  it("excludes Attended history from the confirmed appointment result", () => {
    const row = ["1", "07/09/2026", "9:00PM", "9:15PM", "23422", "Example", "M", "25", "Saudi", "0562397420", "Original remarks"];
    const parsed = parseHmsReportCsv(providerScopedCsv("NR011", row).replaceAll("NotAttended", "Attended"));
    expect(parsed.rows).toEqual([]);
    expect(parsed.fatalErrors).toEqual([]);
    expect(parsed.providerVerifiedFromSource).toBe(true);
  });

  it("keeps NotAttended schedule rows and excludes a later Attended history page from the same authorized report", () => {
    const scheduled = ["1", "07/09/2026", "7:00PM", "7:15PM", "23422", "Scheduled example", "M", "25", "Saudi", "0562397420", "ديكا"];
    const excluded = ["2", "07/09/2026", "8:00PM", "8:15PM", "23423", "Excluded example", "M", "26", "Saudi", "0562397421", "جنتل"];
    const attendedPage = providerScopedCsv("NR011", excluded).replace(`\uFEFF${providerScopedHeader}\r\n`, "").replaceAll("NotAttended", "Attended");
    const parsed = parseHmsReportCsv(`${providerScopedCsv("NR011", scheduled)}${attendedPage}`);
    expect(parsed.fatalErrors).toEqual([]);
    expect(parsed.rows.map(row => row.patientName)).toEqual(["Scheduled example"]);
  });

  it("rejects an unrelated provider without fuzzy matching or returning appointment rows", () => {
    const row = ["1", "07/09/2026", "9:00PM", "9:15PM", "23422", "Example", "M", "25", "Saudi", "0562397420", "Original remarks"];
    const parsed = parseHmsReportCsv(providerScopedCsv("Mohamed Taha (JT)", row));
    expect(parsed.rows).toEqual([]);
    expect(parsed.providerVerifiedFromSource).toBe(false);
    expect(parsed.normalizedProviderCode).toBeNull();
    expect(parsed.fatalErrors[0]).toContain("provider is not authorized");
  });

  it("rejects a provider-scoped export when its metadata or table-label rows are changed", () => {
    const row = ["1", "07/09/2026", "9:00PM", "9:15PM", "23422", "Example", "M", "25", "Saudi", "0562397420", "Original remarks"];
    const changedLabels = providerScopedCsv("Mohamed Taha (JF)", row).replace("From Appointment", "Start Time");
    const parsed = parseHmsReportCsv(changedLabels);
    expect(parsed.rows).toEqual([]);
    expect(parsed.fatalErrors[0]).toContain("column labels is incomplete or reordered");
  });

  it("retains zero and unknown source values instead of inventing an MRN, sex, age, nationality, or end time", () => {
    const row = ["2", "24/08/2026", "1:00PM", "1:15PM", "0", "Example", "u", "0", "", "562397420", "رتوش- جيمس - ديكا"];
    const parsed = parseHmsReportCsv(providerScopedCsv("NR011", row));
    const appointment = parsed.rows[0]!;
    expect(appointment.mrn).toBeNull();
    expect(appointment.originalMrn).toBe("0");
    expect(appointment.normalizedSex).toBe("Unknown");
    expect(appointment.normalizedAge).toBeNull();
    expect(appointment.nationality).toBeNull();
    expect(appointment.normalizedWhatsapp).toBe("+966562397420");
    expect(appointment.suggestedVisitType).toBe("retouch");
    expect(appointment.suggestedMachine).toBe("DEKA AGAIN");
    expect(appointment.raw.Datasp_RPTAllAppointment_Screen_LastAppointment).toBe("1:15PM");
  });

  it("marks same-file, existing-source, and already-imported records as duplicate without changing source values", () => {
    const row = ["3", "24/08/2026", "1:00PM", "1:15PM", "123", "Example", "M", "25", "Saudi", "562397420", "Original remarks"];
    const parsed = parseHmsReportCsv(providerScopedCsv("NR011", row));
    const sourceRow = parsed.rows[0]!;
    const sameFile = markHmsPreviewDuplicates([sourceRow, { ...sourceRow }], false, new Set());
    expect(sameFile[0]?.validation).toBe("READY");
    expect(sameFile[1]?.validation).toBe("DUPLICATE");
    expect(sameFile[1]?.remarks).toBe("Original remarks");
    expect(markHmsPreviewDuplicates([sourceRow], false, new Set([sourceRow.fingerprint]))[0]?.validation).toBe("DUPLICATE");
    expect(markHmsPreviewDuplicates([sourceRow], true, new Set())[0]?.warnings).toContain("This exact file was already imported.");
  });

  it("skips a re-uploaded appointment when MRN, normalized phone number, date, and time already match while allowing a later visit", () => {
    const firstVisit = parseHmsReportCsv(providerScopedCsv("NR011", ["4", "24/08/2026", "1:00PM", "1:15PM", "123", "Example", "M", "25", "Saudi", "0562397420", "Original remarks"])).rows[0]!;
    const sameAppointmentWithDifferentSourceText = parseHmsReportCsv(providerScopedCsv("NR011", ["99", "24/08/2026", "1:00PM", "1:15PM", "123", "Example Updated", "M", "25", "Saudi", "+966 56 239 7420", "Corrected remarks"])).rows[0]!;
    const laterVisit = parseHmsReportCsv(providerScopedCsv("NR011", ["5", "31/08/2026", "1:00PM", "1:15PM", "123", "Example", "M", "25", "Saudi", "562397420", "Follow-up"])).rows[0]!;
    const identityKey = hmsAppointmentIdentityKey(firstVisit);

    expect(identityKey).toBeTruthy();
    expect(hmsAppointmentIdentityKey(sameAppointmentWithDifferentSourceText)).toBe(identityKey);
    expect(hmsAppointmentIdentityKey(laterVisit)).not.toBe(identityKey);
    expect(markHmsPreviewDuplicates([sameAppointmentWithDifferentSourceText], false, new Set(), new Set([identityKey!]))[0]?.validation).toBe("DUPLICATE");
    expect(markHmsPreviewDuplicates([sameAppointmentWithDifferentSourceText], false, new Set(), new Set([identityKey!]))[0]?.warnings.join(" ")).toContain("same MRN, normalized phone number, date, and time");
    expect(markHmsPreviewDuplicates([laterVisit], false, new Set(), new Set([identityKey!]))[0]?.validation).not.toBe("DUPLICATE");
  });
});
