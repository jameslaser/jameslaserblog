import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const source = readFileSync(resolve(import.meta.dirname, "_core/index.ts"), "utf8");

describe("WhatsApp scheduler authentication boundary", () => {
  it("rejects an absent or invalid session as cron-only before dispatch", () => {
    const start = source.indexOf('app.post("/api/scheduled/whatsapp-automation"');
    const end = source.indexOf("registerStorageProxy", start);
    const scheduler = source.slice(start, end);

    expect(scheduler).toContain("const user = await sdk.authenticateRequest(req).catch(() => null);");
    expect(scheduler).toContain('if (!user?.isCron || !user.taskUid) return res.status(403).json({ error: "cron-only" });');
    expect(scheduler).toContain("runDueWhatsAppAutomation(user.taskUid)");
    expect(scheduler).not.toContain("Invalid session cookie");
  });

  it("does not expose internal scheduler failures to unauthenticated callers", () => {
    const start = source.indexOf('app.post("/api/scheduled/whatsapp-automation"');
    const end = source.indexOf("registerStorageProxy", start);
    const scheduler = source.slice(start, end);

    expect(scheduler).toContain('error: "WhatsApp automation scheduler failed."');
    expect(scheduler).not.toContain("error instanceof Error ? error.message");
  });
});
