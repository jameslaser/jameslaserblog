export function resolveSinglePatientFile({
  mobilePatientId,
  mrnPatientId,
  linkedPatientId = null,
}: {
  mobilePatientId: number | null;
  mrnPatientId: number | null;
  linkedPatientId?: number | null;
}) {
  if (mobilePatientId && mrnPatientId && mobilePatientId !== mrnPatientId) {
    throw new Error("The supplied MRN and mobile number belong to different patient files. Review the patient file before saving.");
  }
  const matchedPatientId = mobilePatientId ?? mrnPatientId;
  if (linkedPatientId && matchedPatientId && linkedPatientId !== matchedPatientId) {
    throw new Error("This appointment is already linked to a different patient file. Update the patient file first.");
  }
  return linkedPatientId ?? matchedPatientId ?? null;
}
