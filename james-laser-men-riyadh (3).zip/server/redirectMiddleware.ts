import type { Express } from "express";
import { getRedirectDestination } from "./sharedBackend";

export function registerRedirectMiddleware(app: Express, lookup: (path: string) => Promise<string | null> = getRedirectDestination) {
  app.use(async (req, res, next) => {
    if (req.method !== "GET" && req.method !== "HEAD") return next();
    const path = req.path;
    if (path.startsWith("/api/") || path.startsWith("/admin") || path.startsWith("/manus-storage") || path.startsWith("/@") || path.startsWith("/__manus__")) return next();
    try {
      const destination = await lookup(path);
      if (!destination) return next();
      const query = req.originalUrl.includes("?") ? req.originalUrl.slice(req.originalUrl.indexOf("?")) : "";
      return res.redirect(301, `${destination}${query}`);
    } catch (error) {
      console.error("[Redirects] Lookup failed:", error);
      return next();
    }
  });
}
