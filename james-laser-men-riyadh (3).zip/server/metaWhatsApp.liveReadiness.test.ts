import { describe, expect, it } from "vitest";
import { fetchMetaWhatsAppTemplates, metaWhatsAppConfigured } from "./metaWhatsApp";

// A live Graph API call is an integration check, not a default unit-test action.
// Opt in explicitly when a credentialed Meta validation window is available.
const canVerifyMetaReadiness = process.env.RUN_LIVE_META_READINESS === "1" && [
  process.env.META_APP_ID,
  process.env.META_APP_SECRET,
  process.env.WHATSAPP_ACCESS_TOKEN,
  process.env.WHATSAPP_PHONE_NUMBER_ID,
  process.env.WHATSAPP_BUSINESS_ACCOUNT_ID,
  process.env.WHATSAPP_WEBHOOK_VERIFY_TOKEN,
  process.env.META_GRAPH_API_VERSION,
].every(Boolean);

describe.skipIf(!canVerifyMetaReadiness)("live Meta WhatsApp Cloud API readiness", () => {
  it("authenticates a read-only template request against the canonical business account", async () => {
    expect(metaWhatsAppConfigured()).toBe(true);
    const response = await fetchMetaWhatsAppTemplates();
    expect(Array.isArray(response.data ?? [])).toBe(true);
  }, 30_000);
});
