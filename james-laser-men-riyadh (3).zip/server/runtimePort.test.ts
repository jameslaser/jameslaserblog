import { describe, expect, it } from "vitest";
import { resolveRuntimePort } from "./_core/runtimePort";

describe("managed production runtime port", () => {
  it("requires the supplied PORT in production and never chooses a fallback port", () => {
    expect(() => resolveRuntimePort({ NODE_ENV: "production" })).toThrow("requires the PORT");
    expect(resolveRuntimePort({ NODE_ENV: "production", PORT: "8080" })).toEqual({ port: 8080, requireExactPort: true });
  });

  it("keeps the local development fallback without permitting invalid ports", () => {
    expect(resolveRuntimePort({ NODE_ENV: "development" })).toEqual({ port: 3000, requireExactPort: false });
    expect(() => resolveRuntimePort({ NODE_ENV: "production", PORT: "not-a-port" })).toThrow("valid TCP");
  });
});
