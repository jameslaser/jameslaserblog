import { beforeEach, describe, expect, it, vi } from "vitest";

const databaseMocks = vi.hoisted(() => ({
  select: vi.fn(),
  insert: vi.fn(),
  delete: vi.fn(),
}));

vi.mock("./db", () => ({
  getDb: vi.fn(async () => ({
    select: databaseMocks.select,
    insert: databaseMocks.insert,
    delete: databaseMocks.delete,
  })),
}));
vi.mock("./cms", () => ({ logCmsActivity: vi.fn() }));

import { guardPublicSubmission } from "./sharedBackend";
import { analyticsOverview } from "./sharedBackend";

function selectResult(rows: unknown[]) {
  const result = Promise.resolve(rows) as Promise<unknown[]> & { limit?: () => Promise<unknown[]> };
  result.limit = () => Promise.resolve(rows);
  return { from: () => ({ where: () => result }) };
}

describe("guardPublicSubmission", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    databaseMocks.insert.mockReturnValue({ values: vi.fn().mockResolvedValue(undefined) });
    databaseMocks.delete.mockReturnValue({ where: vi.fn().mockResolvedValue(undefined) });
  });

  it("rejects a varied repeat submission when the trusted signal has exceeded the ten-minute threshold", async () => {
    databaseMocks.select
      .mockReturnValueOnce(selectResult([]))
      .mockReturnValueOnce(selectResult([{ id: 1 }, { id: 2 }, { id: 3 }, { id: 4 }, { id: 5 }]));
    await expect(guardPublicSubmission("enquiry", "unique-content-fingerprint", "same-trusted-signal")).rejects.toThrow("Too many submissions");
    expect(databaseMocks.insert).not.toHaveBeenCalled();
  });

  it("rejects a matching duplicate before recording another security event", async () => {
    databaseMocks.select
      .mockReturnValueOnce(selectResult([{ id: 1 }]))
      .mockReturnValueOnce(selectResult([]));
    await expect(guardPublicSubmission("consultation_request", "matching-content", "trusted-signal")).rejects.toThrow("matching submission");
    expect(databaseMocks.insert).not.toHaveBeenCalled();
  });

  it("records a separate content and trusted-signal fingerprint for an allowed public submission", async () => {
    databaseMocks.select
      .mockReturnValueOnce(selectResult([]))
      .mockReturnValueOnce(selectResult([]));
    await expect(guardPublicSubmission("enquiry", "content-fingerprint", "trusted-signal")).resolves.toBeUndefined();
    expect(databaseMocks.insert).toHaveBeenCalledWith(expect.anything());
    const values = databaseMocks.insert.mock.results[0].value.values.mock.calls[0][0];
    expect(values).toEqual([{ formType: "enquiry", fingerprint: "content-fingerprint" }, { formType: "enquiry", fingerprint: "trusted-signal" }]);
  });
});

describe("analyticsOverview", () => {
  it("aggregates anonymous social clicks by configured platform", async () => {
    databaseMocks.select.mockReturnValueOnce({ from: () => ({ where: () => Promise.resolve([
      { eventType: "page_view", locale: "en", source: "google.com", deviceType: "mobile", treatmentSlug: null, contentSlug: null },
      { eventType: "social_click", locale: "en", source: "google.com", deviceType: "mobile", treatmentSlug: null, contentSlug: "instagram" },
      { eventType: "social_click", locale: "ar-SA", source: "google.com", deviceType: "desktop", treatmentSlug: null, contentSlug: "youtube" },
      { eventType: "social_click", locale: "en", source: null, deviceType: "mobile", treatmentSlug: null, contentSlug: "instagram" },
    ]) }) });

    await expect(analyticsOverview()).resolves.toMatchObject({
      pageViews: 1,
      socialClicks: 3,
      socialPlatforms: [
        { label: "instagram", total: 2 },
        { label: "youtube", total: 1 },
      ],
    });
  });
});
