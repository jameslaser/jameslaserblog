import { and, desc, eq, inArray, lte, or, sql } from "drizzle-orm";
import {
  activityLogs,
  appointments,
  consultationRequests,
  patients,
  users,
  whatsappAutomationLogs,
  whatsappAutomationTemplateDefinitions,
  whatsappContacts,
  whatsappConversations,
  whatsappMessages,
  whatsappSettings,
  whatsappTemplates,
  whatsappWebhookEvents,
} from "../drizzle/schema";
import { getDb, normalizeMobileNumber } from "./db";
import { createStaffNotification, listStaffNotifications } from "./notifications";
import { metaTimestamp, safeWebhookSummary, type MetaWebhookMessage, type MetaWebhookPayload, type MetaWebhookStatus } from "./whatsappWebhook";

export type WhatsAppConversationStatus = "open" | "pending" | "resolved" | "archived";
export type WhatsAppMessageStatus = "received" | "sending" | "sent" | "delivered" | "read" | "failed";
type WebhookProcessingStatus = "received" | "processing" | "processed" | "ignored" | "failed";
const WEBHOOK_PROCESSING_LEASE_MS = 5 * 60 * 1000;

function databaseUnavailable() {
  return new Error("The WhatsApp service is temporarily unavailable.");
}

function inboundMessageType(message: MetaWebhookMessage): "text" | "image" | "document" | "audio" | "interactive" | "unsupported" {
  if (message.type === "text") return "text";
  if (message.type === "image") return "image";
  if (message.type === "document") return "document";
  if (message.type === "audio") return "audio";
  if (message.type === "interactive") return "interactive";
  return "unsupported";
}

function inboundBody(message: MetaWebhookMessage) {
  if (message.type === "text") return message.text?.body?.trim() || null;
  if (message.type === "image") return message.image?.caption?.trim() || null;
  if (message.type === "document") return message.document?.caption?.trim() || message.document?.filename?.trim() || null;
  if (message.type === "interactive") return message.interactive?.button_reply?.title?.trim() || message.interactive?.list_reply?.title?.trim() || message.interactive?.button_reply?.id?.trim() || message.interactive?.list_reply?.id?.trim() || null;
  return null;
}

function media(message: MetaWebhookMessage) {
  if (message.type === "image") return { id: message.image?.id ?? null, mimeType: message.image?.mime_type ?? null };
  if (message.type === "document") return { id: message.document?.id ?? null, mimeType: message.document?.mime_type ?? null };
  if (message.type === "audio") return { id: message.audio?.id ?? null, mimeType: message.audio?.mime_type ?? null };
  return { id: null, mimeType: null };
}

function normalizeStatus(value: string): "sent" | "delivered" | "read" | "failed" | null {
  if (["sent", "delivered", "read", "failed"].includes(value)) return value as "sent" | "delivered" | "read" | "failed";
  return null;
}

const metaStatusRank: Record<"sending" | "sent" | "delivered" | "read" | "failed", number> = { sending: 0, sent: 1, delivered: 2, read: 3, failed: 4 };

/** Meta delivery states are authoritative and may only move forward. A read receipt and a failure are terminal. */
export function shouldApplyMetaStatus(current: WhatsAppMessageStatus, incoming: WhatsAppMessageStatus) {
  if (!["sent", "delivered", "read", "failed"].includes(incoming)) return false;
  if (current === "read" || current === "failed") return false;
  const currentRank = current === "received" ? 0 : metaStatusRank[current as keyof typeof metaStatusRank] ?? 0;
  return metaStatusRank[incoming as keyof typeof metaStatusRank] > currentRank;
}

/** Failed and interrupted receipts are reprocessed; successful and ignored receipts are safe duplicates. */
export function shouldReprocessWebhookEvent(status: WebhookProcessingStatus) {
  return status === "received" || status === "failed";
}

function statusTimestampField(status: WhatsAppMessageStatus) {
  if (status === "sent") return "sentAt" as const;
  if (status === "delivered") return "deliveredAt" as const;
  if (status === "read") return "readAt" as const;
  if (status === "failed") return "failedAt" as const;
  return null;
}

function isRescheduleRequest(text: string | null) {
  return Boolean(text && /(reschedul|change.*appointment|move.*appointment|تغيير.*موعد|تعديل.*موعد|تأجيل.*موعد)/i.test(text));
}

function isCancellationRequest(text: string | null) {
  return Boolean(text && /(cancel.*appointment|cancel my|إلغاء.*موعد|الغاء.*موعد)/i.test(text));
}

async function deterministicLinks(db: NonNullable<Awaited<ReturnType<typeof getDb>>>, normalizedPhone: string) {
  const [requests, patientRows, appointmentRows] = await Promise.all([
    db.select({ id: consultationRequests.id }).from(consultationRequests).where(eq(consultationRequests.normalizedWhatsapp, normalizedPhone)).limit(2),
    db.select({ id: patients.id }).from(patients).where(eq(patients.whatsapp, normalizedPhone)).limit(2),
    db.select({ id: appointments.id }).from(appointments).where(eq(appointments.whatsapp, normalizedPhone)).orderBy(desc(appointments.createdAt)).limit(2),
  ]);
  return {
    requestId: requests.length === 1 ? requests[0].id : null,
    patientId: patientRows.length === 1 ? patientRows[0].id : null,
    appointmentId: appointmentRows.length === 1 ? appointmentRows[0].id : null,
  };
}

async function ensureContactAndConversation(db: NonNullable<Awaited<ReturnType<typeof getDb>>>, message: MetaWebhookMessage, displayName: string | null) {
  const normalizedPhone = normalizeMobileNumber(message.from);
  await db.insert(whatsappContacts).values({
    waId: message.from,
    phoneNumber: message.from,
    normalizedPhone,
    displayName,
    profileName: displayName,
    language: "unknown",
  }).onDuplicateKeyUpdate({
    set: { phoneNumber: message.from, normalizedPhone, displayName, profileName: displayName },
  });
  const contacts = await db.select().from(whatsappContacts).where(eq(whatsappContacts.waId, message.from)).limit(1);
  const contact = contacts[0];
  if (!contact) throw new Error("WhatsApp contact could not be stored.");

  const links = await deterministicLinks(db, normalizedPhone);
  await db.update(whatsappContacts).set({
    patientRequestId: contact.patientRequestId ?? links.requestId,
    patientId: contact.patientId ?? links.patientId,
  }).where(eq(whatsappContacts.id, contact.id));
  const linkedContacts = await db.select().from(whatsappContacts).where(eq(whatsappContacts.id, contact.id)).limit(1);
  const linkedContact = linkedContacts[0];
  if (!linkedContact) throw new Error("WhatsApp contact could not be linked.");

  const receivedAt = metaTimestamp(message.timestamp);
  await db.insert(whatsappConversations).values({
    contactId: linkedContact.id,
    status: "open",
    linkedRequestId: links.requestId,
    linkedPatientId: links.patientId,
    linkedAppointmentId: links.appointmentId,
    serviceWindowOpenedAt: receivedAt,
    serviceWindowExpiresAt: new Date(receivedAt.getTime() + 24 * 60 * 60 * 1000),
    lastInboundAt: receivedAt,
    lastMessageAt: receivedAt,
  }).onDuplicateKeyUpdate({
    set: {
      linkedRequestId: sql`COALESCE(${whatsappConversations.linkedRequestId}, ${links.requestId})`,
      linkedPatientId: sql`COALESCE(${whatsappConversations.linkedPatientId}, ${links.patientId})`,
      linkedAppointmentId: sql`COALESCE(${whatsappConversations.linkedAppointmentId}, ${links.appointmentId})`,
      serviceWindowOpenedAt: receivedAt,
      serviceWindowExpiresAt: new Date(receivedAt.getTime() + 24 * 60 * 60 * 1000),
      lastInboundAt: receivedAt,
      lastMessageAt: receivedAt,
      status: "open",
    },
  });
  const conversations = await db.select().from(whatsappConversations).where(eq(whatsappConversations.contactId, linkedContact.id)).limit(1);
  const conversation = conversations[0];
  if (!conversation) throw new Error("WhatsApp conversation could not be stored.");
  return { contact: linkedContact, conversation };
}

async function markConversationRequest(db: NonNullable<Awaited<ReturnType<typeof getDb>>>, conversationId: number, messageId: number, kind: "reschedule" | "cancellation") {
  const column = kind === "reschedule" ? "rescheduleRequestedAt" : "cancellationRequestedAt";
  await db.update(whatsappConversations).set({ [column]: new Date() }).where(eq(whatsappConversations.id, conversationId));
  await db.insert(whatsappAutomationLogs).values({ conversationId, messageId, automationType: kind === "reschedule" ? "reschedule_flagged" : "cancellation_flagged", outcome: "staff_review_required", details: "Inbound customer message requires staff review; no appointment change was made." });
  const existing = await listStaffNotifications();
  const alreadyNotified = existing.some(notification => !notification.isRead && notification.type === "system" && notification.linkPath === "/admin/whatsapp");
  if (!alreadyNotified) {
    await createStaffNotification({ type: "system", title: "WhatsApp staff review needed", message: "A customer message may require appointment review. No appointment change was made.", linkPath: "/admin/whatsapp" });
  }
}

async function processInboundMessage(db: NonNullable<Awaited<ReturnType<typeof getDb>>>, message: MetaWebhookMessage, displayName: string | null) {
  const existing = await db.select({ id: whatsappMessages.id }).from(whatsappMessages).where(eq(whatsappMessages.metaMessageId, message.id)).limit(1);
  if (existing[0]) return { created: false, conversationId: null };

  const { conversation } = await ensureContactAndConversation(db, message, displayName);
  const receivedAt = metaTimestamp(message.timestamp);
  const content = inboundBody(message);
  const attachment = media(message);
  await db.insert(whatsappMessages).values({
    conversationId: conversation.id,
    metaMessageId: message.id,
    direction: "inbound",
    messageType: inboundMessageType(message),
    body: content,
    mediaId: attachment.id,
    mediaMimeType: attachment.mimeType,
    replyToMetaMessageId: message.context?.id ?? null,
    status: "received",
    createdAt: receivedAt,
  }).onDuplicateKeyUpdate({ set: { metaMessageId: sql`${whatsappMessages.metaMessageId}` } });
  const storedRows = await db.select({ id: whatsappMessages.id }).from(whatsappMessages).where(eq(whatsappMessages.metaMessageId, message.id)).limit(1);
  const stored = storedRows[0];
  if (!stored || existing[0]) return { created: false, conversationId: conversation.id };

  await db.update(whatsappConversations).set({ unreadCount: sql`${whatsappConversations.unreadCount} + 1`, lastInboundAt: receivedAt, lastMessageAt: receivedAt, serviceWindowOpenedAt: receivedAt, serviceWindowExpiresAt: new Date(receivedAt.getTime() + 24 * 60 * 60 * 1000), status: "open" }).where(eq(whatsappConversations.id, conversation.id));
  await db.insert(activityLogs).values({ action: "Recorded inbound WhatsApp message", subjectType: "whatsapp_conversation", subjectId: conversation.id });
  await createStaffNotification({ type: "system", title: "New WhatsApp message", message: "A new customer WhatsApp message is available in the protected inbox.", linkPath: "/admin/whatsapp" });
  const automation = await import("./whatsappAutomation");
  await automation.processWhatsAppAutomationReply(db, { conversationId: conversation.id, messageId: stored.id, message });
  if (isRescheduleRequest(content)) await markConversationRequest(db, conversation.id, stored.id, "reschedule");
  if (isCancellationRequest(content)) await markConversationRequest(db, conversation.id, stored.id, "cancellation");
  return { created: true, conversationId: conversation.id };
}

async function processStatus(db: NonNullable<Awaited<ReturnType<typeof getDb>>>, status: MetaWebhookStatus) {
  const normalized = normalizeStatus(status.status);
  if (!normalized) return false;
  const [existing] = await db.select({ status: whatsappMessages.status, conversationId: whatsappMessages.conversationId }).from(whatsappMessages).where(eq(whatsappMessages.metaMessageId, status.id)).limit(1);
  if (!existing || !shouldApplyMetaStatus(existing.status, normalized)) return false;
  const occurredAt = metaTimestamp(status.timestamp);
  const field = statusTimestampField(normalized);
  const error = status.errors?.[0];
  await db.update(whatsappMessages).set({
    status: normalized,
    ...(field ? { [field]: occurredAt } : {}),
    ...(normalized === "failed" ? { errorCode: error?.code ? String(error.code) : "meta_delivery_failed", errorMessage: (error?.message ?? error?.title ?? "Meta reported delivery failure.").slice(0, 1000) } : {}),
  }).where(eq(whatsappMessages.metaMessageId, status.id));
  const updatedRows = await db.select({ conversationId: whatsappMessages.conversationId }).from(whatsappMessages).where(eq(whatsappMessages.metaMessageId, status.id)).limit(1);
  const updated = updatedRows[0];
  if (!updated) return false;
  await db.update(whatsappConversations).set({ lastMessageAt: occurredAt }).where(eq(whatsappConversations.id, updated.conversationId));
  const automation = await import("./whatsappAutomation");
  await automation.syncProviderMessageStatus(status.id, normalized, occurredAt);
  return true;
}

async function recordWebhookReceipt(db: NonNullable<Awaited<ReturnType<typeof getDb>>>) {
  const now = new Date();
  const [settings] = await db.select({ id: whatsappSettings.id }).from(whatsappSettings).orderBy(desc(whatsappSettings.updatedAt)).limit(1);
  if (settings) {
    await db.update(whatsappSettings).set({ webhookConfigured: true, lastWebhookReceivedAt: now, recentFailureCount: 0 }).where(eq(whatsappSettings.id, settings.id));
  } else {
    await db.insert(whatsappSettings).values({ webhookConfigured: true, lastWebhookReceivedAt: now, recentFailureCount: 0 });
  }
}

async function recordWebhookFailure(db: NonNullable<Awaited<ReturnType<typeof getDb>>>) {
  const now = new Date();
  const [settings] = await db.select({ id: whatsappSettings.id }).from(whatsappSettings).orderBy(desc(whatsappSettings.updatedAt)).limit(1);
  if (settings) {
    await db.update(whatsappSettings).set({ lastWebhookFailureAt: now, recentFailureCount: sql`${whatsappSettings.recentFailureCount} + 1` }).where(eq(whatsappSettings.id, settings.id));
  } else {
    await db.insert(whatsappSettings).values({ lastWebhookFailureAt: now, recentFailureCount: 1 });
  }
}

/** Persists an authenticated Meta webhook once. Failed or interrupted receipts are retried safely; successful receipts are acknowledged as duplicates. */
export async function ingestMetaWhatsAppWebhook(input: { fingerprint: string; payload: MetaWebhookPayload }) {
  const db = await getDb();
  if (!db) throw databaseUnavailable();
  await db.insert(whatsappWebhookEvents).values({
    eventFingerprint: input.fingerprint,
    eventType: "messages",
    payloadSummary: safeWebhookSummary(input.payload),
    processingStatus: "received",
  }).onDuplicateKeyUpdate({ set: { eventFingerprint: sql`${whatsappWebhookEvents.eventFingerprint}` } });
  const [storedEvent] = await db.select({ id: whatsappWebhookEvents.id, processingStatus: whatsappWebhookEvents.processingStatus }).from(whatsappWebhookEvents).where(eq(whatsappWebhookEvents.eventFingerprint, input.fingerprint)).limit(1);
  if (!storedEvent) throw new Error("Webhook receipt could not be loaded after persistence.");
  const processingStartedAt = new Date();
  const leaseExpiredAt = new Date(processingStartedAt.getTime() - WEBHOOK_PROCESSING_LEASE_MS);
  // This conditional update is the database-backed compare-and-set claim: only one concurrent callback can move a receipt into processing.
  // A stale processing lease is reclaimable after five minutes so an interrupted worker cannot permanently strand an authenticated callback.
  const retried = storedEvent.processingStatus === "failed" || storedEvent.processingStatus === "processing";
  const claimed = await db.update(whatsappWebhookEvents).set({ processingStatus: "processing", processingStartedAt, processedAt: null, errorMessage: null })
    .where(and(
      eq(whatsappWebhookEvents.id, storedEvent.id),
      or(
        inArray(whatsappWebhookEvents.processingStatus, ["received", "failed"]),
        and(eq(whatsappWebhookEvents.processingStatus, "processing"), lte(whatsappWebhookEvents.processingStartedAt, leaseExpiredAt)),
      ),
    ));
  const receipt = claimed[0].affectedRows === 1
    ? { eventId: storedEvent.id, duplicate: false, retried }
    : { eventId: storedEvent.id, duplicate: true, retried: false };
  if (receipt.duplicate) {
    await recordWebhookReceipt(db);
    return { duplicate: true, createdMessages: 0, updatedStatuses: 0, retried: false };
  }
  const eventId = receipt.eventId;

  try {
    let createdMessages = 0;
    let updatedStatuses = 0;
    for (const entry of input.payload.entry ?? []) {
      for (const change of entry.changes ?? []) {
        if (change.field !== "messages") continue;
        const contactByWaId = new Map((change.value?.contacts ?? []).map(contact => [contact.wa_id, contact.profile?.name ?? null]));
        for (const message of change.value?.messages ?? []) {
          if (!message.id || !message.from) continue;
          const outcome = await processInboundMessage(db, message, contactByWaId.get(message.from) ?? null);
          if (outcome.created) createdMessages += 1;
        }
        for (const status of change.value?.statuses ?? []) {
          if (status.id && await processStatus(db, status)) updatedStatuses += 1;
        }
      }
    }
    await db.update(whatsappWebhookEvents).set({ processingStatus: createdMessages || updatedStatuses ? "processed" : "ignored", processingStartedAt: null, processedAt: new Date() }).where(eq(whatsappWebhookEvents.id, eventId));
    await recordWebhookReceipt(db);
    return { duplicate: false, createdMessages, updatedStatuses, retried: receipt.retried };
  } catch (error) {
    await db.update(whatsappWebhookEvents).set({ processingStatus: "failed", processingStartedAt: null, errorMessage: error instanceof Error ? error.message.replace(/Bearer\s+\S+/gi, "[redacted]").slice(0, 1000) : "Webhook processing failed." }).where(eq(whatsappWebhookEvents.id, eventId));
    await recordWebhookFailure(db);
    throw error;
  }
}

export function isServiceWindowOpen(conversation: { serviceWindowExpiresAt: Date | null }) {
  return Boolean(conversation.serviceWindowExpiresAt && conversation.serviceWindowExpiresAt.getTime() > Date.now());
}

export type WhatsAppConversationFilters = {
  status?: WhatsAppConversationStatus;
  unreadOnly?: boolean;
  assigned?: "me" | "unassigned" | "all";
  query?: string;
  userId?: number;
};

export async function listWhatsAppConversations(filters: WhatsAppConversationFilters = {}) {
  const db = await getDb();
  if (!db) throw databaseUnavailable();
  const rows = await db.select({
    id: whatsappConversations.id,
    status: whatsappConversations.status,
    unreadCount: whatsappConversations.unreadCount,
    assignedUserId: whatsappConversations.assignedUserId,
    linkedRequestId: whatsappConversations.linkedRequestId,
    linkedPatientId: whatsappConversations.linkedPatientId,
    linkedAppointmentId: whatsappConversations.linkedAppointmentId,
    serviceWindowExpiresAt: whatsappConversations.serviceWindowExpiresAt,
    lastMessageAt: whatsappConversations.lastMessageAt,
    lastInboundAt: whatsappConversations.lastInboundAt,
    contactId: whatsappContacts.id,
    waId: whatsappContacts.waId,
    phoneNumber: whatsappContacts.phoneNumber,
    displayName: whatsappContacts.displayName,
    profileName: whatsappContacts.profileName,
    language: whatsappContacts.language,
  }).from(whatsappConversations).innerJoin(whatsappContacts, eq(whatsappConversations.contactId, whatsappContacts.id)).orderBy(desc(whatsappConversations.lastMessageAt)).limit(200);
  const latestRows = await db.select().from(whatsappMessages).orderBy(desc(whatsappMessages.createdAt)).limit(1000);
  return rows.filter(row => {
    if (filters.status && row.status !== filters.status) return false;
    if (filters.unreadOnly && row.unreadCount < 1) return false;
    if (filters.assigned === "me" && row.assignedUserId !== filters.userId) return false;
    if (filters.assigned === "unassigned" && row.assignedUserId !== null) return false;
    if (filters.query) {
      const query = filters.query.toLocaleLowerCase();
      if (![row.displayName, row.profileName, row.phoneNumber, row.waId].some(value => value?.toLocaleLowerCase().includes(query))) return false;
    }
    return true;
  }).map(row => {
    const latest = latestRows.find(message => message.conversationId === row.id);
    return {
      ...row,
      latestMessage: latest ? { body: latest.body, messageType: latest.messageType, direction: latest.direction, createdAt: latest.createdAt, status: latest.status } : null,
    };
  });
}

export async function getWhatsAppConversation(conversationId: number) {
  const db = await getDb();
  if (!db) throw databaseUnavailable();
  const rows = await db.select({
    id: whatsappConversations.id,
    status: whatsappConversations.status,
    assignedUserId: whatsappConversations.assignedUserId,
    linkedRequestId: whatsappConversations.linkedRequestId,
    linkedPatientId: whatsappConversations.linkedPatientId,
    linkedAppointmentId: whatsappConversations.linkedAppointmentId,
    serviceWindowOpenedAt: whatsappConversations.serviceWindowOpenedAt,
    serviceWindowExpiresAt: whatsappConversations.serviceWindowExpiresAt,
    lastInboundAt: whatsappConversations.lastInboundAt,
    lastOutboundAt: whatsappConversations.lastOutboundAt,
    unreadCount: whatsappConversations.unreadCount,
    rescheduleRequestedAt: whatsappConversations.rescheduleRequestedAt,
    cancellationRequestedAt: whatsappConversations.cancellationRequestedAt,
    contactId: whatsappContacts.id,
    waId: whatsappContacts.waId,
    phoneNumber: whatsappContacts.phoneNumber,
    normalizedPhone: whatsappContacts.normalizedPhone,
    displayName: whatsappContacts.displayName,
    profileName: whatsappContacts.profileName,
    language: whatsappContacts.language,
    patientRequestId: whatsappContacts.patientRequestId,
    patientId: whatsappContacts.patientId,
  }).from(whatsappConversations).innerJoin(whatsappContacts, eq(whatsappConversations.contactId, whatsappContacts.id)).where(eq(whatsappConversations.id, conversationId)).limit(1);
  const conversation = rows[0];
  if (!conversation) throw new Error("WhatsApp conversation not found.");
  const messages = await db.select().from(whatsappMessages).where(eq(whatsappMessages.conversationId, conversationId)).orderBy(whatsappMessages.createdAt).limit(500);
  const [requestRows, patientRows, appointmentRows] = await Promise.all([
    conversation.linkedRequestId ? db.select({ id: consultationRequests.id, publicRequestId: consultationRequests.publicRequestId, fullName: consultationRequests.fullName, status: consultationRequests.status, treatmentArea: consultationRequests.treatmentArea }).from(consultationRequests).where(eq(consultationRequests.id, conversation.linkedRequestId)).limit(1) : [],
    conversation.linkedPatientId ? db.select({ id: patients.id, fullName: patients.fullName, mrn: patients.mrn, treatmentArea: patients.treatmentArea }).from(patients).where(eq(patients.id, conversation.linkedPatientId)).limit(1) : [],
    conversation.linkedAppointmentId ? db.select({ id: appointments.id, appointmentDate: appointments.appointmentDate, appointmentTime: appointments.appointmentTime, status: appointments.status, treatmentArea: appointments.treatmentArea }).from(appointments).where(eq(appointments.id, conversation.linkedAppointmentId)).limit(1) : [],
  ]);
  return { ...conversation, messages, request: requestRows[0] ?? null, patient: patientRows[0] ?? null, appointment: appointmentRows[0] ?? null, serviceWindowOpen: isServiceWindowOpen(conversation) };
}

async function conversationForMutation(conversationId: number) {
  const db = await getDb();
  if (!db) throw databaseUnavailable();
  const rows = await db.select({ id: whatsappConversations.id, contactId: whatsappConversations.contactId, serviceWindowExpiresAt: whatsappConversations.serviceWindowExpiresAt, waId: whatsappContacts.waId }).from(whatsappConversations).innerJoin(whatsappContacts, eq(whatsappConversations.contactId, whatsappContacts.id)).where(eq(whatsappConversations.id, conversationId)).limit(1);
  if (!rows[0]) throw new Error("WhatsApp conversation not found.");
  return { db, conversation: rows[0] };
}

async function logWhatsAppActivity(actor: { id: number; name: string | null }, action: string, conversationId: number) {
  const db = await getDb();
  if (!db) throw databaseUnavailable();
  await db.insert(activityLogs).values({ actorUserId: actor.id, actorName: actor.name, action, subjectType: "whatsapp_conversation", subjectId: conversationId });
}

export async function markWhatsAppConversationRead(conversationId: number, actor: { id: number; name: string | null }) {
  const { db } = await conversationForMutation(conversationId);
  await db.update(whatsappConversations).set({ unreadCount: 0 }).where(eq(whatsappConversations.id, conversationId));
  await logWhatsAppActivity(actor, "Marked WhatsApp conversation read", conversationId);
}

export async function setWhatsAppConversationStatus(conversationId: number, status: WhatsAppConversationStatus, actor: { id: number; name: string | null }) {
  const { db } = await conversationForMutation(conversationId);
  await db.update(whatsappConversations).set({ status }).where(eq(whatsappConversations.id, conversationId));
  await logWhatsAppActivity(actor, `Set WhatsApp conversation status to ${status}`, conversationId);
}

export async function assignWhatsAppConversation(conversationId: number, assignedUserId: number | null, actor: { id: number; name: string | null }) {
  const { db } = await conversationForMutation(conversationId);
  if (assignedUserId !== null) {
    const staff = await db.select({ id: users.id, role: users.role }).from(users).where(eq(users.id, assignedUserId)).limit(1);
    if (!staff[0] || !["owner", "admin", "reception"].includes(staff[0].role)) throw new Error("Conversations may be assigned only to authorized clinic staff.");
  }
  await db.update(whatsappConversations).set({ assignedUserId }).where(eq(whatsappConversations.id, conversationId));
  await logWhatsAppActivity(actor, assignedUserId === null ? "Unassigned WhatsApp conversation" : "Assigned WhatsApp conversation", conversationId);
}

export async function linkWhatsAppConversation(input: { conversationId: number; requestId?: number | null; patientId?: number | null; appointmentId?: number | null }, actor: { id: number; name: string | null }) {
  const { db, conversation } = await conversationForMutation(input.conversationId);
  const updates = {
    linkedRequestId: input.requestId === undefined ? undefined : input.requestId,
    linkedPatientId: input.patientId === undefined ? undefined : input.patientId,
    linkedAppointmentId: input.appointmentId === undefined ? undefined : input.appointmentId,
  };
  await db.update(whatsappConversations).set(updates).where(eq(whatsappConversations.id, input.conversationId));
  if (input.requestId !== undefined || input.patientId !== undefined) {
    await db.update(whatsappContacts).set({ patientRequestId: input.requestId === undefined ? undefined : input.requestId, patientId: input.patientId === undefined ? undefined : input.patientId }).where(eq(whatsappContacts.id, conversation.contactId));
  }
  await logWhatsAppActivity(actor, "Updated WhatsApp conversation links", input.conversationId);
}

function textForStorage(value: string) {
  const text = value.normalize("NFKC").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "").trim();
  if (!text || text.length > 4096) throw new Error("Message text must be between 1 and 4096 characters.");
  return text;
}

export async function sendWhatsAppFreeformMessage(input: { conversationId: number; body: string; replyToMetaMessageId?: string | null }, actor: { id: number; name: string | null }) {
  const { db, conversation } = await conversationForMutation(input.conversationId);
  if (!isServiceWindowOpen(conversation)) throw new Error("The customer service window is closed. Send an approved template instead.");
  const body = textForStorage(input.body);
  const [stored] = await db.insert(whatsappMessages).values({ conversationId: input.conversationId, direction: "outbound", messageType: "text", body, replyToMetaMessageId: input.replyToMetaMessageId ?? null, status: "sending" }).$returningId();
  if (!stored) throw new Error("Outgoing WhatsApp message could not be prepared.");
  try {
    const { sendMetaWhatsAppText } = await import("./metaWhatsApp");
    const response = await sendMetaWhatsAppText({ to: conversation.waId, body, replyToMetaMessageId: input.replyToMetaMessageId });
    const metaMessageId = response.messages?.[0]?.id;
    if (!metaMessageId) throw new Error("Meta did not return a message identifier.");
    await db.update(whatsappMessages).set({ metaMessageId }).where(eq(whatsappMessages.id, stored.id));
    await db.update(whatsappConversations).set({ lastOutboundAt: new Date(), lastMessageAt: new Date() }).where(eq(whatsappConversations.id, input.conversationId));
    await logWhatsAppActivity(actor, "Sent WhatsApp free-form message", input.conversationId);
    return { messageId: stored.id, metaMessageId };
  } catch (error) {
    const typed = error as Error & { code?: string };
    await db.update(whatsappMessages).set({ status: "failed", failedAt: new Date(), errorCode: typed.code ?? "send_failed", errorMessage: typed.message.slice(0, 1000) }).where(eq(whatsappMessages.id, stored.id));
    throw error;
  }
}

export type WhatsAppTemplateBodyComponent = { type: "body"; parameters: Array<{ type: "text"; text: string }> };

export function templateBodyVariableCount(bodyPreview: string | null) {
  if (!bodyPreview) return 0;
  const placeholders = Array.from(bodyPreview.matchAll(/{{\s*(\d+)\s*}}/g)).map(match => Number(match[1])).filter(value => Number.isInteger(value) && value > 0);
  return placeholders.length ? Math.max(...placeholders) : 0;
}

export function validateTemplateBodyComponents(bodyPreview: string | null, components?: WhatsAppTemplateBodyComponent[]) {
  const expected = templateBodyVariableCount(bodyPreview);
  if (expected === 0) {
    if (components?.length) throw new Error("This approved template does not declare body variables.");
    return undefined;
  }
  if (!components || components.length !== 1 || components[0]?.type !== "body" || components[0].parameters.length !== expected) {
    throw new Error(`Provide exactly ${expected} text variable${expected === 1 ? "" : "s"} for this approved template.`);
  }
  const parameters = components[0].parameters.map(parameter => ({ type: parameter.type, text: textForStorage(parameter.text).slice(0, 500) }));
  if (parameters.some(parameter => parameter.type !== "text")) throw new Error("Only text template variables are supported in this workflow.");
  return [{ type: "body" as const, parameters }];
}

export async function sendWhatsAppTemplateMessage(input: { conversationId: number; templateId: number; components?: WhatsAppTemplateBodyComponent[] }, actor: { id: number; name: string | null }) {
  const { db, conversation } = await conversationForMutation(input.conversationId);
  const templates = await db.select().from(whatsappTemplates).where(eq(whatsappTemplates.id, input.templateId)).limit(1);
  const template = templates[0];
  if (!template || template.status !== "approved") throw new Error("Only an approved WhatsApp template can be sent.");
  const components = validateTemplateBodyComponents(template.bodyPreview, input.components);
  const [stored] = await db.insert(whatsappMessages).values({ conversationId: input.conversationId, direction: "outbound", messageType: "template", templateName: template.templateName, templateLanguage: template.language, status: "sending" }).$returningId();
  if (!stored) throw new Error("Outgoing WhatsApp template could not be prepared.");
  try {
    const { sendMetaWhatsAppTemplate } = await import("./metaWhatsApp");
    const response = await sendMetaWhatsAppTemplate({ to: conversation.waId, name: template.templateName, language: template.language, components });
    const metaMessageId = response.messages?.[0]?.id;
    if (!metaMessageId) throw new Error("Meta did not return a message identifier.");
    await db.update(whatsappMessages).set({ metaMessageId }).where(eq(whatsappMessages.id, stored.id));
    await db.update(whatsappConversations).set({ lastOutboundAt: new Date(), lastMessageAt: new Date() }).where(eq(whatsappConversations.id, input.conversationId));
    await logWhatsAppActivity(actor, "Sent WhatsApp template message", input.conversationId);
    return { messageId: stored.id, metaMessageId };
  } catch (error) {
    const typed = error as Error & { code?: string };
    await db.update(whatsappMessages).set({ status: "failed", failedAt: new Date(), errorCode: typed.code ?? "send_failed", errorMessage: typed.message.slice(0, 1000) }).where(eq(whatsappMessages.id, stored.id));
    throw error;
  }
}

export async function listWhatsAppTemplates() {
  const db = await getDb();
  if (!db) throw databaseUnavailable();
  return db.select().from(whatsappTemplates).orderBy(desc(whatsappTemplates.updatedAt));
}

export async function getWhatsAppSettings() {
  const db = await getDb();
  if (!db) throw databaseUnavailable();
  const settings = await db.select().from(whatsappSettings).orderBy(desc(whatsappSettings.updatedAt)).limit(1);
  return settings[0] ?? null;
}

export async function syncWhatsAppTemplates(actor: { id: number; name: string | null }) {
  const db = await getDb();
  if (!db) throw databaseUnavailable();
  const { fetchMetaWhatsAppTemplates, getMetaWhatsAppConfig } = await import("./metaWhatsApp");
  const config = getMetaWhatsAppConfig();
  if (!config) throw new Error("WhatsApp Cloud API is not configured. An authorized owner must complete Manus-managed server-side secret setup.");
  let response: Awaited<ReturnType<typeof fetchMetaWhatsAppTemplates>>;
  try {
    response = await fetchMetaWhatsAppTemplates();
  } catch (error) {
    const failure = error as { code?: string };
    if (failure.code !== "200") throw error;
    const cached = await db.select({ id: whatsappTemplates.id }).from(whatsappTemplates).where(eq(whatsappTemplates.businessAccountId, config.businessAccountId));
    await db.insert(activityLogs).values({ actorUserId: actor.id, actorName: actor.name, action: "Meta template sync was denied; retained cached provider statuses", subjectType: "whatsapp_settings" });
    return { synchronized: 0, cached: cached.length, providerReadDenied: true as const };
  }
  for (const template of response.data ?? []) {
    if (!template.name || !template.language) continue;
    const body = template.components?.find(component => component.type === "BODY")?.text ?? null;
    const variables = template.components ? JSON.stringify(template.components.map(component => ({ type: component.type, example: component.example }))) : null;
    const status = (["approved", "pending", "rejected", "paused", "disabled"].includes((template.status ?? "").toLowerCase()) ? template.status!.toLowerCase() : "unknown") as "approved" | "pending" | "rejected" | "paused" | "disabled" | "unknown";
    const values = { businessAccountId: config.businessAccountId, templateName: template.name, language: template.language, category: template.category ?? null, status, bodyPreview: body, variables, metaTemplateId: template.id ?? null, lastSyncedAt: new Date() };
    await db.insert(whatsappTemplates).values(values).onDuplicateKeyUpdate({ set: values });
  }
  await db.insert(whatsappSettings).values({ businessAccountId: config.businessAccountId, phoneNumberId: config.phoneNumberId, apiVersion: config.graphApiVersion, lastTemplateSyncAt: new Date() }).onDuplicateKeyUpdate({ set: { phoneNumberId: config.phoneNumberId, apiVersion: config.graphApiVersion, lastTemplateSyncAt: new Date() } });
  await db.insert(activityLogs).values({ actorUserId: actor.id, actorName: actor.name, action: "Synchronized WhatsApp template metadata", subjectType: "whatsapp_settings" });
  return { synchronized: (response.data ?? []).length, cached: 0, providerReadDenied: false as const };
}

const META_WHATSAPP_CALLBACK_URL = "https://www.jameslaserformen.com/api/webhooks/whatsapp";

function supportedProviderLanguage(language: "en" | "ar", providerLanguage: string) {
  return language === "ar" ? ["ar", "ar_SA"].includes(providerLanguage) : ["en", "en_US"].includes(providerLanguage);
}

function templateExampleValues(language: "en" | "ar", count: number) {
  const english = ["Customer", "20 September 2026", "10:00", "treatment area", "Follow the clinic preparation instructions."];
  const arabic = ["العميل", "20 سبتمبر 2026", "10:00", "منطقة العلاج", "اتبع تعليمات التحضير من العيادة."];
  return (language === "ar" ? arabic : english).slice(0, count);
}

function templateButtons(input: { language: "en" | "ar"; interactiveLabels: string | null }) {
  const labels = input.interactiveLabels ? JSON.parse(input.interactiveLabels) as string[] : [];
  if (labels.includes("YES_SESSION")) {
    return input.language === "ar"
      ? [{ type: "QUICK_REPLY", text: "نعم، سأحضر" }, { type: "QUICK_REPLY", text: "لا أستطيع الحضور" }]
      : [{ type: "QUICK_REPLY", text: "Yes, I will attend" }, { type: "QUICK_REPLY", text: "I cannot attend" }];
  }
  if (labels.includes("YES_RETOUCH")) {
    return input.language === "ar"
      ? [{ type: "QUICK_REPLY", text: "نعم، أطلب رتوش" }, { type: "QUICK_REPLY", text: "لا، ليس الآن" }]
      : [{ type: "QUICK_REPLY", text: "Yes, request retouch" }, { type: "QUICK_REPLY", text: "No, not now" }];
  }
  return [];
}

function templateSubmissionComponents(definition: { language: "en" | "ar"; bodyPreview: string; interactiveLabels: string | null }) {
  const placeholderCount = Math.max(0, ...Array.from(definition.bodyPreview.matchAll(/{{\s*(\d+)\s*}}/g)).map(match => Number(match[1])));
  const components: Array<Record<string, unknown>> = [{
    type: "BODY",
    text: definition.bodyPreview,
    ...(placeholderCount ? { example: { body_text: [templateExampleValues(definition.language, placeholderCount)] } } : {}),
  }];
  const buttons = templateButtons(definition);
  if (buttons.length) components.push({ type: "BUTTONS", buttons });
  return components;
}

function providerBodyText(template: { components?: Array<{ type?: string; text?: string }> }) {
  return template.components?.find(component => component.type?.toUpperCase() === "BODY")?.text?.trim() ?? null;
}

/** Registers the HTTPS callback using only Manus-managed runtime secrets; the token is never returned or stored locally. */
export async function registerWhatsAppWebhook(actor: { id: number; name: string | null }) {
  const db = await getDb();
  if (!db) throw databaseUnavailable();
  const { getMetaWhatsAppConfig, registerMetaWhatsAppWebhook } = await import("./metaWhatsApp");
  const config = getMetaWhatsAppConfig();
  if (!config) throw new Error("WhatsApp Cloud API is not configured. An authorized owner must complete Manus-managed server-side secret setup.");
  const result = await registerMetaWhatsAppWebhook(META_WHATSAPP_CALLBACK_URL);
  if (!result.success) throw new Error("Meta did not confirm the WhatsApp webhook subscription.");
  await db.insert(whatsappSettings).values({
    businessAccountId: config.businessAccountId,
    phoneNumberId: config.phoneNumberId,
    apiVersion: config.graphApiVersion,
    webhookConfigured: true,
  }).onDuplicateKeyUpdate({ set: { phoneNumberId: config.phoneNumberId, apiVersion: config.graphApiVersion, webhookConfigured: true } });
  await db.insert(activityLogs).values({ actorUserId: actor.id, actorName: actor.name, action: "Registered Meta WhatsApp webhook callback", subjectType: "whatsapp_settings" });
  return { registered: true as const, callbackUrl: META_WHATSAPP_CALLBACK_URL };
}

/** Submits only missing reviewed utility templates to Meta. Pending templates are explicitly not mapped or sent. */
export async function submitMissingWhatsAppUtilityTemplates(actor: { id: number; name: string | null }) {
  const db = await getDb();
  if (!db) throw databaseUnavailable();
  const { fetchMetaWhatsAppTemplates, getMetaWhatsAppConfig, submitMetaWhatsAppUtilityTemplate } = await import("./metaWhatsApp");
  const config = getMetaWhatsAppConfig();
  if (!config) throw new Error("WhatsApp Cloud API is not configured. An authorized owner must complete Manus-managed server-side secret setup.");
  const { syncWhatsAppAutomationTemplateDefinitions } = await import("./whatsappAutomation");
  const [definitions, remote] = await Promise.all([
    syncWhatsAppAutomationTemplateDefinitions(),
    fetchMetaWhatsAppTemplates(),
  ]);
  let submitted = 0;
  let alreadyPresent = 0;
  for (const definition of definitions) {
    if (definition.language !== "en" && definition.language !== "ar") continue;
    const language: "en" | "ar" = definition.language === "ar" ? "ar" : "en";
    const existing = (remote.data ?? []).find(template => template.name === definition.suggestedName && template.language && supportedProviderLanguage(language, template.language));
    if (existing) {
      alreadyPresent += 1;
      continue;
    }
    let response: Awaited<ReturnType<typeof submitMetaWhatsAppUtilityTemplate>>;
    try {
      response = await submitMetaWhatsAppUtilityTemplate({
        name: definition.suggestedName,
        language: language === "en" ? "en_US" : "ar",
        category: "UTILITY",
        components: templateSubmissionComponents({ language, bodyPreview: definition.bodyPreview, interactiveLabels: definition.interactiveLabels }),
      });
    } catch (error) {
      const failure = error as Error;
      throw new Error(`Meta rejected reviewed utility template ${definition.suggestedName}: ${failure.message}`);
    }
    const status = (response.status ?? "PENDING").toLowerCase();
    await db.insert(whatsappTemplates).values({
      businessAccountId: config.businessAccountId,
      templateName: definition.suggestedName,
      language,
      category: response.category ?? "UTILITY",
      status: ["approved", "pending", "rejected", "paused", "disabled"].includes(status) ? status as "approved" | "pending" | "rejected" | "paused" | "disabled" : "unknown",
      metaTemplateId: response.id ?? null,
      bodyPreview: definition.bodyPreview,
      variables: definition.interactiveLabels,
      lastSyncedAt: new Date(),
    }).onDuplicateKeyUpdate({ set: { category: response.category ?? "UTILITY", status: ["approved", "pending", "rejected", "paused", "disabled"].includes(status) ? status as "approved" | "pending" | "rejected" | "paused" | "disabled" : "unknown", metaTemplateId: response.id ?? null, bodyPreview: definition.bodyPreview, variables: definition.interactiveLabels, lastSyncedAt: new Date() } });
    submitted += 1;
  }
  await db.insert(activityLogs).values({ actorUserId: actor.id, actorName: actor.name, action: "Submitted missing WhatsApp utility templates for Meta review", subjectType: "whatsapp_templates" });
  return { submitted, alreadyPresent };
}

/** Maps only exact, language-matched templates after Meta reports them as approved. */
export async function mapExactApprovedWhatsAppUtilityTemplates(actor: { id: number; name: string | null }) {
  const db = await getDb();
  if (!db) throw databaseUnavailable();
  const { fetchMetaWhatsAppTemplates, getMetaWhatsAppConfig } = await import("./metaWhatsApp");
  const config = getMetaWhatsAppConfig();
  if (!config) throw new Error("WhatsApp Cloud API is not configured. An authorized owner must complete Manus-managed server-side secret setup.");
  const { syncWhatsAppAutomationTemplateDefinitions } = await import("./whatsappAutomation");
  const [definitions, remote] = await Promise.all([
    syncWhatsAppAutomationTemplateDefinitions(),
    fetchMetaWhatsAppTemplates(),
  ]);
  let mapped = 0;
  for (const definition of definitions) {
    if (definition.language !== "en" && definition.language !== "ar") continue;
    const language: "en" | "ar" = definition.language === "ar" ? "ar" : "en";
    const approved = (remote.data ?? []).find(template =>
      template.name === definition.suggestedName &&
      template.category?.toUpperCase() === "UTILITY" &&
      template.status?.toLowerCase() === "approved" &&
      template.language &&
      supportedProviderLanguage(language, template.language) &&
      providerBodyText(template) === definition.bodyPreview.trim(),
    );
    if (!approved) continue;
    await db.update(whatsappAutomationTemplateDefinitions).set({ providerTemplateName: approved.name, providerTemplateId: approved.id ?? null }).where(eq(whatsappAutomationTemplateDefinitions.id, definition.id));
    mapped += 1;
  }
  await db.insert(activityLogs).values({ actorUserId: actor.id, actorName: actor.name, action: "Mapped exact approved WhatsApp utility templates", subjectType: "whatsapp_templates" });
  return { mapped };
}

/** Links a new public request only when a single existing WhatsApp contact has the exact normalized mobile number. */
export async function linkWhatsAppConversationForRequest(input: { requestId: number; whatsapp: string }) {
  const db = await getDb();
  if (!db) throw databaseUnavailable();
  const normalizedPhone = normalizeMobileNumber(input.whatsapp);
  const contacts = await db.select({ id: whatsappContacts.id, patientRequestId: whatsappContacts.patientRequestId }).from(whatsappContacts).where(eq(whatsappContacts.normalizedPhone, normalizedPhone)).limit(2);
  if (contacts.length !== 1) return { linked: false, reason: contacts.length > 1 ? "ambiguous" as const : "not_found" as const };
  const [conversation] = await db.select({ id: whatsappConversations.id }).from(whatsappConversations).where(eq(whatsappConversations.contactId, contacts[0].id)).limit(1);
  if (!conversation) return { linked: false, reason: "not_found" as const };
  await db.update(whatsappContacts).set({ patientRequestId: input.requestId }).where(eq(whatsappContacts.id, contacts[0].id));
  await db.update(whatsappConversations).set({ linkedRequestId: input.requestId }).where(eq(whatsappConversations.id, conversation.id));
  await db.insert(whatsappAutomationLogs).values({ conversationId: conversation.id, automationType: "request_linked", outcome: "deterministic_phone_match", details: "Linked to a public appointment request by exact normalized phone." });
  return { linked: true, conversationId: conversation.id };
}

/** Records staff-approved transfer links; it never performs the approval or creates an appointment itself. */
export async function linkWhatsAppConversationForApprovedRequest(input: { requestId: number; patientId: number; appointmentId: number; whatsapp: string }) {
  const linked = await linkWhatsAppConversationForRequest({ requestId: input.requestId, whatsapp: input.whatsapp });
  if (!linked.linked || !("conversationId" in linked)) return linked;
  const conversationId = Number(linked.conversationId);
  if (!Number.isInteger(conversationId) || conversationId <= 0) return linked;
  const db = await getDb();
  if (!db) throw databaseUnavailable();
  await db.update(whatsappConversations).set({ linkedRequestId: input.requestId, linkedPatientId: input.patientId, linkedAppointmentId: input.appointmentId }).where(eq(whatsappConversations.id, conversationId));
  const conversation = await db.select({ contactId: whatsappConversations.contactId }).from(whatsappConversations).where(eq(whatsappConversations.id, conversationId)).limit(1);
  if (conversation[0]) await db.update(whatsappContacts).set({ patientRequestId: input.requestId, patientId: input.patientId }).where(eq(whatsappContacts.id, conversation[0].contactId));
  return linked;
}

export async function listWhatsAppContacts(query?: string) {
  const db = await getDb();
  if (!db) throw databaseUnavailable();
  const contacts = await db.select().from(whatsappContacts).orderBy(desc(whatsappContacts.updatedAt)).limit(200);
  if (!query) return contacts;
  const normalized = query.toLocaleLowerCase();
  return contacts.filter(contact => [contact.displayName, contact.profileName, contact.phoneNumber, contact.waId].some(value => value?.toLocaleLowerCase().includes(normalized)));
}

export async function listWhatsAppWebhookEvents() {
  const db = await getDb();
  if (!db) throw databaseUnavailable();
  return db.select({ id: whatsappWebhookEvents.id, eventType: whatsappWebhookEvents.eventType, payloadSummary: whatsappWebhookEvents.payloadSummary, processingStatus: whatsappWebhookEvents.processingStatus, errorMessage: whatsappWebhookEvents.errorMessage, processedAt: whatsappWebhookEvents.processedAt, createdAt: whatsappWebhookEvents.createdAt }).from(whatsappWebhookEvents).orderBy(desc(whatsappWebhookEvents.createdAt)).limit(200);
}

export async function listWhatsAppAutomationLogs() {
  const db = await getDb();
  if (!db) throw databaseUnavailable();
  return db.select().from(whatsappAutomationLogs).orderBy(desc(whatsappAutomationLogs.createdAt)).limit(200);
}

/** Returns only exact normalized-phone candidates for staff-mediated link resolution. */
export async function getWhatsAppLinkCandidates(conversationId: number) {
  const db = await getDb();
  if (!db) throw databaseUnavailable();
  const rows = await db.select({ normalizedPhone: whatsappContacts.normalizedPhone }).from(whatsappConversations).innerJoin(whatsappContacts, eq(whatsappConversations.contactId, whatsappContacts.id)).where(eq(whatsappConversations.id, conversationId)).limit(1);
  const normalizedPhone = rows[0]?.normalizedPhone;
  if (!normalizedPhone) return { requests: [], patients: [], appointments: [] };
  const [requests, patientRows, appointmentRows] = await Promise.all([
    db.select({ id: consultationRequests.id, publicRequestId: consultationRequests.publicRequestId, fullName: consultationRequests.fullName, status: consultationRequests.status, preferredDate: consultationRequests.preferredDate }).from(consultationRequests).where(eq(consultationRequests.normalizedWhatsapp, normalizedPhone)).orderBy(desc(consultationRequests.createdAt)).limit(20),
    db.select({ id: patients.id, fullName: patients.fullName, mrn: patients.mrn }).from(patients).where(eq(patients.whatsapp, normalizedPhone)).orderBy(desc(patients.updatedAt)).limit(20),
    db.select({ id: appointments.id, patientName: appointments.patientName, appointmentDate: appointments.appointmentDate, appointmentTime: appointments.appointmentTime, status: appointments.status }).from(appointments).where(eq(appointments.whatsapp, normalizedPhone)).orderBy(desc(appointments.createdAt)).limit(20),
  ]);
  return { requests, patients: patientRows, appointments: appointmentRows };
}
