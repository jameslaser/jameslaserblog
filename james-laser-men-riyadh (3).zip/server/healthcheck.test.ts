import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const serverSource = readFileSync(resolve(process.cwd(), "server/_core/index.ts"), "utf8");

describe("external-host health endpoint", () => {
  it("exposes a lightweight JSON health endpoint before application routing", () => {
    expect(serverSource).toContain('app.get("/healthz"');
    expect(serverSource).toContain('res.status(200).json({ status: "ok" })');
  });
});
