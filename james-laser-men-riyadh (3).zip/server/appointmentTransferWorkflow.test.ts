import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const dbSource = readFileSync(new URL("./db.ts", import.meta.url), "utf8");
const requestWorkspaceSource = readFileSync(new URL("../client/src/pages/AdminRequestsWorkspace.tsx", import.meta.url), "utf8");
const appointmentPortalSource = readFileSync(new URL("../client/src/pages/AdminPortal.tsx", import.meta.url), "utf8");

describe("appointment request transfer workflow", () => {
  it("allows a request to become transferred only inside the linked appointment transaction", () => {
    expect(dbSource).toContain('if (status === "transferred") throw new Error("Use the approved transfer action');
    expect(dbSource).toContain('status: "transferred"');
    expect(dbSource).toContain("consultationRequestId: request.id");
  });

  it("persists final snapshots and consent continuity without overwriting original public request fields", () => {
    expect(dbSource).toContain("finalizedFullName: details.fullName");
    expect(dbSource).toContain("finalizedTreatmentAreas: JSON.stringify(details.treatmentAreas)");
    expect(dbSource).toContain("originalConsentSetReference: request.originalConsentSetReference");
    expect(dbSource).toContain("consentSignatureReference: request.consentSignatureReference");
  });

  it("checks duration-aware mobile and machine conflicts before creating a finalized appointment", () => {
    expect(dbSource).toContain("clinicDurationMinutes(details.treatmentAreas, details.visitType)");
    expect(dbSource).toContain("hasAppointmentConflict({ appointmentTime: details.appointmentTime");
    expect(dbSource).toContain("A scheduled appointment already overlaps this mobile number");
    expect(dbSource).toContain("The selected machine is already assigned during the selected appointment time");
    expect(dbSource).toContain("appointmentEndTime: finalizedAppointmentEndTime");
    expect(dbSource).toContain('inArray(appointments.status, ["confirmed", "waiting", "arrived"])');
  });

  it("keeps the request transfer workflow explicit while the daily appointment page remains HMS-only", () => {
    expect(requestWorkspaceSource).toContain("Approve & transfer to Appointments");
    expect(requestWorkspaceSource).toContain("Transfer after finalizing appointment details");
    expect(requestWorkspaceSource).not.toContain('onStatus("transferred")');
    expect(appointmentPortalSource).toContain('Exclude<RequestStatusFilter, "pending" | "approved" | "transferred">');
    expect(appointmentPortalSource).not.toContain('onClick={() => updateWorkflow(request, "transferred")}>Transfer</Button>');
    expect(appointmentPortalSource).not.toContain("Source request #");
    expect(appointmentPortalSource).toContain("selectedDateName");
    expect(appointmentPortalSource).toContain("confirmed appointments");
    expect(appointmentPortalSource).toContain('appointment.source !== "hms_csv"');
  });
});
