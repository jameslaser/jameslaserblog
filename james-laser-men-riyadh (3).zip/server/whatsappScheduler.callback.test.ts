import { describe, expect, it } from "vitest";
import { getDb } from "./db";

describe("live Manus WhatsApp scheduler callback", () => {
  it("records the managed callback while leaving outbound automation disabled", async () => {
    const db = await getDb();
    const rows = await db!.execute("SELECT schedulerTaskUid, schedulerVerifiedAt, automationEnabled FROM whatsappSettings WHERE businessAccountId = '1833666484124208' ORDER BY updatedAt DESC LIMIT 1");
    const settings = rows[0][0] as { schedulerTaskUid: string | null; schedulerVerifiedAt: Date | null; automationEnabled: number };

    expect(settings.schedulerTaskUid).toBeTruthy();
    expect(settings.schedulerVerifiedAt).toBeTruthy();
    expect(settings.automationEnabled).toBe(0);
  });
});
