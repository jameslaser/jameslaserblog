import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const source = (path: string) => readFileSync(path, "utf8");

describe("managed database runtime contract", () => {
  it("uses the existing MySQL/TiDB adapter and MYSQL_URL precedence", () => {
    const db = source("server/db.ts");
    const env = source("server/_core/env.ts");
    const schema = source("drizzle/schema.ts");

    expect(db).toContain('drizzle-orm/mysql2');
    expect(env).toContain("MYSQL_URL");
    expect(schema).toContain("mysqlTable");
    expect(schema).not.toContain("pgTable");
    expect(schema).not.toContain("pgEnum");
  });

  it("does not expose PostgreSQL-only write builders in active modules", () => {
    const modules = [
      "server/cms.ts",
      "server/consentSignature.ts",
      "server/notifications.ts",
      "server/sharedBackend.ts",
      "server/whatsappService.ts",
    ].map(source).join("\n");

    expect(modules).not.toContain(".returning(");
    expect(modules).not.toContain(".onConflictDo");
    expect(modules).toContain("$returningId");
    expect(modules).toContain("onDuplicateKeyUpdate");
  });
});
