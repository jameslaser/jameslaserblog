import { createHash } from "node:crypto";

export type RevenueValidation = "READY" | "WARNING" | "DUPLICATE" | "ERROR";
export type RevenueMoney = { gross: number; quantity: number; discount: number; deduct: number; net: number };
export type RevenueServiceRow = RevenueMoney & {
  sourceRowNumber: number;
  mrn: string | null;
  patientName: string;
  serviceCode: string;
  serviceName: string;
  fromDate: string | null;
  toDate: string | null;
  printDate: string | null;
  validation: RevenueValidation;
  warnings: string[];
  errors: string[];
  fingerprint: string;
};
export type RevenuePatientGroup = { mrn: string | null; patientName: string; rows: RevenueServiceRow[]; totals: RevenueMoney; matchedPatientId?: number | null };
export type RevenueGrandTotal = RevenueMoney;
export type RevenueReconciliationDifference = {
  scope: "PATIENT_SUBTOTAL" | "GRAND_TOTAL";
  sourceRowNumber: number;
  mrn: string | null;
  reported: RevenueMoney;
  calculated: RevenueMoney;
  differences: Partial<RevenueMoney>;
};
export type RevenueMrnDuplicateEntry = {
  mrn: string;
  sourceRowNumbers: number[];
  serviceCode: string;
  serviceName: string;
  totals: RevenueMoney;
};
export type RevenueParsedReport = {
  fileSha256: string;
  fromDate: string | null;
  toDate: string | null;
  account: string | null;
  printDate: string | null;
  grandTotal: RevenueGrandTotal | null;
  rows: RevenueServiceRow[];
  patients: RevenuePatientGroup[];
  fatalErrors: string[];
  invalidRowCount: number;
  subtotalRowCount: number;
  grandTotalRowCount: number;
  reconciliationDifferences: RevenueReconciliationDifference[];
  mrnDuplicateEntries: RevenueMrnDuplicateEntry[];
};

type CsvRecord = { values: string[]; sourceRowNumber: number };
function csvRecords(input: string): CsvRecord[] {
  const records: CsvRecord[] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;
  let currentSourceRowNumber = 1;
  let recordSourceRowNumber = 1;
  for (let i = 0; i < input.length; i += 1) {
    const character = input[i]!;
    if (quoted) {
      if (character === '"' && input[i + 1] === '"') { cell += '"'; i += 1; continue; }
      if (character === '"') { quoted = false; continue; }
      if (character === "\n") currentSourceRowNumber += 1;
      cell += character;
    } else if (character === '"') quoted = true;
    else if (character === ",") { row.push(cell.trim()); cell = ""; }
    else if (character === "\n") {
      row.push(cell.trim());
      records.push({ values: row, sourceRowNumber: recordSourceRowNumber });
      row = [];
      cell = "";
      currentSourceRowNumber += 1;
      recordSourceRowNumber = currentSourceRowNumber;
    }
    else if (character !== "\r") cell += character;
  }
  if (cell.length || row.length) {
    row.push(cell.trim());
    records.push({ values: row, sourceRowNumber: recordSourceRowNumber });
  }
  return records.filter(record => record.values.some(Boolean));
}

const cleanHeader = (value: string) => value.toLocaleLowerCase().replace(/[\s_\-/()]+/g, "").replace(/[^a-z0-9]/g, "");
const aliases = {
  mrn: ["mrn", "patientmrn", "medicalrecordnumber"],
  patientName: ["patientname", "patient", "patname", "name"],
  serviceCode: ["servicecode", "code", "itemcode", "serviceno"],
  serviceName: ["servicename", "service", "treatmentname", "treatment", "description"],
  gross: ["gross", "grossamount"],
  quantity: ["quantity", "qty"],
  discount: ["discount", "discountamount"],
  deduct: ["deduct", "deduction", "deductamount"],
  net: ["net", "netamount", "netrevenue"],
  fromDate: ["fromdate", "datefrom", "reportfromdate"],
  toDate: ["todate", "dateto", "reporttodate"],
  account: ["account", "accountname"],
  printDate: ["printdate"],
} as const;

type RevenueField = keyof typeof aliases;
function findColumn(headers: string[], field: RevenueField) {
  const normalized = headers.map(cleanHeader);
  return normalized.findIndex(value => aliases[field].includes(value as never));
}
function cell(record: string[], index: number) { return index >= 0 ? (record[index] ?? "").trim() : ""; }
function numberValue(value: string): number | null {
  const normalized = value.replace(/[\s, currencySARريال]/gi, "").replace(/[()]/g, match => match === "(" ? "-" : "");
  if (!normalized) return null;
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : null;
}
function dateValue(value: string): string | null {
  const match = value.trim().match(/^(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})$/);
  if (!match) return value.trim() || null;
  const [, day, month, year] = match;
  return `${year}-${String(Number(month)).padStart(2, "0")}-${String(Number(day)).padStart(2, "0")}`;
}
function nextNonEmptyCell(record: string[], index: number) {
  for (let position = index + 1; position < record.length; position += 1) {
    const value = (record[position] ?? "").trim();
    if (value) return value;
  }
  return "";
}
function metadataCell(record: string[], field: RevenueField) {
  const index = record
    .map(cleanHeader)
    .findIndex(value => aliases[field].includes(value as never));
  return { found: index >= 0, value: index >= 0 ? nextNonEmptyCell(record, index) : "" };
}
function totals(rows: RevenueMoney[]): RevenueMoney { return rows.reduce((sum, row) => ({ gross: sum.gross + row.gross, quantity: sum.quantity + row.quantity, discount: sum.discount + row.discount, deduct: sum.deduct + row.deduct, net: sum.net + row.net }), { gross: 0, quantity: 0, discount: 0, deduct: 0, net: 0 }); }
function sameTotals(left: RevenueMoney, right: RevenueMoney) { return ["gross", "quantity", "discount", "deduct", "net"].every(key => Math.abs(left[key as keyof RevenueMoney] - right[key as keyof RevenueMoney]) < 0.005); }
const moneyFields = ["gross", "quantity", "discount", "deduct", "net"] as const;
type RevenueMoneyField = (typeof moneyFields)[number];
function reportTotals(record: string[], values: Record<RevenueMoneyField, number | null>): RevenueMoney {
  const numericValues = record.map(numberValue).filter((value): value is number => value !== null);
  const lastFive = numericValues.length >= 5 ? numericValues.slice(-5) : [];
  if (lastFive.length === 5) return { gross: lastFive[0]!, quantity: lastFive[1]!, discount: lastFive[2]!, deduct: lastFive[3]!, net: lastFive[4]! };
  return { gross: values.gross ?? 0, quantity: values.quantity ?? 0, discount: values.discount ?? 0, deduct: values.deduct ?? 0, net: values.net ?? 0 };
}
function totalsDifference(reported: RevenueMoney, calculated: RevenueMoney): Partial<RevenueMoney> {
  return moneyFields.reduce((result, field) => {
    const value = calculated[field] - reported[field];
    if (Math.abs(value) >= 0.005) result[field] = Math.round((value + Number.EPSILON) * 100) / 100;
    return result;
  }, {} as Partial<RevenueMoney>);
}
function findMrnDuplicateEntries(rows: RevenueServiceRow[]): RevenueMrnDuplicateEntry[] {
  const groups = rows.reduce((result, row) => {
    if (!row.mrn) return result;
    const key = [row.mrn, row.serviceCode, row.serviceName, row.gross, row.quantity, row.discount, row.deduct, row.net].join("\u001f");
    const group = result.get(key) ?? { mrn: row.mrn, sourceRowNumbers: [], serviceCode: row.serviceCode, serviceName: row.serviceName, totals: { gross: row.gross, quantity: row.quantity, discount: row.discount, deduct: row.deduct, net: row.net } };
    group.sourceRowNumbers.push(row.sourceRowNumber);
    result.set(key, group);
    return result;
  }, new Map<string, RevenueMrnDuplicateEntry>());
  return Array.from(groups.values()).filter(group => group.sourceRowNumbers.length > 1);
}

export function parseRevenueCsv(input: string): RevenueParsedReport {
  const source = input.replace(/^\uFEFF/, "");
  const records = csvRecords(source);
  const fileSha256 = createHash("sha256").update(source, "utf8").digest("hex");
  const fatalErrors: string[] = [];
  if (!records.length) return { fileSha256, fromDate: null, toDate: null, account: null, printDate: null, grandTotal: null, rows: [], patients: [], fatalErrors: ["The CSV is empty."], invalidRowCount: 0, subtotalRowCount: 0, grandTotalRowCount: 0, reconciliationDifferences: [], mrnDuplicateEntries: [] };

  let fromDate: string | null = null;
  let toDate: string | null = null;
  let account: string | null = null;
  let printDate: string | null = null;
  let grandTotal: RevenueMoney | null = null;
  let grandTotalSourceRowNumber: number | null = null;
  let grandTotalRowCount = 0;
  let subtotalRowCount = 0;
  let currentMrn: string | null = null;
  let currentPatientName = "";
  let headers: string[] = [];
  let headerIndexes: Record<RevenueField, number> | null = null;
  const rows: RevenueServiceRow[] = [];
  const reportedSubtotals: Array<{ sourceRowNumber: number; mrn: string | null; patientName: string; reported: RevenueMoney }> = [];

  records.forEach(({ values: record, sourceRowNumber }) => {
    const label = record.join(" ").toLocaleLowerCase();
    const isRevenueHeader = findColumn(record, "gross") >= 0 && findColumn(record, "net") >= 0 && findColumn(record, "mrn") >= 0 && findColumn(record, "patientName") >= 0;
    if (isRevenueHeader) {
      if (!headers.length) {
        headers = record;
        headerIndexes = Object.fromEntries((Object.keys(aliases) as RevenueField[]).map(field => [field, findColumn(headers, field)])) as Record<RevenueField, number>;
      }
      return;
    }
    const fromDateCell = metadataCell(record, "fromDate");
    const toDateCell = metadataCell(record, "toDate");
    const accountCell = metadataCell(record, "account");
    const printDateCell = metadataCell(record, "printDate");
    if (fromDateCell.found || toDateCell.found || accountCell.found || printDateCell.found) {
      if (fromDateCell.value) fromDate = dateValue(fromDateCell.value);
      if (toDateCell.value) toDate = dateValue(toDateCell.value);
      if (accountCell.value) account = accountCell.value;
      if (printDateCell.value) printDate = dateValue(printDateCell.value);
      return;
    }
    if (/^detail\s*revenue\s*by\s*patient\b/.test(label)) return;

    const indexes = headerIndexes ?? ({ mrn: findColumn(record, "mrn"), patientName: findColumn(record, "patientName"), serviceCode: findColumn(record, "serviceCode"), serviceName: findColumn(record, "serviceName"), gross: findColumn(record, "gross"), quantity: findColumn(record, "quantity"), discount: findColumn(record, "discount"), deduct: findColumn(record, "deduct"), net: findColumn(record, "net"), fromDate: findColumn(record, "fromDate"), toDate: findColumn(record, "toDate"), account: findColumn(record, "account"), printDate: findColumn(record, "printDate") } as Record<RevenueField, number>);
    const compactServiceLayout = Boolean(headerIndexes && indexes.serviceCode < 0);
    const serviceCodeIndex = compactServiceLayout ? 0 : indexes.serviceCode;
    const serviceNameIndex = compactServiceLayout ? indexes.patientName : indexes.serviceName;
    const moneyIndexes = indexes;
    const candidateMrn = cell(record, indexes.mrn);
    const groupedPatientHeader = compactServiceLayout ? /^\d+$/.test(candidateMrn) : Boolean(candidateMrn);
    const mrn = groupedPatientHeader ? candidateMrn : null;
    const patientName = groupedPatientHeader ? cell(record, indexes.patientName) : "";
    const serviceCode = cell(record, serviceCodeIndex);
    const serviceName = cell(record, serviceNameIndex);
    const values = { gross: numberValue(cell(record, moneyIndexes.gross)), quantity: numberValue(cell(record, moneyIndexes.quantity)), discount: numberValue(cell(record, moneyIndexes.discount)), deduct: numberValue(cell(record, moneyIndexes.deduct)), net: numberValue(cell(record, moneyIndexes.net)) };
    const hasMoneyFields = Object.values(values).some(value => value !== null);
    if (!headerIndexes && ["mrn", "patientmrn"].includes(cleanHeader(candidateMrn))) return;
    if (groupedPatientHeader && !hasMoneyFields) { currentMrn = mrn || currentMrn; currentPatientName = patientName || currentPatientName; return; }
    const isGrandTotal = /grand\s*total|total\s*report|report\s*total/.test(label);
    const isSubtotal = /patient\s*subtotal|subtotal|patient\s*total/.test(label) && !isGrandTotal;
    if (isGrandTotal) {
      grandTotalRowCount += 1;
      grandTotal = reportTotals(record, values);
      grandTotalSourceRowNumber = sourceRowNumber;
      return;
    }
    const isUnlabeledSubtotal = compactServiceLayout && !candidateMrn && !serviceCode && !serviceName && hasMoneyFields;
    if (isSubtotal || isUnlabeledSubtotal) {
      subtotalRowCount += 1;
      reportedSubtotals.push({ sourceRowNumber, mrn: currentMrn, patientName: currentPatientName, reported: reportTotals(record, values) });
      return;
    }
    if (mrn || patientName) { currentMrn = mrn || currentMrn; currentPatientName = patientName || currentPatientName; }
    if (!serviceCode && !serviceName && !hasMoneyFields) return;
    const warnings: string[] = [];
    const errors: string[] = [];
    if (!serviceCode) errors.push("Service code is missing.");
    if (!serviceName) errors.push("Service name is missing.");
    if (!currentMrn) warnings.push("MRN is missing; this service row will remain unmatched.");
    if (!currentPatientName) warnings.push("Patient name is missing from the report group.");
    for (const [key, value] of Object.entries(values)) if (value === null) errors.push(`${key[0]!.toUpperCase()}${key.slice(1)} must be numeric.`);
    const money = Object.fromEntries(Object.entries(values).map(([key, value]) => [key, value ?? 0])) as RevenueMoney;
    if (Math.abs(money.gross - money.discount - money.deduct - money.net) > 0.005) warnings.push("HMS Net differs from Gross - Discount - Deduct; original HMS values are retained.");
    const fingerprint = createHash("sha256").update([sourceRowNumber, currentMrn ?? "", currentPatientName, serviceCode, serviceName, money.gross, money.quantity, money.discount, money.deduct, money.net].join("\u001f"), "utf8").digest("hex");
    rows.push({ ...money, sourceRowNumber, mrn: currentMrn, patientName: currentPatientName, serviceCode, serviceName, fromDate: dateValue(cell(record, indexes.fromDate)) || fromDate, toDate: dateValue(cell(record, indexes.toDate)) || toDate, printDate: dateValue(cell(record, indexes.printDate)) || printDate, validation: errors.length ? "ERROR" : warnings.length ? "WARNING" : "READY", warnings, errors, fingerprint });
  });

  if (!rows.length) fatalErrors.push("No HMS service rows were detected. Check that the CSV contains service code, service name, and Gross/Quantity/Discount/Deduct/Net columns.");
  const patients = Array.from(rows.reduce((groups, row) => { const key = `${row.mrn ?? "unmatched"}\u001f${row.patientName}`; const group = groups.get(key) ?? { mrn: row.mrn, patientName: row.patientName, rows: [], totals: { gross: 0, quantity: 0, discount: 0, deduct: 0, net: 0 } }; group.rows.push(row); group.totals = totals(group.rows); groups.set(key, group); return groups; }, new Map<string, RevenuePatientGroup>()).values());
  const calculatedTotals = totals(rows);
  const reconciliationDifferences: RevenueReconciliationDifference[] = reportedSubtotals.flatMap(subtotal => {
    const calculated = totals(rows.filter(row => row.mrn === subtotal.mrn && row.patientName === subtotal.patientName));
    const differences = totalsDifference(subtotal.reported, calculated);
    return Object.keys(differences).length ? [{ scope: "PATIENT_SUBTOTAL" as const, sourceRowNumber: subtotal.sourceRowNumber, mrn: subtotal.mrn, reported: subtotal.reported, calculated, differences }] : [];
  });
  if (grandTotal && grandTotalSourceRowNumber !== null) {
    const differences = totalsDifference(grandTotal, calculatedTotals);
    if (Object.keys(differences).length) reconciliationDifferences.push({ scope: "GRAND_TOTAL", sourceRowNumber: grandTotalSourceRowNumber, mrn: null, reported: grandTotal, calculated: calculatedTotals, differences });
  }
  const subtotalDifferenceCount = reconciliationDifferences.filter(item => item.scope === "PATIENT_SUBTOTAL").length;
  if (subtotalDifferenceCount) fatalErrors.push(`HMS SUBTOTAL RECONCILIATION FAILED: ${subtotalDifferenceCount} patient subtotal${subtotalDifferenceCount === 1 ? "" : "s"} ${subtotalDifferenceCount === 1 ? "does" : "do"} not match ${subtotalDifferenceCount === 1 ? "its" : "their"} service rows.`);
  if (grandTotal && !sameTotals(calculatedTotals, grandTotal)) fatalErrors.push("HMS TOTAL RECONCILIATION FAILED: service-row totals do not equal the HMS Grand Total.");
  if (!grandTotal) fatalErrors.push("The HMS Grand Total row was not detected; import is blocked until the report total is available.");
  return { fileSha256, fromDate, toDate, account, printDate, grandTotal, rows, patients, fatalErrors, invalidRowCount: rows.filter(row => row.validation === "ERROR").length, subtotalRowCount, grandTotalRowCount, reconciliationDifferences, mrnDuplicateEntries: findMrnDuplicateEntries(rows) };
}

export function markRevenueDuplicates(rows: RevenueServiceRow[], existingFingerprints: Set<string>, fileAlreadyImported: boolean) {
  const seen = new Set<string>();
  return rows.map(row => {
    if (row.validation === "ERROR") return row;
    if (fileAlreadyImported || seen.has(row.fingerprint) || existingFingerprints.has(row.fingerprint)) return { ...row, validation: "DUPLICATE" as const, warnings: [...row.warnings, fileAlreadyImported ? "This exact revenue report file was already imported." : "This revenue service row already exists."] };
    seen.add(row.fingerprint);
    return row;
  });
}

export function revenueTotals(rows: RevenueMoney[]) { return totals(rows); }
export function revenueTotalsMatch(left: RevenueMoney, right: RevenueMoney) { return sameTotals(left, right); }
