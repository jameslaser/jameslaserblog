import { describe, expect, it } from "vitest";
import { isPublicStorageKey } from "./_core/storageProxy";

describe("public storage key policy", () => {
  it("allows only public CMS media, the public homepage assets, and the authoritative original consent PDFs", () => {
    expect(isPublicStorageKey("cms-media/1/example.jpg")).toBe(true);
    expect(isPublicStorageKey("public-home/exterior/IMG_6504_a7062d4c.jpeg")).toBe(true);
    expect(isPublicStorageKey("james-laser-mens-facial-laser-hair-removal-riyadh_fb2a3e42.mp4")).toBe(true);
    expect(isPublicStorageKey("deka-again-riyadh-photo_ac4f0d6e.jpeg")).toBe(true);
    expect(isPublicStorageKey("gentle-promax-riyadh-photo_30349ffb.jpeg")).toBe(true);
    expect(isPublicStorageKey("duetto-machine-riyadh-photo_03e9b4c8.jpeg")).toBe(true);
    expect(isPublicStorageKey("FILENO3(1)_9dee31e1.pdf")).toBe(true);
  });

  it("does not expose private consent-signature evidence or arbitrary storage keys through the public proxy", () => {
    expect(isPublicStorageKey("consent-signatures/request-42/ES-2026-000042-signature.png")).toBe(false);
    expect(isPublicStorageKey("consent-signatures/request-42/ES-2026-000042-evidence.json")).toBe(false);
    expect(isPublicStorageKey("patient-files/private-record.pdf")).toBe(false);
    expect(isPublicStorageKey("private-media/internal-review.jpg")).toBe(false);
    expect(isPublicStorageKey("unknown-object.pdf")).toBe(false);
  });
});
