import { describe, expect, it } from "vitest";
import { getDb } from "./db";
import { listHeartbeatJobs } from "./_core/heartbeat";
import { configureWhatsAppAutomationScheduler } from "./whatsappAutomation";

const ownerActor = { id: 1, name: null };

describe("live Manus scheduler readiness", () => {
  it("lists the project-owner scheduler inventory through the managed service", async () => {
    const result = await listHeartbeatJobs("");

    expect(typeof result.total).toBe("number");
    expect(Array.isArray(result.jobs)).toBe(true);
  }, 30_000);

  it("provisions exactly one dormant scheduler and preserves the no-send gate", async () => {
    const result = await configureWhatsAppAutomationScheduler("", ownerActor);
    const db = await getDb();
    const row = await db!.execute("SELECT schedulerTaskUid, automationEnabled FROM whatsappSettings WHERE businessAccountId = '1833666484124208' ORDER BY updatedAt DESC LIMIT 1");

    expect(result.taskUid).toBeTruthy();
    expect(row[0][0]).toMatchObject({ schedulerTaskUid: result.taskUid, automationEnabled: 0 });
  }, 30_000);
});
