import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
import { followUpQueueStatus } from "./sessionFollowUps";

const schema = readFileSync(resolve(process.cwd(), "drizzle/schema.ts"), "utf8");
const migration = readFileSync(resolve(process.cwd(), "drizzle/migrations/0028_add_session_follow_up_workflows.sql"), "utf8");
const backend = readFileSync(resolve(process.cwd(), "server/sessionFollowUps.ts"), "utf8");
const router = readFileSync(resolve(process.cwd(), "server/routers.ts"), "utf8");
const portal = readFileSync(resolve(process.cwd(), "client/src/pages/AdminPortal.tsx"), "utf8");
const sessionsPortal = readFileSync(resolve(process.cwd(), "client/src/pages/SessionFollowUpWorkspaces.tsx"), "utf8");
const app = readFileSync(resolve(process.cwd(), "client/src/App.tsx"), "utf8");

function riyadhDate() {
  return new Intl.DateTimeFormat("sv-SE", { timeZone: "Asia/Riyadh", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
}

function addDays(value: string, days: number) {
  const date = new Date(`${value}T12:00:00Z`);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

describe("Sessions and Follow-Ups workflow", () => {
  it("uses an additive schema and preserves existing appointment follow-up fields", () => {
    expect(schema).toContain('mysqlTable("sessionRecords"');
    expect(schema).toContain('mysqlTable("followUps"');
    expect(schema).toContain('uniqueIndex("sessionRecords_appointment_idx")');
    expect(schema).toContain('onDelete: "restrict"');
    expect(migration).toContain("Existing appointments, patients, legacy follow-up fields");
    expect(migration).not.toMatch(/\bDROP\b|\bTRUNCATE\b|\bDELETE\s+FROM\b/i);
    expect(migration).not.toContain("ALTER TABLE `appointments`");
  });

  it("requires a real arrived or completed appointment and records an audit event", () => {
    expect(backend).toContain('appointment.status !== "arrived" && appointment.status !== "completed"');
    expect(backend).toContain('subjectType: "session_record"');
    expect(backend).toContain('action: input.id ? notesChanged ? "Updated private nurse\'s notes on session record" : "Updated session record" : "Created session record"');
    expect(backend).not.toContain("deleteSessionRecord");
  });

  it("supports auditable historical nurse-notes corrections in protected session history", () => {
    expect(backend).toContain('notes: sessionRecords.notes');
    expect(backend).toContain('notesChanged = existingRows[0].notes !== input.notes');
    expect(backend).toContain('row.sessionDate.includes(query)');
    expect(sessionsPortal).toContain("Private Nurse’s Notes");
    expect(sessionsPortal).toContain("Historical records remain available for authorized Nurse’s Notes corrections.");
    expect(sessionsPortal).toContain("Search patient, MRN, or date");
    expect(sessionsPortal).toContain("Edit Nurse’s Notes");
  });

  it("finishes an arrived appointment only with a protected post-session record", () => {
    expect(backend).toContain("finishAppointmentWithPostSessionNotes");
    expect(backend).toContain('appointment.status !== "arrived"');
    expect(backend).toContain('action: "Finished appointment and recorded post-session notes"');
    expect(backend).toContain('action: "Created session record from post-session notes"');
    expect(router).toContain("finishSession: receptionProcedure.input(postSessionNotesInput)");
    expect(router).toContain('status: z.enum(["arrived", "no-show", "cancelled"])');
    expect(portal).toContain("function PostSessionNotesPanel");
    expect(portal).toContain("Private Nurse’s Notes");
    expect(portal).toContain("Save notes & finish session");
  });

  it("preserves a legacy reminder until staff explicitly starts tracking it", () => {
    expect(backend).toContain('kind: "legacy" as const');
    expect(backend).toContain("trackLegacyAppointmentFollowUp");
    expect(backend).toContain('action: "Started tracking legacy follow-up"');
    expect(backend).not.toContain("deleteFollowUp");
  });

  it("derives queue urgency in Riyadh while retaining terminal workflow states", () => {
    const today = riyadhDate();
    expect(followUpQueueStatus(today, "pending")).toBe("due");
    expect(followUpQueueStatus(addDays(today, -1), "contacted")).toBe("overdue");
    expect(followUpQueueStatus(addDays(today, 1), "pending")).toBe("upcoming");
    expect(followUpQueueStatus(null, "pending")).toBe("unscheduled");
    expect(followUpQueueStatus(today, "completed")).toBe("completed");
    expect(followUpQueueStatus(today, "cancelled")).toBe("cancelled");
  });

  it("enforces owner/admin backend access and links every workflow route", () => {
    expect(router).toContain("sessionRecords: adminProcedure");
    expect(router).toContain("saveSessionRecord: adminProcedure");
    expect(router).toContain("followUps: adminProcedure");
    expect(router).toContain("updateFollowUp: adminProcedure");
    expect(portal).toContain('page === "sessions" ? <SessionsWorkspace />');
    expect(portal).toContain('page === "followups" ? <FollowUpsWorkspace />');
    expect(app).toContain('path={"/admin/sessions"}');
    expect(app).toContain('path={"/admin/follow-ups"}');
    expect(app).toContain('path={"/admin/reminders"}');
  });
});
