import { describe, expect, it } from "vitest";
import { createZeroCreditDraft, rankTemplateSuggestions } from "./webChat";

const templates = [
  { id: 1, label: "Secure appointment request", language: "en" as const, body: "Use the secure appointment form for a staff-reviewed request.", isActive: true },
  { id: 2, label: "Privacy and medical questions", language: "en" as const, body: "This chat cannot accept medical details or provide medical advice.", isActive: true },
  { id: 3, label: "Inactive reply", language: "en" as const, body: "Do not use this template.", isActive: false },
];

describe("createZeroCreditDraft", () => {
  it("redirects appointment requests to the secure appointment form", () => {
    const draft = createZeroCreditDraft({ visitorMessage: "Can I book an appointment?", language: "en" });
    expect(draft).toContain("secure appointment form");
    expect(draft).toContain("before confirmation");
  });

  it("does not offer medical advice for sensitive health context", () => {
    const draft = createZeroCreditDraft({ visitorMessage: "I take medication for a skin condition", language: "en" });
    expect(draft).toContain("cannot provide medical advice");
    expect(draft).toContain("secure appointment form");
  });

  it("returns Arabic privacy-safe guidance for medical context", () => {
    const draft = createZeroCreditDraft({ visitorMessage: "لدي حساسية في الجلد", language: "ar" });
    expect(draft).toContain("لا تقدم نصيحة طبية");
    expect(draft).toContain("نموذج طلب الموعد الآمن");
  });
});

describe("rankTemplateSuggestions", () => {
  it("prefers the saved appointment template for booking language", () => {
    const suggestions = rankTemplateSuggestions("Can I book an appointment this week?", templates);
    expect(suggestions[0]?.id).toBe(1);
    expect(suggestions[0]?.body).toContain("secure appointment form");
  });

  it("prefers the saved privacy template for medical context and excludes inactive templates", () => {
    const suggestions = rankTemplateSuggestions("Can I discuss medication and a skin condition?", templates);
    expect(suggestions[0]?.id).toBe(2);
    expect(suggestions.some(template => template.id === 3)).toBe(false);
  });
});
