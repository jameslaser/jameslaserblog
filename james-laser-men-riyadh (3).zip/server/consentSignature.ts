import { and, eq } from "drizzle-orm";
import { createHash, randomBytes } from "node:crypto";
import { activityLogs, consentSignatureSessions, consultationRequests } from "../drizzle/schema";
import { ORIGINAL_CONSENT_DOCUMENTS, ORIGINAL_CONSENT_SET_REFERENCE } from "@shared/originalConsent";
import { getDb } from "./db";
import { storageGetSignedUrl, storagePut } from "./storage";

const ACTIVE_REQUEST_STATUSES = ["pending", "contacted", "clarification_requested"] as const;
const SIGNATURE_TTL_MS = 7 * 24 * 60 * 60 * 1000;

type SignatureSessionStatus = "pending" | "signed" | "revoked" | "expired";

type PublicRequestSignatureInput = {
  clientSubmissionId: string;
  signerName: string;
  signatureDataUrl: string;
  language: "en" | "ar";
};

function hashToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

function publicSessionToken() {
  return randomBytes(32).toString("base64url");
}

function isActiveRequestStatus(status: string) {
  return ACTIVE_REQUEST_STATUSES.includes(status as (typeof ACTIVE_REQUEST_STATUSES)[number]);
}

function isExpired(expiresAt: Date) {
  return expiresAt.getTime() <= Date.now();
}

async function expireIfNeeded(session: { id: number; status: SignatureSessionStatus; expiresAt: Date }) {
  if (session.status === "pending" && isExpired(session.expiresAt)) {
    const db = await getDb();
    if (!db) throw new Error("The signature service is temporarily unavailable.");
    await db.update(consentSignatureSessions).set({ status: "expired" }).where(eq(consentSignatureSessions.id, session.id));
    return "expired" as const;
  }
  return session.status;
}

function signatureSessionView(session: typeof consentSignatureSessions.$inferSelect) {
  return {
    id: session.id,
    consultationRequestId: session.consultationRequestId,
    status: session.status,
    consentSetReference: session.consentSetReference,
    recipientLanguage: session.recipientLanguage,
    expiresAt: session.expiresAt,
    signerName: session.signerName,
    signedAt: session.signedAt,
    signatureReference: session.signatureReference,
    hasSignatureEvidence: Boolean(session.signatureEvidenceKey),
    createdAt: session.createdAt,
    revokedAt: session.revokedAt,
  };
}

/** Create or renew a single private signing session for an active appointment request. */
export async function createConsentSignatureSession(requestId: number, staffUserId: number, language: "en" | "ar") {
  const db = await getDb();
  if (!db) throw new Error("The signature service is temporarily unavailable.");

  const requestRows = await db.select({
    id: consultationRequests.id,
    status: consultationRequests.status,
    originalConsentSetReference: consultationRequests.originalConsentSetReference,
    originalConsentDocuments: consultationRequests.originalConsentDocuments,
  }).from(consultationRequests).where(eq(consultationRequests.id, requestId)).limit(1);
  const request = requestRows[0];
  if (!request) throw new Error("The appointment request was not found.");
  if (!isActiveRequestStatus(request.status)) throw new Error("Only active appointment requests can receive a signing session.");
  if (request.originalConsentSetReference !== ORIGINAL_CONSENT_SET_REFERENCE || !request.originalConsentDocuments) {
    throw new Error("This request does not contain the required original consent set.");
  }

  const token = publicSessionToken();
  const tokenHash = hashToken(token);
  const expiresAt = new Date(Date.now() + SIGNATURE_TTL_MS);
  const existingRows = await db.select().from(consentSignatureSessions).where(eq(consentSignatureSessions.consultationRequestId, requestId)).limit(1);
  const existing = existingRows[0];

  if (existing?.status === "signed") throw new Error("A signed consent record already exists for this appointment request.");
  if (existing) {
    await db.update(consentSignatureSessions).set({
      tokenHash,
      status: "pending",
      consentSetReference: ORIGINAL_CONSENT_SET_REFERENCE,
      sourceConsentDocuments: JSON.stringify(ORIGINAL_CONSENT_DOCUMENTS),
      recipientLanguage: language,
      expiresAt,
      signerName: null,
      signedAt: null,
      signatureEvidenceKey: null,
      signatureEvidenceUrl: null,
      signatureReference: null,
      createdByUserId: staffUserId,
      revokedByUserId: null,
      revokedAt: null,
    }).where(eq(consentSignatureSessions.id, existing.id));
    await db.insert(activityLogs).values({ actorUserId: staffUserId, action: "Renewed e-signature session", subjectType: "consultation_request", subjectId: requestId });
    return { sessionId: existing.id, token, expiresAt };
  }

  const [inserted] = await db.insert(consentSignatureSessions).values({
    consultationRequestId: requestId,
    tokenHash,
    status: "pending",
    consentSetReference: ORIGINAL_CONSENT_SET_REFERENCE,
    sourceConsentDocuments: JSON.stringify(ORIGINAL_CONSENT_DOCUMENTS),
    recipientLanguage: language,
    expiresAt,
    createdByUserId: staffUserId,
  }).$returningId();
  if (!inserted) throw new Error("The e-signature session could not be created.");
  const sessionId = inserted.id;
  await db.insert(activityLogs).values({ actorUserId: staffUserId, action: "Created e-signature session", subjectType: "consultation_request", subjectId: requestId });
  return { sessionId, token, expiresAt };
}

export async function getConsentSignatureSessionForStaff(requestId: number) {
  const db = await getDb();
  if (!db) throw new Error("The signature service is temporarily unavailable.");
  const rows = await db.select().from(consentSignatureSessions).where(eq(consentSignatureSessions.consultationRequestId, requestId)).limit(1);
  const session = rows[0];
  if (!session) return null;
  const status = await expireIfNeeded(session);
  return signatureSessionView({ ...session, status });
}

export async function revokeConsentSignatureSession(requestId: number, staffUserId: number) {
  const db = await getDb();
  if (!db) throw new Error("The signature service is temporarily unavailable.");
  const rows = await db.select().from(consentSignatureSessions).where(eq(consentSignatureSessions.consultationRequestId, requestId)).limit(1);
  const session = rows[0];
  if (!session) throw new Error("No e-signature session exists for this request.");
  const status = await expireIfNeeded(session);
  if (status !== "pending") throw new Error("Only a pending e-signature session can be revoked.");
  await db.update(consentSignatureSessions).set({ status: "revoked", revokedByUserId: staffUserId, revokedAt: new Date() }).where(eq(consentSignatureSessions.id, session.id));
  await db.insert(activityLogs).values({ actorUserId: staffUserId, action: "Revoked e-signature session", subjectType: "consultation_request", subjectId: requestId });
}

/** Only authorized staff can resolve a short-lived download URL for signed evidence. */
export async function getConsentSignatureEvidenceDownload(requestId: number) {
  const db = await getDb();
  if (!db) throw new Error("The signature service is temporarily unavailable.");
  const rows = await db.select({ status: consentSignatureSessions.status, key: consentSignatureSessions.signatureEvidenceKey }).from(consentSignatureSessions).where(eq(consentSignatureSessions.consultationRequestId, requestId)).limit(1);
  const session = rows[0];
  if (session?.key && session.status === "signed") return { url: await storageGetSignedUrl(session.key) };
  const requestRows = await db.select({ status: consultationRequests.consentSignatureStatus, key: consultationRequests.consentSignatureEvidenceKey }).from(consultationRequests).where(eq(consultationRequests.id, requestId)).limit(1);
  const request = requestRows[0];
  if (!request?.key || request.status !== "received") throw new Error("No signed evidence is available for this request.");
  return { url: await storageGetSignedUrl(request.key) };
}

/**
 * Stores signature evidence collected inside the existing public appointment
 * request. The returned private storage key is persisted only on that exact
 * consultation request; the original consent PDFs remain unchanged.
 */
export async function storePublicRequestSignatureEvidence(input: PublicRequestSignatureInput) {
  const base64 = input.signatureDataUrl.replace(/^data:image\/png;base64,/, "");
  const image = Buffer.from(base64, "base64");
  if (!image.length || image.length > 500_000) throw new Error("The signature image is not valid.");
  const signedAt = new Date();
  const safeSubmissionId = input.clientSubmissionId.replace(/[^a-zA-Z0-9-]/g, "").slice(0, 64);
  const signatureReference = `ES-${signedAt.getUTCFullYear()}-${safeSubmissionId.slice(0, 18).toUpperCase()}`;
  const signatureAsset = await storagePut(`consent-signatures/public-request-${safeSubmissionId}/${signatureReference}-signature.png`, image, "image/png");
  const evidencePack = await storagePut(`consent-signatures/public-request-${safeSubmissionId}/${signatureReference}-evidence.json`, JSON.stringify({
    version: "appointment-request-inline-signature-v1",
    signatureReference,
    consentSetReference: ORIGINAL_CONSENT_SET_REFERENCE,
    originalDocuments: ORIGINAL_CONSENT_DOCUMENTS,
    signerName: input.signerName,
    language: input.language,
    signedAt: signedAt.toISOString(),
    signatureImageKey: signatureAsset.key,
    clientSubmissionId: input.clientSubmissionId,
  }), "application/json");
  return { signedAt, signatureReference, signatureEvidenceKey: evidencePack.key };
}

async function findPendingSessionByToken(token: string) {
  const db = await getDb();
  if (!db) throw new Error("The signature service is temporarily unavailable.");
  const rows = await db.select().from(consentSignatureSessions).where(eq(consentSignatureSessions.tokenHash, hashToken(token))).limit(1);
  const session = rows[0];
  if (!session) throw new Error("This signing link is invalid, expired, or no longer available.");
  const status = await expireIfNeeded(session);
  if (status !== "pending") throw new Error("This signing link is invalid, expired, or no longer available.");
  return session;
}

/** Public token view intentionally omits patient, request, and staff information. */
export async function getPublicConsentSignatureSession(token: string) {
  const session = await findPendingSessionByToken(token);
  return {
    consentSetReference: session.consentSetReference,
    sourceConsentDocuments: session.sourceConsentDocuments,
    language: session.recipientLanguage,
    expiresAt: session.expiresAt,
  };
}

/** Store a separate signature evidence pack; original PDFs are never copied, edited, or replaced. */
export async function submitPublicConsentSignature(input: { token: string; signerName: string; signatureDataUrl: string }) {
  const db = await getDb();
  if (!db) throw new Error("The signature service is temporarily unavailable.");
  const session = await findPendingSessionByToken(input.token);
  const requestRows = await db.select({ id: consultationRequests.id, status: consultationRequests.status }).from(consultationRequests).where(eq(consultationRequests.id, session.consultationRequestId)).limit(1);
  const request = requestRows[0];
  if (!request || !isActiveRequestStatus(request.status)) throw new Error("This appointment request is no longer available for signature.");

  const base64 = input.signatureDataUrl.replace(/^data:image\/png;base64,/, "");
  const image = Buffer.from(base64, "base64");
  if (!image.length || image.length > 500_000) throw new Error("The signature image is not valid.");

  const signedAt = new Date();
  const signatureReference = `ES-${signedAt.getUTCFullYear()}-${String(session.id).padStart(6, "0")}`;
  const signatureAsset = await storagePut(`consent-signatures/request-${request.id}/${signatureReference}-signature.png`, image, "image/png");
  const evidencePack = await storagePut(`consent-signatures/request-${request.id}/${signatureReference}-evidence.json`, JSON.stringify({
    version: "e-signature-evidence-v1",
    signatureReference,
    consentSetReference: session.consentSetReference,
    originalDocuments: JSON.parse(session.sourceConsentDocuments),
    signerName: input.signerName,
    signedAt: signedAt.toISOString(),
    signatureImageKey: signatureAsset.key,
  }), "application/json");

  await db.transaction(async tx => {
    await tx.update(consentSignatureSessions).set({
      status: "signed",
      signerName: input.signerName,
      signedAt,
      signatureEvidenceKey: evidencePack.key,
      signatureEvidenceUrl: null,
      signatureReference,
    }).where(and(eq(consentSignatureSessions.id, session.id), eq(consentSignatureSessions.status, "pending")));
    const updated = await tx.select({ id: consentSignatureSessions.id }).from(consentSignatureSessions).where(and(eq(consentSignatureSessions.id, session.id), eq(consentSignatureSessions.status, "signed"))).limit(1);
    if (updated.length !== 1) throw new Error("This signing link is no longer available.");
    await tx.update(consultationRequests).set({ consentSignatureStatus: "received", consentSignatureReference: signatureReference }).where(eq(consultationRequests.id, request.id));
    await tx.insert(activityLogs).values({ action: "Recorded e-signature evidence", subjectType: "consultation_request", subjectId: request.id });
  });

  return { signatureReference };
}
