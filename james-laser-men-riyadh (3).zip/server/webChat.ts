import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";
import { activityLogs, webChatConversations, webChatMessages, webChatTemplates } from "../drizzle/schema";
import { getDb } from "./db";

type StaffActor = { id: number; name: string | null };
type ChatLanguage = "en" | "ar";
type ConversationStatus = "open" | "resolved" | "archived";
type MessageSource = "manual" | "template" | "ai_draft";
type InboxSort = "newest" | "oldest" | "unread";
type TemplateCandidate = Pick<typeof webChatTemplates.$inferSelect, "id" | "label" | "language" | "body" | "isActive">;

const defaultTemplates: Array<{ label: string; language: ChatLanguage; body: string }> = [
  {
    label: "Secure appointment request",
    language: "en",
    body: "Thank you for contacting James Laser at New Look Clinic. To request an appointment, please use the secure appointment form. A staff member will review the request before confirmation.",
  },
  {
    label: "Privacy and medical questions",
    language: "en",
    body: "For your privacy, please do not share medical details in website chat. This chat cannot provide medical advice. Use the secure appointment request form so the clinic team can review your information privately.",
  },
  {
    label: "طلب موعد آمن",
    language: "ar",
    body: "شكرًا لتواصلك مع جيمس ليزر في نيو لوك كلينك. لطلب موعد، يرجى استخدام نموذج طلب الموعد الآمن. سيراجع أحد أعضاء الفريق الطلب قبل تأكيده.",
  },
  {
    label: "الخصوصية والأسئلة الطبية",
    language: "ar",
    body: "حفاظًا على خصوصيتك، يرجى عدم مشاركة التفاصيل الطبية في محادثة الموقع. هذه المحادثة لا تقدم نصيحة طبية. استخدم نموذج طلب الموعد الآمن ليتمكن فريق العيادة من مراجعة معلوماتك بشكل خاص.",
  },
];

async function database() {
  const db = await getDb();
  if (!db) throw new Error("The website chat service is temporarily unavailable.");
  return db;
}

function publicMessage(message: typeof webChatMessages.$inferSelect) {
  return {
    id: message.id,
    direction: message.direction,
    body: message.body,
    createdAt: message.createdAt,
  };
}

function isTyping(timestamp: Date | null) {
  return Boolean(timestamp && Date.now() - timestamp.getTime() < 12_000);
}

function rejectPublicSensitiveText(body: string) {
  if (/\b[\w.+-]+@[\w-]+\.[\w.-]+\b/i.test(body) || /(?:\+?\d[\s().-]*){7,}/.test(body)) {
    throw new Error("For privacy, do not include phone numbers or email addresses in website chat. Use the secure appointment form for contact details.");
  }
  if (/\b(medication|medicine|isotretinoin|roaccutane|diagnosis|skin condition|allergy|pregnan|medical history)\b|دواء|علاج|حساسية|حامل|تاريخ طبي|حالة جلد/i.test(body)) {
    throw new Error("For privacy and safety, website chat cannot accept medical information. Please use the secure appointment form for clinic review.");
  }
}

async function ensureDefaultTemplates() {
  const db = await database();
  const existing = await db.select({ id: webChatTemplates.id }).from(webChatTemplates).limit(1);
  if (existing.length) return;
  await db.insert(webChatTemplates).values(defaultTemplates.map(template => ({ ...template, isActive: true })));
}

/** Scores saved, staff-reviewed reply templates against the latest visitor wording without invoking an LLM. */
export function rankTemplateSuggestions(visitorMessage: string, templates: TemplateCandidate[]) {
  const message = visitorMessage.toLocaleLowerCase();
  const requestWords = /appointment|book|booking|schedule|موعد|حجز|طلب/.test(message);
  const sensitiveWords = /privacy|medical|medicine|medication|skin|condition|price|cost|package|خصوصية|طبي|دواء|جلد|سعر|تكلفة|باقة/.test(message);

  return templates.filter(template => template.isActive).map(template => {
    const content = `${template.label} ${template.body}`.toLocaleLowerCase();
    let score = 0;
    if (requestWords && /appointment|request|موعد|طلب/.test(content)) score += 12;
    if (sensitiveWords && /privacy|medical|price|خصوصية|طبي|سعر/.test(content)) score += 12;
    const sharedTerms = message.split(/[^a-zA-Z0-9\u0600-\u06ff]+/).filter(term => term.length > 3 && content.includes(term));
    score += Math.min(sharedTerms.length, 4);
    return { ...template, score };
  }).sort((a, b) => b.score - a.score || a.label.localeCompare(b.label));
}

export async function getPublicWebChatConversation(sessionToken: string) {
  const db = await database();
  const conversation = await db.select({
    id: webChatConversations.id,
    language: webChatConversations.language,
    status: webChatConversations.status,
    staffTypingAt: webChatConversations.staffTypingAt,
    lastStaffReadAt: webChatConversations.lastStaffReadAt,
  }).from(webChatConversations).where(eq(webChatConversations.sessionToken, sessionToken)).limit(1);
  if (!conversation[0]) return null;

  const messages = await db.select().from(webChatMessages)
    .where(eq(webChatMessages.conversationId, conversation[0].id))
    .orderBy(webChatMessages.createdAt, webChatMessages.id);
  const latestVisitorMessage = [...messages].reverse().find(message => message.direction === "visitor");

  return {
    language: conversation[0].language,
    status: conversation[0].status,
    staffIsTyping: isTyping(conversation[0].staffTypingAt),
    staffReadLatestVisitor: Boolean(conversation[0].lastStaffReadAt && latestVisitorMessage && latestVisitorMessage.createdAt <= conversation[0].lastStaffReadAt),
    messages: messages.map(publicMessage),
  };
}

export async function markVisitorWebChatRead(sessionToken: string) {
  const db = await database();
  await db.update(webChatConversations).set({ unreadForVisitor: 0, lastVisitorReadAt: new Date() })
    .where(eq(webChatConversations.sessionToken, sessionToken));
}

export async function markVisitorWebChatTyping(sessionToken: string) {
  const db = await database();
  await db.update(webChatConversations).set({ visitorTypingAt: new Date() })
    .where(eq(webChatConversations.sessionToken, sessionToken));
}

export async function sendVisitorWebChatMessage(input: { sessionToken: string; language: ChatLanguage; body: string }) {
  rejectPublicSensitiveText(input.body);
  const db = await database();
  const now = new Date();

  return db.transaction(async tx => {
    let conversation = await tx.select({
      id: webChatConversations.id,
      unreadForStaff: webChatConversations.unreadForStaff,
    }).from(webChatConversations).where(eq(webChatConversations.sessionToken, input.sessionToken)).limit(1);

    if (!conversation[0]) {
      const inserted = await tx.insert(webChatConversations).values({
        sessionToken: input.sessionToken,
        language: input.language,
        status: "open",
        unreadForStaff: 0,
        unreadForVisitor: 0,
        lastMessageAt: now,
      });
      const id = Number(inserted[0].insertId);
      conversation = [{ id, unreadForStaff: 0 }];
    }

    const conversationId = conversation[0].id;
    const insertedMessage = await tx.insert(webChatMessages).values({
      conversationId,
      direction: "visitor",
      source: "manual",
      body: input.body,
    });
    const messageId = Number(insertedMessage[0].insertId);

    await tx.update(webChatConversations).set({
      language: input.language,
      status: "open",
      unreadForStaff: sql`${webChatConversations.unreadForStaff} + 1`,
      visitorTypingAt: null,
      lastMessageAt: now,
    }).where(eq(webChatConversations.id, conversationId));

    return { conversationId, messageId, shouldNotifyStaff: conversation[0].unreadForStaff === 0 };
  });
}

export async function listAdminWebChatConversations(input: { status?: ConversationStatus; query?: string; language?: ChatLanguage; unreadOnly?: boolean; sort?: InboxSort }) {
  const db = await database();
  const conditions = [
    input.status ? eq(webChatConversations.status, input.status) : undefined,
    input.language ? eq(webChatConversations.language, input.language) : undefined,
    input.unreadOnly ? sql`${webChatConversations.unreadForStaff} > 0` : undefined,
  ].filter(Boolean) as ReturnType<typeof eq>[];
  const rows = await (conditions.length
    ? db.select().from(webChatConversations).where(and(...conditions)).orderBy(desc(webChatConversations.lastMessageAt))
    : db.select().from(webChatConversations).orderBy(desc(webChatConversations.lastMessageAt)));

  if (!rows.length) return [];
  const messages = await db.select().from(webChatMessages)
    .where(inArray(webChatMessages.conversationId, rows.map(row => row.id)))
    .orderBy(desc(webChatMessages.createdAt), desc(webChatMessages.id));
  const previews = new Map<number, typeof messages[number]>();
  const messageBodies = new Map<number, string[]>();
  for (const message of messages) {
    if (!previews.has(message.conversationId)) previews.set(message.conversationId, message);
    messageBodies.set(message.conversationId, [...(messageBodies.get(message.conversationId) ?? []), message.body]);
  }

  const query = input.query?.trim().toLocaleLowerCase();
  const filtered = rows.map(row => ({
    id: row.id,
    language: row.language,
    status: row.status,
    unreadForStaff: row.unreadForStaff,
    unreadForVisitor: row.unreadForVisitor,
    lastStaffReadAt: row.lastStaffReadAt,
    lastVisitorReadAt: row.lastVisitorReadAt,
    staffIsTyping: isTyping(row.staffTypingAt),
    visitorIsTyping: isTyping(row.visitorTypingAt),
    lastMessageAt: row.lastMessageAt,
    createdAt: row.createdAt,
    latestMessage: previews.get(row.id) ? publicMessage(previews.get(row.id)!) : null,
  })).filter(row => !query || row.id.toString() === query || messageBodies.get(row.id)?.some(body => body.toLocaleLowerCase().includes(query)));

  if (input.sort === "oldest") return filtered.sort((a, b) => a.lastMessageAt.getTime() - b.lastMessageAt.getTime());
  if (input.sort === "unread") return filtered.sort((a, b) => b.unreadForStaff - a.unreadForStaff || b.lastMessageAt.getTime() - a.lastMessageAt.getTime());
  return filtered.sort((a, b) => b.lastMessageAt.getTime() - a.lastMessageAt.getTime());
}

export async function getAdminWebChatConversation(conversationId: number) {
  const db = await database();
  const conversation = await db.select().from(webChatConversations).where(eq(webChatConversations.id, conversationId)).limit(1);
  if (!conversation[0]) throw new Error("Website chat conversation not found.");
  const messages = await db.select().from(webChatMessages)
    .where(eq(webChatMessages.conversationId, conversationId))
    .orderBy(asc(webChatMessages.createdAt), asc(webChatMessages.id));
  return { ...conversation[0], staffIsTyping: isTyping(conversation[0].staffTypingAt), visitorIsTyping: isTyping(conversation[0].visitorTypingAt), messages };
}

export async function markAdminWebChatRead(conversationId: number, actor: StaffActor) {
  const db = await database();
  const updated = await db.update(webChatConversations).set({ unreadForStaff: 0, lastStaffReadAt: new Date() }).where(eq(webChatConversations.id, conversationId));
  if (updated[0].affectedRows !== 1) throw new Error("Website chat conversation not found.");
  await db.insert(activityLogs).values({ actorUserId: actor.id, actorName: actor.name, action: "Read website chat conversation", subjectType: "web_chat", subjectId: conversationId });
}

export async function markAdminWebChatTyping(conversationId: number) {
  const db = await database();
  const updated = await db.update(webChatConversations).set({ staffTypingAt: new Date() }).where(eq(webChatConversations.id, conversationId));
  if (updated[0].affectedRows !== 1) throw new Error("Website chat conversation not found.");
}

export async function setAdminWebChatStatus(conversationId: number, status: ConversationStatus, actor: StaffActor) {
  const db = await database();
  const updated = await db.update(webChatConversations).set({ status }).where(eq(webChatConversations.id, conversationId));
  if (updated[0].affectedRows !== 1) throw new Error("Website chat conversation not found.");
  await db.insert(activityLogs).values({ actorUserId: actor.id, actorName: actor.name, action: `Set website chat status to ${status}`, subjectType: "web_chat", subjectId: conversationId });
}

export async function sendStaffWebChatMessage(input: { conversationId: number; body: string; source: MessageSource }, actor: StaffActor) {
  const db = await database();
  const now = new Date();
  return db.transaction(async tx => {
    const conversation = await tx.select({ id: webChatConversations.id }).from(webChatConversations).where(eq(webChatConversations.id, input.conversationId)).limit(1);
    if (!conversation[0]) throw new Error("Website chat conversation not found.");

    const inserted = await tx.insert(webChatMessages).values({
      conversationId: input.conversationId,
      direction: "staff",
      source: input.source,
      body: input.body,
      staffUserId: actor.id,
      staffName: actor.name,
    });
    await tx.update(webChatConversations).set({
      unreadForVisitor: sql`${webChatConversations.unreadForVisitor} + 1`,
      staffTypingAt: null,
      lastMessageAt: now,
    }).where(eq(webChatConversations.id, input.conversationId));
    await tx.insert(activityLogs).values({ actorUserId: actor.id, actorName: actor.name, action: `Sent website chat reply (${input.source})`, subjectType: "web_chat", subjectId: input.conversationId });
    return { messageId: Number(inserted[0].insertId) };
  });
}

export async function listSentWebChatMessages() {
  const db = await database();
  return db.select({
    id: webChatMessages.id,
    conversationId: webChatMessages.conversationId,
    body: webChatMessages.body,
    source: webChatMessages.source,
    staffName: webChatMessages.staffName,
    createdAt: webChatMessages.createdAt,
    status: webChatConversations.status,
    language: webChatConversations.language,
  }).from(webChatMessages)
    .innerJoin(webChatConversations, eq(webChatMessages.conversationId, webChatConversations.id))
    .where(eq(webChatMessages.direction, "staff"))
    .orderBy(desc(webChatMessages.createdAt), desc(webChatMessages.id))
    .limit(100);
}

export async function listWebChatTemplates() {
  await ensureDefaultTemplates();
  const db = await database();
  return db.select().from(webChatTemplates).orderBy(webChatTemplates.language, webChatTemplates.label);
}

export async function createTemplateGroundedSuggestion(conversationId: number, actor: StaffActor) {
  await ensureDefaultTemplates();
  const db = await database();
  const conversation = await db.select().from(webChatConversations).where(eq(webChatConversations.id, conversationId)).limit(1);
  if (!conversation[0]) throw new Error("Website chat conversation not found.");
  const messages = await db.select().from(webChatMessages).where(eq(webChatMessages.conversationId, conversationId)).orderBy(desc(webChatMessages.createdAt), desc(webChatMessages.id));
  const visitorMessage = messages.find(message => message.direction === "visitor");
  if (!visitorMessage) throw new Error("A visitor message is required before a reply can be suggested.");
  const templates = await db.select({ id: webChatTemplates.id, label: webChatTemplates.label, language: webChatTemplates.language, body: webChatTemplates.body, isActive: webChatTemplates.isActive })
    .from(webChatTemplates).where(and(eq(webChatTemplates.isActive, true), eq(webChatTemplates.language, conversation[0].language)));
  const selected = rankTemplateSuggestions(visitorMessage.body, templates)[0];
  if (!selected) throw new Error("No active reply template is available for this conversation language.");

  await db.insert(activityLogs).values({ actorUserId: actor.id, actorName: actor.name, action: `Prepared zero-credit template suggestion: ${selected.label}`, subjectType: "web_chat", subjectId: conversationId });
  return { body: selected.body, source: "template" as const, templateId: selected.id, templateLabel: selected.label, zeroCredit: true as const, modelUsed: null };
}

export async function saveWebChatTemplate(input: { id?: number; label: string; language: ChatLanguage; body: string; isActive: boolean }, actor: StaffActor) {
  const db = await database();
  if (input.id) {
    const updated = await db.update(webChatTemplates).set({ label: input.label, language: input.language, body: input.body, isActive: input.isActive }).where(eq(webChatTemplates.id, input.id));
    if (updated[0].affectedRows !== 1) throw new Error("Reply template not found.");
    await db.insert(activityLogs).values({ actorUserId: actor.id, actorName: actor.name, action: "Updated website chat reply template", subjectType: "web_chat_template", subjectId: input.id });
    return { id: input.id };
  }

  const inserted = await db.insert(webChatTemplates).values({ label: input.label, language: input.language, body: input.body, isActive: input.isActive, createdByUserId: actor.id });
  const id = Number(inserted[0].insertId);
  await db.insert(activityLogs).values({ actorUserId: actor.id, actorName: actor.name, action: "Created website chat reply template", subjectType: "web_chat_template", subjectId: id });
  return { id };
}

/** Retained for compatibility with existing staff workflows; it remains zero-credit and never calls an LLM. */
export function createZeroCreditDraft(input: { visitorMessage: string; language: ChatLanguage }) {
  const text = input.visitorMessage.toLocaleLowerCase();
  const wantsAppointment = /appointment|book|booking|موعد|حجز/.test(text);
  const hasMedicalContext = /medication|medicine|skin|condition|pregnan|دواء|علاج|جلد|حساسية|مرض/.test(text);
  const asksPrice = /price|cost|package|سعر|تكلفة|باقة/.test(text);

  if (input.language === "ar") {
    if (hasMedicalContext) return "شكرًا لرسالتك. هذه المحادثة لا تقدم نصيحة طبية. حفاظًا على خصوصيتك، يرجى استخدام نموذج طلب الموعد الآمن حتى يراجع فريق العيادة معلوماتك بشكل خاص.";
    if (wantsAppointment) return "شكرًا لتواصلك. لطلب موعد، يرجى استخدام نموذج طلب الموعد الآمن. سيراجع أحد أعضاء الفريق طلبك قبل التأكيد.";
    if (asksPrice) return "للحصول على معلومات دقيقة حول الخدمة المناسبة لك، يرجى استخدام نموذج طلب الموعد الآمن. لا تؤكد هذه المحادثة الأسعار أو التوفر.";
    return "شكرًا لتواصلك مع جيمس ليزر في نيو لوك كلينك. كيف يمكن لفريقنا مساعدتك بمعلومات عامة؟";
  }

  if (hasMedicalContext) return "Thank you for your message. This chat cannot provide medical advice. For privacy, please use the secure appointment form so the clinic team can review your information privately.";
  if (wantsAppointment) return "Thank you for contacting us. To request an appointment, please use the secure appointment form. A staff member will review the request before confirmation.";
  if (asksPrice) return "For accurate information about the service that may suit you, please use the secure appointment form. This chat does not confirm clinic pricing or availability.";
  return "Thank you for contacting James Laser at New Look Clinic. How can our team help with general information?";
}
