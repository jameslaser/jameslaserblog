import { describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({ createConsultationRequest: vi.fn(), createPublicAppointmentRequest: vi.fn(), findPublicAppointmentRequestBySubmissionId: vi.fn().mockResolvedValue(null), guardAppointmentRequestRate: vi.fn(), guardPublicSubmission: vi.fn(), listConsultationRequests: vi.fn(), recordAnalyticsEvent: vi.fn(), updateConsultationRequestWorkflow: vi.fn() }));
const cmsMocks = vi.hoisted(() => ({ ensureClinicSettings: vi.fn().mockResolvedValue({ appointmentFormEnabled: true, maintenanceMode: false, preferredTimes: null, appointmentTreatmentOptions: null, visitTypeOptions: null, availableDays: null }) }));
const notificationMocks = vi.hoisted(() => ({ createStaffNotification: vi.fn().mockResolvedValue(1), listStaffNotifications: vi.fn(), markStaffNotificationRead: vi.fn(), markAllStaffNotificationsRead: vi.fn() }));
vi.mock("./db", () => ({ createConsultationRequest: mocks.createConsultationRequest, createPublicAppointmentRequest: mocks.createPublicAppointmentRequest, findPublicAppointmentRequestBySubmissionId: mocks.findPublicAppointmentRequestBySubmissionId, listConsultationRequests: mocks.listConsultationRequests, updateConsultationRequestWorkflow: mocks.updateConsultationRequestWorkflow }));
vi.mock("./cms", () => cmsMocks);
vi.mock("./notifications", () => notificationMocks);
vi.mock("./sharedBackend", () => ({
  analyticsOverview: vi.fn(),
  createEnquiry: vi.fn(),
  deleteRedirect: vi.fn(),
  exportRows: vi.fn(),
  guardAppointmentRequestRate: mocks.guardAppointmentRequestRate,
  guardPublicSubmission: mocks.guardPublicSubmission,
  listEnquiries: vi.fn(),
  listRedirects: vi.fn(),
  recordAnalyticsEvent: mocks.recordAnalyticsEvent,
  saveRedirect: vi.fn(),
  updateEnquiry: vi.fn(),
}));

import { appRouter } from "./routers";

const context = { user: null, req: {}, res: {} } as TrpcContext;
const ownerContext = { user: { id: 1, role: "owner", name: "Owner" }, req: {}, res: {} } as TrpcContext;

describe("consultationRequest.create", () => {
  it("records a valid public consultation request", async () => {
    mocks.createConsultationRequest.mockResolvedValueOnce({ id: 42 });
    const caller = appRouter.createCaller(context);

    await expect(caller.consultationRequest.create({
      fullName: "Ahmad Khalid",
      nationality: "Saudi Arabian",
      whatsapp: "+966501234567",
      treatmentArea: "Chest & abdomen",
      preferredContact: "WhatsApp",
      preferredDate: "2026-09-03",
      preferredTime: "18:00–20:00",
      firstTime: true,
      takingMedication: false,
      tookVitaminD: false,
      takingIron: false,
      tannedPastThreeMonths: false,
      hadMoroccanBathLastSevenDays: false,
      hadSkinTreatment: false,
      hadSevereSunExposure: false,
      consentRead: true,
      privacyConsent: true,
    })).resolves.toEqual({ success: true, requestId: 42 });

    expect(mocks.createConsultationRequest).toHaveBeenCalledWith(expect.objectContaining({
      fullName: "Ahmad Khalid",
      privacyConsent: true,
    }));
    expect(mocks.guardPublicSubmission).toHaveBeenCalledWith("consultation_request", expect.any(String), expect.any(String));
  });

  it("rejects a submission without consent", async () => {
    const caller = appRouter.createCaller(context);
    await expect(caller.consultationRequest.create({
      fullName: "Ahmad Khalid",
      nationality: "Saudi Arabian",
      whatsapp: "+966501234567",
      treatmentArea: "Face & neck",
      preferredContact: "WhatsApp",
      preferredDate: "2026-09-03",
      preferredTime: "18:00–20:00",
      firstTime: true,
      takingMedication: false,
      tookVitaminD: false,
      takingIron: false,
      tannedPastThreeMonths: false,
      hadMoroccanBathLastSevenDays: false,
      hadSkinTreatment: false,
      hadSevereSunExposure: false,
      consentRead: true,
      privacyConsent: false,
    })).rejects.toThrow();
  });

  it("rejects a consultation request that fills the hidden honeypot before persistence", async () => {
    const caller = appRouter.createCaller(context);
    await expect(caller.consultationRequest.create({
      fullName: "Ahmad Khalid",
      nationality: "Saudi Arabian",
      whatsapp: "+966501234567",
      treatmentArea: "Face",
      preferredContact: "WhatsApp",
      preferredDate: "2026-09-03",
      preferredTime: "18:00–20:00",
      firstTime: true,
      takingMedication: false,
      tookVitaminD: false,
      takingIron: false,
      tannedPastThreeMonths: false,
      hadMoroccanBathLastSevenDays: false,
      hadSkinTreatment: false,
      hadSevereSunExposure: false,
      consentRead: true,
      privacyConsent: true,
      website: "bot-filled-this",
    })).rejects.toThrow();
    expect(mocks.createConsultationRequest).not.toHaveBeenCalledWith(expect.objectContaining({ website: expect.anything() }));
  });

  it("surfaces a temporary request-service failure without persisting a retry", async () => {
    mocks.createConsultationRequest.mockRejectedValueOnce(new Error("The request service is temporarily unavailable."));
    const caller = appRouter.createCaller(context);

    await expect(caller.consultationRequest.create({
      fullName: "Ahmad Khalid",
      nationality: "Saudi Arabian",
      whatsapp: "+966501234567",
      treatmentArea: "Back & shoulders",
      preferredContact: "Phone",
      preferredDate: "2026-09-03",
      preferredTime: "18:00–20:00",
      firstTime: true,
      takingMedication: false,
      tookVitaminD: false,
      takingIron: false,
      tannedPastThreeMonths: false,
      hadMoroccanBathLastSevenDays: false,
      hadSkinTreatment: false,
      hadSevereSunExposure: false,
      consentRead: true,
      privacyConsent: true,
    })).rejects.toThrow("The request service is temporarily unavailable.");
  });

  it("requires the correct follow-up detail when a screening answer needs one", async () => {
    const caller = appRouter.createCaller(context);

    await expect(caller.consultationRequest.create({
      fullName: "Ahmad Khalid",
      nationality: "Saudi Arabian",
      whatsapp: "+966501234567",
      treatmentArea: "Mini full body",
      preferredContact: "WhatsApp",
      preferredDate: "2026-09-03",
      preferredTime: "18:00–20:00",
      firstTime: false,
      takingMedication: true,
      tookVitaminD: false,
      takingIron: false,
      tannedPastThreeMonths: false,
      hadMoroccanBathLastSevenDays: false,
      hadSkinTreatment: false,
      hadSevereSunExposure: false,
      consentRead: true,
      privacyConsent: true,
    })).rejects.toThrow();
  });

  it("rejects a request when the consent form has not been acknowledged", async () => {
    const caller = appRouter.createCaller(context);

    await expect(caller.consultationRequest.create({
      fullName: "Ahmad Khalid",
      nationality: "Saudi Arabian",
      whatsapp: "+966501234567",
      treatmentArea: "Face & neck",
      preferredContact: "WhatsApp",
      preferredDate: "2026-09-03",
      preferredTime: "18:00–20:00",
      firstTime: true,
      takingMedication: false,
      tookVitaminD: false,
      takingIron: false,
      tannedPastThreeMonths: false,
      hadMoroccanBathLastSevenDays: false,
      hadSkinTreatment: false,
      hadSevereSunExposure: false,
      consentRead: false,
      privacyConsent: true,
    })).rejects.toThrow();
  });

  it("rejects a request with missing required intake data", async () => {
    const caller = appRouter.createCaller(context);

    await expect(caller.consultationRequest.create({
      fullName: "A",
      nationality: "",
      whatsapp: "123",
      treatmentArea: "",
      preferredContact: "WhatsApp",
      preferredDate: "not-a-date",
      preferredTime: "",
      firstTime: true,
      takingMedication: false,
      tookVitaminD: false,
      takingIron: false,
      tannedPastThreeMonths: false,
      hadMoroccanBathLastSevenDays: false,
      hadSkinTreatment: false,
      hadSevereSunExposure: false,
      consentRead: true,
      privacyConsent: true,
    })).rejects.toThrow();
  });
});

describe("appointmentRequest.create", () => {
  const validAppointmentRequest = {
    clientSubmissionId: "11111111-1111-4111-8111-111111111111", fullName: "Ahmad Khalid", whatsapp: "+966 50 123 4567", nationality: "Saudi Arabian", preferredDate: "2099-09-03", preferredTime: "18:15", visitType: "session" as const, treatmentAreas: ["Full Face", "Neck"] as const, previousLaser: false, takingMedication: false, medicationTypes: [] as const, recentExposures: [] as const, hasSkinCondition: false, notes: "Evening preferred.", appointmentAcknowledgement: true as const, informationAccuracyAcknowledgement: true, originalConsentAcknowledgement: true as const, privacyConsent: true as const, healthScreeningConsent: true as const, marketingConsent: false, signatureDataUrl: "data:image/png;base64,AA==", language: "en" as const, source: "appointment_page",
  };

  it("stores a valid public appointment request privately and returns only a safe request reference", async () => {
    mocks.createPublicAppointmentRequest.mockResolvedValueOnce({ id: 7, publicRequestId: "JR-2099-000007", isPotentialDuplicate: false });
    const caller = appRouter.createCaller(context);
    await expect(caller.appointmentRequest.create(validAppointmentRequest)).resolves.toEqual({ success: true, requestId: "JR-2099-000007", isPotentialDuplicate: false });
    expect(mocks.guardAppointmentRequestRate).toHaveBeenCalledWith("consultation_request", expect.any(String));
    expect(mocks.createPublicAppointmentRequest).toHaveBeenCalledWith(expect.objectContaining({ clientSubmissionId: validAppointmentRequest.clientSubmissionId, visitType: "session", treatmentAreas: ["Full Face", "Neck"], informationAccuracyAcknowledgement: true, originalConsentAcknowledgement: true, signatureDataUrl: validAppointmentRequest.signatureDataUrl, privacyConsent: true, healthScreeningConsent: true }));
    expect(notificationMocks.createStaffNotification).toHaveBeenCalledWith({ type: "appointment_request", title: "New appointment request", message: "A new website appointment request is ready for protected staff review.", linkPath: "/admin/requests" });
  });

  it("keeps the public-to-private queue contract separate from approval and patient creation", async () => {
    mocks.createPublicAppointmentRequest.mockResolvedValueOnce({ id: 9, publicRequestId: "JR-2099-000009", isPotentialDuplicate: false });
    const publicResult = await appRouter.createCaller(context).appointmentRequest.create(validAppointmentRequest);
    expect(publicResult).toEqual({ success: true, requestId: "JR-2099-000009", isPotentialDuplicate: false });
    expect(publicResult).not.toHaveProperty("fullName");
    expect(publicResult).not.toHaveProperty("whatsapp");

    mocks.listConsultationRequests.mockResolvedValueOnce([{ id: 9, publicRequestId: "JR-2099-000009", fullName: "Ahmad Khalid", status: "pending" }]);
    await expect(appRouter.createCaller(ownerContext).admin.requests({ status: "pending" })).resolves.toEqual([{ id: 9, publicRequestId: "JR-2099-000009", fullName: "Ahmad Khalid", status: "pending" }]);

    await appRouter.createCaller(ownerContext).admin.updateRequestStatus({ requestId: 9, status: "contacted", internalNotes: "Private callback requested." });
    expect(mocks.updateConsultationRequestWorkflow).toHaveBeenCalledWith(9, "contacted", "Owner", "Private callback requested.");
  });

  it("accepts the final 10:00 PM Riyadh preference without confirming an appointment", async () => {
    mocks.createPublicAppointmentRequest.mockResolvedValueOnce({ id: 8, publicRequestId: "JR-2099-000008", isPotentialDuplicate: false });
    const caller = appRouter.createCaller(context);

    await expect(caller.appointmentRequest.create({ ...validAppointmentRequest, preferredTime: "22:00" })).resolves.toEqual({ success: true, requestId: "JR-2099-000008", isPotentialDuplicate: false });
    expect(mocks.createPublicAppointmentRequest).toHaveBeenLastCalledWith(expect.objectContaining({ preferredTime: "22:00" }));
  });

  it("enforces enabled clinic preferences without creating a patient, appointment, or request when a choice is disabled", async () => {
    cmsMocks.ensureClinicSettings.mockResolvedValueOnce({ appointmentFormEnabled: true, maintenanceMode: false, preferredTimes: "18:00", appointmentTreatmentOptions: "Full Face", visitTypeOptions: "session", availableDays: null });
    await expect(appRouter.createCaller(context).appointmentRequest.create({ ...validAppointmentRequest, preferredTime: "18:15" })).rejects.toThrow("not enabled in clinic settings");
    expect(mocks.createPublicAppointmentRequest).not.toHaveBeenLastCalledWith(expect.objectContaining({ preferredTime: "18:15" }));
  });

  it("returns localized Arabic mobile, date, and time validation errors before rate limiting or persistence", async () => {
    const caller = appRouter.createCaller(context);

    await expect(caller.appointmentRequest.create({ ...validAppointmentRequest, language: "ar", whatsapp: "123" })).rejects.toThrow("أدخل رقم جوال أو واتساب صحيحًا");
    await expect(caller.appointmentRequest.create({ ...validAppointmentRequest, language: "ar", preferredDate: "2001-01-01" })).rejects.toThrow("اختر تاريخ اليوم أو تاريخًا مستقبليًا في الرياض");
    await expect(caller.appointmentRequest.create({ ...validAppointmentRequest, language: "ar", preferredTime: "22:15" })).rejects.toThrow("اختر وقتًا كل 15 دقيقة بين 1:00 ظهرًا و10:00 مساءً");
    expect(mocks.createPublicAppointmentRequest).not.toHaveBeenLastCalledWith(expect.objectContaining({ whatsapp: "123" }));
  });

  it("returns English mobile, date, and time validation errors before persistence", async () => {
    const caller = appRouter.createCaller(context);

    await expect(caller.appointmentRequest.create({ ...validAppointmentRequest, whatsapp: "123" })).rejects.toThrow("Enter a valid mobile or WhatsApp number");
    await expect(caller.appointmentRequest.create({ ...validAppointmentRequest, preferredDate: "2001-01-01" })).rejects.toThrow("Choose today or a future date in Riyadh");
    await expect(caller.appointmentRequest.create({ ...validAppointmentRequest, preferredTime: "22:15" })).rejects.toThrow("Choose a 15-minute preference between 1:00 PM and 10:00 PM");
  });

  it("rejects a past date, invalid time, missing treatment selection, or missing required acknowledgement before persistence", async () => {
    const caller = appRouter.createCaller(context);
    await expect(caller.appointmentRequest.create({ ...validAppointmentRequest, preferredDate: "2001-01-01" })).rejects.toThrow();
    await expect(caller.appointmentRequest.create({ ...validAppointmentRequest, preferredTime: "12:30" })).rejects.toThrow();
    await expect(caller.appointmentRequest.create({ ...validAppointmentRequest, treatmentAreas: [] })).rejects.toThrow();
    await expect(caller.appointmentRequest.create({ ...validAppointmentRequest, appointmentAcknowledgement: false as true })).rejects.toThrow();
    await expect(caller.appointmentRequest.create({ ...validAppointmentRequest, originalConsentAcknowledgement: false as true })).rejects.toThrow("Read, acknowledge, and sign the original consent information");
  });

  it("requires an explicit acknowledgement before storing full-page health-screening answers", async () => {
    const beforePersist = mocks.createPublicAppointmentRequest.mock.calls.length;
    await expect(appRouter.createCaller(context).appointmentRequest.create({ ...validAppointmentRequest, healthScreeningConsent: undefined })).rejects.toThrow("Confirm your explicit acknowledgement");
    expect(mocks.createPublicAppointmentRequest.mock.calls.length).toBe(beforePersist);
  });

  it("rejects a filled honeypot before calling the rate guard or private persistence helper", async () => {
    const caller = appRouter.createCaller(context);
    await expect(caller.appointmentRequest.create({ ...validAppointmentRequest, website: "bot content" })).rejects.toThrow();
  });

  it("returns the same safe request reference for a repeated client submission without a second insert or notification", async () => {
    mocks.findPublicAppointmentRequestBySubmissionId.mockResolvedValueOnce({ id: 12, publicRequestId: "JR-2099-000012", isPotentialDuplicate: false });
    const beforeCreate = mocks.createPublicAppointmentRequest.mock.calls.length;
    const beforeNotify = notificationMocks.createStaffNotification.mock.calls.length;
    await expect(appRouter.createCaller(context).appointmentRequest.create(validAppointmentRequest)).resolves.toEqual({ success: true, requestId: "JR-2099-000012", isPotentialDuplicate: false });
    expect(mocks.createPublicAppointmentRequest.mock.calls.length).toBe(beforeCreate);
    expect(notificationMocks.createStaffNotification.mock.calls.length).toBe(beforeNotify);
  });
});
