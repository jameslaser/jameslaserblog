import { existsSync } from "node:fs";
import { spawn } from "node:child_process";
import { once } from "node:events";
import { describe, expect, it } from "vitest";

const canRun = Boolean(process.env.MYSQL_URL) && existsSync("dist/index.js");

describe.skipIf(!canRun)("production readiness endpoint", () => {
  it("uses MYSQL_URL to report a ready database through the deployed server endpoint", async () => {
    const port = 4873;
    const serverProcess = spawn("node", ["dist/index.js"], {
      env: { ...process.env, NODE_ENV: "production", PORT: String(port) },
      stdio: "ignore",
    });

    try {
      let response: Response | null = null;
      let lastError: unknown = null;
      for (let attempt = 0; attempt < 20; attempt += 1) {
        try {
          response = await fetch(`http://127.0.0.1:${port}/readyz`);
          break;
        } catch (error) {
          lastError = error;
          await new Promise(resolve => setTimeout(resolve, 500));
        }
      }
      if (!response) throw lastError ?? new Error("Production server did not become reachable.");
      expect(response.status).toBe(200);
      await expect(response.json()).resolves.toEqual({ status: "ready" });
    } finally {
      serverProcess.kill("SIGTERM");
      await once(serverProcess, "exit");
    }
  }, 15_000);
});
