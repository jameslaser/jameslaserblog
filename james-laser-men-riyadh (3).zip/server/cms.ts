import { and, asc, count, desc, eq, gte, isNull, lte, or } from "drizzle-orm";
import { activityLogs, clinicSettings, contentCalendarItems, faqs, guidePosts, homepageSections, mediaItems, policies, promotions, resultCases, reviews, seoSettings, settingsChangeAudits, treatments } from "../drizzle/schema";
import { getDb } from "./db";

type CmsActor = { id: number; name: string | null };

const defaultClinicSettings = {
  businessName: "James Laser Hair Removal for Men Riyadh @ New Look Clinic",
  specialistName: "Nurse James",
  professionalTitle: "Laser Specialist",
  clinicName: "New Look Clinic",
  addressEn: "New Look Clinic, Al Sahafah / As Sahafah, Riyadh, Saudi Arabia",
  whatsapp: "+966557401562",
  workingHours: "1:00 PM – 10:00 PM",
  appointmentFormEnabled: true,
};

async function database() {
  const db = await getDb();
  if (!db) throw new Error("The CMS service is temporarily unavailable.");
  return db;
}

export async function logCmsActivity(actor: CmsActor, action: string, subjectType?: string, subjectId?: number) {
  const db = await database();
  await db.insert(activityLogs).values({ actorUserId: actor.id, actorName: actor.name ?? "Clinic administrator", action, subjectType, subjectId });
}

export async function ensureClinicSettings() {
  const db = await database();
  const current = await db.select().from(clinicSettings).orderBy(asc(clinicSettings.id)).limit(1);
  if (current[0]) return current[0];
  const [created] = await db.insert(clinicSettings).values(defaultClinicSettings).$returningId();
  if (!created) throw new Error("Clinic settings could not be initialized.");
  const result = await db.select().from(clinicSettings).where(eq(clinicSettings.id, created.id)).limit(1);
  if (!result[0]) throw new Error("Clinic settings could not be initialized.");
  return result[0];
}

export async function updateClinicSettings(values: Partial<typeof clinicSettings.$inferInsert>, actor: CmsActor) {
  const current = await ensureClinicSettings();
  const db = await database();
  const auditFields = [
    "businessName", "specialistName", "professionalTitle", "clinicName", "addressEn", "addressAr", "mapsUrl", "whatsapp", "telephone", "email", "workingHours",
    "instagramUrl", "tiktokUrl", "snapchatUrl", "facebookUrl", "youtubeUrl", "xUrl", "googleBusinessUrl",
    "appointmentFormEnabled", "preferredTimes", "availableDays", "appointmentTreatmentOptions", "visitTypeOptions", "defaultLanguage", "maintenanceMode",
    "homepageTheme", "homepageHeroImageUrl", "homepageSpecialistImageUrl", "homepageClinicImageUrl",
  ] as const;
  const valueChanged = (field: typeof auditFields[number]) => values[field] !== undefined && values[field] !== current[field];
  const changedFields = auditFields.filter(valueChanged);
  if (!changedFields.length) return current;
  const safeValueFields = new Set(["appointmentFormEnabled", "preferredTimes", "availableDays", "appointmentTreatmentOptions", "visitTypeOptions", "defaultLanguage", "maintenanceMode", "homepageTheme", "homepageHeroImageUrl", "homepageSpecialistImageUrl", "homepageClinicImageUrl"]);
  const previousValues = Object.fromEntries(changedFields.filter(field => safeValueFields.has(field)).map(field => [field, current[field] ?? null]));
  const newValues = Object.fromEntries(changedFields.filter(field => safeValueFields.has(field)).map(field => [field, values[field] ?? null]));
  await db.transaction(async tx => {
    await tx.update(clinicSettings).set(values).where(eq(clinicSettings.id, current.id));
    await tx.insert(settingsChangeAudits).values({
      actorUserId: actor.id,
      actorName: actor.name ?? "Clinic administrator",
      settingArea: "Clinic settings",
      changedFieldsJson: JSON.stringify(changedFields),
      previousValuesJson: Object.keys(previousValues).length ? JSON.stringify(previousValues) : null,
      newValuesJson: Object.keys(newValues).length ? JSON.stringify(newValues) : null,
    });
    await tx.insert(activityLogs).values({
      actorUserId: actor.id,
      actorName: actor.name ?? "Clinic administrator",
      action: `Updated clinic settings: ${changedFields.join(", ")}`.slice(0, 180),
      subjectType: "clinic_settings",
      subjectId: current.id,
    });
  });
  return ensureClinicSettings();
}

export async function listSettingsChangeAudit() {
  const db = await database();
  const rows = await db.select().from(settingsChangeAudits).orderBy(desc(settingsChangeAudits.createdAt)).limit(30);
  const parse = (value: string | null) => {
    if (!value) return null;
    try { return JSON.parse(value) as Record<string, string | boolean | null>; } catch { return null; }
  };
  return rows.map(row => ({
    ...row,
    changedFields: (() => { try { return JSON.parse(row.changedFieldsJson) as string[]; } catch { return []; } })(),
    previousValues: parse(row.previousValuesJson),
    newValues: parse(row.newValuesJson),
  }));
}

export async function listHomepageSections(includeDrafts = true) {
  const db = await database();
  const query = db.select().from(homepageSections).orderBy(asc(homepageSections.displayOrder), asc(homepageSections.id));
  return includeDrafts ? query : query.where(eq(homepageSections.status, "published"));
}

export async function saveHomepageSection(input: typeof homepageSections.$inferInsert, actor: CmsActor) {
  const db = await database();
  await db.insert(homepageSections).values(input).onDuplicateKeyUpdate({ set: { ...input, updatedAt: new Date() } });
  const section = await db.select().from(homepageSections).where(eq(homepageSections.sectionKey, input.sectionKey)).limit(1);
  if (!section[0]) throw new Error("Homepage section could not be saved.");
  await logCmsActivity(actor, input.status === "published" ? "Published homepage section" : "Saved homepage section draft", "homepage_section", section[0].id);
  return section[0];
}

export async function cmsDashboardStats() {
  const db = await database();
  const now = new Date();
  const [treatmentRows, promotionRows, reviewRows, pendingReviewRows, resultRows, postRows] = await Promise.all([
    db.select({ total: count() }).from(treatments).where(eq(treatments.isActive, true)),
    db.select({ total: count() }).from(promotions).where(and(
      eq(promotions.status, "published"),
      or(isNull(promotions.startsAt), lte(promotions.startsAt, now)),
      or(isNull(promotions.endsAt), gte(promotions.endsAt, now)),
    )),
    db.select({ total: count() }).from(reviews).where(eq(reviews.status, "approved")),
    db.select({ total: count() }).from(reviews).where(eq(reviews.status, "pending")),
    db.select({ total: count() }).from(resultCases).where(eq(resultCases.isActive, true)),
    db.select({ total: count() }).from(guidePosts).where(eq(guidePosts.status, "published")),
  ]);
  return {
    activeTreatments: Number(treatmentRows[0]?.total ?? 0), activePromotions: Number(promotionRows[0]?.total ?? 0),
    publishedReviews: Number(reviewRows[0]?.total ?? 0), reviewsPendingApproval: Number(pendingReviewRows[0]?.total ?? 0),
    publishedResults: Number(resultRows[0]?.total ?? 0), publishedPosts: Number(postRows[0]?.total ?? 0),
  };
}

export async function recentCmsActivity() {
  const db = await database();
  return db.select().from(activityLogs).orderBy(desc(activityLogs.createdAt)).limit(12);
}

export async function listPolicies(includeDrafts = true) {
  const db = await database();
  const query = db.select().from(policies).orderBy(desc(policies.updatedAt));
  return includeDrafts ? query : query.where(eq(policies.status, "published"));
}

export async function listTreatments(includeInactive = true) {
  const db = await database();
  const query = db.select().from(treatments).orderBy(asc(treatments.displayOrder), asc(treatments.nameEn));
  return includeInactive ? query : query.where(eq(treatments.isActive, true));
}

export async function saveTreatment(input: typeof treatments.$inferInsert, actor: CmsActor) {
  const db = await database();
  await db.insert(treatments).values(input).onDuplicateKeyUpdate({ set: { ...input, updatedAt: new Date() } });
  const record = await db.select().from(treatments).where(eq(treatments.slug, input.slug)).limit(1);
  if (!record[0]) throw new Error("Treatment could not be saved.");
  await logCmsActivity(actor, input.isActive ? "Published treatment" : "Saved treatment draft", "treatment", record[0].id);
  return record[0];
}

export async function deleteTreatment(id: number, actor: CmsActor) {
  const db = await database();
  await db.delete(treatments).where(eq(treatments.id, id));
  await logCmsActivity(actor, "Deleted treatment", "treatment", id);
}

export async function listPromotions(includeAll = true) {
  const db = await database();
  const query = db.select().from(promotions).orderBy(asc(promotions.displayOrder), desc(promotions.updatedAt));
  if (includeAll) return query;
  const now = new Date();
  return query.where(and(
    eq(promotions.status, "published"),
    or(isNull(promotions.startsAt), lte(promotions.startsAt, now)),
    or(isNull(promotions.endsAt), gte(promotions.endsAt, now)),
  ));
}

export async function savePromotion(input: typeof promotions.$inferInsert, actor: CmsActor) {
  const db = await database();
  await db.insert(promotions).values(input).onDuplicateKeyUpdate({ set: { ...input, updatedAt: new Date() } });
  const record = await db.select().from(promotions).where(eq(promotions.slug, input.slug)).limit(1);
  if (!record[0]) throw new Error("Promotion could not be saved.");
  await logCmsActivity(actor, input.status === "published" ? "Published promotion" : "Saved promotion", "promotion", record[0].id);
  return record[0];
}

export async function deletePromotion(id: number, actor: CmsActor) {
  const db = await database();
  await db.delete(promotions).where(eq(promotions.id, id));
  await logCmsActivity(actor, "Deleted promotion", "promotion", id);
}

export async function listReviews(includeAll = true) {
  const db = await database();
  const query = db.select().from(reviews).orderBy(desc(reviews.createdAt));
  return includeAll ? query : query.where(eq(reviews.status, "approved"));
}

export async function saveReview(input: typeof reviews.$inferInsert, actor: CmsActor) {
  const db = await database();
  const [inserted] = await db.insert(reviews).values(input).$returningId();
  if (!inserted) throw new Error("Review could not be saved.");
  const id = inserted.id;
  await logCmsActivity(actor, "Added review for moderation", "review", id);
  return id;
}

export async function setReviewStatus(id: number, status: "pending" | "approved" | "rejected" | "hidden", actor: CmsActor) {
  const db = await database();
  await db.update(reviews).set({ status, reviewedAt: new Date() }).where(eq(reviews.id, id));
  await logCmsActivity(actor, `${status === "approved" ? "Approved" : "Updated"} review`, "review", id);
}

export async function deleteReview(id: number, actor: CmsActor) {
  const db = await database();
  await db.delete(reviews).where(eq(reviews.id, id));
  await logCmsActivity(actor, "Deleted review", "review", id);
}

export async function listResultCases(includeAll = true) {
  const db = await database();
  const query = db.select().from(resultCases).orderBy(asc(resultCases.displayOrder), desc(resultCases.createdAt));
  return includeAll ? query : query.where(eq(resultCases.isActive, true));
}

export async function saveResultCase(input: typeof resultCases.$inferInsert, actor: CmsActor) {
  const db = await database();
  const [inserted] = await db.insert(resultCases).values(input).$returningId();
  if (!inserted) throw new Error("Result case could not be saved.");
  const id = inserted.id;
  await logCmsActivity(actor, input.isActive ? "Published result case" : "Saved result case", "result_case", id);
  return id;
}

export async function deleteResultCase(id: number, actor: CmsActor) {
  const db = await database();
  await db.delete(resultCases).where(eq(resultCases.id, id));
  await logCmsActivity(actor, "Deleted result case", "result_case", id);
}

export async function listGuidePosts(includeDrafts = true) {
  const db = await database();
  const query = db.select().from(guidePosts).orderBy(desc(guidePosts.updatedAt));
  return includeDrafts ? query : query.where(eq(guidePosts.status, "published"));
}

const publicGuidePostFields = {
  id: guidePosts.id,
  slug: guidePosts.slug,
  postType: guidePosts.postType,
  titleEn: guidePosts.titleEn,
  titleAr: guidePosts.titleAr,
  summaryEn: guidePosts.summaryEn,
  summaryAr: guidePosts.summaryAr,
  contentEn: guidePosts.contentEn,
  contentAr: guidePosts.contentAr,
  category: guidePosts.category,
  tags: guidePosts.tags,
  featuredImageUrl: guidePosts.featuredImageUrl,
  featuredImageAltEn: guidePosts.featuredImageAltEn,
  featuredImageAltAr: guidePosts.featuredImageAltAr,
  videoUrl: guidePosts.videoUrl,
  seoTitle: guidePosts.seoTitle,
  metaDescription: guidePosts.metaDescription,
  canonicalUrl: guidePosts.canonicalUrl,
  socialImageUrl: guidePosts.socialImageUrl,
  socialCaptionEn: guidePosts.socialCaptionEn,
  socialCaptionAr: guidePosts.socialCaptionAr,
  socialHashtags: guidePosts.socialHashtags,
  authorName: guidePosts.authorName,
  reviewEvidence: guidePosts.clinicalReviewedAt,
  isFeatured: guidePosts.isFeatured,
  publishedAt: guidePosts.publishedAt,
  updatedAt: guidePosts.updatedAt,
} as const;

export async function listPublishedGuidePosts() {
  const db = await database();
  const rows = await db.select(publicGuidePostFields).from(guidePosts).where(eq(guidePosts.status, "published")).orderBy(desc(guidePosts.updatedAt));
  return rows.map(({ reviewEvidence, ...article }) => ({ ...article, isClinicallyReviewed: Boolean(reviewEvidence) }));
}

export async function getPublishedGuidePostBySlug(slug: string) {
  const db = await database();
  const rows = await db.select(publicGuidePostFields).from(guidePosts).where(and(eq(guidePosts.slug, slug), eq(guidePosts.status, "published"))).limit(1);
  const record = rows[0];
  if (!record) return null;
  const { reviewEvidence, ...article } = record;
  return { ...article, isClinicallyReviewed: Boolean(reviewEvidence) };
}

export async function getGuidePostBySlug(slug: string) {
  const db = await database();
  const rows = await db.select().from(guidePosts).where(eq(guidePosts.slug, slug)).limit(1);
  return rows[0] ?? null;
}

export async function saveGuidePost(input: typeof guidePosts.$inferInsert, actor: CmsActor) {
  const db = await database();
  const current = await db.select().from(guidePosts).where(eq(guidePosts.slug, input.slug)).limit(1);
  const publishedAt = input.status === "published" ? (current[0]?.publishedAt ?? input.publishedAt ?? new Date()) : null;
  await db.insert(guidePosts).values({ ...input, publishedAt }).onDuplicateKeyUpdate({ set: { ...input, publishedAt, updatedAt: new Date() } });
  const record = await db.select().from(guidePosts).where(eq(guidePosts.slug, input.slug)).limit(1);
  if (!record[0]) throw new Error("Guide post could not be saved.");
  await logCmsActivity(actor, input.status === "published" ? "Published guide post" : "Saved guide post draft", "guide_post", record[0].id);
  return record[0];
}

export async function deleteGuidePost(id: number, actor: CmsActor) {
  const db = await database();
  await db.delete(guidePosts).where(eq(guidePosts.id, id));
  await logCmsActivity(actor, "Deleted guide post", "guide_post", id);
}

export async function listFaqs(includeInactive = true) {
  const db = await database();
  const query = db.select().from(faqs).orderBy(asc(faqs.displayOrder), desc(faqs.updatedAt));
  return includeInactive ? query : query.where(eq(faqs.isActive, true));
}

export async function saveFaq(input: typeof faqs.$inferInsert, actor: CmsActor) {
  const db = await database();
  if (input.id) await db.update(faqs).set({ ...input, updatedAt: new Date() }).where(eq(faqs.id, input.id));
  else await db.insert(faqs).values(input);
  await logCmsActivity(actor, input.isActive ? "Published FAQ" : "Saved FAQ", "faq", input.id);
}

export async function deleteFaq(id: number, actor: CmsActor) {
  const db = await database();
  await db.delete(faqs).where(eq(faqs.id, id));
  await logCmsActivity(actor, "Deleted FAQ", "faq", id);
}

export async function savePolicy(input: typeof policies.$inferInsert, actor: CmsActor) {
  const db = await database();
  await db.insert(policies).values(input).onDuplicateKeyUpdate({ set: { ...input, updatedAt: new Date() } });
  const record = await db.select().from(policies).where(eq(policies.slug, input.slug)).limit(1);
  if (!record[0]) throw new Error("Policy could not be saved.");
  await logCmsActivity(actor, input.status === "published" ? "Published policy" : "Saved policy draft", "policy", record[0].id);
  return record[0];
}

export async function deletePolicy(id: number, actor: CmsActor) {
  const db = await database();
  await db.delete(policies).where(eq(policies.id, id));
  await logCmsActivity(actor, "Deleted policy", "policy", id);
}

export async function listMediaItems() {
  const db = await database();
  return db.select().from(mediaItems).orderBy(desc(mediaItems.createdAt));
}

export async function registerMediaItem(input: typeof mediaItems.$inferInsert, actor: CmsActor) {
  const db = await database();
  const [inserted] = await db.insert(mediaItems).values(input).$returningId();
  if (!inserted) throw new Error("Media item could not be registered.");
  const id = inserted.id;
  await logCmsActivity(actor, "Registered media item", "media", id);
  return id;
}

export async function deleteMediaItem(id: number, actor: CmsActor) {
  const db = await database();
  await db.delete(mediaItems).where(eq(mediaItems.id, id));
  await logCmsActivity(actor, "Removed media reference", "media", id);
}

export async function updateMediaItem(id: number, input: Pick<typeof mediaItems.$inferInsert, "fileName" | "altEn" | "altAr">, actor: CmsActor) {
  const db = await database();
  await db.update(mediaItems).set(input).where(eq(mediaItems.id, id));
  const result = await db.select({ id: mediaItems.id }).from(mediaItems).where(eq(mediaItems.id, id)).limit(1);
  if (result.length !== 1) throw new Error("Media item not found.");
  await logCmsActivity(actor, "Updated media metadata", "media", id);
}

export async function listSeoSettings() {
  const db = await database();
  return db.select().from(seoSettings).orderBy(asc(seoSettings.locale));
}

export async function saveSeoSettings(input: typeof seoSettings.$inferInsert, actor: CmsActor) {
  const db = await database();
  await db.insert(seoSettings).values(input).onDuplicateKeyUpdate({ set: { ...input, updatedAt: new Date() } });
  await logCmsActivity(actor, "Updated SEO settings", "seo", undefined);
}

export async function listContentCalendarItems() {
  const db = await database();
  return db.select().from(contentCalendarItems).orderBy(asc(contentCalendarItems.weekNumber), asc(contentCalendarItems.plannedFor), asc(contentCalendarItems.id));
}

type ContentCalendarSaveInput = Omit<typeof contentCalendarItems.$inferInsert, "createdAt" | "updatedAt">;

export async function saveContentCalendarItem(input: ContentCalendarSaveInput, actor: CmsActor) {
  const db = await database();
  const { id, ...values } = input;
  if (id) {
    await db.update(contentCalendarItems).set({ ...values, updatedAt: new Date() }).where(eq(contentCalendarItems.id, id));
    const updated = await db.select().from(contentCalendarItems).where(eq(contentCalendarItems.id, id)).limit(1);
    if (!updated[0]) throw new Error("Content calendar item not found.");
    await logCmsActivity(actor, "Updated content calendar item", "content_calendar", id);
    return updated[0];
  }
  const [inserted] = await db.insert(contentCalendarItems).values(values).$returningId();
  if (!inserted) throw new Error("Content calendar item could not be saved.");
  const createdId = inserted.id;
  const created = await db.select().from(contentCalendarItems).where(eq(contentCalendarItems.id, createdId)).limit(1);
  if (!created[0]) throw new Error("Content calendar item could not be saved.");
  await logCmsActivity(actor, "Created content calendar item", "content_calendar", createdId);
  return created[0];
}

export async function deleteContentCalendarItem(id: number, actor: CmsActor) {
  const db = await database();
  await db.delete(contentCalendarItems).where(eq(contentCalendarItems.id, id));
  await logCmsActivity(actor, "Deleted content calendar item", "content_calendar", id);
}
