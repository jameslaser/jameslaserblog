import { createHmac } from "node:crypto";
import { afterEach, describe, expect, it, vi } from "vitest";
import { CANONICAL_WABA_ID } from "./metaWhatsApp";
import { metaWebhookFingerprint, parseMetaWebhookPayload, verifyMetaWebhookChallenge, verifyMetaWebhookSignature } from "./whatsappWebhook";

const originalEnv = { ...process.env };

afterEach(() => {
  vi.unstubAllEnvs();
  process.env = { ...originalEnv };
});

describe("Meta WhatsApp webhook security", () => {
  it("accepts only a correctly signed raw payload", () => {
    const secret = "unit-test-app-secret";
    const body = Buffer.from(JSON.stringify({ object: "whatsapp_business_account", entry: [] }));
    const signature = `sha256=${createHmac("sha256", secret).update(body).digest("hex")}`;
    expect(verifyMetaWebhookSignature(body, signature, secret)).toBe(true);
    expect(verifyMetaWebhookSignature(body, "sha256=invalid", secret)).toBe(false);
    expect(verifyMetaWebhookSignature(body, undefined, secret)).toBe(false);
  });

  it("returns Meta's challenge only for the configured verification token", () => {
    vi.stubEnv("META_APP_ID", "app");
    vi.stubEnv("META_APP_SECRET", "secret");
    vi.stubEnv("WHATSAPP_ACCESS_TOKEN", "token");
    vi.stubEnv("WHATSAPP_PHONE_NUMBER_ID", "phone");
    vi.stubEnv("WHATSAPP_BUSINESS_ACCOUNT_ID", CANONICAL_WABA_ID);
    vi.stubEnv("WHATSAPP_WEBHOOK_VERIFY_TOKEN", "verify-token");
    vi.stubEnv("META_GRAPH_API_VERSION", "v99.0");
    expect(verifyMetaWebhookChallenge({ "hub.mode": "subscribe", "hub.verify_token": "verify-token", "hub.challenge": "challenge-value" })).toBe("challenge-value");
    expect(verifyMetaWebhookChallenge({ "hub.mode": "subscribe", "hub.verify_token": "wrong", "hub.challenge": "challenge-value" })).toBeNull();
  });

  it("parses only WhatsApp business payloads and uses a stable content fingerprint", () => {
    const body = Buffer.from(JSON.stringify({ object: "whatsapp_business_account", entry: [{ changes: [] }] }));
    expect(parseMetaWebhookPayload(body)?.object).toBe("whatsapp_business_account");
    expect(parseMetaWebhookPayload(Buffer.from("not json"))).toBeNull();
    expect(parseMetaWebhookPayload(Buffer.from(JSON.stringify({ object: "other", entry: [] })))).toBeNull();
    expect(metaWebhookFingerprint(body)).toMatch(/^[a-f0-9]{64}$/);
    expect(metaWebhookFingerprint(body)).toBe(metaWebhookFingerprint(body));
  });
});
