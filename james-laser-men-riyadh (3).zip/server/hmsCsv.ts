import { createHash } from "node:crypto";

export const HMS_REPORT_HEADERS = [
  "Text1",
  "Datasp_RPTAllAppointment_Screen_APPTDATE",
  "Datasp_RPTAllAppointment_Screen_FirstAppointment",
  "Datasp_RPTAllAppointment_Screen_LastAppointment",
  "Datasp_RPTAllAppointment_Screen_PATMRN",
  "Datasp_RPTAllAppointment_Screen_PATNAME",
  "Datasp_RPTAllAppointment_Screen_PATSEX",
  "Datasp_RPTAllAppointment_Screen_PATAGE",
  "Datasp_RPTAllAppointment_Screen_PATNATNAME",
  "Datasp_RPTAllAppointment_Screen_Telephone",
  "Datasp_RPTAllAppointment_Screen_Remarks",
] as const;

export const HMS_PROVIDER_SCOPED_REPORT_HEADERS = [
  "Headersp_RPTAllAppointment_Screen_AppType",
  "Headersp_RPTAllAppointment_Screen_APPTDATE",
  "Datasp_RPTAllAppointment_Screen_AppType",
  "Headersp_RPTAllAppointment_Screen_DoctorName",
  "Datasp_RPTAllAppointment_Screen_DoctorName",
  "Headersp_RPTAllAppointment_Screen_PATNAME",
  "Headersp_RPTAllAppointment_Screen_PATSEX",
  "Headersp_RPTAllAppointment_Screen_PATAGE",
  "Headersp_RPTAllAppointment_Screen_PATNATNAME",
  "Headersp_RPTAllAppointment_Screen_Telephone",
  "Headersp_RPTAllAppointment_Screen_Remarks",
] as const;

const HMS_PROVIDER_SCOPED_COLUMN_LABELS = [
  "#",
  "APPTDATE",
  "From Appointment",
  "To Appointment",
  "PATMRN",
  "PATNAME",
  "Gender",
  "Age",
  "Nationality",
  "Telephone",
  "Remarks",
] as const;

const HMS_PROVIDER_SCOPED_METADATA = ["AppType", "", "NotAttended", "DoctorName"] as const;
const HMS_NORMALIZED_PROVIDER_CODE = "NR011" as const;
const HMS_NORMALIZED_PROVIDER_LABEL = "NR011 JAMES FLORES" as const;

export type HmsMachineSuggestion = "DEKA AGAIN" | "CLARITY 2" | "GENTLE PROMAX" | "DUETTO MACHINE";
export type HmsVisitTypeSuggestion = "session" | "retouch" | "unknown";
export type HmsPreviewStatus = "READY" | "WARNING" | "DUPLICATE" | "ERROR";

export type HmsPreviewRow = {
  sourceRowNumber: number | null;
  sourceRowNumberRaw: string;
  appointmentDate: string | null;
  appointmentStartTime: string | null;
  appointmentEndTime: string | null;
  mrn: string | null;
  originalMrn: string;
  patientName: string;
  originalSex: string;
  normalizedSex: "Male" | "Female" | "Unknown";
  originalAge: string;
  normalizedAge: number | null;
  nationality: string | null;
  originalTelephone: string;
  normalizedWhatsapp: string | null;
  remarks: string;
  suggestedVisitType: HmsVisitTypeSuggestion;
  suggestedTreatment: string | null;
  suggestedMachine: HmsMachineSuggestion | null;
  validation: HmsPreviewStatus;
  warnings: string[];
  errors: string[];
  raw: Record<(typeof HMS_REPORT_HEADERS)[number], string>;
  fingerprint: string;
};

export type HmsParsedReport = {
  rows: HmsPreviewRow[];
  fatalErrors: string[];
  providerAttestationRequired: boolean;
  providerVerifiedFromSource: boolean;
  sourceProvider: string | null;
  normalizedProviderCode: typeof HMS_NORMALIZED_PROVIDER_CODE | null;
  normalizedProviderLabel: typeof HMS_NORMALIZED_PROVIDER_LABEL | null;
};

function parseCsvRecords(input: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let quoted = false;

  for (let index = 0; index < input.length; index += 1) {
    const character = input[index]!;
    if (quoted) {
      if (character === '"' && input[index + 1] === '"') { field += '"'; index += 1; continue; }
      if (character === '"') { quoted = false; continue; }
      field += character;
      continue;
    }
    if (character === '"') { quoted = true; continue; }
    if (character === ",") { row.push(field); field = ""; continue; }
    if (character === "\n") { row.push(field); rows.push(row); row = []; field = ""; continue; }
    if (character !== "\r") field += character;
  }
  if (field.length || row.length) { row.push(field); rows.push(row); }
  return rows;
}

function hasExactFields(actual: readonly string[], expected: readonly string[]): boolean {
  return actual.length === expected.length && expected.every((value, index) => actual[index] === value);
}

function normalizeSourceProvider(value: string): { sourceProvider: string; normalizedProviderCode: typeof HMS_NORMALIZED_PROVIDER_CODE; normalizedProviderLabel: typeof HMS_NORMALIZED_PROVIDER_LABEL } | null {
  const sourceProvider = value.trim();
  const normalized = sourceProvider.toUpperCase();
  if (normalized !== "NR011" && normalized !== "MOHAMED TAHA (JF)") return null;
  return { sourceProvider, normalizedProviderCode: HMS_NORMALIZED_PROVIDER_CODE, normalizedProviderLabel: HMS_NORMALIZED_PROVIDER_LABEL };
}

function parseProviderScopedPreamble(records: string[][], startIndex: number, fatalErrors: string[]) {
  const metadata = records[startIndex] ?? [];
  const spacer = records[startIndex + 1] ?? [];
  const columnLabels = records[startIndex + 2] ?? [];
  const metadataMatches = metadata.length === HMS_REPORT_HEADERS.length
    && metadata[0] === HMS_PROVIDER_SCOPED_METADATA[0]
    && metadata[1] === HMS_PROVIDER_SCOPED_METADATA[1]
    && metadata[3] === HMS_PROVIDER_SCOPED_METADATA[3]
    && metadata.slice(5).every(value => value === "");
  const spacerMatches = spacer.length === HMS_REPORT_HEADERS.length && spacer.every(value => value === "");
  const labelsMatch = hasExactFields(columnLabels, HMS_PROVIDER_SCOPED_COLUMN_LABELS);
  if (!metadataMatches || !spacerMatches || !labelsMatch) {
    const invalidPart = !metadataMatches ? "metadata" : !spacerMatches ? "separator" : "column labels";
    fatalErrors.push(`The provider-scoped HMS report ${invalidPart} is incomplete or reordered. Export the appointment report again without editing its metadata or column-label rows.`);
    return null;
  }

  const provider = normalizeSourceProvider(metadata[4] ?? "");
  if (!provider) {
    fatalErrors.push("The HMS report provider is not authorized. Only NR011 or Mohamed Taha (JF) can be normalized to NR011 JAMES FLORES; no fuzzy or unknown provider is accepted.");
    return null;
  }
  const sourceStatus = metadata[2]?.trim();
  if (sourceStatus !== "Attended" && sourceStatus !== "NotAttended") {
    fatalErrors.push("The HMS report status is not recognized. Only the NotAttended schedule can be synchronized as confirmed appointments; Attended history is excluded.");
    return null;
  }
  return { ...provider, sourceStatus };
}

function normalizeDate(value: string): string | null {
  const match = value.trim().match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (!match) return null;
  const [, day, month, year] = match;
  const date = new Date(`${year}-${month}-${day}T12:00:00Z`);
  if (Number.isNaN(date.getTime()) || date.getUTCFullYear() !== Number(year) || date.getUTCMonth() + 1 !== Number(month) || date.getUTCDate() !== Number(day)) return null;
  return `${year}-${month}-${day}`;
}

function normalizeTime(value: string): string | null {
  const match = value.trim().toUpperCase().match(/^(\d{1,2}):(\d{2})\s*([AP]M)$/);
  if (!match) return null;
  const [, rawHour, rawMinute, meridiem] = match;
  const minute = Number(rawMinute);
  let hour = Number(rawHour);
  if (hour < 1 || hour > 12 || minute > 59) return null;
  if (meridiem === "PM" && hour !== 12) hour += 12;
  if (meridiem === "AM" && hour === 12) hour = 0;
  return `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
}

function normalizeWhatsapp(value: string): string | null {
  const digits = value.replace(/\D/g, "");
  if (!digits) return null;
  const local = digits.startsWith("966") ? digits.slice(3) : digits.startsWith("0") ? digits.slice(1) : digits;
  return /^5\d{8}$/.test(local) ? `+966${local}` : null;
}

function normalizeSex(value: string): "Male" | "Female" | "Unknown" {
  const normalized = value.trim().toUpperCase();
  if (normalized === "M") return "Male";
  if (normalized === "F") return "Female";
  return "Unknown";
}

function detectSuggestions(remarks: string): Pick<HmsPreviewRow, "suggestedVisitType" | "suggestedTreatment" | "suggestedMachine"> {
  const text = remarks.toLocaleLowerCase();
  const suggestedVisitType: HmsVisitTypeSuggestion = /retouch|رتوش/.test(text) ? "retouch" : /session|جلس/.test(text) ? "session" : "unknown";
  const suggestedMachine: HmsMachineSuggestion | null = /\bdeka\b|ديكا/.test(text) ? "DEKA AGAIN" : /\bduetto\b|دويتو/.test(text) ? "DUETTO MACHINE" : /\bclarity(?:\s*2)?\b|كلاريتي/.test(text) ? "CLARITY 2" : /\bgentle\s*(?:pro\s*)?max\b|\bgentlemax\b|جنتل/.test(text) ? "GENTLE PROMAX" : null;
  const suggestedTreatment = /full\s*body|فل\s*بدي/.test(text) ? "FULL BODY" : /face|وجه/.test(text) ? "FACE" : /chest|صدر/.test(text) ? "Chest" : null;
  return { suggestedVisitType, suggestedMachine, suggestedTreatment };
}

function fingerprint(raw: Record<(typeof HMS_REPORT_HEADERS)[number], string>): string {
  return createHash("sha256").update([
    raw.Datasp_RPTAllAppointment_Screen_APPTDATE,
    raw.Datasp_RPTAllAppointment_Screen_FirstAppointment,
    raw.Datasp_RPTAllAppointment_Screen_LastAppointment,
    raw.Datasp_RPTAllAppointment_Screen_PATMRN,
    raw.Datasp_RPTAllAppointment_Screen_PATNAME,
    raw.Datasp_RPTAllAppointment_Screen_Telephone,
    raw.Datasp_RPTAllAppointment_Screen_Remarks,
  ].join("\u001f"), "utf8").digest("hex");
}

export function parseHmsReportCsv(input: string): HmsParsedReport {
  const records = parseCsvRecords(input.replace(/^\uFEFF/, ""));
  const header = records[0] ?? [];
  const fatalErrors: string[] = [];
  const isLegacyLayout = hasExactFields(header, HMS_REPORT_HEADERS);
  const isProviderScopedLayout = hasExactFields(header, HMS_PROVIDER_SCOPED_REPORT_HEADERS);
  let sourceRecords: string[][];
  const providerAttestationRequired = false;
  let providerVerifiedFromSource = false;
  let sourceProvider: string | null = null;
  let normalizedProviderCode: typeof HMS_NORMALIZED_PROVIDER_CODE | null = null;
  let normalizedProviderLabel: typeof HMS_NORMALIZED_PROVIDER_LABEL | null = null;

  if (isLegacyLayout) {
    fatalErrors.push("Provider-less HMS appointment exports are not accepted. Export the provider-scoped appointment report for NR011 or Mohamed Taha (JF).");
    return { rows: [], fatalErrors, providerAttestationRequired, providerVerifiedFromSource: false, sourceProvider: null, normalizedProviderCode: null, normalizedProviderLabel: null };
  } else if (isProviderScopedLayout) {
    const provider = parseProviderScopedPreamble(records, 1, fatalErrors);
    if (!provider) {
      return { rows: [], fatalErrors, providerAttestationRequired, providerVerifiedFromSource: false, sourceProvider: null, normalizedProviderCode: null, normalizedProviderLabel: null };
    }
    sourceRecords = [];
    let includeCurrentSection = provider.sourceStatus === "NotAttended";
    for (let index = 4; index < records.length;) {
      const record = records[index] ?? [];
      if (record.every(value => value === "")) { index += 1; continue; }
      if (record[0] === HMS_PROVIDER_SCOPED_METADATA[0] || record[3] === HMS_PROVIDER_SCOPED_METADATA[3]) {
        const repeatedProvider = parseProviderScopedPreamble(records, index, fatalErrors);
        if (!repeatedProvider || repeatedProvider.normalizedProviderCode !== provider.normalizedProviderCode) {
          return { rows: [], fatalErrors, providerAttestationRequired, providerVerifiedFromSource: false, sourceProvider: null, normalizedProviderCode: null, normalizedProviderLabel: null };
        }
        includeCurrentSection = repeatedProvider.sourceStatus === "NotAttended";
        index += 3;
        continue;
      }
      if (includeCurrentSection) sourceRecords.push(record);
      index += 1;
    }
    providerVerifiedFromSource = true;
    sourceProvider = provider.sourceProvider;
    normalizedProviderCode = provider.normalizedProviderCode;
    normalizedProviderLabel = provider.normalizedProviderLabel;
  } else {
    fatalErrors.push("Expected the exact 11-column provider-scoped HMS appointment export. The selected file headers do not match the supported layout.");
    return { rows: [], fatalErrors, providerAttestationRequired, providerVerifiedFromSource: false, sourceProvider: null, normalizedProviderCode: null, normalizedProviderLabel: null };
  }

  const rows: HmsPreviewRow[] = sourceRecords.filter(record => record.some(value => value.length > 0)).map(record => {
    const raw = Object.fromEntries(HMS_REPORT_HEADERS.map((headerName, index) => [headerName, record[index] ?? ""])) as HmsPreviewRow["raw"];
    const warnings: string[] = [];
    const errors: string[] = [];
    if (record.length !== HMS_REPORT_HEADERS.length) errors.push(`Expected 11 columns but found ${record.length}.`);
    const sourceRowNumberRaw = raw.Text1;
    const sourceRowNumber = /^\d+$/.test(sourceRowNumberRaw.trim()) ? Number(sourceRowNumberRaw.trim()) : null;
    if (sourceRowNumber === null) errors.push("Text1 must contain the original source row number.");
    const appointmentDate = normalizeDate(raw.Datasp_RPTAllAppointment_Screen_APPTDATE);
    if (!appointmentDate) errors.push("Appointment date must use DD/MM/YYYY.");
    const appointmentStartTime = normalizeTime(raw.Datasp_RPTAllAppointment_Screen_FirstAppointment);
    if (!appointmentStartTime) errors.push("FirstAppointment must use an HMS 12-hour time such as 1:00PM.");
    const appointmentEndTime = normalizeTime(raw.Datasp_RPTAllAppointment_Screen_LastAppointment);
    if (!appointmentEndTime) errors.push("LastAppointment must use an HMS 12-hour time such as 1:15PM.");
    if (raw.Datasp_RPTAllAppointment_Screen_FirstAppointment.trim() === raw.Datasp_RPTAllAppointment_Screen_LastAppointment.trim()) warnings.push("Start and end values are identical; both original values are retained without inventing an end time.");
    const patientName = raw.Datasp_RPTAllAppointment_Screen_PATNAME;
    if (!patientName.trim()) errors.push("Patient name is missing.");
    const originalMrn = raw.Datasp_RPTAllAppointment_Screen_PATMRN;
    const mrn = originalMrn.trim() && originalMrn.trim() !== "0" ? originalMrn : null;
    if (!mrn) warnings.push("MRN is not assigned; the original source value is retained.");
    const originalSex = raw.Datasp_RPTAllAppointment_Screen_PATSEX;
    const normalizedSex = normalizeSex(originalSex);
    if (normalizedSex === "Unknown") warnings.push("Sex is unknown or unrecognized; the original source value is retained.");
    const originalAge = raw.Datasp_RPTAllAppointment_Screen_PATAGE;
    const normalizedAge = /^\d+$/.test(originalAge.trim()) && Number(originalAge) > 0 ? Number(originalAge) : null;
    if (!normalizedAge) warnings.push("Age is unknown or zero; the original source value is retained.");
    const nationality = raw.Datasp_RPTAllAppointment_Screen_PATNATNAME.trim() || null;
    if (!nationality) warnings.push("Nationality is blank and has not been inferred.");
    const originalTelephone = raw.Datasp_RPTAllAppointment_Screen_Telephone;
    const normalizedWhatsapp = normalizeWhatsapp(originalTelephone);
    if (!normalizedWhatsapp) warnings.push("Telephone could not be normalized for matching; the original source value is retained.");
    const remarks = raw.Datasp_RPTAllAppointment_Screen_Remarks;
    const suggestions = detectSuggestions(remarks);
    return {
      sourceRowNumber,
      sourceRowNumberRaw,
      appointmentDate,
      appointmentStartTime,
      appointmentEndTime,
      mrn,
      originalMrn,
      patientName,
      originalSex,
      normalizedSex,
      originalAge,
      normalizedAge,
      nationality,
      originalTelephone,
      normalizedWhatsapp,
      remarks,
      ...suggestions,
      validation: (errors.length ? "ERROR" : warnings.length ? "WARNING" : "READY") as HmsPreviewStatus,
      warnings,
      errors,
      raw,
      fingerprint: fingerprint(raw),
    };
  });
  return { rows, fatalErrors, providerAttestationRequired, providerVerifiedFromSource, sourceProvider, normalizedProviderCode, normalizedProviderLabel };
}

/**
 * Returns a privacy-preserving stable key only when both user-selected patient
 * identifiers and a precise appointment schedule are available. The schedule
 * prevents a legitimate later visit from being mistaken for a re-upload.
 */
export function hmsAppointmentIdentityKey({
  mrn,
  normalizedWhatsapp,
  appointmentDate,
  appointmentStartTime,
}: Pick<HmsPreviewRow, "mrn" | "normalizedWhatsapp" | "appointmentDate" | "appointmentStartTime">): string | null {
  const normalizedMrn = mrn?.trim();
  if (!normalizedMrn || !normalizedWhatsapp || !appointmentDate || !appointmentStartTime) return null;
  return createHash("sha256").update([
    normalizedMrn,
    normalizedWhatsapp,
    appointmentDate,
    appointmentStartTime,
  ].join("\u001f"), "utf8").digest("hex");
}

/** Applies database/file duplicate facts to a parsed preview without mutating any appointment data. */
export function markHmsPreviewDuplicates(rows: HmsPreviewRow[], fileAlreadyImported: boolean, existingFingerprints: Set<string>, existingIdentityKeys: Set<string> = new Set()): HmsPreviewRow[] {
  const seenFingerprints = new Set<string>();
  const seenIdentityKeys = new Set<string>();
  return rows.map(row => {
    if (row.validation === "ERROR") return row;
    const duplicateInFile = seenFingerprints.has(row.fingerprint);
    const identityKey = hmsAppointmentIdentityKey(row);
    const duplicateIdentityInFile = Boolean(identityKey && seenIdentityKeys.has(identityKey));
    seenFingerprints.add(row.fingerprint);
    if (identityKey) seenIdentityKeys.add(identityKey);
    if (fileAlreadyImported || duplicateInFile || existingFingerprints.has(row.fingerprint) || duplicateIdentityInFile || Boolean(identityKey && existingIdentityKeys.has(identityKey))) {
      const duplicateWarning = fileAlreadyImported
        ? "This exact file was already imported."
        : duplicateInFile || existingFingerprints.has(row.fingerprint)
          ? "An appointment with the same HMS source fingerprint already exists."
          : "An appointment with the same MRN, normalized phone number, date, and time already exists.";
      return { ...row, validation: "DUPLICATE", warnings: [...row.warnings, duplicateWarning] };
    }
    return row;
  });
}
