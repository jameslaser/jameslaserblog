import { describe, expect, it } from "vitest";
import {
  decryptGoogleBusinessToken,
  encryptGoogleBusinessToken,
  getGoogleBusinessConfiguration,
} from "./googleBusiness";

describe("Google Business review integration safeguards", () => {
  const encryptionKey = Buffer.alloc(32, 7).toString("base64");

  it("requires all server-side connection secrets", () => {
    const configuration = getGoogleBusinessConfiguration({}, "https://www.jameslaserformen.com");

    expect(configuration.configured).toBe(false);
    expect(configuration.missing).toEqual([
      "GOOGLE_BUSINESS_CLIENT_ID",
      "GOOGLE_BUSINESS_CLIENT_SECRET",
      "GOOGLE_BUSINESS_TOKEN_ENCRYPTION_KEY",
    ]);
    expect(configuration.redirectUri).toBe("https://www.jameslaserformen.com/api/google-business/callback");
  });

  it("accepts a complete server-side configuration without exposing secret values", () => {
    const configuration = getGoogleBusinessConfiguration({
      GOOGLE_BUSINESS_CLIENT_ID: "client-id.apps.googleusercontent.com",
      GOOGLE_BUSINESS_CLIENT_SECRET: "client-secret",
      GOOGLE_BUSINESS_TOKEN_ENCRYPTION_KEY: encryptionKey,
    }, "https://www.jameslaserformen.com");

    expect(configuration.configured).toBe(true);
    expect(configuration.missing).toEqual([]);
    expect(configuration.redirectUri).toBe("https://www.jameslaserformen.com/api/google-business/callback");
  });

  it("encrypts persisted refresh tokens and rejects an incorrect key", () => {
    const encrypted = encryptGoogleBusinessToken("refresh-token-value", encryptionKey);

    expect(encrypted).not.toContain("refresh-token-value");
    expect(decryptGoogleBusinessToken(encrypted, encryptionKey)).toBe("refresh-token-value");
    expect(() => decryptGoogleBusinessToken(encrypted, Buffer.alloc(32, 8).toString("base64"))).toThrow();
  });

  it("accepts the configured OAuth client at Google's token endpoint without exposing credentials", async () => {
    const clientId = process.env.GOOGLE_BUSINESS_CLIENT_ID;
    const clientSecret = process.env.GOOGLE_BUSINESS_CLIENT_SECRET;

    expect(clientId).toBeTruthy();
    expect(clientSecret).toBeTruthy();

    const response = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: clientId!,
        client_secret: clientSecret!,
        refresh_token: "validation-token-not-issued",
        grant_type: "refresh_token",
      }),
    });
    const body = await response.json() as { error?: string };

    // Google verifies the client before rejecting our deliberately invalid
    // refresh token. An invalid_client response would fail this check.
    expect(response.status).toBe(400);
    expect(body.error).toBe("invalid_grant");
  }, 20_000);
});
