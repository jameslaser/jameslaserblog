import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
import { addRiyadhDays, jobParameters, retouchScheduleFor } from "./whatsappAutomation";

const root = resolve(import.meta.dirname, "..");
const serviceSource = readFileSync(resolve(root, "server/whatsappAutomation.ts"), "utf8");
const schedulerSource = readFileSync(resolve(root, "server/_core/index.ts"), "utf8");

describe("WhatsApp appointment automation safeguards", () => {
  it("calculates the requested session and retouch timing without a timezone drift", () => {
    expect(addRiyadhDays("2026-09-01", -1)).toBe("2026-08-31");
    expect(retouchScheduleFor("2026-09-01")).toEqual({
      reminderDate: "2026-09-08",
      eligibleStartDate: "2026-09-11",
      eligibleEndDate: "2026-09-15",
    });
  });

  it("rejects malformed scheduling dates rather than guessing an appointment day", () => {
    expect(() => addRiyadhDays("01/09/2026", 1)).toThrow("valid appointment date");
  });

  it("preserves the provider-verification boundary for communication and status facts", () => {
    expect(serviceSource).toContain('status: "provider_not_connected"');
    expect(serviceSource).toContain('status: "blocked_consent"');
    expect(serviceSource).toContain('status: "blocked_template"');
    expect(serviceSource).toContain('status: "provider_accepted"');
    expect(serviceSource).toContain('Meta did not return a message identifier.');
    expect(serviceSource).toContain('Sent, delivered, and read states require a later provider webhook');
  });

  it("requires explicit staff confirmation before a retouch appointment is created", () => {
    expect(serviceSource).toContain('if (input.action === "decline")');
    expect(serviceSource).toContain('if (input.action === "suggest")');
    expect(serviceSource).toContain('if (!input.machine) throw new Error("Choose the machine before confirming a retouch appointment.")');
    expect(serviceSource).toContain('A scheduled appointment already exists for this WhatsApp number');
    expect(serviceSource).toContain('The selected machine is already assigned');
  });

  it("supplies each bilingual reviewed template with the matching positional parameter count", () => {
    const appointment = { patientName: "Test", appointmentDate: "2026-09-20", appointmentTime: "10:00", treatmentAreas: '["Area"]', treatmentArea: null } as never;
    const englishTwoHour = { jobType: "session_reminder_2h", language: "en" } as never;
    const arabicTwoHour = { jobType: "session_reminder_2h", language: "ar" } as never;
    const followUp = { jobType: "appointment_completed_follow_up", language: "en" } as never;

    expect(jobParameters(englishTwoHour, appointment, null)).toEqual(["Test", "2026-09-20", "10:00", "Area"]);
    expect(jobParameters(arabicTwoHour, appointment, null)).toEqual(["Test", "10:00", "Area"]);
    expect(jobParameters(followUp, appointment, null)).toEqual(["Test", "2026-09-20", "10:00", "Area"]);
  });

  it("binds the scheduled endpoint to the authenticated heartbeat task identity", () => {
    expect(schedulerSource).toContain('"/api/scheduled/whatsapp-automation"');
    expect(schedulerSource).toContain('if (!user?.isCron || !user.taskUid)');
    expect(schedulerSource).toContain('runDueWhatsAppAutomation(user.taskUid)');
  });
});
