import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const schemaSource = readFileSync(resolve(process.cwd(), "drizzle/schema.ts"), "utf8");
const importSource = readFileSync(resolve(process.cwd(), "server/db.ts"), "utf8");

describe("HMS import identity guard", () => {
  it("stores a unique privacy-preserving identity key for imported appointments", () => {
    expect(schemaSource).toContain('hmsImportIdentityKey: varchar("hmsImportIdentityKey", { length: 128 }).unique()');
    expect(importSource).toContain('hmsImportIdentityKey: hmsAppointmentIdentityKey(row)');
  });

  it("checks MRN and normalized phone identity during preview and rechecks it inside the import transaction", () => {
    expect(importSource).toContain('existingIdentityRows');
    expect(importSource).toContain('hmsAppointmentIdentityKey({');
    expect(importSource).toContain('markHmsPreviewDuplicates(parsed.rows, fileAlreadyImported, existingFingerprints, existingIdentityKeys)');
    expect(importSource).toContain('const rowsToImport = importable.filter');
    expect(importSource).toContain('All selected appointments are already present. Refresh the preview to review the skipped duplicates.');
  });

  it("keeps file-level and source-fingerprint protections in place", () => {
    expect(importSource).toContain('This exact HMS file has already been imported and cannot be imported again.');
    expect(importSource).toContain('importFingerprint: row.fingerprint');
  });
});
