import { describe, expect, it } from "vitest";
import { markRevenueDuplicates, parseRevenueCsv, revenueTotals, revenueTotalsMatch } from "./revenueCsv";

const report = [
  "From Date,02/09/2026",
  "To Date,02/09/2026",
  "Account,James Laser Hair Removal For Men",
  "Print Date,02/12/2015",
  "MRN,Patient Name,Gross,Quantity,Discount,Deduct,Net",
  "22637,ABDULSALAM SOUD AL SULAIMI,,,,,",
  "C0004,FR Consultation,0,1,0,0,0",
  "CLT01,Clarity Full Body,900,1,304,0,596",
  "Patient Subtotal,,,,900,2,304,0,596",
  "22638,SECOND PATIENT,,,,,",
  "SAM22,One area men,400,2,208,0,192",
  "C0004,FR Consultation,0,1,0,0,0",
  "C0004,FR Consultation,0,1,0,0,0",
  "Patient Subtotal,,,,400,4,208,0,192",
  "Grand Total,,,,1300,6,512,0,788",
].join("\n");

const offsetReport = [
  "Detail Revenue By Patient,,,,,,,,,",
  "From Date,01/09/2026,,,,Print Date,,02/12/2015 10:53:49,,",
  "To Date,19/09/2026,,,,,,Page 1 of 2,,,",
  "Account,,,,,,,,,",
  "MRN,,Patient Name,Gross,Quantity,,Discount,,Deduct,Net",
  "1001,,PATIENT ONE,,,,,,",
  "C0004,,FR Consultation,0,1,,0,,0,0",
  ",,,0,1,,0,,0,0",
  "1002,,PATIENT TWO,,,,,,",
  "CLT02,,Clarity Any Small Area,200,1,,104,,0,96",
  ",,,200,1,,104,,0,96",
  "Detail Revenue By Patient,,,,,,,,,",
  "From Date,01/09/2026,,,,Print Date,,02/12/2015 10:53:49,,",
  "To Date,19/09/2026,,,,,,Page 2 of 2,,,",
  "MRN,,Patient Name,Gross,Quantity,,Discount,,Deduct,Net",
  "1003,,PATIENT THREE,,,,,,",
  "DUT06,,Duetto Any Small Area,100,1,,33.67,,0,66.33",
  ",,,100,1,,33.67,,0,66.33",
  "GRAND TOTAL,,,300,3,,137.67,,0,162.33",
].join("\n");

const alternateOffsetReport = [
  "Detail Revenue By Patient,,,,,,,,,",
  "From Date,01/10/2026,,,,Print Date,,21/10/2026 09:15:00,,",
  "To Date,20/10/2026,,,,,,Page 1 of 1,,,",
  "Account,HMS TEST LEDGER,,,,,,,,",
  "MRN,,Patient Name,Gross,Quantity,,Discount,,Deduct,Net",
  "9001,,SAMPLE PATIENT A,,,,,,",
  "C0004,,FR Consultation,0,1,,0,,0,0",
  "CLT10,,Clarity Large Area,600,1,,150,,50,400",
  ",,,600,2,,150,,50,400",
  "9002,,SAMPLE PATIENT B,,,,,,",
  "DEA04,,Deka Treatment Area,400,1,,80,,0,320",
  ",,,400,1,,80,,0,320",
  "GRAND TOTAL,,,1000,3,,230,,50,720",
].join("\n");

describe("HMS Detail Revenue By Patient parser", () => {
  it("detects grouped patients, service rows, subtotals, grand total, and preserves Print Date as metadata", () => {
    const parsed = parseRevenueCsv(report);
    expect(parsed.fatalErrors).toEqual([]);
    expect(parsed.fromDate).toBe("2026-09-02");
    expect(parsed.toDate).toBe("2026-09-02");
    expect(parsed.printDate).toBe("2015-12-02");
    expect(parsed.rows).toHaveLength(5);
    expect(parsed.subtotalRowCount).toBe(2);
    expect(parsed.grandTotalRowCount).toBe(1);
    expect(parsed.patients).toHaveLength(2);
    expect(parsed.rows[0]).toMatchObject({ mrn: "22637", serviceCode: "C0004", net: 0 });
    expect(parsed.rows[1]).toMatchObject({ mrn: "22637", serviceCode: "CLT01", serviceName: "Clarity Full Body", gross: 900, quantity: 1, discount: 304, net: 596 });
    expect(parsed.grandTotal).toEqual({ gross: 1300, quantity: 6, discount: 512, deduct: 0, net: 788 });
    expect(revenueTotalsMatch(revenueTotals(parsed.rows), parsed.grandTotal!)).toBe(true);
  });

  it("keeps zero-value services and flags Net discrepancies without replacing HMS Net", () => {
    const parsed = parseRevenueCsv([
      "MRN,Patient Name,Gross,Quantity,Discount,Deduct,Net",
      "22637,ABDULSALAM SOUD AL SULAIMI,,,,,",
      "C0004,FR Consultation,0,1,0,0,0",
      "CLT01,Clarity Full Body,900,1,304,0,590",
      "Grand Total,,,,900,2,304,0,590",
    ].join("\n"));
    expect(parsed.rows).toHaveLength(2);
    expect(parsed.rows[0]?.net).toBe(0);
    expect(parsed.rows[1]?.net).toBe(590);
    expect(parsed.rows[1]?.warnings).toContain("HMS Net differs from Gross - Discount - Deduct; original HMS values are retained.");
  });

  it("parses HMS exports with spacer columns, page-break headers, and unlabeled patient subtotals", () => {
    const parsed = parseRevenueCsv(offsetReport);
    expect(parsed.fatalErrors).toEqual([]);
    expect(parsed.fromDate).toBe("2026-09-01");
    expect(parsed.toDate).toBe("2026-09-19");
    expect(parsed.printDate).toBe("02/12/2015 10:53:49");
    expect(parsed.rows).toHaveLength(3);
    expect(parsed.patients).toHaveLength(3);
    expect(parsed.subtotalRowCount).toBe(3);
    expect(parsed.grandTotalRowCount).toBe(1);
    expect(parsed.rows[1]).toMatchObject({
      mrn: "1002",
      serviceCode: "CLT02",
      serviceName: "Clarity Any Small Area",
      gross: 200,
      quantity: 1,
      discount: 104,
      deduct: 0,
      net: 96,
    });
    expect(parsed.grandTotal).toEqual({ gross: 300, quantity: 3, discount: 137.67, deduct: 0, net: 162.33 });
    expect(revenueTotalsMatch(revenueTotals(parsed.rows), parsed.grandTotal!)).toBe(true);
  });

  it("reconciles an alternate HMS Detail Revenue By Patient sample with a non-zero deduction", () => {
    const parsed = parseRevenueCsv(alternateOffsetReport);

    expect(parsed.fatalErrors).toEqual([]);
    expect(parsed.fromDate).toBe("2026-10-01");
    expect(parsed.toDate).toBe("2026-10-20");
    expect(parsed.account).toBe("HMS TEST LEDGER");
    expect(parsed.printDate).toBe("21/10/2026 09:15:00");
    expect(parsed.rows).toHaveLength(3);
    expect(parsed.patients).toHaveLength(2);
    expect(parsed.subtotalRowCount).toBe(2);
    expect(parsed.reconciliationDifferences).toEqual([]);
    expect(parsed.mrnDuplicateEntries).toEqual([]);
    expect(parsed.grandTotal).toEqual({ gross: 1000, quantity: 3, discount: 230, deduct: 50, net: 720 });
    expect(revenueTotals(parsed.rows)).toEqual(parsed.grandTotal);
    expect(parsed.patients[0]?.totals).toEqual({ gross: 600, quantity: 2, discount: 150, deduct: 50, net: 400 });
  });

  it("reports the exact subtotal and grand-total fields that disagree with service rows", () => {
    const parsed = parseRevenueCsv([
      "MRN,,Patient Name,Gross,Quantity,,Discount,,Deduct,Net",
      "1001,,PATIENT ONE,,,,,,",
      "CLT02,,Clarity Any Small Area,200,1,,100,,0,100",
      ",,,200,1,,110,,0,90",
      "GRAND TOTAL,,,200,1,,105,,0,95",
    ].join("\n"));

    expect(parsed.fatalErrors).toContain("HMS SUBTOTAL RECONCILIATION FAILED: 1 patient subtotal does not match its service rows.");
    expect(parsed.fatalErrors).toContain("HMS TOTAL RECONCILIATION FAILED: service-row totals do not equal the HMS Grand Total.");
    expect(parsed.reconciliationDifferences).toEqual([
      expect.objectContaining({
        scope: "PATIENT_SUBTOTAL",
        mrn: "1001",
        differences: { discount: -10, net: 10 },
      }),
      expect.objectContaining({
        scope: "GRAND_TOTAL",
        mrn: null,
        differences: { discount: -5, net: 5 },
      }),
    ]);
  });

  it("flags exact repeated service entries under the same MRN for review without treating all MRN activity as duplicate", () => {
    const parsed = parseRevenueCsv([
      "MRN,,Patient Name,Gross,Quantity,,Discount,,Deduct,Net",
      "1001,,PATIENT ONE,,,,,,",
      "CLT02,,Clarity Any Small Area,200,1,,100,,0,100",
      "CLT02,,Clarity Any Small Area,200,1,,100,,0,100",
      ",,,400,2,,200,,0,200",
      "1002,,PATIENT TWO,,,,,,",
      "CLT02,,Clarity Any Small Area,200,1,,100,,0,100",
      ",,,200,1,,100,,0,100",
      "GRAND TOTAL,,,600,3,,300,,0,300",
    ].join("\n"));

    expect(parsed.mrnDuplicateEntries).toEqual([
      expect.objectContaining({
        mrn: "1001",
        sourceRowNumbers: [3, 4],
        serviceCode: "CLT02",
      }),
    ]);
    expect(parsed.mrnDuplicateEntries).toHaveLength(1);
  });

  it("blocks reconciliation when the Grand Total differs from service rows", () => {
    const parsed = parseRevenueCsv(report.replace("Grand Total,,,,1300,6,512,0,788", "Grand Total,,,,1300,6,500,0,800"));
    expect(parsed.fatalErrors[0]).toContain("HMS TOTAL RECONCILIATION FAILED");
  });

  it("marks exact file and row duplicates without mutating the source rows", () => {
    const parsed = parseRevenueCsv(report);
    const marked = markRevenueDuplicates(parsed.rows, new Set([parsed.rows[0]!.fingerprint]), false);
    expect(marked[0]?.validation).toBe("DUPLICATE");
    expect(marked[1]?.validation).toBe("READY");
    const allMarked = markRevenueDuplicates(parsed.rows, new Set(), true);
    expect(allMarked.every(row => row.validation === "DUPLICATE")).toBe(true);
  });
});
