type PublishedArticle = {
  slug: string;
  titleEn: string;
  summaryEn?: string | null;
  authorName?: string | null;
  category?: string | null;
  publishedAt?: Date | null;
  updatedAt?: Date | null;
};

const XML_ESCAPE: Record<string, string> = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;" };
function escapeXml(value: string) { return value.replace(/[&<>"']/g, character => XML_ESCAPE[character]); }
function rfc822(value?: Date | null) { return value && !Number.isNaN(value.getTime()) ? value.toUTCString() : undefined; }

export function buildBlogRssXml(origin: string, articles: readonly PublishedArticle[]) {
  const base = origin.replace(/\/+$/, "");
  const items = articles.slice(0, 50).map(article => {
    const url = `${base}/en/blog/${encodeURIComponent(article.slug)}`;
    const published = rfc822(article.publishedAt ?? article.updatedAt);
    return [
      "    <item>",
      `      <title>${escapeXml(article.titleEn)}</title>`,
      `      <link>${escapeXml(url)}</link>`,
      `      <guid isPermaLink="true">${escapeXml(url)}</guid>`,
      article.summaryEn ? `      <description>${escapeXml(article.summaryEn)}</description>` : "",
      article.authorName ? `      <dc:creator>${escapeXml(article.authorName)}</dc:creator>` : "",
      article.category ? `      <category>${escapeXml(article.category)}</category>` : "",
      published ? `      <pubDate>${published}</pubDate>` : "",
      "    </item>",
    ].filter(Boolean).join("\n");
  }).join("\n");
  const lastBuild = rfc822(articles[0]?.updatedAt ?? articles[0]?.publishedAt) ?? new Date().toUTCString();
  return `<?xml version="1.0" encoding="UTF-8"?>\n<rss version="2.0" xmlns:dc="http://purl.org/dc/elements/1.1/">\n  <channel>\n    <title>James Laser Men’s Laser Hair Removal Blog</title>\n    <link>${escapeXml(`${base}/en/blog`)}</link>\n    <description>Clinic-reviewed education about men’s laser hair removal in Riyadh.</description>\n    <language>en-SA</language>\n    <lastBuildDate>${lastBuild}</lastBuildDate>\n    <atom:link xmlns:atom="http://www.w3.org/2005/Atom" href="${escapeXml(`${base}/blog/rss.xml`)}" rel="self" type="application/rss+xml" />\n${items}\n  </channel>\n</rss>\n`;
}
