import { describe, expect, it } from "vitest";
import { appointmentEndTime, appointmentRangesOverlap, clinicDurationMinutes, hasAppointmentConflict } from "@shared/appointmentScheduling";

describe("clinic appointment scheduling", () => {
  it("derives conservative durations from the approved clinic treatment rules", () => {
    expect(clinicDurationMinutes(["Full Face"], "session")).toBe(15);
    expect(clinicDurationMinutes(["Chest", "Abdomen"], "session")).toBe(60);
    expect(clinicDurationMinutes(["Full Back"], "session")).toBe(45);
    expect(clinicDurationMinutes(["Full Body"], "session")).toBe(120);
    expect(clinicDurationMinutes(["Full Body"], "retouch")).toBe(90);
    expect(clinicDurationMinutes(["Mini Full Body"], "session")).toBe(105);
    expect(clinicDurationMinutes(["Mini Full Body"], "retouch")).toBe(60);
  });

  it("requires finalized appointments to use 15-minute slots that finish within clinic hours", () => {
    expect(appointmentEndTime("13:15", 15)).toBe("13:30");
    expect(appointmentEndTime("21:30", 30)).toBe("22:00");
    expect(() => appointmentEndTime("12:45", 15)).toThrow("Choose a 15-minute appointment time");
    expect(() => appointmentEndTime("22:00", 15)).toThrow("Choose a 15-minute appointment time");
    expect(() => appointmentEndTime("21:45", 30)).toThrow("extends beyond the 10:00 PM clinic closing time");
  });

  it("detects overlapping mobile and machine bookings, including legacy appointments without an end time", () => {
    expect(appointmentRangesOverlap("13:15", "13:45", "13:30", "14:00")).toBe(true);
    expect(appointmentRangesOverlap("13:15", "13:30", "13:30", "13:45")).toBe(false);
    expect(hasAppointmentConflict(
      { appointmentTime: "13:30", appointmentEndTime: "14:00", whatsapp: "+966501234567", machine: "DEKA AGAIN" },
      { id: 1, appointmentTime: "13:15", appointmentEndTime: "13:45", durationMinutes: 30, whatsapp: "+966501234567", machine: "DEKA AGAIN" },
    )).toEqual({ mobile: true, machine: true });
    expect(hasAppointmentConflict(
      { appointmentTime: "13:15", appointmentEndTime: "13:30", whatsapp: "+966500000000", machine: "DEKA AGAIN" },
      { id: 2, appointmentTime: "13:15", appointmentEndTime: null, durationMinutes: null, whatsapp: "+966511111111", machine: "DEKA AGAIN" },
    )).toEqual({ mobile: false, machine: true });
  });
});
