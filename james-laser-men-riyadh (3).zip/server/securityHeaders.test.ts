import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const source = readFileSync(resolve(process.cwd(), "server/_core/index.ts"), "utf8");

describe("server security headers", () => {
  it("disables framework disclosure and sets safe baseline headers", () => {
    expect(source).toContain('app.disable("x-powered-by")');
    expect(source).toContain('X-Content-Type-Options", "nosniff"');
    expect(source).toContain('Referrer-Policy", "strict-origin-when-cross-origin"');
    expect(source).toContain('Permissions-Policy", "camera=(), microphone=(), geolocation=()');
    expect(source).toContain('X-Frame-Options", "DENY"');
    expect(source).toContain('Content-Security-Policy"');
    expect(source).toContain("frame-src 'self' https://d36hbw14aib5lz.cloudfront.net https://www.google.com");
    expect(source).toContain("script-src 'self' https://manus-analytics.com");
    expect(source).toContain('Strict-Transport-Security"');
    expect(source).toContain('if (process.env.NODE_ENV === "production")');
    expect(source).toContain('app.set("trust proxy", 1)');
    expect(source).toContain('express.json({ limit: "2mb" })');
    expect(source).toContain('app.use("/api/trpc/cms.uploadMedia", express.json({ limit: "14mb" }))');
    expect(source).toContain('express.urlencoded({ limit: "2mb", extended: true })');
    expect(source).not.toContain('express.json({ limit: "50mb" })');
  });
});
