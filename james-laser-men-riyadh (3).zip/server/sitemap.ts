const XML_ESCAPE: Record<string, string> = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&apos;",
};

type TimestampedPublishedItem = {
  slug: string;
  publishedAt?: Date | null;
  updatedAt?: Date | null;
  titleAr?: string | null;
  summaryAr?: string | null;
  contentAr?: string | null;
};

type SitemapInput = {
  origin: string;
  guidePosts: readonly TimestampedPublishedItem[];
  policies: readonly TimestampedPublishedItem[];
};

type SitemapEntry = {
  path: string;
  lastmod?: Date | null;
  changefreq?: "weekly" | "monthly";
  priority?: string;
};

function escapeXml(value: string) {
  return value.replace(/[&<>"']/g, character => XML_ESCAPE[character]);
}

function isoDate(value?: Date | null) {
  if (!value || Number.isNaN(value.getTime())) return undefined;
  return value.toISOString().slice(0, 10);
}

function uniqueEntries(entries: SitemapEntry[]) {
  const paths = new Set<string>();
  return entries.filter(entry => {
    if (paths.has(entry.path)) return false;
    paths.add(entry.path);
    return true;
  });
}

/**
 * Uses only canonical public URLs. Draft, private, administrative, and API
 * records are excluded because the caller supplies published-only data.
 */
export function buildSitemapXml({ origin, guidePosts, policies }: SitemapInput) {
  const base = origin.replace(/\/+$/, "");
  const entries: SitemapEntry[] = [
    { path: "/", changefreq: "weekly", priority: "1.0" },
    { path: "/ar", changefreq: "weekly", priority: "0.9" },
    { path: "/en/treatments", changefreq: "weekly", priority: "0.8" },
    { path: "/ar/treatments", changefreq: "weekly", priority: "0.8" },
    { path: "/en/offers", changefreq: "weekly", priority: "0.7" },
    { path: "/ar/offers", changefreq: "weekly", priority: "0.7" },
    { path: "/en/results", changefreq: "weekly", priority: "0.7" },
    { path: "/ar/results", changefreq: "weekly", priority: "0.7" },
    { path: "/en/faq", changefreq: "monthly", priority: "0.6" },
    { path: "/ar/faq", changefreq: "monthly", priority: "0.6" },
    { path: "/en/blog", changefreq: "weekly", priority: "0.8" },
    { path: "/ar/blog", changefreq: "weekly", priority: "0.8" },
    { path: "/appointment", changefreq: "monthly", priority: "0.6" },
    { path: "/ar/appointment", changefreq: "monthly", priority: "0.6" },
    { path: "/whatsapp", changefreq: "monthly", priority: "0.7" },
    { path: "/ar/whatsapp", changefreq: "monthly", priority: "0.7" },
  ];

  for (const policy of policies) {
    const lastmod = policy.updatedAt ?? policy.publishedAt;
    entries.push({ path: `/policies/${encodeURIComponent(policy.slug)}`, lastmod, changefreq: "monthly", priority: "0.4" });
    if (policy.titleAr?.trim() && policy.contentAr?.trim()) {
      entries.push({ path: `/ar/policies/${encodeURIComponent(policy.slug)}`, lastmod, changefreq: "monthly", priority: "0.4" });
    }
  }

  const newestGuide = guidePosts.reduce<Date | null>((latest, post) => {
    const candidate = post.updatedAt ?? post.publishedAt ?? null;
    if (!candidate || (latest && latest >= candidate)) return latest;
    return candidate;
  }, null);
  if (newestGuide) {
    for (const entry of entries) {
      if (entry.path === "/en/blog" || entry.path === "/ar/blog") entry.lastmod = newestGuide;
    }
  }
  for (const guide of guidePosts) {
    const lastmod = guide.updatedAt ?? guide.publishedAt;
    entries.push({ path: `/en/blog/${encodeURIComponent(guide.slug)}`, lastmod, changefreq: "monthly", priority: "0.7" });
    if (guide.titleAr?.trim() && (guide.summaryAr?.trim() || guide.contentAr?.trim())) {
      entries.push({ path: `/ar/blog/${encodeURIComponent(guide.slug)}`, lastmod, changefreq: "monthly", priority: "0.7" });
    }
  }

  const xmlEntries = uniqueEntries(entries)
    .map(entry => {
      const lastmod = isoDate(entry.lastmod);
      const lines = [`  <url>`, `    <loc>${escapeXml(`${base}${entry.path}`)}</loc>`];
      if (lastmod) lines.push(`    <lastmod>${lastmod}</lastmod>`);
      if (entry.changefreq) lines.push(`    <changefreq>${entry.changefreq}</changefreq>`);
      if (entry.priority) lines.push(`    <priority>${entry.priority}</priority>`);
      lines.push("  </url>");
      return lines.join("\n");
    })
    .join("\n");

  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${xmlEntries}\n</urlset>\n`;
}
