import { beforeEach, describe, expect, it, vi } from "vitest";
import { generatePromotionDraft } from "./promotionAi";
import { invokeLLM, listLLMModels } from "./_core/llm";
import { storageGetSignedUrl } from "./storage";

vi.mock("./_core/llm", () => ({ listLLMModels: vi.fn(), invokeLLM: vi.fn() }));
vi.mock("./storage", () => ({ storageGetSignedUrl: vi.fn() }));

const draft = {
  slug: "riyadh-appointment-review-offer",
  name: "Riyadh appointment review offer",
  titleEn: "Riyadh Appointment Review Offer",
  titleAr: "عرض مراجعة الموعد في الرياض",
  descriptionEn: "Clinic-approved details are reviewed before any appointment is confirmed.",
  descriptionAr: "تُراجع التفاصيل المعتمدة من العيادة قبل تأكيد أي موعد.",
  includedTreatments: "Facial and neck laser discussion",
  originalPrice: "500.00",
  promotionalPrice: "350.00",
  sessionCount: 1,
  retouchIncluded: false,
  startsAt: "2026-10-10",
  endsAt: "2026-10-20",
  termsEn: "Valid only for the stated period and subject to clinic review.",
  termsAr: "يسري خلال الفترة المذكورة ويخضع لمراجعة العيادة.",
  reviewChecklist: ["Verify the exact price.", "Verify inclusions and exclusions.", "Approve the date range and terms."],
};

beforeEach(() => {
  vi.clearAllMocks();
  vi.mocked(listLLMModels).mockResolvedValue({ object: "list", data: [{ id: "gpt-5-mini", object: "model", created: 0, owned_by: "manus" }] });
  vi.mocked(invokeLLM).mockResolvedValue({ id: "promotion", created: 0, model: "gpt-5-mini", choices: [{ index: 0, message: { role: "assistant", content: JSON.stringify(draft) }, finish_reason: "stop" }] });
  vi.mocked(storageGetSignedUrl).mockResolvedValue("https://signed.example/promotion-card.jpg");
});

describe("protected promotion AI drafting", () => {
  it("creates one structured private review draft from approved text only", async () => {
    const result = await generatePromotionDraft({ sourceDetails: "Riyadh appointment review offer. Normal price 500 SAR. Promotion price 350 SAR. 10–20 October 2026.", sourceImageUrl: null });
    expect(result).toEqual({ ...draft, model: "gpt-5-mini" });
    const request = vi.mocked(invokeLLM).mock.calls[0]?.[0];
    expect(request?.model).toBe("gpt-5-mini");
    expect(JSON.stringify(request?.response_format)).toContain("clinic_promotion_review_draft");
    expect(JSON.stringify(request?.messages)).toContain("never published automatically");
    expect(JSON.stringify(request?.messages)).toContain("Do not infer, reconstruct, calculate, convert, or add any price");
  });

  it("uses a signed CMS image URL only when an authorized source image is supplied", async () => {
    await generatePromotionDraft({ sourceDetails: "", sourceImageUrl: "/manus-storage/cms-media/1/approved-offer.png" });
    expect(storageGetSignedUrl).toHaveBeenCalledWith("cms-media/1/approved-offer.png");
    expect(JSON.stringify(vi.mocked(invokeLLM).mock.calls[0]?.[0]?.messages)).toContain("https://signed.example/promotion-card.jpg");
  });

  it("rejects incomplete output rather than returning a partially invented offer", async () => {
    vi.mocked(invokeLLM).mockResolvedValueOnce({ id: "bad", created: 0, model: "gpt-5-mini", choices: [{ index: 0, message: { role: "assistant", content: "{}" }, finish_reason: "stop" }] });
    await expect(generatePromotionDraft({ sourceDetails: "Approved source details are present for a clinic offer.", sourceImageUrl: null })).rejects.toThrow("AI promotion draft was incomplete");
  });
});
