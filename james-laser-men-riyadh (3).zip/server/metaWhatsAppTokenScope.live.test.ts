import { createHmac } from "node:crypto";
import { describe, expect, it } from "vitest";
import { CANONICAL_WABA_ID, getMetaWhatsAppConfig } from "./metaWhatsApp";

const describeLive = process.env.RUN_LIVE_META_CREDENTIAL_TESTS === "1" ? describe : describe.skip;

type DebugTokenData = {
  app_id?: string;
  is_valid?: boolean;
  profile_id?: string;
  scopes?: string[];
};

describeLive("live Manus-managed Meta WhatsApp token scope", () => {
  it("belongs to the configured app and contains the required WhatsApp management scopes", async () => {
    const config = getMetaWhatsAppConfig();
    expect(config).not.toBeNull();
    if (!config) return;

    const appAccessToken = `${config.appId}|${config.appSecret}`;
    const url = new URL(`https://graph.facebook.com/${encodeURIComponent(config.graphApiVersion)}/debug_token`);
    url.searchParams.set("input_token", config.accessToken);
    url.searchParams.set("access_token", appAccessToken);
    url.searchParams.set("appsecret_proof", createHmac("sha256", config.appSecret).update(appAccessToken).digest("hex"));

    const response = await fetch(url, { method: "GET" });
    const payload = await response.json().catch(() => null) as { data?: DebugTokenData; error?: { code?: number | string; type?: string } } | null;
    if (!response.ok) {
      throw new Error(`Meta token debug request failed: HTTP ${response.status}; code ${String(payload?.error?.code ?? "unknown")}; type ${String(payload?.error?.type ?? "unknown")}`);
    }
    expect(payload?.data?.is_valid).toBe(true);
    expect(payload?.data?.app_id).toBe(config.appId);
    expect(payload?.data?.profile_id).toBe(CANONICAL_WABA_ID);
    expect(payload?.data?.scopes ?? []).toEqual(expect.arrayContaining([
      "business_management",
      "whatsapp_business_management",
      "whatsapp_business_messaging",
    ]));
  }, 30_000);
});
