import express from "express";
import { afterEach, describe, expect, it } from "vitest";
import { registerRedirectMiddleware } from "./redirectMiddleware";

const servers: Array<ReturnType<ReturnType<typeof express>["listen"]>> = [];
afterEach(async () => { await Promise.all(servers.splice(0).map(server => new Promise<void>(resolve => server.close(() => resolve())))); });

async function serve(lookup: (path: string) => Promise<string | null>) {
  const app = express();
  registerRedirectMiddleware(app, lookup);
  app.use((_req, res) => res.status(204).end());
  const server = app.listen(0); servers.push(server);
  await new Promise<void>(resolve => server.once("listening", () => resolve()));
  const address = server.address(); if (!address || typeof address === "string") throw new Error("Test server did not bind.");
  return `http://127.0.0.1:${address.port}`;
}

describe("redirect middleware", () => {
  it("emits a 301 before frontend routing and preserves the public query string", async () => {
    const url = await serve(async path => path === "/old-laser-guide" ? "/new-laser-guide" : null);
    const response = await fetch(`${url}/old-laser-guide?source=legacy`, { redirect: "manual" });
    expect(response.status).toBe(301);
    expect(response.headers.get("location")).toBe("/new-laser-guide?source=legacy");
  });

  it("does not resolve API or admin paths through the public redirect lookup", async () => {
    const calls: string[] = [];
    const url = await serve(async path => { calls.push(path); return "/should-not-run"; });
    await expect(fetch(`${url}/admin/redirects`, { redirect: "manual" })).resolves.toMatchObject({ status: 204 });
    await expect(fetch(`${url}/api/trpc`, { redirect: "manual" })).resolves.toMatchObject({ status: 204 });
    expect(calls).toEqual([]);
  });
});
