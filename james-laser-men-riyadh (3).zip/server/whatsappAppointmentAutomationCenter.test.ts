import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const root = resolve(import.meta.dirname, "..");
const automationSource = readFileSync(resolve(root, "server/whatsappAutomation.ts"), "utf8");
const dbSource = readFileSync(resolve(root, "server/db.ts"), "utf8");
const routerSource = readFileSync(resolve(root, "server/routers.ts"), "utf8");
const migrationSource = readFileSync(resolve(root, "drizzle/migrations/0026_add_appointment_automation_center.sql"), "utf8");

describe("WhatsApp appointment automation centre", () => {
  it("defines the requested bilingual appointment lifecycle templates", () => {
    [
      "appointment_confirmation",
      "appointment_reminder_24h",
      "appointment_final_reminder",
      "appointment_rescheduled",
      "appointment_cancellation",
      "appointment_completed_follow_up",
      "appointment_no_show_follow_up",
      "newlook_appointment_confirmation_en",
      "newlook_appointment_confirmation_ar",
    ].forEach(value => expect(automationSource).toContain(value));
  });

  it("uses a rollout marker and appointment version to avoid late or duplicate confirmation sends", () => {
    expect(automationSource).toContain("eligibleForLifecycleAutomation");
    expect(automationSource).toContain("appointment.whatsappAutomationVersion === 1");
    expect(automationSource).toContain("appointment.whatsappAutomationVersion > 1");
    expect(automationSource).toContain("v${version}:${input.language}");
    expect(dbSource).toContain("whatsappAutomationInitializedAt: new Date()");
    expect(dbSource).toContain('whatsappAutomationVersion: sql`${appointments.whatsappAutomationVersion} + 1`');
  });

  it("keeps provider delivery states evidence-based and protects completed messages from resend", () => {
    expect(automationSource).toContain('status: "provider_accepted"');
    expect(automationSource).toContain('status, ...(status === "sent" ? { sentAt: occurredAt } : {})');
    expect(automationSource).toContain('["sent", "delivered", "read", "provider_accepted", "claimed"]');
    expect(automationSource).toContain("This message requires a provider, recipient, or template correction");
  });

  it("makes feature flags and appointment status data protected server procedures", () => {
    expect(routerSource).toContain("appointmentWhatsAppStatus: adminProcedure");
    expect(routerSource).toContain("appointmentConfirmationEnabled: z.boolean()");
    expect(routerSource).toContain("appointmentFinalReminderHours");
  });

  it("supplies an additive, non-destructive migration for the built-in application database", () => {
    expect(migrationSource).toContain("ADD COLUMN `whatsappAutomationInitializedAt`");
    expect(migrationSource).toContain("ADD COLUMN `appointmentConfirmationEnabled`");
    expect(migrationSource).toContain("ADD COLUMN `retryable`");
    expect(migrationSource).not.toMatch(/DROP TABLE|DELETE FROM|TRUNCATE/i);
  });
});
