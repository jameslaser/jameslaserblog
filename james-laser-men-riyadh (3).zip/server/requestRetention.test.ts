import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const dbSource = readFileSync(new URL("./db.ts", import.meta.url), "utf8");
const workspaceSource = readFileSync(new URL("../client/src/pages/AdminRequestsWorkspace.tsx", import.meta.url), "utf8");

describe("consultation request retention", () => {
  it("retains the row and cancels it rather than physically deleting it", () => {
    const deleteHelper = dbSource.slice(dbSource.indexOf("export async function deleteConsultationRequest"));
    expect(deleteHelper).not.toContain("db.delete(consultationRequests)");
    expect(deleteHelper).toContain('status: "cancelled"');
    expect(deleteHelper).toContain("Retained request history and cancelled active request");
  });

  it("blocks retention-action rewrites for linked appointments and signed consent evidence", () => {
    const deleteHelper = dbSource.slice(dbSource.indexOf("export async function deleteConsultationRequest"));
    expect(deleteHelper).toContain("consentSignatureSessions.status, \"signed\"");
    expect(deleteHelper).toContain("Requests linked to appointments are retained as immutable clinic history.");
    expect(deleteHelper).toContain("Requests with signed consent evidence are retained as immutable clinic history.");
  });

  it("does not present the active request workspace as a permanent-deletion action", () => {
    expect(workspaceSource).toContain("Request retained and cancelled.");
    expect(workspaceSource).not.toContain("Delete permanently");
  });
});
