import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("original consent set persistence", () => {
  it("derives immutable consent metadata and separately stored signature evidence server-side", () => {
    const source = readFileSync(resolve(process.cwd(), "server/db.ts"), "utf8");

    expect(source).toContain("ORIGINAL_CONSENT_SET_REFERENCE");
    expect(source).toContain("ORIGINAL_CONSENT_DOCUMENTS");
    expect(source).toContain("originalConsentAcknowledgedAt: signature?.signedAt ?? new Date()");
    expect(source).toContain("informationAccuracyAcknowledgedAt: input.informationAccuracyAcknowledgement ? signature?.signedAt ?? new Date() : null");
    expect(source).toContain("originalConsentLanguage: input.language");
    expect(source).toContain('consentSignatureStatus: signature ? "received" : "required"');
    expect(source).toContain("consentSignatureReference: signature?.signatureReference ?? null");
    expect(source).toContain("consentSignatureEvidenceKey: signature?.signatureEvidenceKey ?? null");
  });
});
