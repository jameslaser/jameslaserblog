import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const dbSource = readFileSync(resolve(process.cwd(), "server/db.ts"), "utf8");
const portalSource = readFileSync(resolve(process.cwd(), "client/src/pages/AdminPortal.tsx"), "utf8");

describe("appointment list control rules", () => {
  it("queries only confirmed HMS rows for the selected Riyadh day and orders them by time", () => {
    const start = dbSource.indexOf("export async function listAppointmentsForDate(date: string)");
    const end = dbSource.indexOf("export async function listAppointmentsForDateRange", start);
    const section = dbSource.slice(start, end);
    expect(section).toContain('eq(appointments.appointmentDate, date)');
    expect(section).toContain('eq(appointments.source, "hms_csv")');
    expect(section).toContain("appointmentStatus = 'confirmed'");
    expect(section).toContain("asc(appointments.appointmentTime)");
  });

  it("defaults to today and provides explicit selected-date navigation", () => {
    const start = portalSource.indexOf("export function Appointments()");
    const end = portalSource.indexOf("function HmsWorkspace()", start);
    const section = portalSource.slice(start, end);
    expect(section).toContain("useState(riyadhToday)");
    expect(section).toContain("appointmentQueryInput");
    expect(section).toContain("date: selectedDate");
    expect(section).toContain("refetchInterval: 5_000");
    expect(section).toContain('appointment.source !== "hms_csv"');
    expect(section).toContain('appointment.status !== "confirmed"');
    for (const label of ["Appointment date", "Previous day", "Next day", "Today", "Tomorrow", "Patient name", "Time", "Confirmed", "Edit appointment"]) expect(section).toContain(label);
    expect(section).toContain("AppointmentEditPanel");
    expect(section).toContain("No appointments for selected date");
    expect(section).not.toContain("Status filter");
    expect(section).not.toContain("Seven-day appointment calendar");
    expect(section).not.toContain("Add appointment");
  });

  it("warns when a machine is missing or outside the four controlled values", () => {
    const start = portalSource.indexOf("export function Appointments()");
    const end = portalSource.indexOf("function HmsWorkspace()", start);
    const section = portalSource.slice(start, end);
    expect(section).toContain("machines.includes(appointment.machine as Machine)");
    expect(section).toContain("Machine review required");
    expect(section).toContain("Missing or incomplete controlled machine value");
    expect(section).toContain("machineReviewCount");
  });
});
