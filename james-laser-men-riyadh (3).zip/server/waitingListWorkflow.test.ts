import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const dbSource = readFileSync(new URL("./db.ts", import.meta.url), "utf8");
const routerSource = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
const portalSource = readFileSync(new URL("../client/src/pages/AdminPortal.tsx", import.meta.url), "utf8");

describe("waiting-list workflow", () => {
  it("retains today’s confirmed, waiting, arrived, no-show, completed, and cancelled appointments", () => {
    expect(dbSource).toContain('inArray(appointments.status, ["confirmed", "waiting", "arrived", "no-show", "completed", "cancelled"])');
    expect(routerSource).toContain('status: z.enum(["arrived", "no-show", "cancelled"])');
    expect(routerSource).toContain("finishSession: receptionProcedure.input(postSessionNotesInput)");
    expect(routerSource).toContain("confirmArrival: receptionProcedure.input(arrivalDetailsInput)");
    expect(routerSource).toContain("markWaiting: receptionProcedure.input(arrivalDetailsInput)");
    expect(dbSource).toContain('return recordWaitingListPatient(input, recordedBy, "waiting")');
  });

  it("requires a waiting patient to arrive before completion while preserving same-day controls", () => {
    expect(dbSource).toContain('status === "arrived" ? "waiting" : "confirmed"');
    expect(portalSource).toContain('status: "arrived"');
    expect(portalSource).toContain("Mark waiting");
    expect(portalSource).toContain("Mark arrived");
    expect(portalSource).toContain("Finish");
    expect(portalSource).toContain("PostSessionNotesPanel");
    expect(portalSource).toContain("Save notes & finish session");
    expect(portalSource).toContain("No show");
    expect(portalSource).toContain('status: "no-show"');
    expect(portalSource).toContain('status: "cancelled"');
  });

  it("validates and persists structured visit details without rewriting HMS source evidence", () => {
    expect(routerSource).toContain("treatmentAreas: multiTreatmentAreasInput");
    expect(routerSource).toContain("machine: machineInput");
    expect(routerSource).toContain("visitType: visitTypeInput");
    expect(dbSource).toContain("treatmentArea: input.treatmentAreas[0]");
    expect(dbSource).toContain("treatmentAreas: JSON.stringify(input.treatmentAreas)");
    expect(dbSource).toContain("machine: input.machine");
    expect(dbSource).toContain("visitType: input.visitType");
    expect(dbSource).toContain('const clinicOwnedAppointmentFields = appointment.source === "hms_csv" ? {}');
    expect(portalSource).toContain("appointmentAreaSummary(appointment)");
  });

  it("filters the protected queue by a validated selected date while retaining today-only attendance mutations", () => {
    expect(routerSource).toContain('waitingList: receptionProcedure.input(appointmentDateInput)');
    expect(dbSource).toContain('export async function listTodayWaitingList(date = riyadhDate())');
    expect(dbSource).toContain('eq(appointments.appointmentDate, date)');
    expect(portalSource).toContain('aria-label="Waiting list date"');
    expect(portalSource).toContain('const canUpdateAttendance = date === today;');
    expect(portalSource).toContain('Attendance controls are intentionally read-only for past or future dates.');
  });

  it("uses one guarded five-second fallback only for the active today queue", () => {
    expect(portalSource).toContain('refetchInterval: canUpdateAttendance ? 5000 : false');
    expect(portalSource).toContain('refetchIntervalInBackground: false');
    expect(portalSource).toContain('staleTime: 0');
    expect(portalSource).not.toContain('setInterval(');
    expect(portalSource).not.toContain('setTimeout(');
  });
});
