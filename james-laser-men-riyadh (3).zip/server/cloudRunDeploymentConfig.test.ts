import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const root = process.cwd();
const cloudBuild = readFileSync(resolve(root, "cloudbuild.yaml"), "utf8");
const dockerfile = readFileSync(resolve(root, "Dockerfile.cloudrun"), "utf8");

describe("Cloud Run deployment configuration", () => {
  it("preserves the existing external MySQL/TiDB database without attaching Cloud SQL", () => {
    expect(cloudBuild).toContain("_MYSQL_URL_SECRET: james-laser-mysql-url");
    expect(cloudBuild).toContain("MYSQL_URL=${_MYSQL_URL_SECRET}:latest");
    expect(cloudBuild).not.toContain("_CLOUDSQL_INSTANCE");
    expect(cloudBuild).not.toContain("--add-cloudsql-instances");
    expect(cloudBuild).not.toContain("DB_SOCKET_PATH");
  });

  it("references server credentials through Secret Manager without embedding values", () => {
    expect(cloudBuild).toContain("JWT_SECRET=${_JWT_SECRET}:latest");
    expect(cloudBuild).toContain("OWNER_OPEN_ID=${_OWNER_OPEN_ID_SECRET}:latest");
    expect(cloudBuild).toContain("BUILT_IN_FORGE_API_KEY=${_FORGE_API_KEY_SECRET}:latest");
    expect(cloudBuild).not.toMatch(/mysql:\/\/[^\s]+/);
    expect(cloudBuild).not.toMatch(/postgres(?:ql)?:\/\/[^\s]+/);
  });

  it("builds a locked multi-stage Node image and runs the production server without embedding server secrets", () => {
    expect(dockerfile).toContain("FROM node:22-slim AS build");
    expect(dockerfile).toContain("pnpm install --frozen-lockfile");
    expect(dockerfile).toContain("FROM node:22-slim AS runtime");
    expect(dockerfile).toContain("USER node");
    expect(dockerfile).toContain("PORT=8080");
    expect(dockerfile).not.toContain("DATABASE_URL=");
    expect(dockerfile).not.toContain("MYSQL_URL=");
    expect(dockerfile).not.toContain("JWT_SECRET=");
  });
});
