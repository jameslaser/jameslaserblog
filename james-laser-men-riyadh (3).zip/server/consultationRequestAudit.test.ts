import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const dbSource = readFileSync(resolve(process.cwd(), "server/db.ts"), "utf8");
const requestWorkspaceSource = readFileSync(resolve(process.cwd(), "client/src/pages/AdminRequestsWorkspace.tsx"), "utf8");

describe("public appointment request source auditability", () => {
  it("records a non-sensitive activity event tied only to the consultation request identifier", () => {
    expect(dbSource).toContain('action: "Created public appointment request"');
    expect(dbSource).toContain('subjectType: "consultation_request"');
    expect(dbSource).toContain("subjectId: id");
    expect(dbSource).not.toContain("actorName: input.fullName");
  });

  it("keeps the public source field private and exposes a safe label only in the protected request workspace", () => {
    expect(requestWorkspaceSource).toContain('source === "whatsapp_page_ar"');
    expect(requestWorkspaceSource).toContain('source === "whatsapp_page_en"');
    expect(requestWorkspaceSource).toContain("Request source");
    expect(requestWorkspaceSource).not.toContain("Public WhatsApp source dashboard");
  });
});
