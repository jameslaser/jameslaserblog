import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { COOKIE_NAME } from "@shared/const";
import { parse as parseCookie } from "cookie";
import { createHash, createHmac } from "node:crypto";
import {
  approveConsultationRequest,
  cancelConsultationRequest,
  confirmAppointmentArrival,
  createConsultationRequest,
  createManualAppointment,
  createManualPatient,
  exportHmsClinicRecordsCsv,
  createPublicAppointmentRequest,
  deleteConsultationRequest,
  findPublicAppointmentRequestBySubmissionId,
  getAdminDashboardStats,
  getAdminAttentionFindings,
  importHmsCsvAppointments,
  listTodayWaitingList,
  listAppointmentsForDate,
  listAppointmentsForDateRange,
  listConsultationRequests,
  listMachineInventory,
  listPublicMachineInventory,
  listStaffUsers,
  getPatientFile,
  listPatients,
  markAppointmentAttendance,
  markAppointmentWaiting,
  previewHmsCsvImport,
  recordAdminAttentionRun,
  recordManualWhatsAppLaunch,
  updateAppointmentDetails,
  updateConsultationRequestDetails,
  updateConsultationRequestWorkflow,
  listSessionRetouchReminders,
  updateMachineNumber,
  updatePatientFile,
  updateStaffRole,
} from "./db";
import { getRevenueBatch, getRevenueWorkspace, importRevenueCsv, previewRevenueCsvImport } from "./revenue";
import { cmsDashboardStats, deleteContentCalendarItem, deleteFaq, deleteGuidePost, deleteMediaItem, deletePolicy, deletePromotion, deleteResultCase, deleteReview, deleteTreatment, ensureClinicSettings, getGuidePostBySlug, getPublishedGuidePostBySlug, listContentCalendarItems, listFaqs, listGuidePosts, listHomepageSections, listMediaItems, listPolicies, listPromotions, listPublishedGuidePosts, listResultCases, listReviews, listSeoSettings, listSettingsChangeAudit, listTreatments, logCmsActivity, recentCmsActivity, registerMediaItem, saveContentCalendarItem, saveFaq, saveGuidePost, saveHomepageSection, savePolicy, savePromotion, saveResultCase, saveReview, saveSeoSettings, saveTreatment, setReviewStatus, updateClinicSettings, updateMediaItem } from "./cms";
import { blogDraftRequestSchema, generateBlogDraft, generateBlogEnrichment } from "./blogAi";
import { generatePromotionDraft, promotionDraftRequestSchema } from "./promotionAi";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, contentProcedure, ownerProcedure, protectedProcedure, publicProcedure, receptionProcedure, router } from "./_core/trpc";
import { createStaffNotification, listStaffNotifications, markAllStaffNotificationsRead, markStaffNotificationRead } from "./notifications";
import { storagePut } from "./storage";
import { createConsentSignatureSession, getConsentSignatureEvidenceDownload, getConsentSignatureSessionForStaff, getPublicConsentSignatureSession, revokeConsentSignatureSession, submitPublicConsentSignature } from "./consentSignature";
import { analyticsOverview, createEnquiry, deleteRedirect, exportRows, guardAppointmentRequestRate, guardPublicSubmission, listEnquiries, listRedirects, recordAnalyticsEvent, saveRedirect, updateEnquiry } from "./sharedBackend";
import { createTemplateGroundedSuggestion, createZeroCreditDraft, getAdminWebChatConversation, getPublicWebChatConversation, listAdminWebChatConversations, listSentWebChatMessages, listWebChatTemplates, markAdminWebChatRead, markAdminWebChatTyping, markVisitorWebChatRead, markVisitorWebChatTyping, saveWebChatTemplate, sendStaffWebChatMessage, sendVisitorWebChatMessage, setAdminWebChatStatus } from "./webChat";
import { assignWhatsAppConversation, getWhatsAppConversation, getWhatsAppLinkCandidates, getWhatsAppSettings, linkWhatsAppConversation, linkWhatsAppConversationForApprovedRequest, linkWhatsAppConversationForRequest, listWhatsAppAutomationLogs, listWhatsAppContacts, listWhatsAppConversations, listWhatsAppTemplates, listWhatsAppWebhookEvents, mapExactApprovedWhatsAppUtilityTemplates, markWhatsAppConversationRead, registerWhatsAppWebhook, sendWhatsAppFreeformMessage, sendWhatsAppTemplateMessage, setWhatsAppConversationStatus, submitMissingWhatsAppUtilityTemplates, syncWhatsAppTemplates } from "./whatsappService";
import { cancelWhatsAppAutomationJob, configureWhatsAppAutomationScheduler, getAppointmentWhatsAppAutomationStatus, listWhatsAppAutomationWorkspace, mapWhatsAppAutomationTemplate, queueWhatsAppAutomationJob, reconcileWhatsAppAutomation, recordConfirmedRetouchNotification, recordWhatsAppActivationPrerequisite, reviewWhatsAppRetouchRequest, setWhatsAppAutomationActivation, updateWhatsAppAutomationSettings, updateWhatsAppConsent } from "./whatsappAutomation";
import { createManualFollowUp, finishAppointmentWithPostSessionNotes, listEligibleSessionAppointments, listFollowUps, listSessionRecords, saveSessionRecord, trackLegacyAppointmentFollowUp, updateFollowUp } from "./sessionFollowUps";
import { beginGoogleBusinessAuthorization, getGoogleBusinessStatus, listGoogleBusinessLocations, recordGoogleBusinessSyncFailure, selectGoogleBusinessLocation, syncGoogleBusinessReviews } from "./googleBusiness";

const consultationRequestInput = z.object({
  fullName: z.string().trim().min(2, "Please enter your full name.").max(120),
  nationality: z.string().trim().min(2, "Please select your nationality.").max(80),
  whatsapp: z.string().trim().min(7, "Please enter a valid WhatsApp number.").max(32),
  email: z.string().trim().email("Please enter a valid email address.").max(320).optional(),
  treatmentArea: z.string().trim().min(2, "Please select a treatment area.").max(120),
  preferredContact: z.enum(["WhatsApp", "Phone", "Email"]),
  preferredDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Please select a preferred date."),
  preferredTime: z.string().trim().min(2, "Please select a preferred time.").max(160),
  firstTime: z.boolean(),
  lastLaserSession: z.string().trim().max(160).optional(),
  takingMedication: z.boolean(),
  medicationDetails: z.string().trim().max(500).optional(),
  tookVitaminD: z.boolean(),
  vitaminDLastTaken: z.string().trim().max(160).optional(),
  takingIron: z.boolean(),
  ironLastTaken: z.string().trim().max(160).optional(),
  tannedPastThreeMonths: z.boolean(),
  hadMoroccanBathLastSevenDays: z.boolean(),
  hadSkinTreatment: z.boolean(),
  skinTreatmentDetails: z.string().trim().max(500).optional(),
  hadSevereSunExposure: z.boolean(),
  notes: z.string().trim().max(2000).optional(),
  language: z.enum(["en", "ar"]).default("en"),
  consentRead: z.literal(true, { error: "Please read and acknowledge the consent form before continuing." }),
  privacyConsent: z.literal(true, { error: "Please confirm consent before sending your request." }),
  website: z.string().max(0).optional(),
}).superRefine((value, context) => {
  const requireDetail = (condition: boolean, valueToCheck: string | undefined, field: "lastLaserSession" | "medicationDetails" | "vitaminDLastTaken" | "ironLastTaken" | "skinTreatmentDetails", message: string) => {
    if (condition && !valueToCheck?.trim()) {
      context.addIssue({ code: "custom", path: [field], message });
    }
  };
  requireDetail(!value.firstTime, value.lastLaserSession, "lastLaserSession", "Please tell us when your last laser session was.");
  requireDetail(value.takingMedication, value.medicationDetails, "medicationDetails", "Please add the medication details.");
  requireDetail(value.tookVitaminD, value.vitaminDLastTaken, "vitaminDLastTaken", "Please tell us when you last took vitamin D.");
  requireDetail(value.takingIron, value.ironLastTaken, "ironLastTaken", "Please tell us when you last took iron.");
  requireDetail(value.hadSkinTreatment, value.skinTreatmentDetails, "skinTreatmentDetails", "Please describe the skin treatment.");
});

const requestIdInput = z.object({ requestId: z.number().int().positive() });
const requestStatusInput = z.object({ requestId: z.number().int().positive(), status: z.enum(["contacted", "clarification_requested", "rejected", "transferred", "completed", "cancelled"]), internalNotes: z.string().trim().max(12000).nullable().optional() });
const machineInput = z.enum(["DEKA AGAIN", "CLARITY 2", "GENTLE PROMAX", "DUETTO MACHINE"]);
const treatmentAreaInput = z.enum(["FACE", "Neck", "Ears", "Underarm", "Chest", "Abdomen", "Full Arms", "Back", "Shoulders", "Bikini", "Thighs", "Legs", "Feet", "Hands", "FULL BODY", "MINI FULL BODY"]);
const visitTypeInput = z.enum(["session", "retouch"]);
const appointmentDateInput = z.object({ date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/) });
const appointmentDateRangeInput = z.object({ startDate: appointmentDateInput.shape.date, endDate: appointmentDateInput.shape.date }).refine(value => value.startDate <= value.endDate, { message: "The appointment range must be chronological.", path: ["endDate"] });
const manualWhatsAppLaunchInput = z.object({ subjectType: z.enum(["patient", "appointment", "follow_up"]), subjectId: z.number().int().positive() });
const hmsPreviewInput = z.object({ csvText: z.string().min(1, "Select an HMS CSV file.").max(1_000_000), originalFileName: z.string().trim().min(1).max(255) });
const hmsImportInput = hmsPreviewInput.extend({ confirm: z.literal(true) });
const revenuePreviewInput = z.object({ csvText: z.string().min(1, "Select an HMS revenue CSV file.").max(1_000_000), originalFileName: z.string().trim().min(1).max(255) });
const revenueImportInput = revenuePreviewInput.extend({ confirm: z.literal(true), includeWarnings: z.boolean() });
const revenueFiltersInput = z.object({ dateFrom: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(), dateTo: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(), search: z.string().trim().max(160).optional(), mrn: z.string().trim().max(64).optional(), patientName: z.string().trim().max(180).optional(), serviceCode: z.string().trim().max(120).optional(), serviceName: z.string().trim().max(240).optional(), batchId: z.number().int().positive().optional() });
const revenueBatchInput = z.object({ batchId: z.number().int().positive() });
const manualTreatmentAreaInput = z.enum(["Face", "Ears", "Neck", "Underarm", "Chest", "Abdomen", "Arms", "Shoulders", "Bikini", "Thighs", "Legs", "Full back", "Buttocks", "Hands", "Feet"]);
const nullableText = (max: number) => z.string().trim().max(max).transform(value => value || null);
const manualPatientInput = z.object({ fullName: z.string().trim().min(2).max(120), mrn: nullableText(64), nationality: z.string().trim().min(2).max(80), contactNumber: z.string().trim().min(7).max(32), whatsapp: z.string().trim().min(7).max(32), email: z.string().trim().email().max(320).or(z.literal("")).transform(value => value || null), treatmentArea: manualTreatmentAreaInput, notes: nullableText(12000) });
const followUpFields = {
  nextFollowUpDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Choose a valid follow-up date.").nullable().optional(),
  nextFollowUpType: visitTypeInput.nullable().optional(),
};
const multiTreatmentAreasInput = z.array(manualTreatmentAreaInput).min(1, "Select at least one treatment area.").max(16).refine(areas => new Set(areas).size === areas.length, "Do not select the same treatment area twice.");
const manualAppointmentInput = manualPatientInput.omit({ treatmentArea: true }).extend({ appointmentDate: appointmentDateInput.shape.date, appointmentTime: z.string().trim().regex(/^([01]\d|2[0-3]):[0-5]\d$/, "Choose a time as HH:MM."), machine: machineInput, visitType: visitTypeInput, treatmentAreas: multiTreatmentAreasInput, ...followUpFields }).superRefine((value, context) => {
  const [hours, minutes] = value.appointmentTime.split(":").map(Number);
  if (minutes % 15 !== 0 || hours < 13 || hours > 22 || (hours === 22 && minutes > 0)) context.addIssue({ code: "custom", path: ["appointmentTime"], message: "Choose a 15-minute time between 1:00 PM and 10:00 PM." });
});
const patientFileUpdateInput = manualPatientInput.extend({ patientId: z.number().int().positive(), treatmentArea: z.string().trim().min(2).max(120) });
const appointmentDetailsUpdateInput = patientFileUpdateInput.omit({ patientId: true, treatmentArea: true }).extend({ appointmentId: z.number().int().positive(), appointmentDate: appointmentDateInput.shape.date, appointmentTime: z.string().trim().regex(/^([01]\d|2[0-3]):[0-5]\d$/, "Choose a time as HH:MM."), machine: machineInput, visitType: visitTypeInput, treatmentAreas: multiTreatmentAreasInput, ...followUpFields }).superRefine((value, context) => {
  const [hours, minutes] = value.appointmentTime.split(":").map(Number);
  if (minutes % 15 !== 0 || hours < 13 || hours > 22 || (hours === 22 && minutes > 0)) context.addIssue({ code: "custom", path: ["appointmentTime"], message: "Choose a 15-minute time between 1:00 PM and 10:00 PM." });
});
const requestDetailsUpdateInput = z.object({ requestId: z.number().int().positive(), fullName: z.string().trim().min(2).max(120), whatsapp: z.string().trim().min(7).max(32), nationality: z.string().trim().min(2).max(80), preferredDate: appointmentDateInput.shape.date, preferredTime: z.string().trim().max(160).nullable(), treatmentAreas: z.array(treatmentAreaInput).min(1).max(16), visitType: visitTypeInput, notes: z.string().trim().max(12000).nullable() });
const arrivalDetailsInput = z.object({
  appointmentId: z.number().int().positive(),
  fullName: z.string().trim().min(2).max(120),
  mrn: nullableText(64),
  nationality: z.string().trim().min(2).max(80),
  contactNumber: z.string().trim().min(7).max(32),
  whatsapp: z.string().trim().min(7).max(32),
  email: z.string().trim().email().max(320).or(z.literal("")).transform(value => value || null),
  treatmentAreas: multiTreatmentAreasInput,
  machine: machineInput,
  visitType: visitTypeInput,
  nurseNotes: z.string().trim().min(2, "Add the nurse’s notes before confirming arrival.").max(12000),
});
const attendanceInput = z.object({ appointmentId: z.number().int().positive(), status: z.enum(["arrived", "no-show", "cancelled"]) });
const postSessionNotesInput = z.object({
  appointmentId: z.number().int().positive(),
  nurseName: nullableText(120),
  outcome: z.string().trim().min(2, "Record the session outcome before finishing.").max(12000),
  notes: z.string().trim().min(2, "Add the nurse's notes before finishing.").max(12000),
});
const patientIdInput = z.object({ patientId: z.number().int().positive() });
const patientSearchInput = z.object({ query: z.string().trim().max(120).optional() });
const machineNumberInput = z.object({ name: machineInput, machineNumber: z.string().trim().min(2, "Please enter a machine ID.").max(64) });
const managedHomepageImageUrl = z.string().trim().regex(/^\/manus-storage\/[A-Za-z0-9._/-]+$/, "Use an image uploaded through the protected media library.").max(500).nullable().optional();
const clinicSettingsInput = z.object({
  businessName: z.string().trim().min(3).max(180).optional(), specialistName: z.string().trim().min(2).max(120).optional(), professionalTitle: z.string().trim().max(160).nullable().optional(), clinicName: z.string().trim().min(2).max(180).optional(),
  addressEn: z.string().trim().max(4000).nullable().optional(), addressAr: z.string().trim().max(4000).nullable().optional(), mapsUrl: z.string().trim().url().nullable().optional(), whatsapp: z.string().trim().min(8).max(32).optional(), telephone: z.string().trim().max(32).nullable().optional(), email: z.string().trim().email().nullable().optional(), workingHours: z.string().trim().min(3).max(160).optional(),
  instagramUrl: z.string().trim().url().nullable().optional(), tiktokUrl: z.string().trim().url().nullable().optional(), snapchatUrl: z.string().trim().url().nullable().optional(), facebookUrl: z.string().trim().url().nullable().optional(), youtubeUrl: z.string().trim().url().nullable().optional(), xUrl: z.string().trim().url().nullable().optional(), googleBusinessUrl: z.string().trim().url().nullable().optional(),
  appointmentFormEnabled: z.boolean().optional(), preferredTimes: z.string().max(4000).nullable().optional(), availableDays: z.string().max(4000).nullable().optional(), appointmentTreatmentOptions: z.string().max(8000).nullable().optional(), visitTypeOptions: z.string().max(4000).nullable().optional(), defaultLanguage: z.enum(["en", "ar"]).optional(), maintenanceMode: z.boolean().optional(),
  homepageTheme: z.enum(["signature", "graphite", "sage"]).optional(), homepageHeroImageUrl: managedHomepageImageUrl, homepageSpecialistImageUrl: managedHomepageImageUrl, homepageClinicImageUrl: managedHomepageImageUrl,
});
const settingsControlInput = z.object({
  availableDays: z.string().max(4000).nullable().optional(),
  preferredTimes: z.string().max(4000).nullable().optional(),
  appointmentTreatmentOptions: z.string().max(8000).nullable().optional(),
  visitTypeOptions: z.string().max(4000).nullable().optional(),
  defaultLanguage: z.enum(["en", "ar"]),
  maintenanceMode: z.boolean(),
  appointmentFormEnabled: z.boolean(),
});
const homepageSectionInput = z.object({
  sectionKey: z.string().trim().min(2).max(80), titleEn: z.string().max(12000).nullable().optional(), subtitleEn: z.string().max(12000).nullable().optional(), descriptionEn: z.string().max(12000).nullable().optional(), titleAr: z.string().max(12000).nullable().optional(), subtitleAr: z.string().max(12000).nullable().optional(), descriptionAr: z.string().max(12000).nullable().optional(),
  ctaText: z.string().max(120).nullable().optional(), ctaLink: z.string().max(500).nullable().optional(), imageUrl: z.string().max(500).nullable().optional(), videoUrl: z.string().max(500).nullable().optional(), isVisible: z.boolean().default(true), displayOrder: z.number().int().min(0).max(1000).default(0), status: z.enum(["draft", "published"]),
});
const pricingInput = z.string().trim().regex(/^\d+(\.\d{1,2})?$/).nullable().optional();
const treatmentInput = z.object({
  slug: z.string().trim().min(2).max(160), nameEn: z.string().trim().min(2).max(160), nameAr: z.string().trim().max(160).nullable().optional(), shortDescriptionEn: z.string().trim().max(12000).nullable().optional(), shortDescriptionAr: z.string().trim().max(12000).nullable().optional(), descriptionEn: z.string().trim().max(18000).nullable().optional(), descriptionAr: z.string().trim().max(18000).nullable().optional(), imageUrl: z.string().trim().max(500).nullable().optional(), startingPrice: pricingInput, regularPrice: pricingInput, promotionalPrice: pricingInput, durationMinutes: z.number().int().min(1).max(600).nullable().optional(), preparationEn: z.string().trim().max(12000).nullable().optional(), preparationAr: z.string().trim().max(12000).nullable().optional(), aftercareEn: z.string().trim().max(12000).nullable().optional(), aftercareAr: z.string().trim().max(12000).nullable().optional(), seoTitle: z.string().trim().max(180).nullable().optional(), seoDescription: z.string().trim().max(320).nullable().optional(), isActive: z.boolean().default(false), isFeatured: z.boolean().default(false), displayOrder: z.number().int().min(0).max(1000).default(0),
});
const promotionInput = z.object({
  slug: z.string().trim().min(2).max(160), name: z.string().trim().min(2).max(180), titleEn: z.string().trim().min(2).max(180), titleAr: z.string().trim().max(180).nullable().optional(), descriptionEn: z.string().trim().max(12000).nullable().optional(), descriptionAr: z.string().trim().max(12000).nullable().optional(), originalPrice: pricingInput, promotionalPrice: pricingInput, includedTreatments: z.string().trim().max(3000).nullable().optional(), sessionCount: z.number().int().min(1).max(100).nullable().optional(), retouchIncluded: z.boolean().default(false), startsAt: z.date().nullable().optional(), endsAt: z.date().nullable().optional(), imageUrl: z.string().trim().max(500).nullable().optional(), termsEn: z.string().trim().max(12000).nullable().optional(), termsAr: z.string().trim().max(12000).nullable().optional(), isFeatured: z.boolean().default(false), status: z.enum(["draft", "published", "paused", "archived"]), displayOrder: z.number().int().min(0).max(1000).default(0),
}).superRefine((value, context) => {
  if (value.startsAt && value.endsAt && value.endsAt <= value.startsAt) context.addIssue({ code: "custom", path: ["endsAt"], message: "Promotion end date must be after its start date." });
});
const cmsDeleteInput = z.object({ id: z.number().int().positive() });
const reviewInput = z.object({ displayName: z.string().trim().min(1).max(120), rating: z.number().int().min(1).max(5), reviewText: z.string().trim().min(4).max(12000), treatment: z.string().trim().max(160).nullable().optional(), language: z.enum(["en", "ar"]).default("en"), isAnonymous: z.boolean().default(false), isFeatured: z.boolean().default(false) });
const reviewStatusInput = cmsDeleteInput.extend({ status: z.enum(["pending", "approved", "rejected", "hidden"]) });
const googleBusinessLocationInput = z.object({ accountResourceName: z.string().trim().regex(/^accounts\/[^/]+$/).max(160), accountName: z.string().trim().min(1).max(240), locationResourceName: z.string().trim().regex(/^locations\/[^/]+$/).max(200), locationName: z.string().trim().min(1).max(240) });
const managedResultImageUrl = z.string().trim().max(500).regex(/^\/manus-storage\/cms-media\/\d+\/[A-Za-z0-9][A-Za-z0-9._-]*$/, "Use an image uploaded through the protected media library.");
const resultCaseImageUrl = z.union([managedResultImageUrl, z.string().trim().url().max(500)]);
const resultCaseInput = z.object({ title: z.string().trim().min(2).max(180), treatmentArea: z.string().trim().min(2).max(160), beforeImageUrl: resultCaseImageUrl, afterImageUrl: resultCaseImageUrl, additionalImages: z.string().trim().max(4000).nullable().optional(), sessionCount: z.number().int().min(1).max(100).nullable().optional(), descriptionEn: z.string().trim().max(12000).nullable().optional(), descriptionAr: z.string().trim().max(12000).nullable().optional(), disclaimerEn: z.string().trim().max(12000).nullable().optional(), disclaimerAr: z.string().trim().max(12000).nullable().optional(), consentConfirmed: z.literal(true), isFeatured: z.boolean().default(false), isActive: z.boolean().default(false), displayOrder: z.number().int().min(0).max(1000).default(0) });
const publicMediaUrl = z.string().trim().max(500).refine(value => value.startsWith("/manus-storage/") || /^https?:\/\//i.test(value), "Use a secure uploaded media path or an HTTP(S) URL.").nullable().optional();
const guidePostInput = z.object({
  id: z.number().int().positive().optional(), slug: z.string().trim().regex(/^[a-z0-9-]+$/i, "Use a safe public slug.").min(2).max(180), postType: z.enum(["blog", "video"]).default("blog"), titleEn: z.string().trim().min(2).max(220), titleAr: z.string().trim().max(220).nullable().optional(), summaryEn: z.string().trim().max(12000).nullable().optional(), summaryAr: z.string().trim().max(12000).nullable().optional(), contentEn: z.string().trim().max(30000).nullable().optional(), contentAr: z.string().trim().max(30000).nullable().optional(), category: z.string().trim().max(120).nullable().optional(), tags: z.string().trim().max(1000).nullable().optional(), featuredImageUrl: publicMediaUrl, videoUrl: z.string().trim().url().max(500).nullable().optional(), seoTitle: z.string().trim().max(180).nullable().optional(), metaDescription: z.string().trim().max(320).nullable().optional(), canonicalUrl: z.string().trim().url().max(500).nullable().optional(), socialImageUrl: publicMediaUrl,
  featuredImageAltEn: z.string().trim().max(320).nullable().optional(), featuredImageAltAr: z.string().trim().max(320).nullable().optional(), focusKeyword: z.string().trim().max(180).nullable().optional(), socialCaptionEn: z.string().trim().max(4000).nullable().optional(), socialCaptionAr: z.string().trim().max(4000).nullable().optional(), socialHashtags: z.string().trim().max(500).nullable().optional(), authorName: z.string().trim().max(120).nullable().optional(), aiGenerated: z.boolean().default(false), clinicalReviewConfirmed: z.boolean().default(false), status: z.enum(["draft", "published"]), isFeatured: z.boolean().default(false), publishedAt: z.coerce.date().nullable().optional(),
}).superRefine((value, context) => {
  if (value.status !== "published") return;
  const required: Array<[keyof typeof value, string]> = [["contentEn", "Add English article content before publishing."]];
  required.forEach(([field, message]) => { if (!String(value[field] ?? "").trim()) context.addIssue({ code: "custom", path: [field], message }); });
  if (!value.clinicalReviewConfirmed) context.addIssue({ code: "custom", path: ["clinicalReviewConfirmed"], message: "Confirm the clinical and factual review before publishing." });
});

const generatedMetadataFields = ["summaryEn", "tags", "seoTitle", "metaDescription", "focusKeyword", "socialCaptionEn", "socialHashtags"] as const;
function missingGeneratedMetadata(value: Record<string, unknown>) {
  return generatedMetadataFields.filter(field => !String(value[field] ?? "").trim());
}
const faqInput = z.object({ id: z.number().int().positive().optional(), questionEn: z.string().trim().min(2).max(500), answerEn: z.string().trim().min(2).max(12000), questionAr: z.string().trim().max(500).nullable().optional(), answerAr: z.string().trim().max(12000).nullable().optional(), category: z.string().trim().max(120).nullable().optional(), isFeatured: z.boolean().default(false), isActive: z.boolean().default(false), displayOrder: z.number().int().min(0).max(1000).default(0) });
const policyInput = z.object({ slug: z.string().trim().min(2).max(120), titleEn: z.string().trim().min(2).max(180), titleAr: z.string().trim().max(180).nullable().optional(), contentEn: z.string().trim().max(30000).nullable().optional(), contentAr: z.string().trim().max(30000).nullable().optional(), status: z.enum(["draft", "published"]), publishedAt: z.coerce.date().nullable().optional() });
const mediaInput = z.object({ fileName: z.string().trim().min(1).max(255), storageKey: z.string().trim().min(1).max(500), url: z.string().trim().url().max(500), mimeType: z.string().trim().min(1).max(120), altEn: z.string().trim().max(320).nullable().optional(), altAr: z.string().trim().max(320).nullable().optional() });
const mediaUpdateInput = z.object({ id: z.number().int().positive(), fileName: z.string().trim().min(1).max(255), altEn: z.string().trim().max(320).nullable().optional(), altAr: z.string().trim().max(320).nullable().optional() });
const mediaUploadInput = z.object({ fileName: z.string().trim().min(1).max(180), mimeType: z.enum(["image/jpeg", "image/png", "image/webp", "image/avif", "video/mp4", "video/webm"]), dataBase64: z.string().min(4).max(14_000_000), altEn: z.string().trim().max(320).nullable().optional(), altAr: z.string().trim().max(320).nullable().optional() });
const seoInput = z.object({ locale: z.enum(["en", "ar-SA"]), title: z.string().trim().min(2).max(180), metaDescription: z.string().trim().min(2).max(320), canonicalUrl: z.string().trim().url().max(500).nullable().optional(), openGraphTitle: z.string().trim().max(180).nullable().optional(), openGraphDescription: z.string().trim().max(320).nullable().optional(), openGraphImageUrl: z.string().trim().url().max(500).nullable().optional(), robotsIndex: z.boolean().default(true), structuredData: z.string().trim().max(30000).nullable().optional() });
const contentCalendarInput = z.object({
  id: z.number().int().positive().optional(), planKey: z.string().trim().regex(/^[a-z0-9-]+$/i, "Use a safe calendar key.").max(180), weekNumber: z.number().int().min(1).max(52), plannedFor: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), contentType: z.enum(["guide_article", "gbp_update", "social_repurpose", "seo_task", "content_update"]), topic: z.string().trim().min(3).max(240), language: z.enum(["en", "ar", "both"]), status: z.enum(["idea", "draft", "review", "scheduled", "published", "update_needed"]), targetPage: z.string().trim().max(500).nullable().optional(), searchIntent: z.string().trim().max(320).nullable().optional(), cta: z.string().trim().max(160).nullable().optional(), contentBrief: z.string().trim().max(12000).nullable().optional(), internalLinks: z.string().trim().max(3000).nullable().optional(), repurposingBrief: z.string().trim().max(6000).nullable().optional(), requiresOwnerAuthorization: z.boolean().default(false), externalPublication: z.boolean().default(false),
});
const staffRoleInput = z.object({ userId: z.number().int().positive(), role: z.enum(["admin", "content_editor", "reception", "user"]) });
const enquiryInput = z.object({ name: z.string().trim().min(2).max(120), mobile: z.string().trim().min(7).max(32), email: z.string().trim().email().max(320).nullable().optional(), subject: z.string().trim().min(2).max(180), message: z.string().trim().min(4).max(4000), language: z.enum(["en", "ar"]).default("en"), source: z.string().trim().min(2).max(120).default("website_contact_form"), website: z.string().max(0).optional() });
const enquiryUpdateInput = z.object({ id: z.number().int().positive(), status: z.enum(["new", "read", "replied", "archived"]).optional(), internalNotes: z.string().trim().max(12000).nullable().optional() }).refine(value => value.status !== undefined || value.internalNotes !== undefined, "Provide an enquiry status or internal note.");
const safeSlug = z.string().trim().regex(/^[a-z0-9-]+$/i, "Use a safe public slug.");
const analyticsEventInput = z.object({ eventType: z.enum(["page_view", "whatsapp_click", "appointment_click", "appointment_form_start", "appointment_form_submit", "treatment_view", "guide_view", "social_click"]), path: z.string().trim().startsWith("/").max(320).refine(path => !path.includes("?") && !path.includes("#"), "Analytics paths cannot include a query or fragment.").nullable().optional(), locale: z.enum(["en", "ar-SA"]).nullable().optional(), source: z.string().trim().regex(/^[a-z0-9.-]+$/i, "Use a hostname only.").max(180).nullable().optional(), deviceType: z.enum(["desktop", "mobile", "tablet", "unknown"]), treatmentSlug: safeSlug.max(160).nullable().optional(), contentSlug: safeSlug.max(180).nullable().optional() });
const redirectInput = z.object({ fromPath: z.string().trim().min(1).max(320), toPath: z.string().trim().min(1).max(320), isActive: z.boolean().default(true) });
const exportInput = z.object({ kind: z.enum(["appointment_requests", "treatments", "promotions", "reviews", "guide_posts", "enquiries"]) });
const adminSearchInput = z.object({ query: z.string().trim().min(2).max(120) });
const adminRequestFiltersInput = z.object({ status: z.enum(["pending", "contacted", "clarification_requested", "approved", "rejected", "transferred", "completed", "cancelled"]).optional(), query: z.string().trim().max(120).optional(), visitType: z.enum(["session", "retouch"]).optional(), language: z.enum(["en", "ar"]).optional(), dateFrom: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(), dateTo: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(), treatment: z.string().trim().max(160).optional() }).superRefine((value, context) => { if (value.dateFrom && value.dateTo && value.dateTo < value.dateFrom) context.addIssue({ code: "custom", path: ["dateTo"], message: "End date must be on or after start date." }); });
const notificationIdInput = z.object({ id: z.number().int().positive() });
const sessionRecordFiltersInput = z.object({ query: z.string().trim().max(120).optional(), status: z.enum(["draft", "completed", "cancelled"]).optional() });
const eligibleSessionAppointmentsInput = z.object({ query: z.string().trim().max(120).optional() });
const sessionRecordInput = z.object({
  id: z.number().int().positive().optional(),
  appointmentId: z.number().int().positive(),
  sessionDate: appointmentDateInput.shape.date,
  sessionTime: z.string().trim().regex(/^([01]\d|2[0-3]):[0-5]\d$/, "Enter time as HH:MM."),
  visitType: visitTypeInput,
  treatmentAreas: z.array(z.string().trim().min(1).max(120)).min(1, "Record at least one treatment area.").max(30),
  machine: machineInput,
  nurseName: nullableText(120),
  outcome: nullableText(12000),
  notes: nullableText(12000),
  status: z.enum(["draft", "completed", "cancelled"]),
  nextFollowUpDate: appointmentDateInput.shape.date.nullable().optional(),
  nextFollowUpType: visitTypeInput.nullable().optional(),
  followUpAssignedStaff: nullableText(120).optional(),
  followUpNotes: nullableText(12000).optional(),
}).superRefine((value, context) => {
  if (value.status === "completed" && !value.outcome) context.addIssue({ code: "custom", path: ["outcome"], message: "Record the session outcome before completion." });
  if (Boolean(value.nextFollowUpDate) !== Boolean(value.nextFollowUpType)) context.addIssue({ code: "custom", path: ["nextFollowUpDate"], message: "Choose both a follow-up date and type, or leave both blank." });
});
const manualFollowUpInput = z.object({ patientId: z.number().int().positive(), followUpType: visitTypeInput, dueDate: appointmentDateInput.shape.date, assignedStaff: nullableText(120), notes: nullableText(12000) });
const legacyFollowUpInput = z.object({ appointmentId: z.number().int().positive() });
const followUpUpdateInput = z.object({ id: z.number().int().positive(), followUpType: visitTypeInput, dueDate: appointmentDateInput.shape.date.nullable(), status: z.enum(["pending", "contacted", "completed", "cancelled"]), assignedStaff: nullableText(120), outcome: nullableText(12000), notes: nullableText(12000) }).superRefine((value, context) => {
  if (value.status === "completed" && !value.outcome) context.addIssue({ code: "custom", path: ["outcome"], message: "Record the follow-up outcome before completion." });
});
const whatsappConversationIdInput = z.object({ conversationId: z.number().int().positive() });
const whatsappConversationListInput = z.object({ status: z.enum(["open", "pending", "resolved", "archived"]).optional(), unreadOnly: z.boolean().optional(), assigned: z.enum(["me", "unassigned", "all"]).optional(), query: z.string().trim().max(120).optional() });
const whatsappStatusInput = whatsappConversationIdInput.extend({ status: z.enum(["open", "pending", "resolved", "archived"]) });
const whatsappAssignmentInput = whatsappConversationIdInput.extend({ assignedUserId: z.number().int().positive().nullable() });
const whatsappLinkInput = whatsappConversationIdInput.extend({ requestId: z.number().int().positive().nullable().optional(), patientId: z.number().int().positive().nullable().optional(), appointmentId: z.number().int().positive().nullable().optional() }).refine(value => value.requestId !== undefined || value.patientId !== undefined || value.appointmentId !== undefined, "Provide at least one link field to update.");
const whatsappTextInput = whatsappConversationIdInput.extend({ body: z.string().trim().min(1).max(4096), replyToMetaMessageId: z.string().trim().max(255).nullable().optional() });
const whatsappTemplateTextParameterInput = z.object({ type: z.literal("text"), text: z.string().trim().min(1).max(500) }).strict();
const whatsappTemplateComponentInput = z.object({ type: z.literal("body"), parameters: z.array(whatsappTemplateTextParameterInput).min(1).max(20) }).strict();
const whatsappTemplateSendInput = whatsappConversationIdInput.extend({ templateId: z.number().int().positive(), components: z.array(whatsappTemplateComponentInput).max(1).optional() });
const whatsappAutomationJobInput = z.object({ jobId: z.number().int().positive(), reason: z.string().trim().min(3, "Provide a staff reason.").max(500) });
const whatsappConsentUpdateInput = z.object({ appointmentId: z.number().int().positive(), status: z.enum(["opted_in", "opted_out"]), source: z.string().trim().min(3, "Record the consent source.").max(160), version: z.string().trim().max(120).nullable().optional() });
const whatsappTemplateMappingInput = z.object({ definitionId: z.number().int().positive(), providerTemplateName: z.string().trim().min(1).max(512), providerTemplateId: z.string().trim().max(128).nullable().optional() });
const whatsappRetouchReviewInput = z.object({ requestId: z.number().int().positive(), action: z.enum(["confirm", "suggest", "decline"]), machine: machineInput.optional(), date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(), time: z.string().regex(/^\d{2}:\d{2}$/).optional() });
const whatsappAutomationSettingsInput = z.object({
  reminderSendingTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/),
  retouchPreparationEn: z.string().trim().max(4000).nullable(),
  retouchPreparationAr: z.string().trim().max(4000).nullable(),
  appointmentConfirmationEnabled: z.boolean(),
  appointmentReminder24hEnabled: z.boolean(),
  appointmentFinalReminderEnabled: z.boolean(),
  appointmentRescheduleEnabled: z.boolean(),
  appointmentCancellationEnabled: z.boolean(),
  appointmentCompletionFollowUpEnabled: z.boolean(),
  appointmentNoShowFollowUpEnabled: z.boolean(),
  appointmentReminder24hHours: z.number().int().min(1).max(168),
  appointmentFinalReminderHours: z.number().int().min(1).max(48),
}).superRefine((value, context) => {
  if (value.appointmentFinalReminderHours >= value.appointmentReminder24hHours) context.addIssue({ code: "custom", path: ["appointmentFinalReminderHours"], message: "The final reminder must be scheduled closer to the appointment than the first reminder." });
});
const whatsappActivationPrerequisiteInput = z.object({
  prerequisiteKey: z.enum(["migration_applied", "meta_business_configuration_completed", "production_credentials_configured", "approved_templates_mapped", "webhook_configured", "webhook_verified", "test_number_configured", "controlled_test_message_completed", "appointment_confirmation_tested", "reminder_tested", "reschedule_tested", "cancellation_tested", "consent_tested", "owner_activation_approval_recorded"]),
  evidenceReference: z.string().trim().min(3, "Record a non-secret evidence reference.").max(500).refine(value => !/(access[_ -]?token|bearer\s+|app[_ -]?secret|password)/i.test(value), "Do not record a credential or secret as activation evidence."),
});
const whatsappAutomationActivationInput = z.object({ enable: z.boolean() });
const webChatSessionTokenInput = z.object({ sessionToken: z.string().uuid() });
const webChatPublicMessageInput = webChatSessionTokenInput.extend({ language: z.enum(["en", "ar"]), body: z.string().trim().min(1, "Write a message before sending.").max(1500, "Keep website chat messages under 1,500 characters."), website: z.string().max(0).optional() });
const webChatInboxInput = z.object({ status: z.enum(["open", "resolved", "archived"]).optional(), query: z.string().trim().max(120).optional(), language: z.enum(["en", "ar"]).optional(), unreadOnly: z.boolean().optional(), sort: z.enum(["newest", "oldest", "unread"]).default("newest") });
const webChatConversationIdInput = z.object({ conversationId: z.number().int().positive() });
const webChatStatusInput = webChatConversationIdInput.extend({ status: z.enum(["open", "resolved", "archived"]) });
const webChatStaffMessageInput = webChatConversationIdInput.extend({ body: z.string().trim().min(1, "Write a reply before sending.").max(1500), source: z.enum(["manual", "template", "ai_draft"]).default("manual") });
const webChatTemplateInput = z.object({ id: z.number().int().positive().optional(), label: z.string().trim().min(2).max(120), language: z.enum(["en", "ar"]), body: z.string().trim().min(2).max(1500), isActive: z.boolean() });
const webChatDraftInput = z.object({ visitorMessage: z.string().trim().min(1).max(1500), language: z.enum(["en", "ar"]) });
const hashSubmission = (formType: string, values: Array<string | undefined | null>) => createHash("sha256").update(`${formType}:${values.map(value => value?.trim().toLowerCase() ?? "").join("|")}`).digest("hex");
const secureFingerprint = (value: string) => createHmac("sha256", process.env.JWT_SECRET || "clinic-form-protection").update(value).digest("hex");
const trustedRequestFingerprint = (req: { headers?: Record<string, string | string[] | undefined>; socket?: { remoteAddress?: string | undefined } }) => {
  const forwarded = req.headers?.["x-forwarded-for"];
  const forwardedAddress = Array.isArray(forwarded) ? forwarded[0] : forwarded?.split(",")[0];
  const userAgent = req.headers?.["user-agent"];
  return secureFingerprint(`${forwardedAddress || req.socket?.remoteAddress || "unknown"}|${Array.isArray(userAgent) ? userAgent[0] : userAgent || "unknown"}`);
};
const normalizePublicText = (value: string) => value.normalize("NFKC").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "").replace(/\r\n/g, "\n").trim();
const riyadhDateString = () => new Intl.DateTimeFormat("sv-SE", { timeZone: "Asia/Riyadh", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
const appointmentTreatmentArea = z.enum(["Full Face", "Beard Lining", "Lower Beard Lining", "Neck", "Nape", "Ears", "External Nose", "Underarms", "Chest", "Abdomen", "Shoulders", "Full Back", "Arms", "Hands", "Bikini / Boxer", "Buttocks", "Thighs", "Legs", "Feet", "Mini Full Body", "Full Body"]);
const medicationTypeInput = z.enum(["Roaccutane / Isotretinoin", "Iron", "Vitamin D", "Other"]);
const recentExposureInput = z.enum(["tanning", "hammam", "skin_treatment"]);
const optionalDateInput = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable().optional();
const appointmentRequestInput = z.object({
  clientSubmissionId: z.string().uuid().default(() => crypto.randomUUID()), fullName: z.string().trim().min(2).max(120), whatsapp: z.string().trim().min(7).max(32), nationality: z.string().trim().min(2).max(80).nullable().optional(), preferredDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), preferredTime: z.string().regex(/^\d{2}:\d{2}$/), visitType: z.enum(["session", "retouch"]), treatmentAreas: z.array(appointmentTreatmentArea).min(1).max(21), previousLaser: z.boolean(), lastLaserSession: optionalDateInput, takingMedication: z.boolean().optional(), medicationTypes: z.array(medicationTypeInput).max(4).optional(), medicationDetails: z.string().trim().max(500).nullable().optional(), medicationLastTaken: optionalDateInput, medicationDosage: z.string().trim().max(160).nullable().optional(), recentExposures: z.array(recentExposureInput).max(3).optional(), recentExposureDate: optionalDateInput, hasSkinCondition: z.boolean().optional(), skinConditionDetails: z.string().trim().max(2000).nullable().optional(), notes: z.string().trim().max(2000).nullable().optional(), appointmentAcknowledgement: z.literal(true), informationAccuracyAcknowledgement: z.boolean().optional(), originalConsentAcknowledgement: z.literal(true, { error: "Read, acknowledge, and sign the original consent information before sending your request." }), privacyConsent: z.literal(true), healthScreeningConsent: z.literal(true).optional(), marketingConsent: z.boolean().default(false), signatureDataUrl: z.string().startsWith("data:image/png;base64,").max(700_000).optional(), language: z.enum(["en", "ar"]).default("en"), source: z.string().trim().min(2).max(120).default("appointment_page"), website: z.string().max(0).optional(),
}).superRefine((value, context) => {
  const mobileDigits = value.whatsapp.replace(/\D/g, "");
  if (mobileDigits.length < 8 || mobileDigits.length > 15) context.addIssue({ code: "custom", path: ["whatsapp"], message: value.language === "ar" ? "أدخل رقم جوال أو واتساب صحيحًا." : "Enter a valid mobile or WhatsApp number." });
  if (value.preferredDate < riyadhDateString()) context.addIssue({ code: "custom", path: ["preferredDate"], message: value.language === "ar" ? "اختر تاريخ اليوم أو تاريخًا مستقبليًا في الرياض." : "Choose today or a future date in Riyadh." });
  const [hours, minutes] = value.preferredTime.split(":").map(Number);
  if (minutes % 15 !== 0 || hours < 13 || hours > 22 || (hours === 22 && minutes > 0)) context.addIssue({ code: "custom", path: ["preferredTime"], message: value.language === "ar" ? "اختر وقتًا كل 15 دقيقة بين 1:00 ظهرًا و10:00 مساءً." : "Choose a 15-minute preference between 1:00 PM and 10:00 PM." });
  const fullAppointmentPage = value.source === "appointment_page_en" || value.source === "appointment_page_ar" || value.source === "appointment_page";
  const requireValue = (condition: boolean, valueToCheck: string | null | undefined, path: string, en: string, ar: string) => {
    if (condition && !valueToCheck?.trim()) context.addIssue({ code: "custom", path: [path], message: value.language === "ar" ? ar : en });
  };
  if (fullAppointmentPage && !value.healthScreeningConsent) context.addIssue({ code: "custom", path: ["healthScreeningConsent"], message: value.language === "ar" ? "أكد موافقتك الصريحة على مراجعة معلومات الفحص الصحي لهذا الطلب." : "Confirm your explicit acknowledgement for the clinic to review the health-screening information in this request." });
  requireValue(fullAppointmentPage, value.nationality, "nationality", "Enter your nationality.", "أدخل الجنسية.");
  requireValue(fullAppointmentPage && value.previousLaser, value.lastLaserSession, "lastLaserSession", "Tell us when your last laser session was.", "اذكر تاريخ آخر جلسة ليزر.");
  if (fullAppointmentPage && (value.takingMedication === undefined || value.hasSkinCondition === undefined || value.recentExposures === undefined)) context.addIssue({ code: "custom", path: ["takingMedication"], message: value.language === "ar" ? "أكمل أسئلة مراجعة العيادة." : "Complete the clinic review questions." });
  if (fullAppointmentPage && value.takingMedication && !value.medicationTypes?.length) context.addIssue({ code: "custom", path: ["medicationTypes"], message: value.language === "ar" ? "اختر الدواء أو المكمل ذي الصلة." : "Select the relevant medication or supplement." });
  requireValue(fullAppointmentPage && value.takingMedication === true, value.medicationLastTaken, "medicationLastTaken", "Tell us when it was last taken.", "اذكر متى تم تناوله آخر مرة.");
  requireValue(fullAppointmentPage && value.takingMedication === true, value.medicationDosage, "medicationDosage", "Enter the dosage or write unknown.", "اكتب الجرعة أو اكتب غير معروف.");
  requireValue(fullAppointmentPage && Boolean(value.medicationTypes?.includes("Other")), value.medicationDetails, "medicationDetails", "Specify the other medication or supplement.", "حدد الدواء أو المكمل الآخر.");
  requireValue(fullAppointmentPage && Boolean(value.recentExposures?.length), value.recentExposureDate, "recentExposureDate", "Tell us when the recent exposure or treatment occurred.", "اذكر تاريخ التعرض أو العلاج الأخير.");
  requireValue(fullAppointmentPage && value.hasSkinCondition === true, value.skinConditionDetails, "skinConditionDetails", "Describe the current skin condition for clinic review.", "صف حالة الجلد الحالية لمراجعة العيادة.");
  if (fullAppointmentPage && (!value.informationAccuracyAcknowledgement || !value.signatureDataUrl)) context.addIssue({ code: "custom", path: ["signatureDataUrl"], message: value.language === "ar" ? "أكمل الإقرار والتوقيع الإلكتروني." : "Complete the information acknowledgement and electronic signature." });
});
const signatureTokenInput = z.object({ token: z.string().trim().min(32).max(256) });
const staffSignatureSessionInput = z.object({ requestId: z.number().int().positive(), language: z.enum(["en", "ar"]) });
const signatureSubmitInput = signatureTokenInput.extend({ signerName: z.string().trim().min(2, "Please enter your full name.").max(120), signatureDataUrl: z.string().startsWith("data:image/png;base64,").max(700_000), acknowledgement: z.literal(true, { error: "Please confirm that you reviewed the original consent forms before signing." }) });
const appointmentTransferInput = requestIdInput.extend({
  fullName: z.string().trim().min(2).max(120),
  whatsapp: z.string().trim().min(7).max(32),
  nationality: z.string().trim().min(2).max(80),
  mrn: z.string().trim().min(2, "Please enter a manual MRN.").max(64),
  appointmentDate: appointmentDateInput.shape.date,
  appointmentTime: z.string().trim().regex(/^([01]\d|2[0-3]):[0-5]\d$/, "Enter time as HH:MM."),
  treatmentArea: treatmentAreaInput,
  treatmentAreas: z.array(treatmentAreaInput).min(1).max(16),
  machine: machineInput,
  visitType: visitTypeInput,
  finalizedNotes: z.string().trim().max(12000).nullable().optional(),
  assignedStaff: z.string().trim().max(120).nullable().optional(),
  durationMinutes: z.number().int().min(5).max(480).nullable().optional(),
}).superRefine((value, context) => {
  const minutes = Number(value.appointmentTime.split(":")[1]);
  if (minutes % 15 !== 0) context.addIssue({ code: "custom", path: ["appointmentTime"], message: "Use a 15-minute appointment time." });
  if (!value.treatmentAreas.includes(value.treatmentArea)) context.addIssue({ code: "custom", path: ["treatmentArea"], message: "Primary treatment area must be included in finalized treatment areas." });
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  consultationRequest: router({
    create: publicProcedure.input(consultationRequestInput).mutation(async ({ input, ctx }) => {
      const { website: _website, ...requestInput } = input;
      await guardPublicSubmission("consultation_request", hashSubmission("consultation_request", [requestInput.whatsapp, requestInput.treatmentArea, requestInput.preferredDate, requestInput.preferredTime]), trustedRequestFingerprint(ctx.req));
      const result = await createConsultationRequest({ ...requestInput, fullName: normalizePublicText(requestInput.fullName), whatsapp: normalizePublicText(requestInput.whatsapp), email: requestInput.email ? normalizePublicText(requestInput.email) : undefined, nationality: normalizePublicText(requestInput.nationality), notes: requestInput.notes ? normalizePublicText(requestInput.notes) : undefined, lastLaserSession: requestInput.lastLaserSession ? normalizePublicText(requestInput.lastLaserSession) : undefined, medicationDetails: requestInput.medicationDetails ? normalizePublicText(requestInput.medicationDetails) : undefined, vitaminDLastTaken: requestInput.vitaminDLastTaken ? normalizePublicText(requestInput.vitaminDLastTaken) : undefined, ironLastTaken: requestInput.ironLastTaken ? normalizePublicText(requestInput.ironLastTaken) : undefined, skinTreatmentDetails: requestInput.skinTreatmentDetails ? normalizePublicText(requestInput.skinTreatmentDetails) : undefined });
      await recordAnalyticsEvent({ eventType: "appointment_form_submit", path: "/", locale: "en", source: "website", deviceType: "unknown" });
      return { success: true as const, requestId: result.id };
    }),
  }),

  appointmentRequest: router({
    create: publicProcedure.input(appointmentRequestInput).mutation(async ({ input, ctx }) => {
      const { website: _website, ...request } = input;
      const existing = await findPublicAppointmentRequestBySubmissionId(request.clientSubmissionId);
      if (existing) return { success: true as const, requestId: existing.publicRequestId!, isPotentialDuplicate: existing.isPotentialDuplicate };
      const clinic = await ensureClinicSettings();
      if (!clinic.appointmentFormEnabled || clinic.maintenanceMode) throw new Error(request.language === "ar" ? "طلبات المواعيد متوقفة مؤقتًا. تواصل مع العيادة عبر واتساب." : "Appointment requests are temporarily paused. Please contact the clinic via WhatsApp.");
      const configuredTimes = clinic.preferredTimes?.split(",").map(value => value.trim()).filter(Boolean) ?? [];
      const configuredAreas = clinic.appointmentTreatmentOptions?.split(",").map(value => value.trim()).filter(Boolean) ?? [];
      const configuredVisitTypes = clinic.visitTypeOptions?.split(",").map(value => value.trim()) ?? [];
      const configuredDays = clinic.availableDays?.split(",").map(value => value.trim().toLocaleLowerCase()).filter(Boolean) ?? [];
      const weekday = new Intl.DateTimeFormat("en-US", { weekday: "long", timeZone: "Asia/Riyadh" }).format(new Date(`${request.preferredDate}T12:00:00+03:00`)).toLocaleLowerCase();
      if (configuredTimes.length && !configuredTimes.includes(request.preferredTime)) throw new Error(request.language === "ar" ? "الوقت المفضل غير متاح ضمن إعدادات العيادة." : "The preferred time is not enabled in clinic settings.");
      if (configuredAreas.length && request.treatmentAreas.some(area => !configuredAreas.includes(area))) throw new Error(request.language === "ar" ? "اختر منطقة علاج مفعلة من قبل العيادة." : "Choose a treatment area enabled by the clinic.");
      if (configuredVisitTypes.length && !configuredVisitTypes.includes(request.visitType)) throw new Error(request.language === "ar" ? "نوع الزيارة غير مفعل ضمن إعدادات العيادة." : "This visit type is not enabled in clinic settings.");
      if (configuredDays.length && !configuredDays.includes(weekday)) throw new Error(request.language === "ar" ? "اليوم المفضل غير مفعل ضمن إعدادات العيادة." : "The preferred day is not enabled in clinic settings.");
      await guardAppointmentRequestRate("consultation_request", trustedRequestFingerprint(ctx.req));
      const result = await createPublicAppointmentRequest({ ...request, fullName: normalizePublicText(request.fullName), whatsapp: normalizePublicText(request.whatsapp), nationality: request.nationality ? normalizePublicText(request.nationality) : null, medicationDetails: request.medicationDetails ? normalizePublicText(request.medicationDetails) : null, medicationDosage: request.medicationDosage ? normalizePublicText(request.medicationDosage) : null, skinConditionDetails: request.skinConditionDetails ? normalizePublicText(request.skinConditionDetails) : null, notes: request.notes ? normalizePublicText(request.notes) : null });
      if (!result.reused) {
        await linkWhatsAppConversationForRequest({ requestId: result.id, whatsapp: request.whatsapp }).catch(() => undefined);
        await createStaffNotification({ type: "appointment_request", title: "New appointment request", message: "A new website appointment request is ready for protected staff review.", linkPath: "/admin/requests" });
        await recordAnalyticsEvent({ eventType: "appointment_form_submit", path: "/appointment", locale: request.language === "ar" ? "ar-SA" : "en", source: "website", deviceType: "unknown" });
      }
      if (!result.publicRequestId) throw new Error("The request reference could not be created.");
      return { success: true as const, requestId: result.publicRequestId, isPotentialDuplicate: result.isPotentialDuplicate };
    }),
  }),

  consentSignature: router({
    getSession: publicProcedure.input(signatureTokenInput).mutation(({ input }) => getPublicConsentSignatureSession(input.token)),
    submit: publicProcedure.input(signatureSubmitInput).mutation(({ input }) => submitPublicConsentSignature(input)),
    staffGet: receptionProcedure.input(requestIdInput).query(({ input }) => getConsentSignatureSessionForStaff(input.requestId)),
    staffEvidence: receptionProcedure.input(requestIdInput).mutation(({ input }) => getConsentSignatureEvidenceDownload(input.requestId)),
    staffCreate: receptionProcedure.input(staffSignatureSessionInput).mutation(({ input, ctx }) => createConsentSignatureSession(input.requestId, ctx.user.id, input.language)),
    staffRevoke: receptionProcedure.input(requestIdInput).mutation(async ({ input, ctx }) => {
      await revokeConsentSignatureSession(input.requestId, ctx.user.id);
      return { success: true as const };
    }),
  }),

  enquiry: router({
    create: publicProcedure.input(enquiryInput).mutation(async ({ input, ctx }) => {
      await guardPublicSubmission("enquiry", hashSubmission("enquiry", [input.mobile, input.subject, input.message]), trustedRequestFingerprint(ctx.req));
      const result = await createEnquiry({ name: normalizePublicText(input.name), mobile: normalizePublicText(input.mobile), email: input.email ? normalizePublicText(input.email) : null, subject: normalizePublicText(input.subject), message: normalizePublicText(input.message), language: input.language, source: normalizePublicText(input.source), status: "new", internalNotes: null });
      await createStaffNotification({ type: "enquiry", title: "New website enquiry", message: "A new general enquiry is ready for protected staff review.", linkPath: "/admin/enquiries" });
      return { success: true as const, enquiryId: result.id };
    }),
  }),

  webChat: router({
    publicConversation: publicProcedure.input(webChatSessionTokenInput).query(({ input }) => getPublicWebChatConversation(input.sessionToken)),
    publicMarkRead: publicProcedure.input(webChatSessionTokenInput).mutation(async ({ input }) => { await markVisitorWebChatRead(input.sessionToken); return { success: true as const }; }),
    publicTyping: publicProcedure.input(webChatSessionTokenInput).mutation(async ({ input }) => { await markVisitorWebChatTyping(input.sessionToken); return { success: true as const }; }),
    sendVisitor: publicProcedure.input(webChatPublicMessageInput).mutation(async ({ input, ctx }) => {
      const { website: _website, ...message } = input;
      await guardPublicSubmission("web_chat", hashSubmission("web_chat", [message.sessionToken, message.body]), trustedRequestFingerprint(ctx.req));
      const result = await sendVisitorWebChatMessage({ ...message, body: normalizePublicText(message.body) });
      if (result.shouldNotifyStaff) {
        await createStaffNotification({ type: "enquiry", title: "New website chat", message: "A visitor has started a website chat. Review it in the protected web-chat inbox.", linkPath: "/admin/web-chat" });
      }
      return { success: true as const };
    }),
    adminInbox: receptionProcedure.input(webChatInboxInput).query(({ input }) => listAdminWebChatConversations(input)),
    adminConversation: receptionProcedure.input(webChatConversationIdInput).query(({ input }) => getAdminWebChatConversation(input.conversationId)),
    markRead: receptionProcedure.input(webChatConversationIdInput).mutation(async ({ input, ctx }) => {
      await markAdminWebChatRead(input.conversationId, { id: ctx.user.id, name: ctx.user.name ?? null });
      return { success: true as const };
    }),
    staffTyping: receptionProcedure.input(webChatConversationIdInput).mutation(async ({ input }) => { await markAdminWebChatTyping(input.conversationId); return { success: true as const }; }),
    setStatus: receptionProcedure.input(webChatStatusInput).mutation(async ({ input, ctx }) => {
      await setAdminWebChatStatus(input.conversationId, input.status, { id: ctx.user.id, name: ctx.user.name ?? null });
      return { success: true as const };
    }),
    send: receptionProcedure.input(webChatStaffMessageInput).mutation(({ input, ctx }) => sendStaffWebChatMessage(input, { id: ctx.user.id, name: ctx.user.name ?? null })),
    sent: receptionProcedure.query(() => listSentWebChatMessages()),
    templates: receptionProcedure.query(() => listWebChatTemplates()),
    saveTemplate: receptionProcedure.input(webChatTemplateInput).mutation((({ input, ctx }) => saveWebChatTemplate(input, { id: ctx.user.id, name: ctx.user.name ?? null }))),
    suggestTemplateReply: receptionProcedure.input(webChatConversationIdInput).mutation(({ input, ctx }) => createTemplateGroundedSuggestion(input.conversationId, { id: ctx.user.id, name: ctx.user.name ?? null })),
    createDraft: receptionProcedure.input(webChatDraftInput).mutation(({ input }) => ({ body: createZeroCreditDraft(input), source: "ai_draft" as const, zeroCredit: true as const, modelUsed: null })),
  }),

  analytics: router({
    record: publicProcedure.input(analyticsEventInput).mutation(async ({ input }) => { await recordAnalyticsEvent(input); return { success: true as const }; }),
  }),

  whatsapp: router({
    conversations: receptionProcedure.input(whatsappConversationListInput).query(({ input, ctx }) => listWhatsAppConversations({ ...input, userId: ctx.user.id })),
    conversation: receptionProcedure.input(whatsappConversationIdInput).query(({ input }) => getWhatsAppConversation(input.conversationId)),
    linkCandidates: receptionProcedure.input(whatsappConversationIdInput).query(({ input }) => getWhatsAppLinkCandidates(input.conversationId)),
    markRead: receptionProcedure.input(whatsappConversationIdInput).mutation(async ({ input, ctx }) => { await markWhatsAppConversationRead(input.conversationId, { id: ctx.user.id, name: ctx.user.name ?? null }); return { success: true as const }; }),
    setStatus: receptionProcedure.input(whatsappStatusInput).mutation(async ({ input, ctx }) => { await setWhatsAppConversationStatus(input.conversationId, input.status, { id: ctx.user.id, name: ctx.user.name ?? null }); return { success: true as const }; }),
    assign: adminProcedure.input(whatsappAssignmentInput).mutation(async ({ input, ctx }) => { await assignWhatsAppConversation(input.conversationId, input.assignedUserId, { id: ctx.user.id, name: ctx.user.name ?? null }); return { success: true as const }; }),
    link: receptionProcedure.input(whatsappLinkInput).mutation(async ({ input, ctx }) => { await linkWhatsAppConversation(input, { id: ctx.user.id, name: ctx.user.name ?? null }); return { success: true as const }; }),
    sendText: receptionProcedure.input(whatsappTextInput).mutation(({ input, ctx }) => sendWhatsAppFreeformMessage(input, { id: ctx.user.id, name: ctx.user.name ?? null })),
    sendTemplate: receptionProcedure.input(whatsappTemplateSendInput).mutation(({ input, ctx }) => sendWhatsAppTemplateMessage(input, { id: ctx.user.id, name: ctx.user.name ?? null })),
    contacts: receptionProcedure.input(z.object({ query: z.string().trim().max(120).optional() })).query(({ input }) => listWhatsAppContacts(input.query)),
    templates: receptionProcedure.query(() => listWhatsAppTemplates()),
    webhookEvents: receptionProcedure.query(() => listWhatsAppWebhookEvents()),
    automationLogs: receptionProcedure.query(() => listWhatsAppAutomationLogs()),
    syncTemplates: adminProcedure.mutation(({ ctx }) => syncWhatsAppTemplates({ id: ctx.user.id, name: ctx.user.name ?? null })),
    registerWebhook: ownerProcedure.mutation(({ ctx }) => registerWhatsAppWebhook({ id: ctx.user.id, name: ctx.user.name ?? null })),
    submitMissingUtilityTemplates: ownerProcedure.mutation(({ ctx }) => submitMissingWhatsAppUtilityTemplates({ id: ctx.user.id, name: ctx.user.name ?? null })),
    mapExactApprovedUtilityTemplates: ownerProcedure.mutation(({ ctx }) => mapExactApprovedWhatsAppUtilityTemplates({ id: ctx.user.id, name: ctx.user.name ?? null })),
    settings: adminProcedure.query(() => getWhatsAppSettings()),
    automationWorkspace: adminProcedure.query(() => listWhatsAppAutomationWorkspace()),
    reconcileAutomation: adminProcedure.mutation(async () => reconcileWhatsAppAutomation()),
    queueAutomationJob: adminProcedure.input(whatsappAutomationJobInput).mutation(async ({ input, ctx }) => {
      await queueWhatsAppAutomationJob(input.jobId, input.reason, { id: ctx.user.id, name: ctx.user.name ?? null });
      return { success: true as const };
    }),
    cancelAutomationJob: adminProcedure.input(whatsappAutomationJobInput).mutation(async ({ input, ctx }) => {
      await cancelWhatsAppAutomationJob(input.jobId, input.reason, { id: ctx.user.id, name: ctx.user.name ?? null });
      return { success: true as const };
    }),
    updateConsent: adminProcedure.input(whatsappConsentUpdateInput).mutation(async ({ input, ctx }) => {
      await updateWhatsAppConsent({ ...input, version: input.version ?? null }, { id: ctx.user.id, name: ctx.user.name ?? null });
      return { success: true as const };
    }),
    mapAutomationTemplate: adminProcedure.input(whatsappTemplateMappingInput).mutation(async ({ input, ctx }) => {
      await mapWhatsAppAutomationTemplate(input, { id: ctx.user.id, name: ctx.user.name ?? null });
      return { success: true as const };
    }),
    configureAutomationScheduler: ownerProcedure.mutation(async ({ ctx }) => {
      const session = parseCookie(ctx.req.headers.cookie ?? "")[COOKIE_NAME] ?? "";
      return configureWhatsAppAutomationScheduler(session, { id: ctx.user.id, name: ctx.user.name ?? null });
    }),
    updateAutomationSettings: adminProcedure.input(whatsappAutomationSettingsInput).mutation(async ({ input, ctx }) => {
      return updateWhatsAppAutomationSettings(input, { id: ctx.user.id, name: ctx.user.name ?? null });
    }),
    recordActivationPrerequisite: ownerProcedure.input(whatsappActivationPrerequisiteInput).mutation(async ({ input, ctx }) => {
      return recordWhatsAppActivationPrerequisite(input, { id: ctx.user.id, name: ctx.user.name ?? null });
    }),
    setAutomationActivation: ownerProcedure.input(whatsappAutomationActivationInput).mutation(async ({ input, ctx }) => {
      return setWhatsAppAutomationActivation(input, { id: ctx.user.id, name: ctx.user.name ?? null });
    }),
    reviewRetouchRequest: adminProcedure.input(whatsappRetouchReviewInput).mutation(async ({ input, ctx }) => {
      const result = await reviewWhatsAppRetouchRequest(input, { id: ctx.user.id, name: ctx.user.name ?? null });
      if (result.action === "confirmed") await recordConfirmedRetouchNotification(input.requestId);
      return result;
    }),
  }),

  publicContent: router({
    clinicSettings: publicProcedure.query(() => ensureClinicSettings()),
    machines: publicProcedure.query(() => listPublicMachineInventory()),
    homepageSections: publicProcedure.query(() => listHomepageSections(false)),
    policies: publicProcedure.query(() => listPolicies(false)),
    treatments: publicProcedure.query(() => listTreatments(false)),
    promotions: publicProcedure.query(() => listPromotions(false)),
    reviews: publicProcedure.query(() => listReviews(false)),
    resultCases: publicProcedure.query(() => listResultCases(false)),
    guidePosts: publicProcedure.query(() => listPublishedGuidePosts()),
    guidePostBySlug: publicProcedure.input(z.object({ slug: safeSlug.max(180) })).query(({ input }) => getPublishedGuidePostBySlug(input.slug)),
    faqs: publicProcedure.query(() => listFaqs(false)),
    seoSettings: publicProcedure.query(() => listSeoSettings()),
  }),

  cms: router({
    dashboard: adminProcedure.query(() => cmsDashboardStats()),
    recentActivity: adminProcedure.query(() => recentCmsActivity()),
    clinicSettings: contentProcedure.query(() => ensureClinicSettings()),
    updateClinicSettings: contentProcedure.input(clinicSettingsInput).mutation(({ input, ctx }) => updateClinicSettings(input, { id: ctx.user.id, name: ctx.user.name })),
    settingsControl: contentProcedure.query(() => ensureClinicSettings()),
    updateSettingsControl: contentProcedure.input(settingsControlInput).mutation(({ input, ctx }) => updateClinicSettings(input, { id: ctx.user.id, name: ctx.user.name })),
    settingsChangeAudit: adminProcedure.query(() => listSettingsChangeAudit()),
    homepageSections: contentProcedure.query(() => listHomepageSections(true)),
    saveHomepageSection: contentProcedure.input(homepageSectionInput).mutation(({ input, ctx }) => saveHomepageSection({ ...input, publishedAt: input.status === "published" ? new Date() : null }, { id: ctx.user.id, name: ctx.user.name })),
    treatments: contentProcedure.query(() => listTreatments(true)),
    saveTreatment: contentProcedure.input(treatmentInput).mutation(({ input, ctx }) => saveTreatment(input, { id: ctx.user.id, name: ctx.user.name })),
    deleteTreatment: contentProcedure.input(cmsDeleteInput).mutation(async ({ input, ctx }) => { await deleteTreatment(input.id, { id: ctx.user.id, name: ctx.user.name }); return { success: true as const }; }),
    promotions: contentProcedure.query(() => listPromotions(true)),
    savePromotion: contentProcedure.input(promotionInput).mutation(async ({ input, ctx }) => { const saved = await savePromotion({ ...input, publishedAt: input.status === "published" ? new Date() : null }, { id: ctx.user.id, name: ctx.user.name }); if (input.status === "published") await createStaffNotification({ type: "promotion", title: "Promotion published", message: "A clinic promotion was published to the public website.", linkPath: "/admin/promotions" }); return saved; }),
    generatePromotionDraft: contentProcedure.input(promotionDraftRequestSchema).mutation(({ input }) => generatePromotionDraft(input)),
    deletePromotion: contentProcedure.input(cmsDeleteInput).mutation(async ({ input, ctx }) => { await deletePromotion(input.id, { id: ctx.user.id, name: ctx.user.name }); return { success: true as const }; }),
    reviews: contentProcedure.query(() => listReviews(true)),
    saveReview: contentProcedure.input(reviewInput).mutation(async ({ input, ctx }) => { const id = await saveReview({ ...input, status: "pending" }, { id: ctx.user.id, name: ctx.user.name }); await createStaffNotification({ type: "review", title: "Review awaiting moderation", message: "A review was added and remains private until an authorized approval decision.", linkPath: "/admin/reviews" }); return id; }),
    setReviewStatus: adminProcedure.input(reviewStatusInput).mutation(async ({ input, ctx }) => { await setReviewStatus(input.id, input.status, { id: ctx.user.id, name: ctx.user.name }); return { success: true as const }; }),
    deleteReview: adminProcedure.input(cmsDeleteInput).mutation(async ({ input, ctx }) => { await deleteReview(input.id, { id: ctx.user.id, name: ctx.user.name }); return { success: true as const }; }),
    googleBusinessStatus: ownerProcedure.query(() => getGoogleBusinessStatus()),
    beginGoogleBusinessAuthorization: ownerProcedure.mutation(({ ctx }) => beginGoogleBusinessAuthorization({ id: ctx.user.id, name: ctx.user.name })),
    googleBusinessLocations: ownerProcedure.query(() => listGoogleBusinessLocations()),
    selectGoogleBusinessLocation: ownerProcedure.input(googleBusinessLocationInput).mutation(({ input }) => selectGoogleBusinessLocation(input)),
    syncGoogleBusinessReviews: ownerProcedure.mutation(async ({ ctx }) => {
      try {
        const result = await syncGoogleBusinessReviews();
        await logCmsActivity({ id: ctx.user.id, name: ctx.user.name }, "Synced Google Business reviews for moderation", "google_business_reviews");
        return result;
      } catch (error) {
        await recordGoogleBusinessSyncFailure();
        throw error;
      }
    }),
    resultCases: contentProcedure.query(() => listResultCases(true)),
    saveResultCase: contentProcedure.input(resultCaseInput).mutation(({ input, ctx }) => saveResultCase({ ...input, consentRecordedAt: new Date() }, { id: ctx.user.id, name: ctx.user.name })),
    deleteResultCase: contentProcedure.input(cmsDeleteInput).mutation(async ({ input, ctx }) => { await deleteResultCase(input.id, { id: ctx.user.id, name: ctx.user.name }); return { success: true as const }; }),
    guidePosts: contentProcedure.query(() => listGuidePosts(true)),
    generateGuideDraft: contentProcedure.input(blogDraftRequestSchema).mutation(async ({ input, ctx }) => {
      const draft = await generateBlogDraft(input);
      await logCmsActivity({ id: ctx.user.id, name: ctx.user.name }, "Generated private AI blog draft", "guide_post");
      return draft;
    }),
    saveGuidePost: contentProcedure.input(guidePostInput).mutation(async ({ input, ctx }) => {
      const { id, clinicalReviewConfirmed, ...submitted } = input;
      const existing = await getGuidePostBySlug(submitted.slug);
      if (!id && existing) throw new TRPCError({ code: "CONFLICT", message: "This URL slug already belongs to another article. Open that article to edit it or choose a new slug." });
      if (id && (!existing || existing.id !== id)) throw new TRPCError({ code: "CONFLICT", message: "The saved article no longer matches this editor. Reload the content library before saving." });
      const values = { ...submitted };
      const missingBefore = missingGeneratedMetadata(values);
      let automaticEnrichment: "generated" | "not_needed" | "existing_post" | "failed" = existing ? "existing_post" : "not_needed";

      if (!existing && missingBefore.length > 0) {
        try {
          const enrichment = await generateBlogEnrichment({
            titleEn: values.titleEn,
            titleAr: values.titleAr,
            summaryEn: values.summaryEn,
            summaryAr: values.summaryAr,
            contentEn: values.contentEn,
            contentAr: values.contentAr,
            category: values.category,
          });
          const hasArabicSource = Boolean(values.titleAr?.trim() || values.contentAr?.trim() || values.summaryAr?.trim());
          values.summaryEn ||= enrichment.summaryEn;
          if (hasArabicSource) values.summaryAr ||= enrichment.summaryAr;
          values.tags ||= enrichment.tags;
          values.seoTitle ||= enrichment.seoTitle;
          values.metaDescription ||= enrichment.metaDescription;
          values.focusKeyword ||= enrichment.focusKeyword;
          values.socialCaptionEn ||= enrichment.socialCaptionEn;
          if (hasArabicSource) values.socialCaptionAr ||= enrichment.socialCaptionAr;
          values.socialHashtags ||= enrichment.socialHashtags;
          values.aiGenerated = true;
          automaticEnrichment = "generated";
        } catch (error) {
          console.warn("[Blog AI] Automatic metadata enrichment was unavailable; the post will remain a private draft.", error instanceof Error ? error.message : "Unknown error");
          automaticEnrichment = "failed";
        }
      }

      values.canonicalUrl ||= `https://www.jameslaserformen.com/en/blog/${values.slug}`;
      const missingForPublication = ["summaryEn", "seoTitle", "metaDescription"].filter(field => !String(values[field as keyof typeof values] ?? "").trim());
      if (values.status === "published" && missingForPublication.length > 0) {
        if (automaticEnrichment === "failed") values.status = "draft";
        else throw new Error(`Complete the required publication metadata: ${missingForPublication.join(", ")}.`);
      }

      const saved = await saveGuidePost({
        ...values,
        clinicalReviewedAt: values.status === "published" && clinicalReviewConfirmed ? new Date() : null,
        clinicalReviewedByUserId: values.status === "published" && clinicalReviewConfirmed ? ctx.user.id : null,
      }, { id: ctx.user.id, name: ctx.user.name });
      if (automaticEnrichment === "generated") await logCmsActivity({ id: ctx.user.id, name: ctx.user.name }, "Automatically enriched new blog SEO metadata and excerpt with AI", "guide_post", saved.id);
      if (automaticEnrichment === "failed") await logCmsActivity({ id: ctx.user.id, name: ctx.user.name }, "Saved blog draft after automatic AI enrichment was unavailable", "guide_post", saved.id);
      return { ...saved, automaticEnrichment };
    }),
    deleteGuidePost: contentProcedure.input(cmsDeleteInput).mutation(async ({ input, ctx }) => { await deleteGuidePost(input.id, { id: ctx.user.id, name: ctx.user.name }); return { success: true as const }; }),
    faqs: contentProcedure.query(() => listFaqs(true)),
    saveFaq: contentProcedure.input(faqInput).mutation(async ({ input, ctx }) => { await saveFaq(input, { id: ctx.user.id, name: ctx.user.name }); return { success: true as const }; }),
    deleteFaq: contentProcedure.input(cmsDeleteInput).mutation(async ({ input, ctx }) => { await deleteFaq(input.id, { id: ctx.user.id, name: ctx.user.name }); return { success: true as const }; }),
    policies: contentProcedure.query(() => listPolicies(true)),
    savePolicy: contentProcedure.input(policyInput).mutation(({ input, ctx }) => savePolicy({ ...input, publishedAt: input.status === "published" ? (input.publishedAt ?? new Date()) : null }, { id: ctx.user.id, name: ctx.user.name })),
    deletePolicy: contentProcedure.input(cmsDeleteInput).mutation(async ({ input, ctx }) => { await deletePolicy(input.id, { id: ctx.user.id, name: ctx.user.name }); return { success: true as const }; }),
    mediaItems: contentProcedure.query(() => listMediaItems()),
    uploadMedia: contentProcedure.input(mediaUploadInput).mutation(async ({ input, ctx }) => {
      const bytes = Buffer.from(input.dataBase64, "base64");
      if (!bytes.length || bytes.length > 10_000_000) throw new Error("Media must be smaller than 10 MB.");
      const safeName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-");
      const stored = await storagePut(`cms-media/${ctx.user.id}/${safeName}`, bytes, input.mimeType);
      const id = await registerMediaItem({ fileName: input.fileName, storageKey: stored.key, url: stored.url, mimeType: input.mimeType, altEn: input.altEn ?? null, altAr: input.altAr ?? null }, { id: ctx.user.id, name: ctx.user.name });
      return { id, ...stored };
    }),
    registerMediaItem: contentProcedure.input(mediaInput).mutation(({ input, ctx }) => registerMediaItem(input, { id: ctx.user.id, name: ctx.user.name })),
    updateMediaItem: contentProcedure.input(mediaUpdateInput).mutation(async ({ input, ctx }) => { await updateMediaItem(input.id, input, { id: ctx.user.id, name: ctx.user.name }); return { success: true as const }; }),
    deleteMediaItem: contentProcedure.input(cmsDeleteInput).mutation(async ({ input, ctx }) => { await deleteMediaItem(input.id, { id: ctx.user.id, name: ctx.user.name }); return { success: true as const }; }),
    seoSettings: contentProcedure.query(() => listSeoSettings()),
    saveSeoSettings: contentProcedure.input(seoInput).mutation(async ({ input, ctx }) => { await saveSeoSettings(input, { id: ctx.user.id, name: ctx.user.name }); return { success: true as const }; }),
    contentCalendarItems: contentProcedure.query(() => listContentCalendarItems()),
    saveContentCalendarItem: contentProcedure.input(contentCalendarInput).mutation(({ input, ctx }) => saveContentCalendarItem({ ...input, requiresOwnerAuthorization: input.requiresOwnerAuthorization || input.externalPublication || input.contentType === "gbp_update", createdByUserId: input.id ? undefined : ctx.user.id }, { id: ctx.user.id, name: ctx.user.name })),
    deleteContentCalendarItem: contentProcedure.input(cmsDeleteInput).mutation(async ({ input, ctx }) => { await deleteContentCalendarItem(input.id, { id: ctx.user.id, name: ctx.user.name }); return { success: true as const }; }),
    staffUsers: ownerProcedure.query(() => listStaffUsers()),
    updateStaffRole: ownerProcedure.input(staffRoleInput).mutation(async ({ input, ctx }) => { await updateStaffRole(input.userId, input.role, { id: ctx.user.id, name: ctx.user.name }); return { success: true as const }; }),
  }),

  admin: router({
    globalSearch: protectedProcedure.input(adminSearchInput).query(async ({ input, ctx }) => {
      const query = input.query.toLocaleLowerCase();
      const matches = (...values: Array<unknown>) => values.some(value => String(value ?? "").toLocaleLowerCase().includes(query));
      const results: Array<{ id: string; type: "request" | "enquiry" | "treatment" | "promotion" | "guide" | "faq" | "review"; title: string; detail: string; path: string }> = [];
      const role = ctx.user.role;
      if (["owner", "admin", "reception"].includes(role)) {
        const requests = await listConsultationRequests();
        results.push(...requests.filter(request => matches(request.publicRequestId, request.id, request.fullName, request.whatsapp, request.treatmentArea, request.treatmentAreas)).slice(0, 8).map(request => ({ id: `request-${request.id}`, type: "request" as const, title: request.publicRequestId || `Request #${request.id}`, detail: `${request.fullName} · ${request.treatmentArea}`, path: "/admin/requests" })));
        const enquiries = await listEnquiries();
        results.push(...enquiries.filter(enquiry => matches(enquiry.subject, enquiry.name, enquiry.mobile, enquiry.message)).slice(0, 6).map(enquiry => ({ id: `enquiry-${enquiry.id}`, type: "enquiry" as const, title: enquiry.subject, detail: `${enquiry.name} · ${enquiry.status}`, path: "/admin/enquiries" })));
      }
      if (["owner", "admin", "content_editor"].includes(role)) {
        const [treatments, promotions, guides, faqs, reviews] = await Promise.all([listTreatments(true), listPromotions(true), listGuidePosts(true), listFaqs(true), listReviews(true)]);
        results.push(...treatments.filter(item => matches(item.nameEn, item.nameAr, item.slug)).slice(0, 5).map(item => ({ id: `treatment-${item.id}`, type: "treatment" as const, title: item.nameEn, detail: item.isActive ? "Active treatment" : "Draft treatment", path: "/admin/treatments" })));
        results.push(...promotions.filter(item => matches(item.titleEn, item.titleAr, item.name, item.slug)).slice(0, 5).map(item => ({ id: `promotion-${item.id}`, type: "promotion" as const, title: item.titleEn, detail: item.status, path: "/admin/promotions" })));
        results.push(...guides.filter(item => matches(item.titleEn, item.titleAr, item.category, item.tags, item.slug)).slice(0, 5).map(item => ({ id: `guide-${item.id}`, type: "guide" as const, title: item.titleEn, detail: item.status, path: "/admin/guide" })));
        results.push(...faqs.filter(item => matches(item.questionEn, item.questionAr, item.category)).slice(0, 5).map(item => ({ id: `faq-${item.id}`, type: "faq" as const, title: item.questionEn, detail: item.category || "FAQ", path: "/admin/faqs" })));
        results.push(...reviews.filter(item => matches(item.displayName, item.treatment, item.reviewText)).slice(0, 5).map(item => ({ id: `review-${item.id}`, type: "review" as const, title: item.displayName, detail: item.status, path: "/admin/reviews" })));
      }
      return results.slice(0, 20);
    }),
    dashboard: receptionProcedure.query(() => getAdminDashboardStats()),
    attention: adminProcedure.query(() => getAdminAttentionFindings()),
    notifyAttention: adminProcedure.mutation(async ({ ctx }) => {
      const result = await getAdminAttentionFindings();
      await recordAdminAttentionRun(ctx.user.name ?? null);
      const actionable = result.findings.filter(finding => finding.severity === "urgent" || finding.severity === "attention");
      const existing = await listStaffNotifications();
      const alreadyNotified = existing.some(notification => !notification.isRead && notification.type === "system" && notification.linkPath === "/admin/attention");
      if (actionable.length > 0 && !alreadyNotified) {
        await createStaffNotification({ type: "system", title: "Admin attention review needed", message: "Protected clinic workflow checks found items that require an authorized staff review.", linkPath: "/admin/attention" });
      }
      return { ...result, notificationCreated: actionable.length > 0 && !alreadyNotified };
    }),
    requests: receptionProcedure.input(adminRequestFiltersInput).query(({ input }) => listConsultationRequests(input)),
    approveRequest: receptionProcedure.input(appointmentTransferInput).mutation(async ({ input, ctx }) => {
      const result = await approveConsultationRequest(input.requestId, {
        fullName: input.fullName,
        whatsapp: input.whatsapp,
        nationality: input.nationality,
        mrn: input.mrn,
        appointmentDate: input.appointmentDate,
        appointmentTime: input.appointmentTime,
        treatmentArea: input.treatmentArea,
        treatmentAreas: input.treatmentAreas,
        machine: input.machine,
        visitType: input.visitType,
        finalizedNotes: input.finalizedNotes ?? null,
        assignedStaff: input.assignedStaff ?? null,
        durationMinutes: input.durationMinutes ?? null,
      }, ctx.user.name ?? null);
      await linkWhatsAppConversationForApprovedRequest({ requestId: input.requestId, patientId: result.patientId, appointmentId: result.appointmentId, whatsapp: input.whatsapp }).catch(() => undefined);
      await reconcileWhatsAppAutomation().catch(() => undefined);
      return { success: true as const, appointmentId: result.appointmentId, patientId: result.patientId, existingPatientFound: result.existingPatientFound, matchedBy: result.matchedBy };
    }),
    cancelRequest: receptionProcedure.input(requestIdInput).mutation(async ({ input, ctx }) => {
      await cancelConsultationRequest(input.requestId, ctx.user.name ?? null);
      return { success: true as const };
    }),
    updateRequestDetails: receptionProcedure.input(requestDetailsUpdateInput).mutation(async ({ input, ctx }) => {
      await updateConsultationRequestDetails(input, ctx.user.name ?? null);
      return { success: true as const };
    }),
    updateRequestStatus: receptionProcedure.input(requestStatusInput).mutation(async ({ input, ctx }) => {
      await updateConsultationRequestWorkflow(input.requestId, input.status, ctx.user.name ?? null, input.internalNotes);
      return { success: true as const };
    }),
    deleteRequest: receptionProcedure.input(requestIdInput).mutation(async ({ input, ctx }) => {
      await deleteConsultationRequest(input.requestId, ctx.user.name ?? null);
      return { success: true };
    }),
    appointments: receptionProcedure.input(appointmentDateInput).query(({ input }) => listAppointmentsForDate(input.date)),
    appointmentsRange: receptionProcedure.input(appointmentDateRangeInput).query(({ input }) => listAppointmentsForDateRange(input.startDate, input.endDate)),
    reminders: adminProcedure.query(() => listSessionRetouchReminders()),
    sessionRecords: adminProcedure.input(sessionRecordFiltersInput).query(({ input }) => listSessionRecords(input)),
    eligibleSessionAppointments: adminProcedure.input(eligibleSessionAppointmentsInput).query(({ input }) => listEligibleSessionAppointments(input.query)),
    saveSessionRecord: adminProcedure.input(sessionRecordInput).mutation(({ input, ctx }) => saveSessionRecord(input, { id: ctx.user.id, name: ctx.user.name ?? null })),
    followUps: adminProcedure.query(() => listFollowUps()),
    createManualFollowUp: adminProcedure.input(manualFollowUpInput).mutation(({ input, ctx }) => createManualFollowUp(input, { id: ctx.user.id, name: ctx.user.name ?? null })),
    trackLegacyFollowUp: adminProcedure.input(legacyFollowUpInput).mutation(({ input, ctx }) => trackLegacyAppointmentFollowUp(input.appointmentId, { id: ctx.user.id, name: ctx.user.name ?? null })),
    updateFollowUp: adminProcedure.input(followUpUpdateInput).mutation(({ input, ctx }) => updateFollowUp(input, { id: ctx.user.id, name: ctx.user.name ?? null })),
    createManualPatient: adminProcedure.input(manualPatientInput).mutation(async ({ input, ctx }) => {
      const result = await createManualPatient(input, ctx.user.name ?? null);
      return { success: true as const, ...result };
    }),
    createManualAppointment: adminProcedure.input(manualAppointmentInput).mutation(async ({ input, ctx }) => {
      const result = await createManualAppointment(input, ctx.user.name ?? null);
      await reconcileWhatsAppAutomation().catch(() => undefined);
      return { success: true as const, ...result };
    }),
    updatePatientFile: adminProcedure.input(patientFileUpdateInput).mutation(async ({ input, ctx }) => {
      await updatePatientFile(input, ctx.user.name ?? null);
      return { success: true as const };
    }),
    updateAppointmentDetails: adminProcedure.input(appointmentDetailsUpdateInput).mutation(async ({ input, ctx }) => {
      await updateAppointmentDetails(input, ctx.user.name ?? null);
      await reconcileWhatsAppAutomation().catch(() => undefined);
      return { success: true as const };
    }),
    recordManualWhatsAppLaunch: adminProcedure.input(manualWhatsAppLaunchInput).mutation(async ({ input, ctx }) => {
      await recordManualWhatsAppLaunch(input, { id: ctx.user.id, name: ctx.user.name ?? null });
      return { success: true as const };
    }),
    appointmentWhatsAppStatus: adminProcedure.input(z.object({ appointmentId: z.number().int().positive() })).query(({ input }) => getAppointmentWhatsAppAutomationStatus(input.appointmentId)),
    hmsPreview: adminProcedure.input(hmsPreviewInput).mutation(({ input }) => previewHmsCsvImport(input.csvText)),
    hmsImport: adminProcedure.input(hmsImportInput).mutation(async ({ input, ctx }) => {
      const result = await importHmsCsvAppointments({ ...input, importedByUserId: ctx.user.id, importedByName: ctx.user.name ?? null });
      return { success: true as const, ...result };
    }),
    hmsExportCsv: adminProcedure.query(() => exportHmsClinicRecordsCsv()),
    revenuePreview: adminProcedure.input(revenuePreviewInput).mutation(({ input }) => previewRevenueCsvImport(input.csvText)),
    revenueImport: adminProcedure.input(revenueImportInput).mutation(async ({ input, ctx }) => { const result = await importRevenueCsv({ ...input, importedByUserId: ctx.user.id, importedByName: ctx.user.name ?? null }); return { success: true as const, ...result }; }),
    revenueWorkspace: adminProcedure.input(revenueFiltersInput).query(({ input }) => getRevenueWorkspace(input)),
    revenueBatch: adminProcedure.input(revenueBatchInput).query(({ input }) => getRevenueBatch(input.batchId)),
    waitingList: receptionProcedure.input(appointmentDateInput).query(({ input }) => listTodayWaitingList(input.date)),
    confirmArrival: receptionProcedure.input(arrivalDetailsInput).mutation(async ({ input, ctx }) => {
      const result = await confirmAppointmentArrival(input, ctx.user.name ?? null);
      await reconcileWhatsAppAutomation().catch(() => undefined);
      return { success: true as const, ...result };
    }),
    markWaiting: receptionProcedure.input(arrivalDetailsInput).mutation(async ({ input, ctx }) => {
      const result = await markAppointmentWaiting(input, ctx.user.name ?? null);
      await reconcileWhatsAppAutomation().catch(() => undefined);
      return { success: true as const, ...result };
    }),
    finishSession: receptionProcedure.input(postSessionNotesInput).mutation(async ({ input, ctx }) => {
      const result = await finishAppointmentWithPostSessionNotes(input, { id: ctx.user.id, name: ctx.user.name ?? null });
      await reconcileWhatsAppAutomation().catch(() => undefined);
      return { success: true as const, ...result };
    }),
    markAttendance: receptionProcedure.input(attendanceInput).mutation(async ({ input }) => {
      await markAppointmentAttendance(input.appointmentId, input.status);
      await reconcileWhatsAppAutomation().catch(() => undefined);
      return { success: true as const };
    }),
    patients: receptionProcedure.input(patientSearchInput).query(({ input }) => listPatients(input.query)),
    patientFile: receptionProcedure.input(patientIdInput).query(({ input }) => getPatientFile(input.patientId)),
    machines: receptionProcedure.query(() => listMachineInventory()),
    updateMachineNumber: adminProcedure.input(machineNumberInput).mutation(async ({ input }) => {
      await updateMachineNumber(input.name, input.machineNumber);
      return { success: true as const };
    }),
    enquiries: receptionProcedure.query(() => listEnquiries()),
    updateEnquiry: receptionProcedure.input(enquiryUpdateInput).mutation(async ({ input, ctx }) => { await updateEnquiry(input.id, { status: input.status, internalNotes: input.internalNotes }, { id: ctx.user.id, name: ctx.user.name }); return { success: true as const }; }),
    analytics: adminProcedure.query(() => analyticsOverview()),
    dataExport: adminProcedure.input(exportInput).query(({ input }) => exportRows(input.kind)),
    redirects: adminProcedure.query(() => listRedirects()),
    saveRedirect: adminProcedure.input(redirectInput).mutation(({ input, ctx }) => saveRedirect(input, { id: ctx.user.id, name: ctx.user.name })),
    deleteRedirect: adminProcedure.input(cmsDeleteInput).mutation(async ({ input, ctx }) => { await deleteRedirect(input.id, { id: ctx.user.id, name: ctx.user.name }); return { success: true as const }; }),
    notifications: receptionProcedure.query(() => listStaffNotifications()),
    markNotificationRead: receptionProcedure.input(notificationIdInput).mutation(async ({ input }) => { await markStaffNotificationRead(input.id); return { success: true as const }; }),
    markAllNotificationsRead: receptionProcedure.mutation(async () => { await markAllStaffNotificationsRead(); return { success: true as const }; }),
  }),
});

export type AppRouter = typeof appRouter;
