import { describe, expect, it } from "vitest";
import { resolveSinglePatientFile } from "./patientIdentity";

describe("patient identity resolution", () => {
  it("uses either matching mobile or MRN as the single patient-file basis", () => {
    expect(resolveSinglePatientFile({ mobilePatientId: 7, mrnPatientId: null })).toBe(7);
    expect(resolveSinglePatientFile({ mobilePatientId: null, mrnPatientId: 9 })).toBe(9);
    expect(resolveSinglePatientFile({ mobilePatientId: 11, mrnPatientId: 11 })).toBe(11);
  });

  it("returns no patient for a new MRN and new phone, allowing one new file", () => {
    expect(resolveSinglePatientFile({ mobilePatientId: null, mrnPatientId: null })).toBeNull();
  });

  it("reuses the matching MRN when the incoming phone is new", () => {
    expect(resolveSinglePatientFile({ mobilePatientId: null, mrnPatientId: 21 })).toBe(21);
  });

  it("reuses the matching phone when the incoming MRN is new", () => {
    expect(resolveSinglePatientFile({ mobilePatientId: 22, mrnPatientId: null })).toBe(22);
  });

  it("keeps an already-linked appointment attached to the same patient file", () => {
    expect(resolveSinglePatientFile({ mobilePatientId: 23, mrnPatientId: 23, linkedPatientId: 23 })).toBe(23);
  });

  it("blocks divergent MRN/mobile identity and attempts to relink an existing appointment", () => {
    expect(() => resolveSinglePatientFile({ mobilePatientId: 7, mrnPatientId: 9 })).toThrow("different patient files");
    expect(() => resolveSinglePatientFile({ mobilePatientId: 7, mrnPatientId: null, linkedPatientId: 9 })).toThrow("already linked");
  });
});
