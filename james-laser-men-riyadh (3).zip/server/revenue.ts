import { and, asc, desc, eq, gte, inArray, like, lte, or } from "drizzle-orm";
import {
  activityLogs,
  patients,
  revenueImportBatches,
  revenueTransactions,
} from "../drizzle/schema";
import { getDb } from "./db";
import {
  markRevenueDuplicates,
  parseRevenueCsv,
  revenueTotals,
  revenueTotalsMatch,
  type RevenueMoney,
  type RevenueParsedReport,
  type RevenueServiceRow,
} from "./revenueCsv";

const database = async () => {
  const db = await getDb();
  if (!db) throw new Error("The Revenue service is temporarily unavailable.");
  return db;
};
const money = (value: number) => value.toFixed(2);
const quantity = (value: number) => value.toFixed(3);
const emptyMoney = (): RevenueMoney => ({
  gross: 0,
  quantity: 0,
  discount: 0,
  deduct: 0,
  net: 0,
});
const addMoney = (left: RevenueMoney, right: RevenueMoney): RevenueMoney => ({
  gross: left.gross + right.gross,
  quantity: left.quantity + right.quantity,
  discount: left.discount + right.discount,
  deduct: left.deduct + right.deduct,
  net: left.net + right.net,
});
const toNumber = (value: unknown) => Number(value ?? 0);

function groupRows(rows: RevenueServiceRow[]) {
  return Array.from(
    rows
      .reduce((groups, row) => {
        const key = `${row.mrn ?? "unmatched"}\u001f${row.patientName}`;
        const group = groups.get(key) ?? {
          mrn: row.mrn,
          patientName: row.patientName,
          matchedPatientId: null as number | null,
          rows: [] as RevenueServiceRow[],
          totals: emptyMoney(),
        };
        group.rows.push(row);
        group.totals = revenueTotals(group.rows);
        groups.set(key, group);
        return groups;
      }, new Map<string, { mrn: string | null; patientName: string; matchedPatientId: number | null; rows: RevenueServiceRow[]; totals: RevenueMoney }>())
      .values()
  );
}

async function matchPatients(rows: RevenueServiceRow[]) {
  const db = await database();
  const mrns = Array.from(
    new Set(
      rows
        .map(row => row.mrn)
        .filter((value): value is string => Boolean(value))
    )
  );
  if (!mrns.length) return new Map<string, number>();
  const matches = await db
    .select({ id: patients.id, mrn: patients.mrn })
    .from(patients)
    .where(inArray(patients.mrn, mrns));
  return new Map(
    matches.filter(item => item.mrn).map(item => [item.mrn!, item.id])
  );
}

export type RevenuePreview = RevenueParsedReport & {
  fileAlreadyImported: boolean;
  batchId: number | null;
  rows: RevenueServiceRow[];
  patients: ReturnType<typeof groupRows>;
  summary: RevenueMoney & {
    patients: number;
    serviceRows: number;
    invalidRows: number;
    duplicateRows: number;
    warnings: number;
    unmatchedPatients: number;
    reconciliation: "PASS" | "FAIL";
  };
};

export async function previewRevenueCsvImport(
  csvText: string
): Promise<RevenuePreview> {
  const parsed = parseRevenueCsv(csvText);
  const db = await database();
  const [existingBatch, existingRows] = await Promise.all([
    db
      .select({ id: revenueImportBatches.id })
      .from(revenueImportBatches)
      .where(eq(revenueImportBatches.fileSha256, parsed.fileSha256))
      .limit(1),
    db
      .select({ sourceFingerprint: revenueTransactions.sourceFingerprint })
      .from(revenueTransactions),
  ]);
  const rows = markRevenueDuplicates(
    parsed.rows,
    new Set(existingRows.map(row => row.sourceFingerprint)),
    Boolean(existingBatch[0])
  );
  const patientMatches = await matchPatients(rows);
  const patientsGroups = groupRows(rows).map(group => ({
    ...group,
    matchedPatientId: group.mrn
      ? (patientMatches.get(group.mrn) ?? null)
      : null,
  }));
  const calculated = revenueTotals(rows);
  const reconciliation =
    parsed.grandTotal &&
    revenueTotalsMatch(calculated, parsed.grandTotal) &&
    !parsed.fatalErrors.length
      ? "PASS"
      : "FAIL";
  return {
    ...parsed,
    fileAlreadyImported: Boolean(existingBatch[0]),
    batchId: existingBatch[0]?.id ?? null,
    rows,
    patients: patientsGroups,
    summary: {
      ...calculated,
      patients: patientsGroups.length,
      serviceRows: rows.length,
      invalidRows: rows.filter(row => row.validation === "ERROR").length,
      duplicateRows: rows.filter(row => row.validation === "DUPLICATE").length,
      warnings: rows.filter(row => row.validation === "WARNING").length,
      unmatchedPatients: patientsGroups.filter(group => !group.matchedPatientId)
        .length,
      reconciliation,
    },
  };
}

export function assertRevenuePreviewImportable(
  preview: RevenuePreview,
  includeWarnings: boolean
) {
  if (preview.fileAlreadyImported)
    throw new Error(
      "This exact HMS Revenue report has already been imported. No duplicate revenue was created."
    );
  if (preview.fatalErrors.length)
    throw new Error(preview.fatalErrors.join(" "));
  if (preview.summary.invalidRows)
    throw new Error(
      "Revenue import blocked: invalid service rows must be corrected in HMS before import."
    );
  if (preview.summary.duplicateRows)
    throw new Error(
      "Revenue import blocked: duplicate service rows were detected."
    );
  if (preview.mrnDuplicateEntries.length)
    throw new Error(
      "Revenue import blocked: exact repeated service entries were detected under the same MRN. Resolve the MRN-led double-entry candidates in HMS before import."
    );
  if (preview.summary.warnings && !includeWarnings)
    throw new Error(
      "Revenue import has validation warnings. Review the preview and confirm that warnings may be imported."
    );
  if (!preview.grandTotal)
    throw new Error("Revenue import blocked: HMS Grand Total is missing.");
}

export async function importRevenueCsv(input: {
  csvText: string;
  originalFileName: string;
  importedByUserId: number;
  importedByName: string | null;
  includeWarnings: boolean;
}) {
  const preview = await previewRevenueCsvImport(input.csvText);
  assertRevenuePreviewImportable(preview, input.includeWarnings);
  const grandTotal = preview.grandTotal!;
  const db = await database();
  const matches = await matchPatients(preview.rows);
  return db.transaction(async tx => {
    const priorBatch = await tx
      .select({ id: revenueImportBatches.id })
      .from(revenueImportBatches)
      .where(eq(revenueImportBatches.fileSha256, preview.fileSha256))
      .limit(1);
    if (priorBatch[0])
      throw new Error("This exact HMS Revenue report was already imported.");
    const batchResult = await tx.insert(revenueImportBatches).values({
      originalFileName: input.originalFileName,
      fileSha256: preview.fileSha256,
      reportFromDate: preview.fromDate,
      reportToDate: preview.toDate,
      account: preview.account,
      printDate: preview.printDate,
      grandGross: money(grandTotal.gross),
      grandQuantity: quantity(grandTotal.quantity),
      grandDiscount: money(grandTotal.discount),
      grandDeduct: money(grandTotal.deduct),
      grandNet: money(grandTotal.net),
      patientCount: preview.patients.length,
      serviceRowCount: preview.rows.length,
      importedByUserId: input.importedByUserId,
      importedByName: input.importedByName,
      validationResult: preview.summary.reconciliation,
    });
    const batchId = Number(batchResult[0].insertId);
    if (preview.rows.length)
      await tx.insert(revenueTransactions).values(
        preview.rows.map(row => ({
          importBatchId: batchId,
          patientId: row.mrn ? (matches.get(row.mrn) ?? null) : null,
          hmsMrn: row.mrn,
          patientName: row.patientName || "Unnamed HMS patient",
          serviceCode: row.serviceCode,
          serviceName: row.serviceName,
          gross: money(row.gross),
          quantity: quantity(row.quantity),
          discount: money(row.discount),
          deduct: money(row.deduct),
          net: money(row.net),
          reportFromDate: row.fromDate,
          reportToDate: row.toDate,
          printDate: row.printDate,
          sourceFileName: input.originalFileName,
          sourceRowNumber: row.sourceRowNumber,
          sourceFingerprint: row.fingerprint,
          importedByUserId: input.importedByUserId,
        }))
      );
    await tx
      .insert(activityLogs)
      .values({
        actorUserId: input.importedByUserId,
        actorName: input.importedByName,
        action: `Imported HMS revenue batch ${batchId}: ${preview.rows.length} service rows`,
        subjectType: "revenue_import_batch",
        subjectId: batchId,
      });
    return {
      batchId,
      importedCount: preview.rows.length,
      unmatchedPatients: preview.summary.unmatchedPatients,
      summary: preview.summary,
    };
  });
}

type RevenueFilters = {
  dateFrom?: string;
  dateTo?: string;
  search?: string;
  mrn?: string;
  patientName?: string;
  serviceCode?: string;
  serviceName?: string;
  batchId?: number;
};
function conditionsFor(filters: RevenueFilters) {
  const conditions = [];
  if (filters.dateFrom)
    conditions.push(gte(revenueTransactions.reportFromDate, filters.dateFrom));
  if (filters.dateTo)
    conditions.push(lte(revenueTransactions.reportFromDate, filters.dateTo));
  if (filters.search)
    conditions.push(
      or(
        like(revenueTransactions.hmsMrn, `%${filters.search}%`),
        like(revenueTransactions.patientName, `%${filters.search}%`),
        like(revenueTransactions.serviceCode, `%${filters.search}%`),
        like(revenueTransactions.serviceName, `%${filters.search}%`)
      )
    );
  if (filters.mrn)
    conditions.push(like(revenueTransactions.hmsMrn, `%${filters.mrn}%`));
  if (filters.patientName)
    conditions.push(
      like(revenueTransactions.patientName, `%${filters.patientName}%`)
    );
  if (filters.serviceCode)
    conditions.push(
      like(revenueTransactions.serviceCode, `%${filters.serviceCode}%`)
    );
  if (filters.serviceName)
    conditions.push(
      like(revenueTransactions.serviceName, `%${filters.serviceName}%`)
    );
  if (filters.batchId)
    conditions.push(eq(revenueTransactions.importBatchId, filters.batchId));
  return conditions.length ? and(...conditions) : undefined;
}
function normalizeRow(row: typeof revenueTransactions.$inferSelect) {
  return {
    ...row,
    gross: toNumber(row.gross),
    quantity: toNumber(row.quantity),
    discount: toNumber(row.discount),
    deduct: toNumber(row.deduct),
    net: toNumber(row.net),
  };
}
function summarize(
  rows: Array<{
    gross: number;
    quantity: number;
    discount: number;
    deduct: number;
    net: number;
  }>
) {
  return rows.reduce((sum, row) => addMoney(sum, row), emptyMoney());
}

/**
 * Groups only existing immutable HMS transaction values by their report calendar month.
 * The date is already a date-only HMS business value; no client-local timezone conversion
 * is applied before grouping. The client selects the current month using Asia/Riyadh.
 */
function monthlyIncome(
  rows: Array<{ reportFromDate: string | null; net: number }>
) {
  const totals = new Map<string, number>();
  for (const row of rows) {
    if (!row.reportFromDate || !/^\d{4}-\d{2}-\d{2}$/.test(row.reportFromDate))
      continue;
    const month = row.reportFromDate.slice(0, 7);
    totals.set(month, (totals.get(month) ?? 0) + row.net);
  }
  return Array.from(totals, ([month, totalIncome]) => ({
    month,
    totalIncome,
  })).sort((left, right) => right.month.localeCompare(left.month));
}

export async function getRevenueWorkspace(filters: RevenueFilters = {}) {
  const db = await database();
  const [selectedRows, allMonthlyRows, batches] = await Promise.all([
    db
      .select()
      .from(revenueTransactions)
      .where(conditionsFor(filters))
      .orderBy(
        desc(revenueTransactions.reportFromDate),
        asc(revenueTransactions.patientName),
        asc(revenueTransactions.sourceRowNumber)
      ),
    db
      .select({
        reportFromDate: revenueTransactions.reportFromDate,
        net: revenueTransactions.net,
      })
      .from(revenueTransactions),
    db
      .select()
      .from(revenueImportBatches)
      .orderBy(desc(revenueImportBatches.importedAt))
      .limit(50),
  ]);
  const rows = selectedRows.map(normalizeRow);
  const byPatient = Array.from(
    rows
      .reduce((groups, row) => {
        const key = `${row.hmsMrn ?? "unmatched"}\u001f${row.patientName}`;
        const group = groups.get(key) ?? {
          mrn: row.hmsMrn,
          patientName: row.patientName,
          patientId: row.patientId,
          totals: emptyMoney(),
          rows: [] as typeof rows,
        };
        group.rows.push(row);
        group.totals = summarize(group.rows);
        groups.set(key, group);
        return groups;
      }, new Map<string, { mrn: string | null; patientName: string; patientId: number | null; totals: RevenueMoney; rows: typeof rows }>())
      .values()
  );
  const byService = Array.from(
    rows
      .reduce((groups, row) => {
        const key = `${row.serviceCode}\u001f${row.serviceName}`;
        const group = groups.get(key) ?? {
          serviceCode: row.serviceCode,
          serviceName: row.serviceName,
          totals: emptyMoney(),
        };
        group.totals = addMoney(group.totals, row);
        groups.set(key, group);
        return groups;
      }, new Map<string, { serviceCode: string; serviceName: string; totals: RevenueMoney }>())
      .values()
  ).sort((a, b) => b.totals.net - a.totals.net);
  const byDay = Array.from(
    rows
      .reduce((groups, row) => {
        const key = row.reportFromDate || "Unspecified";
        const group = groups.get(key) ?? { date: key, totals: emptyMoney() };
        group.totals = addMoney(group.totals, row);
        groups.set(key, group);
        return groups;
      }, new Map<string, { date: string; totals: RevenueMoney }>())
      .values()
  ).sort((a, b) => b.date.localeCompare(a.date));
  return {
    rows,
    patients: byPatient,
    services: byService,
    daily: byDay,
    summary: summarize(rows),
    monthlySummary: monthlyIncome(
      allMonthlyRows.map(row => ({
        reportFromDate: row.reportFromDate,
        net: toNumber(row.net),
      }))
    ),
    batches,
  };
}

export async function getRevenueBatch(batchId: number) {
  const db = await database();
  const batch = await db
    .select()
    .from(revenueImportBatches)
    .where(eq(revenueImportBatches.id, batchId))
    .limit(1);
  if (!batch[0]) return null;
  const rows = (
    await db
      .select()
      .from(revenueTransactions)
      .where(eq(revenueTransactions.importBatchId, batchId))
      .orderBy(asc(revenueTransactions.sourceRowNumber))
  ).map(normalizeRow);
  return { batch: batch[0], rows };
}
