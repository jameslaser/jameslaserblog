import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const root = process.cwd();
const packageJson = JSON.parse(readFileSync(resolve(root, "package.json"), "utf8")) as {
  scripts: Record<string, string>;
  dependencies: Record<string, string>;
  devDependencies: Record<string, string>;
};
const dbSource = readFileSync(resolve(root, "server/db.ts"), "utf8");
const envSource = readFileSync(resolve(root, "server/_core/env.ts"), "utf8");
const schemaSource = readFileSync(resolve(root, "drizzle/schema.ts"), "utf8");

describe("built-in database contract", () => {
  it("uses MySQL/TiDB Drizzle runtime and MYSQL_URL precedence", () => {
    expect(dbSource).toContain('drizzle-orm/mysql2');
    expect(schemaSource).toContain('drizzle-orm/mysql-core');
    expect(envSource).toContain("process.env.MYSQL_URL");
  });

  it("does not expose executable PostgreSQL migration paths", () => {
    expect(packageJson.scripts).not.toHaveProperty("postgres:preflight");
    expect(packageJson.scripts).not.toHaveProperty("postgres:migrate");
    expect(packageJson.dependencies).not.toHaveProperty("pg");
    expect(packageJson.devDependencies).not.toHaveProperty("@types/pg");
  });
});
