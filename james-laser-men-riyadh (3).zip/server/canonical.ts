import type { Express } from "express";

const VERIFIED_PRODUCTION_ORIGIN = "https://www.jameslaserformen.com";

const LEGACY_PATHS: Record<string, string> = {
  "/en": "/",
  "/treatments": "/en/treatments",
  "/offers": "/en/offers",
  "/results": "/en/results",
  "/faq": "/en/faq",
  "/blog": "/en/blog",
  "/guide": "/en/blog",
  "/en/guide": "/en/blog",
  "/ar/guide": "/ar/blog",
  "/en/appointment": "/appointment",
  "/en/whatsapp": "/whatsapp",
};

export function configuredCanonicalOrigin() {
  const configured = process.env.CANONICAL_ORIGIN || process.env.VITE_PUBLIC_SITE_ORIGIN || VERIFIED_PRODUCTION_ORIGIN;
  if (!configured) return null;
  try {
    const parsed = new URL(configured);
    if (parsed.protocol !== "https:" && parsed.protocol !== "http:") return null;
    return parsed.origin.replace(/\/+$/, "");
  } catch {
    return null;
  }
}

function normalizedIncomingHost(value: string | undefined) {
  return value?.split(",")[0]?.trim().toLowerCase().replace(/\.$/, "") || "";
}

/**
 * Collapses known duplicate public paths and host variants before the static or
 * SSR handlers. Unknown paths retain their normal 404 behavior.
 */
export function registerCanonicalRedirects(app: Express) {
  app.use((req, res, next) => {
    if (req.method !== "GET" && req.method !== "HEAD") return next();
    const canonicalOrigin = configuredCanonicalOrigin();
    const query = req.originalUrl.includes("?") ? req.originalUrl.slice(req.originalUrl.indexOf("?")) : "";
    const requestedPath = req.path;
    const legacyGuide = requestedPath.match(/^\/(en|ar)\/guide\/(.+)$/);
    const explicitTarget = LEGACY_PATHS[requestedPath] || (legacyGuide ? `/${legacyGuide[1]}/blog/${legacyGuide[2]}` : undefined);
    const normalizedPath = requestedPath !== "/" && /\/+$/.test(requestedPath)
      ? (requestedPath.replace(/\/+$/, "") || "/").replace(/^\/\/+/, "/")
      : null;
    const canonicalPath = explicitTarget || normalizedPath || requestedPath;

    if (canonicalOrigin && process.env.NODE_ENV === "production") {
      const canonicalHost = new URL(canonicalOrigin).host.toLowerCase();
      const incomingHost = normalizedIncomingHost(req.get("x-forwarded-host") || req.get("host"));
      if (incomingHost && incomingHost !== canonicalHost) {
        return res.redirect(301, `${canonicalOrigin}${canonicalPath}${query}`);
      }
    }

    if (canonicalPath !== requestedPath) return res.redirect(301, `${canonicalPath}${query}`);

    return next();
  });
}
