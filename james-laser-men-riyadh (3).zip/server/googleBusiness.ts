import {
  createCipheriv,
  createDecipheriv,
  createHash,
  randomBytes,
} from "node:crypto";
import type { Express, Request, Response } from "express";
import { and, eq, isNull } from "drizzle-orm";
import {
  googleBusinessConnections,
  googleBusinessOAuthStates,
  reviews,
} from "../drizzle/schema";
import { configuredCanonicalOrigin } from "./canonical";
import { getDb } from "./db";
import { ENV } from "./_core/env";

type GoogleBusinessActor = { id: number; name: string | null };
type GoogleRecord = Record<string, unknown>;

type GoogleBusinessLocation = {
  accountResourceName: string;
  accountName: string;
  locationResourceName: string;
  locationName: string;
};

const GOOGLE_BUSINESS_SCOPE = "https://www.googleapis.com/auth/business.manage";
const PRIMARY_CONNECTION_KEY = "primary";
const OAUTH_STATE_TTL_MS = 10 * 60 * 1000;

function asRecord(value: unknown): GoogleRecord | null {
  return typeof value === "object" && value !== null && !Array.isArray(value)
    ? (value as GoogleRecord)
    : null;
}

function stringValue(value: unknown, maxLength = 1000): string | null {
  return typeof value === "string" && value.trim()
    ? value.trim().slice(0, maxLength)
    : null;
}

function timestampValue(value: unknown): Date | null {
  const parsed = stringValue(value);
  if (!parsed) return null;
  const date = new Date(parsed);
  return Number.isNaN(date.getTime()) ? null : date;
}

function resourcePath(value: string) {
  return value
    .split("/")
    .map(segment => encodeURIComponent(segment))
    .join("/");
}

function reviewRating(value: unknown): number | null {
  const ratings: Record<string, number> = {
    ONE: 1,
    TWO: 2,
    THREE: 3,
    FOUR: 4,
    FIVE: 5,
  };
  if (
    typeof value === "number" &&
    Number.isInteger(value) &&
    value >= 1 &&
    value <= 5
  )
    return value;
  return typeof value === "string"
    ? (ratings[value.toUpperCase()] ?? null)
    : null;
}

function stateDigest(value: string) {
  return createHash("sha256").update(value).digest("hex");
}

async function database() {
  const db = await getDb();
  if (!db)
    throw new Error(
      "The Google Business integration is temporarily unavailable."
    );
  return db;
}

export function getGoogleBusinessConfiguration(
  env: NodeJS.ProcessEnv = process.env,
  canonicalOrigin = configuredCanonicalOrigin()
) {
  const redirectUri =
    env.GOOGLE_BUSINESS_REDIRECT_URI?.trim() ||
    `${canonicalOrigin}/api/google-business/callback`;
  const missing = [
    ["GOOGLE_BUSINESS_CLIENT_ID", env.GOOGLE_BUSINESS_CLIENT_ID],
    ["GOOGLE_BUSINESS_CLIENT_SECRET", env.GOOGLE_BUSINESS_CLIENT_SECRET],
    [
      "GOOGLE_BUSINESS_TOKEN_ENCRYPTION_KEY",
      env.GOOGLE_BUSINESS_TOKEN_ENCRYPTION_KEY,
    ],
  ]
    .filter(([, value]) => !value?.trim())
    .map(([key]) => key);

  return {
    configured: missing.length === 0,
    missing,
    redirectUri,
    clientId: env.GOOGLE_BUSINESS_CLIENT_ID?.trim() ?? "",
    clientSecret: env.GOOGLE_BUSINESS_CLIENT_SECRET?.trim() ?? "",
    encryptionKey: env.GOOGLE_BUSINESS_TOKEN_ENCRYPTION_KEY?.trim() ?? "",
  };
}

function requireGoogleBusinessConfiguration() {
  const config = getGoogleBusinessConfiguration({
    ...process.env,
    GOOGLE_BUSINESS_CLIENT_ID: ENV.googleBusinessClientId,
    GOOGLE_BUSINESS_CLIENT_SECRET: ENV.googleBusinessClientSecret,
    GOOGLE_BUSINESS_REDIRECT_URI: ENV.googleBusinessRedirectUri,
    GOOGLE_BUSINESS_TOKEN_ENCRYPTION_KEY: ENV.googleBusinessTokenEncryptionKey,
  });
  if (!config.configured) {
    throw new Error(
      "Google Business credentials have not been configured for this portal."
    );
  }
  return config;
}

function encryptionKey(value: string) {
  const key = Buffer.from(value, "base64");
  if (key.length !== 32) {
    throw new Error(
      "Google Business token encryption is not configured correctly."
    );
  }
  return key;
}

export function encryptGoogleBusinessToken(token: string, keyValue: string) {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", encryptionKey(keyValue), iv);
  const encrypted = Buffer.concat([
    cipher.update(token, "utf8"),
    cipher.final(),
  ]);
  const tag = cipher.getAuthTag();
  return [
    iv.toString("base64url"),
    tag.toString("base64url"),
    encrypted.toString("base64url"),
  ].join(".");
}

export function decryptGoogleBusinessToken(payload: string, keyValue: string) {
  const [ivPart, tagPart, encryptedPart, extraPart] = payload.split(".");
  if (!ivPart || !tagPart || !encryptedPart || extraPart) {
    throw new Error("Stored Google Business credentials are invalid.");
  }
  const decipher = createDecipheriv(
    "aes-256-gcm",
    encryptionKey(keyValue),
    Buffer.from(ivPart, "base64url")
  );
  decipher.setAuthTag(Buffer.from(tagPart, "base64url"));
  return Buffer.concat([
    decipher.update(Buffer.from(encryptedPart, "base64url")),
    decipher.final(),
  ]).toString("utf8");
}

async function fetchJson(
  url: string,
  accessToken: string
): Promise<GoogleRecord> {
  const response = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  const body = await response.json().catch(() => null);
  const parsed = asRecord(body);
  if (!response.ok || !parsed) {
    if (response.status === 401 || response.status === 403) {
      throw new Error(
        "Google Business access was denied. Reconnect an account that manages the clinic profile."
      );
    }
    throw new Error(
      "Google Business did not return review data. Try again later."
    );
  }
  return parsed;
}

async function refreshGoogleAccessToken(encryptedRefreshToken: string) {
  const config = requireGoogleBusinessConfiguration();
  const refreshToken = decryptGoogleBusinessToken(
    encryptedRefreshToken,
    config.encryptionKey
  );
  const response = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: config.clientId,
      client_secret: config.clientSecret,
      refresh_token: refreshToken,
      grant_type: "refresh_token",
    }),
  });
  const body = asRecord(await response.json().catch(() => null));
  const accessToken = stringValue(body?.access_token);
  if (!response.ok || !accessToken) {
    throw new Error(
      "Google Business authorization expired or was revoked. Reconnect the clinic profile."
    );
  }
  return accessToken;
}

async function currentConnection() {
  const db = await database();
  const records = await db
    .select()
    .from(googleBusinessConnections)
    .where(eq(googleBusinessConnections.connectionKey, PRIMARY_CONNECTION_KEY))
    .limit(1);
  return records[0] ?? null;
}

function safeConnection(
  connection: Awaited<ReturnType<typeof currentConnection>>
) {
  if (!connection) return null;
  return {
    status: connection.status,
    accountName: connection.accountName,
    locationName: connection.locationName,
    locationResourceName: connection.locationResourceName,
    lastSyncedAt: connection.lastSyncedAt,
    lastSyncStatus: connection.lastSyncStatus,
    lastSyncError: connection.lastSyncError,
    updatedAt: connection.updatedAt,
  };
}

export async function getGoogleBusinessStatus() {
  const config = getGoogleBusinessConfiguration({
    ...process.env,
    GOOGLE_BUSINESS_CLIENT_ID: ENV.googleBusinessClientId,
    GOOGLE_BUSINESS_CLIENT_SECRET: ENV.googleBusinessClientSecret,
    GOOGLE_BUSINESS_REDIRECT_URI: ENV.googleBusinessRedirectUri,
    GOOGLE_BUSINESS_TOKEN_ENCRYPTION_KEY: ENV.googleBusinessTokenEncryptionKey,
  });
  return {
    configured: config.configured,
    missingConfiguration: config.missing,
    redirectUri: config.redirectUri,
    connection: safeConnection(await currentConnection()),
  };
}

export async function beginGoogleBusinessAuthorization(
  actor: GoogleBusinessActor
) {
  const config = requireGoogleBusinessConfiguration();
  const db = await database();
  const state = randomBytes(32).toString("base64url");
  await db.insert(googleBusinessOAuthStates).values({
    stateDigest: stateDigest(state),
    createdByUserId: actor.id,
    createdByName: actor.name,
    redirectUri: config.redirectUri,
    expiresAt: new Date(Date.now() + OAUTH_STATE_TTL_MS),
  });

  const authorizationUrl = new URL(
    "https://accounts.google.com/o/oauth2/v2/auth"
  );
  authorizationUrl.search = new URLSearchParams({
    client_id: config.clientId,
    redirect_uri: config.redirectUri,
    response_type: "code",
    scope: GOOGLE_BUSINESS_SCOPE,
    access_type: "offline",
    prompt: "consent",
    state,
  }).toString();

  return { authorizationUrl: authorizationUrl.toString() };
}

async function exchangeAuthorizationCode(code: string, redirectUri: string) {
  const config = requireGoogleBusinessConfiguration();
  const response = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      code,
      client_id: config.clientId,
      client_secret: config.clientSecret,
      redirect_uri: redirectUri,
      grant_type: "authorization_code",
    }),
  });
  const body = asRecord(await response.json().catch(() => null));
  const refreshToken = stringValue(body?.refresh_token);
  if (!response.ok || !refreshToken) {
    throw new Error(
      "Google did not return a reusable authorization. Try connecting the profile again."
    );
  }
  return encryptGoogleBusinessToken(refreshToken, config.encryptionKey);
}

export async function completeGoogleBusinessAuthorization(
  code: string,
  state: string
) {
  const db = await database();
  const states = await db
    .select()
    .from(googleBusinessOAuthStates)
    .where(
      and(
        eq(googleBusinessOAuthStates.stateDigest, stateDigest(state)),
        isNull(googleBusinessOAuthStates.consumedAt)
      )
    )
    .limit(1);
  const authorization = states[0];
  if (!authorization || authorization.expiresAt.getTime() < Date.now()) {
    throw new Error(
      "This Google Business connection request has expired. Start again from the Reviews page."
    );
  }

  await db
    .update(googleBusinessOAuthStates)
    .set({ consumedAt: new Date() })
    .where(eq(googleBusinessOAuthStates.id, authorization.id));

  const encryptedRefreshToken = await exchangeAuthorizationCode(
    code,
    authorization.redirectUri
  );
  const existing = await currentConnection();
  const values = {
    status: "awaiting_location" as const,
    encryptedRefreshToken,
    accountResourceName: null,
    accountName: null,
    locationResourceName: null,
    locationName: null,
    lastSyncStatus: "never" as const,
    lastSyncedAt: null,
    lastSyncError: null,
    createdByUserId: authorization.createdByUserId,
    createdByName: authorization.createdByName,
    updatedAt: new Date(),
  };

  if (existing) {
    await db
      .update(googleBusinessConnections)
      .set(values)
      .where(eq(googleBusinessConnections.id, existing.id));
  } else {
    await db.insert(googleBusinessConnections).values({
      connectionKey: PRIMARY_CONNECTION_KEY,
      ...values,
    });
  }

  return { redirectUri: authorization.redirectUri };
}

async function allLocations(
  accessToken: string
): Promise<GoogleBusinessLocation[]> {
  const accounts = await fetchJson(
    "https://mybusinessaccountmanagement.googleapis.com/v1/accounts?pageSize=20",
    accessToken
  );
  const accountList = Array.isArray(accounts.accounts) ? accounts.accounts : [];
  const locations: GoogleBusinessLocation[] = [];

  for (const entry of accountList) {
    const account = asRecord(entry);
    const accountResourceName = stringValue(account?.name, 160);
    if (!accountResourceName) continue;
    const accountName =
      stringValue(account?.accountName, 240) ?? accountResourceName;
    const url = new URL(
      `https://mybusinessbusinessinformation.googleapis.com/v1/${resourcePath(accountResourceName)}/locations`
    );
    url.search = new URLSearchParams({
      pageSize: "100",
      readMask: "title",
    }).toString();
    const response = await fetchJson(url.toString(), accessToken);
    const locationList = Array.isArray(response.locations)
      ? response.locations
      : [];

    for (const entry of locationList) {
      const location = asRecord(entry);
      const locationResourceName = stringValue(location?.name, 200);
      if (!locationResourceName) continue;
      locations.push({
        accountResourceName,
        accountName,
        locationResourceName,
        locationName: stringValue(location?.title, 240) ?? locationResourceName,
      });
    }
  }

  return locations;
}

export async function listGoogleBusinessLocations() {
  const connection = await currentConnection();
  if (!connection)
    throw new Error(
      "Connect a Google Business account before selecting a clinic location."
    );
  const accessToken = await refreshGoogleAccessToken(
    connection.encryptedRefreshToken
  );
  return allLocations(accessToken);
}

export async function selectGoogleBusinessLocation(
  input: GoogleBusinessLocation
) {
  const connection = await currentConnection();
  if (!connection)
    throw new Error(
      "Connect a Google Business account before selecting a clinic location."
    );
  const accessToken = await refreshGoogleAccessToken(
    connection.encryptedRefreshToken
  );
  const allowedLocations = await allLocations(accessToken);
  const selected = allowedLocations.find(
    location =>
      location.accountResourceName === input.accountResourceName &&
      location.locationResourceName === input.locationResourceName
  );
  if (!selected)
    throw new Error(
      "The selected Google Business location is no longer available to this account."
    );

  const db = await database();
  await db
    .update(googleBusinessConnections)
    .set({
      status: "active",
      accountResourceName: selected.accountResourceName,
      accountName: selected.accountName,
      locationResourceName: selected.locationResourceName,
      locationName: selected.locationName,
      lastSyncStatus: "never",
      lastSyncError: null,
      updatedAt: new Date(),
    })
    .where(eq(googleBusinessConnections.id, connection.id));

  return safeConnection(await currentConnection());
}

export async function syncGoogleBusinessReviews() {
  const connection = await currentConnection();
  if (
    !connection ||
    connection.status !== "active" ||
    !connection.locationResourceName
  ) {
    throw new Error(
      "Choose an active Google Business clinic location before syncing reviews."
    );
  }

  const accessToken = await refreshGoogleAccessToken(
    connection.encryptedRefreshToken
  );
  const db = await database();
  let pageToken: string | null = null;
  let imported = 0;
  let skipped = 0;
  let totalReviewCount: number | null = null;

  do {
    const url = new URL(
      `https://mybusiness.googleapis.com/v4/${resourcePath(connection.locationResourceName)}/reviews`
    );
    url.search = new URLSearchParams({
      pageSize: "50",
      orderBy: "updateTime desc",
      ...(pageToken ? { pageToken } : {}),
    }).toString();
    const page = await fetchJson(url.toString(), accessToken);
    const reviewList = Array.isArray(page.reviews) ? page.reviews : [];
    if (typeof page.totalReviewCount === "number")
      totalReviewCount = page.totalReviewCount;

    for (const entry of reviewList) {
      const review = asRecord(entry);
      const sourceReviewId = stringValue(review?.name, 320);
      const rating = reviewRating(review?.starRating);
      if (!sourceReviewId || !rating) {
        skipped += 1;
        continue;
      }
      const reviewer = asRecord(review?.reviewer);
      const reply = asRecord(review?.reviewReply);
      const values = {
        displayName:
          stringValue(reviewer?.displayName, 120) ?? "Google reviewer",
        rating,
        reviewText: stringValue(review?.comment, 12000) ?? "",
        treatment: null,
        language: "en" as const,
        isAnonymous: false,
        isFeatured: false,
        status: "pending" as const,
        source: "google_business" as const,
        sourceReviewId,
        sourceUpdatedAt: timestampValue(review?.updateTime),
        googleReplyText: stringValue(reply?.comment, 12000),
        googleReviewCreatedAt: timestampValue(review?.createTime),
      };
      await db
        .insert(reviews)
        .values(values)
        .onDuplicateKeyUpdate({
          set: {
            displayName: values.displayName,
            rating: values.rating,
            reviewText: values.reviewText,
            sourceUpdatedAt: values.sourceUpdatedAt,
            googleReplyText: values.googleReplyText,
            googleReviewCreatedAt: values.googleReviewCreatedAt,
          },
        });
      imported += 1;
    }

    pageToken = stringValue(page.nextPageToken, 5000);
  } while (pageToken);

  await db
    .update(googleBusinessConnections)
    .set({
      lastSyncedAt: new Date(),
      lastSyncStatus: "success",
      lastSyncError: null,
      updatedAt: new Date(),
    })
    .where(eq(googleBusinessConnections.id, connection.id));

  return { imported, skipped, totalReviewCount };
}

export async function recordGoogleBusinessSyncFailure() {
  const connection = await currentConnection();
  if (!connection) return;
  const db = await database();
  await db
    .update(googleBusinessConnections)
    .set({
      lastSyncStatus: "failed",
      lastSyncError:
        "Google Business review sync failed. Reconnect the clinic profile if the problem persists.",
      updatedAt: new Date(),
    })
    .where(eq(googleBusinessConnections.id, connection.id));
}

function reviewRedirect(
  redirectUri: string,
  status: "connected" | "cancelled" | "error"
) {
  const origin = new URL(redirectUri).origin;
  const url = new URL("/admin/reviews", origin);
  url.searchParams.set("googleBusiness", status);
  return url.toString();
}

export function registerGoogleBusinessOAuthRoutes(app: Express) {
  app.get(
    "/api/google-business/callback",
    async (req: Request, res: Response) => {
      res.setHeader("Cache-Control", "no-store");
      const code = typeof req.query.code === "string" ? req.query.code : "";
      const state = typeof req.query.state === "string" ? req.query.state : "";
      if (!code || !state) {
        return res.redirect(
          303,
          `${configuredCanonicalOrigin()}/admin/reviews?googleBusiness=cancelled`
        );
      }
      try {
        const result = await completeGoogleBusinessAuthorization(code, state);
        return res.redirect(
          303,
          reviewRedirect(result.redirectUri, "connected")
        );
      } catch {
        return res.redirect(
          303,
          `${configuredCanonicalOrigin()}/admin/reviews?googleBusiness=error`
        );
      }
    }
  );
}
