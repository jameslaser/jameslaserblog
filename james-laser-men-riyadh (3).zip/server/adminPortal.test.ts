import { describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({
  approveConsultationRequest: vi.fn(),
  cancelConsultationRequest: vi.fn(),
  confirmAppointmentArrival: vi.fn(),
  createConsultationRequest: vi.fn(),
  createManualAppointment: vi.fn(),
  createManualPatient: vi.fn(),
  exportHmsClinicRecordsCsv: vi.fn(),
  createPublicAppointmentRequest: vi.fn(),
  deleteConsultationRequest: vi.fn(),
  getAdminDashboardStats: vi.fn(),
  getPatientFile: vi.fn(),
  importHmsCsvAppointments: vi.fn(),
  listAppointmentsForDate: vi.fn(),
  listConsultationRequests: vi.fn(),
  listMachineInventory: vi.fn(),
  listPatients: vi.fn(),
  listStaffUsers: vi.fn(),
  listTodayWaitingList: vi.fn(),
  markAppointmentAttendance: vi.fn(),
  markAppointmentWaiting: vi.fn(),
  previewHmsCsvImport: vi.fn(),
  recordManualWhatsAppLaunch: vi.fn(),
  updateAppointmentDetails: vi.fn(),
  updateConsultationRequestDetails: vi.fn(),
  updateConsultationRequestWorkflow: vi.fn(),
  listSessionRetouchReminders: vi.fn(),
  updateMachineNumber: vi.fn(),
  updateStaffRole: vi.fn(),
}));
const cmsMocks = vi.hoisted(() => ({
  cmsDashboardStats: vi.fn(), deleteContentCalendarItem: vi.fn(), deleteFaq: vi.fn(), deleteGuidePost: vi.fn(), deleteMediaItem: vi.fn(), deletePolicy: vi.fn(), deletePromotion: vi.fn(), deleteResultCase: vi.fn(), deleteReview: vi.fn(), deleteTreatment: vi.fn(), ensureClinicSettings: vi.fn(), getGuidePostBySlug: vi.fn(), getPublishedGuidePostBySlug: vi.fn(), listContentCalendarItems: vi.fn(), listFaqs: vi.fn(), listGuidePosts: vi.fn(), listHomepageSections: vi.fn(), listMediaItems: vi.fn(), listPolicies: vi.fn(), listPromotions: vi.fn(), listPublishedGuidePosts: vi.fn(), listResultCases: vi.fn(), listReviews: vi.fn(), listSeoSettings: vi.fn(), listSettingsChangeAudit: vi.fn(), listTreatments: vi.fn(), logCmsActivity: vi.fn(), recentCmsActivity: vi.fn(), registerMediaItem: vi.fn(), saveContentCalendarItem: vi.fn(), saveFaq: vi.fn(), saveGuidePost: vi.fn(), saveHomepageSection: vi.fn(), savePolicy: vi.fn(), savePromotion: vi.fn(), saveResultCase: vi.fn(), saveReview: vi.fn(), saveSeoSettings: vi.fn(), saveTreatment: vi.fn(), setReviewStatus: vi.fn(), updateClinicSettings: vi.fn(), updateMediaItem: vi.fn(),
}));
const sharedMocks = vi.hoisted(() => ({
  analyticsOverview: vi.fn(), createEnquiry: vi.fn(), deleteRedirect: vi.fn(), exportRows: vi.fn(), guardPublicSubmission: vi.fn(), listEnquiries: vi.fn(), listRedirects: vi.fn(), recordAnalyticsEvent: vi.fn(), saveRedirect: vi.fn(), updateEnquiry: vi.fn(),
}));
const notificationMocks = vi.hoisted(() => ({ createStaffNotification: vi.fn(), listStaffNotifications: vi.fn(), markStaffNotificationRead: vi.fn(), markAllStaffNotificationsRead: vi.fn() }));
const blogAiMocks = vi.hoisted(() => ({ generateBlogDraft: vi.fn(), generateBlogEnrichment: vi.fn() }));
const promotionAiMocks = vi.hoisted(() => ({ generatePromotionDraft: vi.fn() }));
const sessionMocks = vi.hoisted(() => ({
  createManualFollowUp: vi.fn(),
  finishAppointmentWithPostSessionNotes: vi.fn(),
  listEligibleSessionAppointments: vi.fn(),
  listFollowUps: vi.fn(),
  listSessionRecords: vi.fn(),
  saveSessionRecord: vi.fn(),
  trackLegacyAppointmentFollowUp: vi.fn(),
  updateFollowUp: vi.fn(),
}));

vi.mock("./db", () => mocks);
vi.mock("./cms", () => cmsMocks);
vi.mock("./sharedBackend", () => sharedMocks);
vi.mock("./notifications", () => notificationMocks);
vi.mock("./sessionFollowUps", () => sessionMocks);
vi.mock("./blogAi", async importOriginal => ({ ...(await importOriginal<typeof import("./blogAi")>()), ...blogAiMocks }));
vi.mock("./promotionAi", async importOriginal => ({ ...(await importOriginal<typeof import("./promotionAi")>()), ...promotionAiMocks }));

import { appRouter } from "./routers";

function contextFor(role: "owner" | "admin" | "content_editor" | "reception" | "user" | null): TrpcContext {
  if (!role) return { user: null, req: {}, res: {} } as TrpcContext;
  return {
    user: {
      id: 1,
      openId: "admin-user",
      name: "Nurse James",
      email: "james@example.com",
      loginMethod: "manus",
      role,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {},
    res: {},
  } as TrpcContext;
}

describe("admin portal procedures", () => {
  it("denies dashboard access to a non-admin user", async () => {
    const caller = appRouter.createCaller(contextFor("user"));
    await expect(caller.admin.dashboard()).rejects.toThrow();
  });

  it("creates a manual patient only through an admin caller without creating a public appointment request", async () => {
    mocks.createManualPatient.mockResolvedValueOnce({ patientId: 41 });
    const admin = appRouter.createCaller(contextFor("admin"));
    await expect(admin.admin.createManualPatient({ fullName: "Manual entry", mrn: "JL-0041", nationality: "Saudi", contactNumber: "0500000000", whatsapp: "0500000000", email: "", treatmentArea: "Face", notes: "" })).resolves.toEqual({ success: true, patientId: 41 });
    expect(mocks.createManualPatient).toHaveBeenCalledWith(expect.objectContaining({ mrn: "JL-0041", email: null, notes: null, treatmentArea: "Face" }), "Nurse James");
    expect(mocks.createPublicAppointmentRequest).not.toHaveBeenCalled();
    await expect(appRouter.createCaller(contextFor("reception")).admin.createManualPatient({ fullName: "Manual entry", mrn: null, nationality: "Saudi", contactNumber: "0500000000", whatsapp: "0500000000", email: "", treatmentArea: "Face", notes: "" })).rejects.toThrow();
  });

  it("records manual WhatsApp Business Web launches only for an administrator", async () => {
    mocks.recordManualWhatsAppLaunch.mockResolvedValueOnce(undefined);
    const admin = appRouter.createCaller(contextFor("admin"));

    await expect(admin.admin.recordManualWhatsAppLaunch({ subjectType: "appointment", subjectId: 41 })).resolves.toEqual({ success: true });
    expect(mocks.recordManualWhatsAppLaunch).toHaveBeenCalledWith({ subjectType: "appointment", subjectId: 41 }, { id: 1, name: "Nurse James" });
    await expect(appRouter.createCaller(contextFor("reception")).admin.recordManualWhatsAppLaunch({ subjectType: "patient", subjectId: 41 })).rejects.toThrow();
    await expect(admin.admin.recordManualWhatsAppLaunch({ subjectType: "conversation" as "patient", subjectId: 41 })).rejects.toThrow();
  });

  it("creates a manual confirmed appointment only through an admin caller and rejects times outside 1:00 PM–10:00 PM", async () => {
    mocks.createManualAppointment.mockResolvedValueOnce({ appointmentId: 51, patientId: null });
    const admin = appRouter.createCaller(contextFor("admin"));
    const input = { fullName: "Manual entry", mrn: "JL-0051", nationality: "Saudi", contactNumber: "0500000000", whatsapp: "0500000000", email: "", appointmentDate: "2026-09-03", appointmentTime: "13:15", treatmentAreas: ["Chest"] as const, machine: "DEKA AGAIN" as const, visitType: "session" as const, nextFollowUpDate: "2026-10-03", nextFollowUpType: "session" as const, notes: "Manual appointment note" };
    await expect(admin.admin.createManualAppointment(input)).resolves.toEqual({ success: true, appointmentId: 51, patientId: null });
    expect(mocks.createManualAppointment).toHaveBeenCalledWith(expect.objectContaining({ appointmentTime: "13:15", machine: "DEKA AGAIN", visitType: "session", treatmentAreas: ["Chest"], nextFollowUpType: "session", notes: "Manual appointment note" }), "Nurse James");
    await expect(admin.admin.createManualAppointment({ ...input, appointmentTime: "12:45" })).rejects.toThrow();
    await expect(admin.admin.createManualAppointment({ ...input, appointmentTime: "22:15" })).rejects.toThrow();
    await expect(appRouter.createCaller(contextFor("user")).admin.createManualAppointment(input)).rejects.toThrow();
  });

  it("allows only owner or admin roles to save validated appointment working details", async () => {
    mocks.updateAppointmentDetails.mockResolvedValueOnce(undefined);
    const input = { appointmentId: 51, fullName: "HMS patient", mrn: "JL-0051", nationality: "Saudi", contactNumber: "0500000000", whatsapp: "0500000000", email: "", appointmentDate: "2026-09-19", appointmentTime: "13:15", treatmentAreas: ["Chest"] as const, machine: "DEKA AGAIN" as const, visitType: "session" as const, nextFollowUpDate: null, nextFollowUpType: null, notes: "Local working note" };
    await expect(appRouter.createCaller(contextFor("admin")).admin.updateAppointmentDetails(input)).resolves.toEqual({ success: true });
    expect(mocks.updateAppointmentDetails).toHaveBeenCalledWith(expect.objectContaining({ appointmentId: 51, email: null, machine: "DEKA AGAIN" }), "Nurse James");
    await expect(appRouter.createCaller(contextFor("reception")).admin.updateAppointmentDetails(input)).rejects.toThrow();
    await expect(appRouter.createCaller(contextFor("user")).admin.updateAppointmentDetails(input)).rejects.toThrow();
  });

  it("keeps HMS preview admin-only and guarantees that previewing never calls the import operation", async () => {
    mocks.previewHmsCsvImport.mockResolvedValueOnce({ fileSha256: "safe-hash", fileAlreadyImported: false, batchId: null, fatalErrors: [], providerAttestationRequired: false, providerVerifiedFromSource: true, sourceProvider: "Mohamed Taha (JF)", normalizedProviderCode: "NR011", normalizedProviderLabel: "NR011 JAMES FLORES", rows: [], summary: { total: 0, ready: 0, warnings: 0, duplicates: 0, errors: 0 } });
    const admin = appRouter.createCaller(contextFor("admin"));
    await expect(admin.admin.hmsPreview({ csvText: "Text1", originalFileName: "Report.csv" })).resolves.toEqual(expect.objectContaining({ fileSha256: "safe-hash" }));
    expect(mocks.previewHmsCsvImport).toHaveBeenCalledWith("Text1");
    expect(mocks.importHmsCsvAppointments).not.toHaveBeenCalled();
    await expect(appRouter.createCaller(contextFor("reception")).admin.hmsPreview({ csvText: "Text1", originalFileName: "Report.csv" })).rejects.toThrow();
  });

  it("exports only through the protected HMS admin procedure", async () => {
    mocks.exportHmsClinicRecordsCsv.mockResolvedValueOnce('"Clinic Record ID","Provider Code"\\r\\n"1","NR011"\\r\\n');
    const admin = appRouter.createCaller(contextFor("admin"));
    await expect(admin.admin.hmsExportCsv()).resolves.toContain('NR011');
    expect(mocks.exportHmsClinicRecordsCsv).toHaveBeenCalledTimes(1);
    await expect(appRouter.createCaller(contextFor("reception")).admin.hmsExportCsv()).rejects.toThrow();
    await expect(appRouter.createCaller(contextFor("user")).admin.hmsExportCsv()).rejects.toThrow();
  });

  it("requires explicit upload confirmation while deriving the NR011 provider only from the verified HMS source", async () => {
    mocks.importHmsCsvAppointments.mockResolvedValueOnce({ batchId: 12, importedCount: 1, skippedDuplicateCount: 0, warningCount: 0, errorCount: 0 });
    const admin = appRouter.createCaller(contextFor("admin"));
    await expect(admin.admin.hmsImport({ csvText: "Text1", originalFileName: "Report.csv", confirm: true })).resolves.toEqual({ success: true, batchId: 12, importedCount: 1, skippedDuplicateCount: 0, warningCount: 0, errorCount: 0 });
    expect(mocks.importHmsCsvAppointments).toHaveBeenCalledWith(expect.objectContaining({ importedByUserId: 1, importedByName: "Nurse James" }));
    expect(mocks.importHmsCsvAppointments).toHaveBeenCalledWith(expect.not.objectContaining({ providerAttested: true }));
    await expect(admin.admin.hmsImport({ csvText: "Text1", originalFileName: "Report.csv", confirm: false as true })).rejects.toThrow();
  });

  it("allows the owner role to use protected operational CMS procedures", async () => {
    cmsMocks.cmsDashboardStats.mockResolvedValueOnce({ requests: 0, appointments: 0 });
    const caller = appRouter.createCaller(contextFor("owner"));
    await expect(caller.cms.dashboard()).resolves.toEqual({ requests: 0, appointments: 0 });
  });

  it("allows a content editor to read content records but denies patient operations", async () => {
    cmsMocks.listTreatments.mockResolvedValueOnce([{ id: 3, nameEn: "Face", isActive: false }]);
    const caller = appRouter.createCaller(contextFor("content_editor"));
    await expect(caller.cms.treatments()).resolves.toEqual([{ id: 3, nameEn: "Face", isActive: false }]);
    await expect(caller.admin.patients({ query: "" })).rejects.toThrow();
  });

  it("denies content CMS access to reception and ordinary users", async () => {
    await expect(appRouter.createCaller(contextFor("reception")).cms.treatments()).rejects.toThrow();
    await expect(appRouter.createCaller(contextFor("user")).cms.treatments()).rejects.toThrow();
  });

  it("keeps AI blog generation behind content-editor access", async () => {
    const input = { topic: "Laser preparation for men", primaryKeyword: "men's laser preparation Riyadh", secondaryKeywords: "", audience: "men_in_riyadh" as const, language: "both" as const, length: "brief" as const, sourceNotes: "" };
    await expect(appRouter.createCaller(contextFor("reception")).cms.generateGuideDraft(input)).rejects.toThrow();
    await expect(appRouter.createCaller(contextFor("user")).cms.generateGuideDraft(input)).rejects.toThrow();
    await expect(appRouter.createCaller(contextFor(null)).cms.generateGuideDraft(input)).rejects.toThrow();
  });

  it("automatically enriches only missing metadata when an editor creates a new blog post", async () => {
    cmsMocks.getGuidePostBySlug.mockResolvedValueOnce(null);
    blogAiMocks.generateBlogEnrichment.mockResolvedValueOnce({
      model: "gpt-5-mini",
      summaryEn: "Generated summary should not replace the editor summary.",
      summaryAr: "ملخص عربي مولد.",
      tags: "men's laser, Riyadh, preparation",
      seoTitle: "Men’s Laser Preparation in Riyadh",
      metaDescription: "Read clinic-reviewed preparation guidance for men considering laser hair removal in Riyadh, including timing, skin care, and realistic expectations.",
      focusKeyword: "men's laser preparation Riyadh",
      socialCaptionEn: "Read the clinic-reviewed preparation guide before requesting an individual assessment.",
      socialCaptionAr: "اقرأ دليل التحضير المراجع من العيادة قبل طلب تقييم فردي.",
      socialHashtags: "#MensLaser #Riyadh #LaserHairRemoval",
    });
    cmsMocks.saveGuidePost.mockImplementationOnce(async input => ({ id: 8, ...input }));
    const editor = appRouter.createCaller(contextFor("content_editor"));
    const result = await editor.cms.saveGuidePost({
      slug: "new-manual-draft", postType: "blog", titleEn: "Men’s laser preparation", titleAr: "التحضير لليزر للرجال", summaryEn: "Editor-written summary remains unchanged.", summaryAr: null, contentEn: "## Preparation\n\nFollow the clinic’s reviewed instructions before treatment.", contentAr: "## التحضير\n\nاتبع تعليمات العيادة التي تمت مراجعتها قبل العلاج.", category: "Preparation", tags: null, featuredImageUrl: null, featuredImageAltEn: null, featuredImageAltAr: null, videoUrl: null, seoTitle: null, metaDescription: null, canonicalUrl: null, socialImageUrl: null, focusKeyword: null, socialCaptionEn: null, socialCaptionAr: null, socialHashtags: null, authorName: "Nurse James", status: "draft", isFeatured: false, aiGenerated: false, clinicalReviewConfirmed: false, publishedAt: null,
    });
    expect(result.automaticEnrichment).toBe("generated");
    expect(blogAiMocks.generateBlogEnrichment).toHaveBeenCalledTimes(1);
    expect(cmsMocks.saveGuidePost).toHaveBeenCalledWith(expect.objectContaining({ summaryEn: "Editor-written summary remains unchanged.", summaryAr: "ملخص عربي مولد.", tags: "men's laser, Riyadh, preparation", seoTitle: "Men’s Laser Preparation in Riyadh", aiGenerated: true, canonicalUrl: "https://www.jameslaserformen.com/en/blog/new-manual-draft" }), { id: 1, name: "Nurse James" });
  });

  it("saves a private draft instead of publishing incomplete content when automatic enrichment is unavailable", async () => {
    cmsMocks.getGuidePostBySlug.mockResolvedValueOnce(null);
    blogAiMocks.generateBlogEnrichment.mockRejectedValueOnce(new Error("Temporary model outage"));
    cmsMocks.saveGuidePost.mockImplementationOnce(async input => ({ id: 9, ...input }));
    const editor = appRouter.createCaller(contextFor("content_editor"));
    const result = await editor.cms.saveGuidePost({
      slug: "safe-ai-fallback", postType: "blog", titleEn: "Safe AI fallback", titleAr: null, summaryEn: null, summaryAr: null, contentEn: "## Guidance\n\nReviewed educational content.", contentAr: null, category: "Education", tags: null, featuredImageUrl: null, featuredImageAltEn: null, featuredImageAltAr: null, videoUrl: null, seoTitle: null, metaDescription: null, canonicalUrl: null, socialImageUrl: null, focusKeyword: null, socialCaptionEn: null, socialCaptionAr: null, socialHashtags: null, authorName: "Nurse James", status: "published", isFeatured: false, aiGenerated: false, clinicalReviewConfirmed: true, publishedAt: null,
    });
    expect(result).toEqual(expect.objectContaining({ id: 9, status: "draft", automaticEnrichment: "failed" }));
    expect(cmsMocks.saveGuidePost).toHaveBeenCalledWith(expect.objectContaining({ status: "draft", clinicalReviewedAt: null, clinicalReviewedByUserId: null }), { id: 1, name: "Nurse James" });
  });

  it("rejects accidental duplicate-slug overwrites unless the editor supplies the matching record id", async () => {
    cmsMocks.getGuidePostBySlug.mockResolvedValueOnce({ id: 7, slug: "existing-article" });
    const savesBeforeConflict = cmsMocks.saveGuidePost.mock.calls.length;
    const editor = appRouter.createCaller(contextFor("content_editor"));
    const input = { slug: "existing-article", postType: "blog" as const, titleEn: "Different draft", titleAr: null, summaryEn: "Draft summary", summaryAr: null, contentEn: "Draft content", contentAr: null, category: null, tags: null, featuredImageUrl: null, featuredImageAltEn: null, featuredImageAltAr: null, videoUrl: null, seoTitle: null, metaDescription: null, canonicalUrl: null, socialImageUrl: null, focusKeyword: null, socialCaptionEn: null, socialCaptionAr: null, socialHashtags: null, authorName: "Nurse James", status: "draft" as const, isFeatured: false, aiGenerated: false, clinicalReviewConfirmed: false, publishedAt: null };
    await expect(editor.cms.saveGuidePost(input)).rejects.toThrow("URL slug already belongs to another article");
    expect(cmsMocks.saveGuidePost.mock.calls.length).toBe(savesBeforeConflict);
  });

  it("requires an explicit clinical and factual review before blog publication", async () => {
    const editor = appRouter.createCaller(contextFor("content_editor"));
    const input = { id: 7, slug: "reviewed-blog-post", postType: "blog" as const, titleEn: "Reviewed blog post", titleAr: null, summaryEn: "A complete clinic-reviewed summary.", summaryAr: null, contentEn: "## Guidance\n\nComplete reviewed educational content.", contentAr: null, category: "Education", tags: "laser, Riyadh", featuredImageUrl: null, featuredImageAltEn: null, featuredImageAltAr: null, videoUrl: null, seoTitle: "Reviewed Blog Post Riyadh | James Laser", metaDescription: "Clinic-reviewed educational guidance about men’s laser hair removal in Riyadh with cautious expectations and preparation advice.", canonicalUrl: "https://www.jameslaserformen.com/en/blog/reviewed-blog-post", socialImageUrl: null, focusKeyword: "men's laser Riyadh", socialCaptionEn: null, socialCaptionAr: null, socialHashtags: null, authorName: "Nurse James", status: "published" as const, isFeatured: false, aiGenerated: true, publishedAt: null };
    const saveCallsBeforeRejectedPublication = cmsMocks.saveGuidePost.mock.calls.length;
    await expect(editor.cms.saveGuidePost({ ...input, clinicalReviewConfirmed: false })).rejects.toThrow("Confirm the clinical and factual review");
    expect(cmsMocks.saveGuidePost.mock.calls.length).toBe(saveCallsBeforeRejectedPublication);
    cmsMocks.getGuidePostBySlug.mockResolvedValueOnce({ id: 7, slug: input.slug });
    cmsMocks.saveGuidePost.mockResolvedValueOnce({ id: 7, ...input, status: "published" });
    const enrichmentCallsBeforeExistingSave = blogAiMocks.generateBlogEnrichment.mock.calls.length;
    await expect(editor.cms.saveGuidePost({ ...input, clinicalReviewConfirmed: true })).resolves.toEqual(expect.objectContaining({ id: 7, status: "published" }));
    expect(cmsMocks.saveGuidePost).toHaveBeenCalledWith(expect.objectContaining({ clinicalReviewedByUserId: 1, aiGenerated: true }), { id: 1, name: "Nurse James" });
    expect(blogAiMocks.generateBlogEnrichment.mock.calls.length).toBe(enrichmentCallsBeforeExistingSave);
  });

  it("keeps editorial planning protected and flags GBP-ready records for owner authorization without posting externally", async () => {
    cmsMocks.listContentCalendarItems.mockResolvedValueOnce([{ id: 1, topic: "How to prepare before your laser appointment", externalPublication: true }]);
    cmsMocks.saveContentCalendarItem.mockResolvedValueOnce({ id: 2, planKey: "week-1-gbp-preparation" });
    const editor = appRouter.createCaller(contextFor("content_editor"));
    await expect(editor.cms.contentCalendarItems()).resolves.toHaveLength(1);
    await editor.cms.saveContentCalendarItem({ planKey: "week-1-gbp-preparation", weekNumber: 1, plannedFor: "2026-08-31", contentType: "gbp_update", topic: "How to prepare before your laser appointment", language: "en", status: "review", targetPage: "/en/guide", searchIntent: "educational", cta: "Read the guide", contentBrief: "Prepare a reviewable Google Business update only.", internalLinks: null, repurposingBrief: null, externalPublication: false });
    expect(cmsMocks.saveContentCalendarItem).toHaveBeenCalledWith(expect.objectContaining({ externalPublication: false, requiresOwnerAuthorization: true, createdByUserId: 1 }), { id: 1, name: "Nurse James" });
    await expect(appRouter.createCaller(contextFor("reception")).cms.contentCalendarItems()).rejects.toThrow();
  });

  it("allows reception to update a consultation request workflow without granting other admin operations", async () => {
    mocks.updateConsultationRequestWorkflow.mockResolvedValueOnce(undefined);
    const reception = appRouter.createCaller(contextFor("reception"));
    await expect(reception.admin.updateRequestStatus({ requestId: 7, status: "contacted", internalNotes: "Called clinic number." })).resolves.toEqual({ success: true });
    expect(mocks.updateConsultationRequestWorkflow).toHaveBeenCalledWith(7, "contacted", "Nurse James", "Called clinic number.");
    await expect(reception.admin.analytics()).rejects.toThrow();
  });

  it("keeps the private notification inbox behind reception access and forwards only read-state actions", async () => {
    notificationMocks.listStaffNotifications.mockResolvedValueOnce([{ id: 2, title: "New appointment request", message: "A new website appointment request is ready for protected staff review.", isRead: false }]);
    const reception = appRouter.createCaller(contextFor("reception"));
    await expect(reception.admin.notifications()).resolves.toEqual([{ id: 2, title: "New appointment request", message: "A new website appointment request is ready for protected staff review.", isRead: false }]);
    await expect(reception.admin.markNotificationRead({ id: 2 })).resolves.toEqual({ success: true });
    expect(notificationMocks.markStaffNotificationRead).toHaveBeenCalledWith(2);
    await expect(appRouter.createCaller(contextFor(null)).admin.notifications()).rejects.toThrow();
  });

  it("forwards validated request filter fields only through the protected request queue", async () => {
    mocks.listConsultationRequests.mockResolvedValueOnce([]);
    const caller = appRouter.createCaller(contextFor("reception"));
    await expect(caller.admin.requests({ status: "contacted", query: "JR-2026", visitType: "session", language: "ar", dateFrom: "2026-09-01", dateTo: "2026-09-07", treatment: "Chest" })).resolves.toEqual([]);
    expect(mocks.listConsultationRequests).toHaveBeenCalledWith({ status: "contacted", query: "JR-2026", visitType: "session", language: "ar", dateFrom: "2026-09-01", dateTo: "2026-09-07", treatment: "Chest" });
  });

  it("routes public treatment reads through the published-only helper", async () => {
    cmsMocks.listTreatments.mockResolvedValueOnce([{ id: 4, nameEn: "Published treatment" }]);
    const caller = appRouter.createCaller(contextFor(null));
    await expect(caller.publicContent.treatments()).resolves.toEqual([{ id: 4, nameEn: "Published treatment" }]);
    expect(cmsMocks.listTreatments).toHaveBeenCalledWith(false);
  });

  it("uses restricted public helpers for reviews, result cases, guides, FAQs, policies, and promotions", async () => {
    cmsMocks.listReviews.mockResolvedValueOnce([{ id: 1, status: "approved" }]);
    cmsMocks.listResultCases.mockResolvedValueOnce([{ id: 2, isActive: true }]);
    cmsMocks.listPublishedGuidePosts.mockResolvedValueOnce([{ id: 3, slug: "published-guide" }]);
    cmsMocks.listFaqs.mockResolvedValueOnce([{ id: 4, isActive: true }]);
    cmsMocks.listPolicies.mockResolvedValueOnce([{ id: 5, status: "published" }]);
    cmsMocks.listPromotions.mockResolvedValueOnce([{ id: 6, status: "published" }]);
    const caller = appRouter.createCaller(contextFor(null));
    await expect(caller.publicContent.reviews()).resolves.toEqual([{ id: 1, status: "approved" }]);
    await expect(caller.publicContent.resultCases()).resolves.toEqual([{ id: 2, isActive: true }]);
    await expect(caller.publicContent.guidePosts()).resolves.toEqual([{ id: 3, slug: "published-guide" }]);
    await expect(caller.publicContent.faqs()).resolves.toEqual([{ id: 4, isActive: true }]);
    await expect(caller.publicContent.policies()).resolves.toEqual([{ id: 5, status: "published" }]);
    await expect(caller.publicContent.promotions()).resolves.toEqual([{ id: 6, status: "published" }]);
    expect(cmsMocks.listReviews).toHaveBeenCalledWith(false);
    expect(cmsMocks.listResultCases).toHaveBeenCalledWith(false);
    expect(cmsMocks.listPublishedGuidePosts).toHaveBeenCalledOnce();
    expect(cmsMocks.listFaqs).toHaveBeenCalledWith(false);
    expect(cmsMocks.listPolicies).toHaveBeenCalledWith(false);
    expect(cmsMocks.listPromotions).toHaveBeenCalledWith(false);
  });

  it("loads a public blog detail through the published-only slug helper", async () => {
    cmsMocks.getPublishedGuidePostBySlug.mockResolvedValueOnce({ id: 3, slug: "laser-preparation", status: "published" });
    const caller = appRouter.createCaller(contextFor(null));
    await expect(caller.publicContent.guidePostBySlug({ slug: "laser-preparation" })).resolves.toEqual({ id: 3, slug: "laser-preparation", status: "published" });
    expect(cmsMocks.getPublishedGuidePostBySlug).toHaveBeenCalledWith("laser-preparation");
  });

  it("uses the published-only homepage-section helper for public website copy", async () => {
    cmsMocks.listHomepageSections.mockResolvedValueOnce([{ id: 9, sectionKey: "hero", status: "published" }]);
    const caller = appRouter.createCaller(contextFor(null));
    await expect(caller.publicContent.homepageSections()).resolves.toEqual([{ id: 9, sectionKey: "hero", status: "published" }]);
    expect(cmsMocks.listHomepageSections).toHaveBeenCalledWith(false);
  });

  it("requires an owner or admin to approve a review after a content editor saves it for moderation", async () => {
    cmsMocks.saveReview.mockResolvedValueOnce(12);
    const editor = appRouter.createCaller(contextFor("content_editor"));
    await expect(editor.cms.saveReview({ displayName: "Verified source", rating: 5, reviewText: "Real owner-provided review.", treatment: null, language: "en", isAnonymous: true, isFeatured: false })).resolves.toEqual(12);
    expect(cmsMocks.saveReview).toHaveBeenCalledWith(expect.objectContaining({ status: "pending", isAnonymous: true }), expect.any(Object));
    await expect(editor.cms.setReviewStatus({ id: 12, status: "approved" })).rejects.toThrow();
  });

  it("accepts protected media-library image paths for consented result cases while rejecting unmanaged relative paths", async () => {
    cmsMocks.saveResultCase.mockResolvedValueOnce(24);
    const editor = appRouter.createCaller(contextFor("content_editor"));
    const input = {
      title: "De-identified treatment detail",
      treatmentArea: "Lower back",
      beforeImageUrl: "/manus-storage/cms-media/1/before-treatment.webp",
      afterImageUrl: "/manus-storage/cms-media/1/after-treatment.webp",
      additionalImages: null,
      sessionCount: null,
      descriptionEn: null,
      descriptionAr: null,
      disclaimerEn: null,
      disclaimerAr: null,
      consentConfirmed: true as const,
      isFeatured: false,
      isActive: false,
      displayOrder: 0,
    };

    await expect(editor.cms.saveResultCase(input)).resolves.toEqual(24);
    expect(cmsMocks.saveResultCase).toHaveBeenCalledWith(expect.objectContaining({ beforeImageUrl: input.beforeImageUrl, afterImageUrl: input.afterImageUrl, consentRecordedAt: expect.any(Date) }), { id: 1, name: "Nurse James" });
    await expect(editor.cms.saveResultCase({ ...input, beforeImageUrl: "/manus-storage/unmanaged-before.webp" })).rejects.toThrow();
  });

  it("restricts the staff security directory to the owner role", async () => {
    mocks.listStaffUsers.mockResolvedValueOnce([{ id: 5, name: "Reception", role: "reception" }]);
    await expect(appRouter.createCaller(contextFor("owner")).cms.staffUsers()).resolves.toEqual([{ id: 5, name: "Reception", role: "reception" }]);
    await expect(appRouter.createCaller(contextFor("admin")).cms.staffUsers()).rejects.toThrow();
  });

  it("restricts role changes to the owner and forwards only allowed internal roles", async () => {
    mocks.updateStaffRole.mockResolvedValueOnce(undefined);
    const owner = appRouter.createCaller(contextFor("owner"));
    await expect(owner.cms.updateStaffRole({ userId: 5, role: "reception" })).resolves.toEqual({ success: true });
    expect(mocks.updateStaffRole).toHaveBeenCalledWith(5, "reception", { id: 1, name: "Nurse James" });
    await expect(appRouter.createCaller(contextFor("admin")).cms.updateStaffRole({ userId: 5, role: "admin" })).rejects.toThrow();
    await expect(owner.cms.updateStaffRole({ userId: 5, role: "owner" as "admin" })).rejects.toThrow();
  });

  it("keeps Settings updates server-authorized and dedicated change history administrator-only", async () => {
    cmsMocks.ensureClinicSettings.mockResolvedValueOnce({ id: 1, defaultLanguage: "en" });
    cmsMocks.updateClinicSettings.mockResolvedValueOnce({ id: 1, defaultLanguage: "ar" });
    const editor = appRouter.createCaller(contextFor("content_editor"));
    await expect(editor.cms.updateSettingsControl({ availableDays: "Monday", preferredTimes: "13:00", appointmentTreatmentOptions: "Face", visitTypeOptions: "session, retouch", defaultLanguage: "ar", maintenanceMode: false, appointmentFormEnabled: true })).resolves.toEqual({ id: 1, defaultLanguage: "ar" });
    expect(cmsMocks.updateClinicSettings).toHaveBeenCalledWith(expect.objectContaining({ defaultLanguage: "ar", appointmentFormEnabled: true }), { id: 1, name: "Nurse James" });
    cmsMocks.listSettingsChangeAudit.mockResolvedValueOnce([{ id: 1, changedFields: ["defaultLanguage"] }]);
    await expect(appRouter.createCaller(contextFor("admin")).cms.settingsChangeAudit()).resolves.toEqual([{ id: 1, changedFields: ["defaultLanguage"] }]);
    await expect(editor.cms.settingsChangeAudit()).rejects.toThrow();
  });

  it("allows content editors to save only managed-storage homepage appearance values", async () => {
    cmsMocks.updateClinicSettings.mockResolvedValueOnce({ id: 1, homepageTheme: "sage" });
    const editor = appRouter.createCaller(contextFor("content_editor"));
    await expect(editor.cms.updateClinicSettings({
      homepageTheme: "sage",
      homepageHeroImageUrl: "/manus-storage/cms-media/1/hero.webp",
      homepageSpecialistImageUrl: "/manus-storage/cms-media/1/specialist.webp",
      homepageClinicImageUrl: "/manus-storage/cms-media/1/clinic.webp",
    })).resolves.toEqual({ id: 1, homepageTheme: "sage" });
    expect(cmsMocks.updateClinicSettings).toHaveBeenCalledWith(expect.objectContaining({ homepageTheme: "sage", homepageHeroImageUrl: "/manus-storage/cms-media/1/hero.webp" }), { id: 1, name: "Nurse James" });
    await expect(editor.cms.updateClinicSettings({ homepageHeroImageUrl: "https://example.com/unmanaged-image.jpg" })).rejects.toThrow();
    await expect(editor.cms.updateClinicSettings({ homepageHeroImageUrl: '/manus-storage/image")-invalid.webp' })).rejects.toThrow();
    await expect(appRouter.createCaller(contextFor("reception")).cms.updateClinicSettings({ homepageTheme: "graphite" })).rejects.toThrow();
  });

  it("keeps general enquiries protected from public callers while allowing authorized reception follow-up", async () => {
    sharedMocks.listEnquiries.mockResolvedValueOnce([{ id: 4, subject: "General question", status: "new" }]);
    await expect(appRouter.createCaller(contextFor("reception")).admin.enquiries()).resolves.toEqual([{ id: 4, subject: "General question", status: "new" }]);
    await expect(appRouter.createCaller(contextFor(null)).admin.enquiries()).rejects.toThrow();
  });

  it("returns only role-authorized results from the protected global admin search", async () => {
    mocks.listConsultationRequests.mockResolvedValueOnce([{ id: 9, publicRequestId: "JR-2026-000009", fullName: "Ahmad Khalid", whatsapp: "+966501234567", treatmentArea: "FULL BODY", treatmentAreas: null }]);
    sharedMocks.listEnquiries.mockResolvedValueOnce([]);
    cmsMocks.listTreatments.mockResolvedValueOnce([{ id: 3, nameEn: "Full Body", nameAr: null, slug: "full-body", isActive: true }]);
    cmsMocks.listPromotions.mockResolvedValueOnce([]); cmsMocks.listGuidePosts.mockResolvedValueOnce([]); cmsMocks.listFaqs.mockResolvedValueOnce([]); cmsMocks.listReviews.mockResolvedValueOnce([]);
    await expect(appRouter.createCaller(contextFor("admin")).admin.globalSearch({ query: "ahmad" })).resolves.toEqual(expect.arrayContaining([expect.objectContaining({ type: "request", title: "JR-2026-000009", path: "/admin/requests" })]));

    cmsMocks.listTreatments.mockResolvedValueOnce([{ id: 3, nameEn: "Full Body", nameAr: null, slug: "full-body", isActive: true }]);
    cmsMocks.listPromotions.mockResolvedValueOnce([]); cmsMocks.listGuidePosts.mockResolvedValueOnce([]); cmsMocks.listFaqs.mockResolvedValueOnce([]); cmsMocks.listReviews.mockResolvedValueOnce([]);
    const editorResults = await appRouter.createCaller(contextFor("content_editor")).admin.globalSearch({ query: "full" });
    expect(editorResults).toEqual([expect.objectContaining({ type: "treatment", title: "Full Body", path: "/admin/treatments" })]);
    expect(editorResults.some(item => item.type === "request" || item.type === "enquiry")).toBe(false);
  });

  it("allows only owner and admin roles to read anonymous analytics and authorized exports", async () => {
    sharedMocks.analyticsOverview.mockResolvedValueOnce({ pageViews: 3, formSubmissions: 1 });
    sharedMocks.exportRows.mockResolvedValueOnce([{ id: 1, status: "pending" }]);
    const admin = appRouter.createCaller(contextFor("admin"));
    await expect(admin.admin.analytics()).resolves.toEqual({ pageViews: 3, formSubmissions: 1 });
    await expect(admin.admin.dataExport({ kind: "appointment_requests" })).resolves.toEqual([{ id: 1, status: "pending" }]);
    await expect(appRouter.createCaller(contextFor("content_editor")).admin.analytics()).rejects.toThrow();
    await expect(appRouter.createCaller(contextFor("reception")).admin.dataExport({ kind: "treatments" })).rejects.toThrow();
  });

  it("forwards protected redirect management through the server-side validator and denies non-admin roles", async () => {
    sharedMocks.saveRedirect.mockResolvedValueOnce({ id: 7, fromPath: "/old", toPath: "/new", isActive: true });
    const owner = appRouter.createCaller(contextFor("owner"));
    await expect(owner.admin.saveRedirect({ fromPath: "/old", toPath: "/new", isActive: true })).resolves.toEqual({ id: 7, fromPath: "/old", toPath: "/new", isActive: true });
    expect(sharedMocks.saveRedirect).toHaveBeenCalledWith({ fromPath: "/old", toPath: "/new", isActive: true }, expect.objectContaining({ id: 1 }));
    await expect(appRouter.createCaller(contextFor("content_editor")).admin.saveRedirect({ fromPath: "/old", toPath: "/new", isActive: true })).rejects.toThrow();
  });

  it("accepts a validated public enquiry only through the guarded private inbox flow", async () => {
    sharedMocks.createEnquiry.mockResolvedValueOnce({ id: 18 });
    const caller = appRouter.createCaller(contextFor(null));
    await expect(caller.enquiry.create({ name: "Hassan Ali", mobile: "+966501234567", email: null, subject: "Clinic information", message: "May I ask a general question?", language: "en", source: "website_contact_form", website: "" })).resolves.toEqual({ success: true, enquiryId: 18 });
    expect(sharedMocks.guardPublicSubmission).toHaveBeenCalledWith("enquiry", expect.any(String), expect.any(String));
    expect(sharedMocks.createEnquiry).toHaveBeenCalledWith(expect.objectContaining({ status: "new", internalNotes: null }));
  });

  it("rejects unsupported CMS media before any storage action is attempted", async () => {
    const editor = appRouter.createCaller(contextFor("content_editor"));
    await expect(editor.cms.uploadMedia({ fileName: "clinic-animation.gif", mimeType: "image/gif" as "image/jpeg", dataBase64: "dGVzdA==", altEn: null, altAr: null })).rejects.toThrow();
  });

  it("creates promotion AI output only as an authorized private draft and never saves or publishes it", async () => {
    promotionAiMocks.generatePromotionDraft.mockResolvedValueOnce({ slug: "clinic-review-offer", titleEn: "Clinic Review Offer", titleAr: "عرض مراجعة العيادة", name: "Clinic review offer", descriptionEn: "Approved offer details.", descriptionAr: "تفاصيل العرض المعتمد.", includedTreatments: "Approved service", originalPrice: "500.00", promotionalPrice: "350.00", sessionCount: 1, retouchIncluded: false, startsAt: null, endsAt: null, termsEn: "Reviewed terms.", termsAr: "شروط تمت مراجعتها.", reviewChecklist: ["Verify price.", "Verify terms.", "Approve publication."], model: "gpt-5-mini" });
    const editor = appRouter.createCaller(contextFor("content_editor"));
    await expect(editor.cms.generatePromotionDraft({ sourceDetails: "Approved promotion details with a stated price and terms.", sourceImageUrl: null })).resolves.toEqual(expect.objectContaining({ slug: "clinic-review-offer", model: "gpt-5-mini" }));
    expect(promotionAiMocks.generatePromotionDraft).toHaveBeenCalledWith({ sourceDetails: "Approved promotion details with a stated price and terms.", sourceImageUrl: null });
    expect(cmsMocks.savePromotion).not.toHaveBeenCalled();
    await expect(appRouter.createCaller(contextFor("user")).cms.generatePromotionDraft({ sourceDetails: "Approved promotion details with a stated price and terms.", sourceImageUrl: null })).rejects.toThrow();
  });

  it("allows a content editor to update media metadata without exposing the library publicly", async () => {
    cmsMocks.updateMediaItem.mockResolvedValueOnce(undefined);
    const editor = appRouter.createCaller(contextFor("content_editor"));
    await expect(editor.cms.updateMediaItem({ id: 9, fileName: "james-laser-face.webp", altEn: "Laser treatment equipment", altAr: null })).resolves.toEqual({ success: true });
    expect(cmsMocks.updateMediaItem).toHaveBeenCalledWith(9, expect.objectContaining({ fileName: "james-laser-face.webp" }), expect.objectContaining({ id: 1 }));
    await expect(appRouter.createCaller(contextFor(null)).cms.updateMediaItem({ id: 9, fileName: "hidden.webp", altEn: null, altAr: null })).rejects.toThrow();
  });

  it("approves a pending request only through an admin caller and records its selected machine", async () => {
    mocks.approveConsultationRequest.mockResolvedValueOnce({ appointmentId: 19, patientId: 7, existingPatientFound: false, matchedBy: null });
    const caller = appRouter.createCaller(contextFor("admin"));

    await expect(caller.admin.approveRequest({ requestId: 8, fullName: "Ahmad Khalid", whatsapp: "+966501234567", nationality: "Saudi", mrn: "MRN-1008", appointmentDate: "2026-09-03", appointmentTime: "18:00", treatmentArea: "FULL BODY", treatmentAreas: ["FULL BODY", "Back"], machine: "GENTLE PROMAX", visitType: "session", finalizedNotes: "Confirm preparation instructions.", assignedStaff: "Nurse James", durationMinutes: 45 }))
      .resolves.toEqual({ success: true, appointmentId: 19, patientId: 7, existingPatientFound: false, matchedBy: null });

    expect(mocks.approveConsultationRequest).toHaveBeenCalledWith(8, expect.objectContaining({ fullName: "Ahmad Khalid", whatsapp: "+966501234567", nationality: "Saudi", mrn: "MRN-1008", machine: "GENTLE PROMAX", treatmentArea: "FULL BODY", treatmentAreas: ["FULL BODY", "Back"], visitType: "session", durationMinutes: 45 }), "Nurse James");
  });

  it("surfaces existing-patient reuse metadata for an approved request without changing the protected route", async () => {
    mocks.approveConsultationRequest.mockResolvedValueOnce({ appointmentId: 20, patientId: 7, existingPatientFound: true, matchedBy: "mrn" });
    const caller = appRouter.createCaller(contextFor("reception"));
    await expect(caller.admin.approveRequest({ requestId: 9, fullName: "Existing patient", whatsapp: "+966500000001", nationality: "Saudi", mrn: "MRN-1009", appointmentDate: "2026-09-04", appointmentTime: "18:00", treatmentArea: "FACE", treatmentAreas: ["FACE"], machine: "GENTLE PROMAX", visitType: "retouch" })).resolves.toMatchObject({ success: true, patientId: 7, existingPatientFound: true, matchedBy: "mrn" });
  });

  it("rejects an unsupported machine before it can be recorded", async () => {
    const caller = appRouter.createCaller(contextFor("admin"));
    await expect(caller.admin.approveRequest({ requestId: 8, fullName: "Ahmad Khalid", whatsapp: "+966501234567", nationality: "Saudi", mrn: "MRN-1008", appointmentDate: "2026-09-03", appointmentTime: "18:00", treatmentArea: "FULL BODY", treatmentAreas: ["FULL BODY"], machine: "Other machine" as "GENTLE PROMAX", visitType: "session" }))
      .rejects.toThrow();
  });

  it("requires a manual MRN and a valid session-or-retouch classification before approval", async () => {
    const caller = appRouter.createCaller(contextFor("admin"));
    await expect(caller.admin.approveRequest({ requestId: 8, fullName: "Ahmad Khalid", whatsapp: "+966501234567", nationality: "Saudi", mrn: "", appointmentDate: "2026-09-03", appointmentTime: "18:00", treatmentArea: "FULL BODY", treatmentAreas: ["FULL BODY"], machine: "GENTLE PROMAX", visitType: "other" as "session" })).rejects.toThrow();
  });

  it("requires a 15-minute final time and requires the primary area to remain in the finalized treatment-area list", async () => {
    const caller = appRouter.createCaller(contextFor("admin"));
    const shared = { requestId: 8, fullName: "Ahmad Khalid", whatsapp: "+966501234567", nationality: "Saudi", mrn: "MRN-1008", appointmentDate: "2026-09-03", treatmentArea: "FULL BODY" as const, machine: "GENTLE PROMAX" as const, visitType: "session" as const };
    await expect(caller.admin.approveRequest({ ...shared, appointmentTime: "18:10", treatmentAreas: ["FULL BODY"] })).rejects.toThrow();
    await expect(caller.admin.approveRequest({ ...shared, appointmentTime: "18:00", treatmentAreas: ["Back"] })).rejects.toThrow();
    await expect(appRouter.createCaller(contextFor("user")).admin.approveRequest({ ...shared, appointmentTime: "18:00", treatmentAreas: ["FULL BODY"] })).rejects.toThrow();
  });

  it("records structured arrival details, nurse notes, and patient-profile linking only through an authorized clinic caller", async () => {
    mocks.confirmAppointmentArrival.mockResolvedValueOnce({ patientId: 27, createdPatient: true });
    const caller = appRouter.createCaller(contextFor("admin"));
    const details = { appointmentId: 19, fullName: "Ahmad Khalid", mrn: "MRN-0019", nationality: "Saudi Arabia", contactNumber: "+966501234567", whatsapp: "+966501234567", email: "", treatmentAreas: ["Full back", "Shoulders"] as const, machine: "CLARITY 2" as const, visitType: "retouch" as const, nurseNotes: "Skin reviewed on arrival; proceed with the planned assessment." };
    await expect(caller.admin.confirmArrival(details)).resolves.toEqual({ success: true, patientId: 27, createdPatient: true });
    expect(mocks.confirmAppointmentArrival).toHaveBeenCalledWith({ ...details, email: null }, "Nurse James");
    await expect(caller.admin.confirmArrival({ ...details, nurseNotes: "" })).rejects.toThrow();
    await expect(caller.admin.confirmArrival({ ...details, treatmentAreas: [] })).rejects.toThrow();
    await expect(caller.admin.confirmArrival({ ...details, machine: "UNKNOWN" as "CLARITY 2" })).rejects.toThrow();
    await expect(caller.admin.confirmArrival({ ...details, visitType: "unknown" as "retouch" })).rejects.toThrow();
    await expect(appRouter.createCaller(contextFor("user")).admin.confirmArrival(details)).rejects.toThrow();
    await expect(caller.admin.markAttendance({ appointmentId: 19, status: "waiting" as "completed" })).rejects.toThrow();
  });

  it("records the same protected intake details before a confirmed appointment becomes waiting", async () => {
    mocks.markAppointmentWaiting.mockResolvedValueOnce({ patientId: 27, createdPatient: false });
    const caller = appRouter.createCaller(contextFor("admin"));
    const details = { appointmentId: 19, fullName: "Ahmad Khalid", mrn: "MRN-0019", nationality: "Saudi Arabia", contactNumber: "+966501234567", whatsapp: "+966501234567", email: "", treatmentAreas: ["Full back", "Shoulders"] as const, machine: "CLARITY 2" as const, visitType: "retouch" as const, nurseNotes: "Registered in the waiting list with a completed intake review." };
    await expect(caller.admin.markWaiting(details)).resolves.toEqual({ success: true, patientId: 27, createdPatient: false });
    expect(mocks.markAppointmentWaiting).toHaveBeenCalledWith({ ...details, email: null }, "Nurse James");
    await expect(caller.admin.markWaiting({ ...details, nurseNotes: "" })).rejects.toThrow();
    await expect(appRouter.createCaller(contextFor("user")).admin.markWaiting(details)).rejects.toThrow();
  });

  it("requires protected outcome and nurse notes before an arrived appointment can be finished", async () => {
    sessionMocks.finishAppointmentWithPostSessionNotes.mockResolvedValueOnce({ sessionRecordId: 74 });
    const caller = appRouter.createCaller(contextFor("admin"));
    const notes = { appointmentId: 19, nurseName: "", outcome: "Treatment completed without an adverse event.", notes: "Post-session advice was reviewed with the patient." };
    await expect(caller.admin.finishSession(notes)).resolves.toEqual({ success: true, sessionRecordId: 74 });
    expect(sessionMocks.finishAppointmentWithPostSessionNotes).toHaveBeenCalledWith({ ...notes, nurseName: null }, { id: 1, name: "Nurse James" });
    await expect(caller.admin.finishSession({ ...notes, outcome: "" })).rejects.toThrow();
    await expect(caller.admin.finishSession({ ...notes, notes: "" })).rejects.toThrow();
    await expect(appRouter.createCaller(contextFor("user")).admin.finishSession(notes)).rejects.toThrow();
    await expect(caller.admin.markAttendance({ appointmentId: 19, status: "completed" as "arrived" })).rejects.toThrow();
  });

  it("denies waiting-list access to a non-admin user", async () => {
    const caller = appRouter.createCaller(contextFor("user"));
    await expect(caller.admin.waitingList()).rejects.toThrow();
  });

  it("returns a patient-file lookup only to an admin caller", async () => {
    mocks.getPatientFile.mockResolvedValueOnce({ patient: { id: 7, fullName: "Ahmad Khalid" }, appointments: [] });
    const caller = appRouter.createCaller(contextFor("admin"));
    await expect(caller.admin.patientFile({ patientId: 7 })).resolves.toEqual({ patient: { id: 7, fullName: "Ahmad Khalid" }, appointments: [] });
    expect(mocks.getPatientFile).toHaveBeenCalledWith(7);
  });

  it("denies patient search to a non-admin user", async () => {
    const caller = appRouter.createCaller(contextFor("user"));
    await expect(caller.admin.patients({ query: "Ahmad" })).rejects.toThrow();
  });

  it("returns matching patient files only to an admin and forwards the WhatsApp or name query", async () => {
    mocks.listPatients.mockResolvedValueOnce([{ id: 7, fullName: "Ahmad Khalid", whatsapp: "+966501234567" }]);
    const caller = appRouter.createCaller(contextFor("admin"));
    await expect(caller.admin.patients({ query: "+966501234567" })).resolves.toEqual([
      { id: 7, fullName: "Ahmad Khalid", whatsapp: "+966501234567" },
    ]);
    expect(mocks.listPatients).toHaveBeenCalledWith("+966501234567");
  });

  it("allows an admin to save a manual machine ID for an approved clinic machine", async () => {
    mocks.updateMachineNumber.mockResolvedValueOnce(undefined);
    const caller = appRouter.createCaller(contextFor("admin"));
    await expect(caller.admin.updateMachineNumber({ name: "CLARITY 2", machineNumber: "JL-M-202" })).resolves.toEqual({ success: true });
    expect(mocks.updateMachineNumber).toHaveBeenCalledWith("CLARITY 2", "JL-M-202");
  });

  it("denies machine inventory access to a non-admin user", async () => {
    const caller = appRouter.createCaller(contextFor("user"));
    await expect(caller.admin.machines()).rejects.toThrow();
  });
});
