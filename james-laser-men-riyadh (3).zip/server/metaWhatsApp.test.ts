import { createHmac } from "node:crypto";
import { afterEach, describe, expect, it, vi } from "vitest";
import { CANONICAL_BUSINESS_PORTFOLIO, CANONICAL_WABA_ID, CANONICAL_WABA_NAME, getMetaWhatsAppConfig, registerMetaWhatsAppWebhook, sendMetaWhatsAppTemplate, sendMetaWhatsAppText, submitMetaWhatsAppUtilityTemplate } from "./metaWhatsApp";

const originalEnv = { ...process.env };

function configureMeta() {
  vi.stubEnv("META_APP_ID", "app-id");
  vi.stubEnv("META_APP_SECRET", "app-secret");
  vi.stubEnv("WHATSAPP_ACCESS_TOKEN", "access-token");
  vi.stubEnv("WHATSAPP_PHONE_NUMBER_ID", "phone-id");
  vi.stubEnv("WHATSAPP_BUSINESS_ACCOUNT_ID", CANONICAL_WABA_ID);
  vi.stubEnv("WHATSAPP_WEBHOOK_VERIFY_TOKEN", "verify-token");
  vi.stubEnv("META_GRAPH_API_VERSION", "v99.0");
}

function clearMeta() {
  for (const key of ["META_APP_ID", "META_APP_SECRET", "WHATSAPP_ACCESS_TOKEN", "WHATSAPP_PHONE_NUMBER_ID", "WHATSAPP_BUSINESS_ACCOUNT_ID", "WHATSAPP_WEBHOOK_VERIFY_TOKEN", "META_GRAPH_API_VERSION"]) {
    vi.stubEnv(key, "");
  }
}

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
  process.env = { ...originalEnv };
});

describe("Meta WhatsApp Cloud API client", () => {
  it("does not report configured until every server-side value exists", () => {
    clearMeta();
    expect(getMetaWhatsAppConfig()).toBeNull();
    configureMeta();
    expect(getMetaWhatsAppConfig()).toMatchObject({ phoneNumberId: "phone-id", businessAccountId: CANONICAL_WABA_ID });
  });

  it("fails closed for a configured WABA other than the canonical clinic WABA", () => {
    configureMeta();
    vi.stubEnv("WHATSAPP_BUSINESS_ACCOUNT_ID", "9999999999999999");
    expect(getMetaWhatsAppConfig()).toBeNull();
    expect(CANONICAL_WABA_NAME).toBe("James Laser Hair Removal WhatsApp Business App");
    expect(CANONICAL_BUSINESS_PORTFOLIO).toBe("JAMES LASER");
  });

  it("sends a server-side text payload through the official graph endpoint without exposing token fields in the body", async () => {
    configureMeta();
    const fetchMock = vi.fn().mockResolvedValue(new Response(JSON.stringify({ messages: [{ id: "wamid.1" }] }), { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);
    await expect(sendMetaWhatsAppText({ to: "+966551234567", body: "Hello" })).resolves.toEqual({ messages: [{ id: "wamid.1" }] });
    const requestUrl = fetchMock.mock.calls[0][0] as string;
    const request = new URL(requestUrl);
    expect(`${request.origin}${request.pathname}`).toBe("https://graph.facebook.com/v99.0/phone-id/messages");
    expect(request.searchParams.get("appsecret_proof")).toBe(createHmac("sha256", "app-secret").update("access-token").digest("hex"));
    expect(requestUrl).not.toContain("app-secret");
    expect(requestUrl).not.toContain("access-token");
    const options = fetchMock.mock.calls[0][1];
    expect(options.headers.Authorization).toBe("Bearer access-token");
    expect(options.body).toContain('"to":"966551234567"');
    expect(options.body).not.toContain("access-token");
  });

  it("formats a template payload and returns a safe Meta error without token details", async () => {
    configureMeta();
    const fetchMock = vi.fn().mockResolvedValue(new Response(JSON.stringify({ error: { code: 131047, message: "access_token should never appear" } }), { status: 400 }));
    vi.stubGlobal("fetch", fetchMock);
    await expect(sendMetaWhatsAppTemplate({ to: "+966551234567", name: "appointment_reminder", language: "en_US" })).rejects.toThrow("[redacted]");
    expect(fetchMock.mock.calls[0][1].body).toContain('"type":"template"');
  });

  it("registers the WABA webhook using the server-side verification token only in the request body", async () => {
    configureMeta();
    const fetchMock = vi.fn().mockImplementation(() => Promise.resolve(new Response(JSON.stringify({ success: true }), { status: 200 })));
    vi.stubGlobal("fetch", fetchMock);

    await expect(registerMetaWhatsAppWebhook("https://www.jameslaserformen.com/api/webhooks/whatsapp")).resolves.toEqual({ success: true });

    const appRequest = new URL(fetchMock.mock.calls[0][0] as string);
    const wabaRequest = new URL(fetchMock.mock.calls[1][0] as string);
    expect(`${appRequest.origin}${appRequest.pathname}`).toBe("https://graph.facebook.com/v99.0/app-id/subscriptions");
    expect(`${wabaRequest.origin}${wabaRequest.pathname}`).toBe(`https://graph.facebook.com/v99.0/${CANONICAL_WABA_ID}/subscribed_apps`);
    expect(appRequest.search).not.toContain("verify-token");
    expect(wabaRequest.search).not.toContain("verify-token");
    expect(fetchMock.mock.calls[0][1].body).toContain("verify_token=verify-token");
    expect(fetchMock.mock.calls[1][1].body).toContain('"verify_token":"verify-token"');
    expect(JSON.stringify(fetchMock.mock.calls.map(call => call[1].headers))).not.toContain("verify-token");
  });

  it("submits a utility template for approval without sending a WhatsApp message", async () => {
    configureMeta();
    const fetchMock = vi.fn().mockResolvedValue(new Response(JSON.stringify({ id: "template-id", status: "PENDING", category: "UTILITY" }), { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);

    await expect(submitMetaWhatsAppUtilityTemplate({
      name: "james_test_utility_en",
      language: "en_US",
      category: "UTILITY",
      components: [{ type: "BODY", text: "Hello {{1}}.", example: { body_text: [["Customer"]] } }],
    })).resolves.toMatchObject({ status: "PENDING" });

    const request = new URL(fetchMock.mock.calls[0][0] as string);
    expect(`${request.origin}${request.pathname}`).toBe(`https://graph.facebook.com/v99.0/${CANONICAL_WABA_ID}/message_templates`);
    const body = JSON.parse(fetchMock.mock.calls[0][1].body);
    expect(body).toMatchObject({ category: "UTILITY" });
    expect(body).not.toHaveProperty("parameter_format");
    expect(body).not.toHaveProperty("messaging_product");
  });
});
