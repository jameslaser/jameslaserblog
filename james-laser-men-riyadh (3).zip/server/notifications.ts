import { desc, eq } from "drizzle-orm";
import { notifications } from "../drizzle/schema";
import { getDb } from "./db";

export type NotificationKind = "appointment_request" | "enquiry" | "review" | "promotion" | "system";

async function database() {
  const db = await getDb();
  if (!db) throw new Error("The notification service is temporarily unavailable.");
  return db;
}

/** Notification messages are intentionally generic: protected recipient actions reveal private details only after server authorization. */
export async function createStaffNotification(input: { type: NotificationKind; title: string; message: string; linkPath?: string | null }) {
  const db = await database();
  const [result] = await db.insert(notifications).values(input).$returningId();
  if (!result) throw new Error("Notification could not be created.");
  return result.id;
}

export async function listStaffNotifications() {
  const db = await database();
  return db.select().from(notifications).orderBy(desc(notifications.createdAt)).limit(50);
}

export async function markStaffNotificationRead(id: number) {
  const db = await database();
  await db.update(notifications).set({ isRead: true, readAt: new Date() }).where(eq(notifications.id, id));
  const result = await db.select({ id: notifications.id }).from(notifications).where(eq(notifications.id, id)).limit(1);
  if (result.length !== 1) throw new Error("Notification not found.");
}

export async function markAllStaffNotificationsRead() {
  const db = await database();
  await db.update(notifications).set({ isRead: true, readAt: new Date() }).where(eq(notifications.isRead, false));
}
