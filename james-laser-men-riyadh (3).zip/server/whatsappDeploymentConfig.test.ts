import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const root = resolve(import.meta.dirname, "..");

describe("Phase 2 WhatsApp Cloud Run deployment contract", () => {
  it("mounts every Meta runtime value from Secret Manager without Vite exposure", () => {
    const cloudBuild = readFileSync(resolve(root, "cloudbuild.yaml"), "utf8");
    for (const name of ["META_APP_ID", "META_APP_SECRET", "WHATSAPP_ACCESS_TOKEN", "WHATSAPP_PHONE_NUMBER_ID", "WHATSAPP_BUSINESS_ACCOUNT_ID", "WHATSAPP_WEBHOOK_VERIFY_TOKEN", "META_GRAPH_API_VERSION"]) {
      expect(cloudBuild).toContain(`${name}=`);
      expect(cloudBuild).not.toContain(`VITE_${name}`);
    }
    expect(cloudBuild).toContain("--update-secrets=");
    expect(cloudBuild).not.toContain("--secrets=");
    expect(cloudBuild).toContain("_META_APP_SECRET");
    expect(cloudBuild).toContain("_WHATSAPP_ACCESS_TOKEN_SECRET");
  });

  it("documents the HTTPS callback, server-side secret boundary, and private-media default", () => {
    const runbook = readFileSync(resolve(root, "PHASE2_WHATSAPP_DEPLOYMENT.md"), "utf8");
    expect(runbook).toContain("/api/webhooks/whatsapp");
    expect(runbook).toContain("Google Secret Manager");
    expect(runbook).toContain("not downloaded automatically");
  });
});
