import { describe, expect, it } from "vitest";
import {
  assertRevenuePreviewImportable,
  type RevenuePreview,
} from "./revenue";

function previewFixture(): RevenuePreview {
  return {
    fileSha256: "test-sha",
    fromDate: "2026-09-01",
    toDate: "2026-09-19",
    account: null,
    printDate: null,
    grandTotal: { gross: 200, quantity: 1, discount: 100, deduct: 0, net: 100 },
    rows: [],
    patients: [],
    fatalErrors: [],
    invalidRowCount: 0,
    subtotalRowCount: 1,
    grandTotalRowCount: 1,
    reconciliationDifferences: [],
    mrnDuplicateEntries: [],
    fileAlreadyImported: false,
    batchId: null,
    summary: {
      gross: 200,
      quantity: 1,
      discount: 100,
      deduct: 0,
      net: 100,
      patients: 1,
      serviceRows: 1,
      invalidRows: 0,
      duplicateRows: 0,
      warnings: 0,
      unmatchedPatients: 0,
      reconciliation: "PASS",
    },
  };
}

describe("revenue import guard", () => {
  it("allows an otherwise reconciled preview without MRN duplicate candidates", () => {
    expect(() => assertRevenuePreviewImportable(previewFixture(), false)).not.toThrow();
  });

  it("blocks exact repeated service entries under the same MRN on the server", () => {
    const preview = previewFixture();
    preview.mrnDuplicateEntries = [
      {
        mrn: "1001",
        sourceRowNumbers: [8, 9],
        serviceCode: "CLT02",
        serviceName: "Clarity Any Small Area",
        totals: { gross: 200, quantity: 1, discount: 100, deduct: 0, net: 100 },
      },
    ];

    expect(() => assertRevenuePreviewImportable(preview, false)).toThrow(
      "Revenue import blocked: exact repeated service entries were detected under the same MRN."
    );
  });
});
