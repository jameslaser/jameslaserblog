import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const routerSource = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");

describe("reception operational access", () => {
  it("allows reception staff to perform the explicitly defined clinic operations without granting sensitive import or manual-entry powers", () => {
    expect(routerSource).toContain("appointments: receptionProcedure");
    expect(routerSource).toContain("waitingList: receptionProcedure");
    expect(routerSource).toContain("markAttendance: receptionProcedure");
    expect(routerSource).toContain("patients: receptionProcedure");
    expect(routerSource).toContain("patientFile: receptionProcedure");
    expect(routerSource).toContain("machines: receptionProcedure");
    expect(routerSource).toContain("hmsImport: adminProcedure");
    expect(routerSource).toContain("createManualPatient: adminProcedure");
  });
});
