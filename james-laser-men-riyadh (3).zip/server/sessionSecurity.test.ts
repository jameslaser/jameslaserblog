import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { ADMIN_SESSION_MAX_AGE_MS } from "../shared/const";

const oauthSource = readFileSync(new URL("./_core/oauth.ts", import.meta.url), "utf8");

describe("administrative session security", () => {
  it("limits new sessions to an eight-hour maximum rather than a long-lived annual cookie", () => {
    expect(ADMIN_SESSION_MAX_AGE_MS).toBe(1000 * 60 * 60 * 8);
    expect(oauthSource).toContain("expiresInMs: ADMIN_SESSION_MAX_AGE_MS");
    expect(oauthSource).toContain("maxAge: ADMIN_SESSION_MAX_AGE_MS");
    expect(oauthSource).not.toContain("ONE_YEAR_MS");
  });
});
