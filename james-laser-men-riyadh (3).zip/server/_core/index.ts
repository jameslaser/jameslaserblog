import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { registerRedirectMiddleware } from "../redirectMiddleware";
import { registerCanonicalRedirects, configuredCanonicalOrigin } from "../canonical";
import { buildSitemapXml } from "../sitemap";
import { buildBlogRssXml } from "../rss";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { getDatabaseReadiness } from "../readiness";
import { resolveRuntimePort } from "./runtimePort";
import { getMetaWhatsAppConfig } from "../metaWhatsApp";
import { ingestMetaWhatsAppWebhook } from "../whatsappService";
import { runDueWhatsAppAutomation } from "../whatsappAutomation";
import { metaWebhookFingerprint, parseMetaWebhookPayload, verifyMetaWebhookChallenge, verifyMetaWebhookSignature } from "../whatsappWebhook";
import { registerGoogleBusinessOAuthRoutes } from "../googleBusiness";
import { sdk } from "./sdk";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  // The managed HTTPS proxy terminates TLS before proxying to this process. Trust only its
  // immediate proxy so secure session cookies use the forwarded HTTPS state.
  app.set("trust proxy", 1);
  const server = createServer(app);
  app.disable("x-powered-by");
  app.use((_req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
    res.setHeader("X-Frame-Options", "DENY");
    if (process.env.NODE_ENV === "production") {
      res.setHeader("Content-Security-Policy", "default-src 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'none'; frame-src 'self' https://d36hbw14aib5lz.cloudfront.net https://www.google.com; form-action 'self'; img-src 'self' data: https:; media-src 'self' https:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' data: https://fonts.gstatic.com; script-src 'self' https://manus-analytics.com; connect-src 'self' https:");
      res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
    }
    next();
  });
  app.get("/healthz", (_req, res) => {
    res.status(200).json({ status: "ok" });
  });
  app.get("/readyz", async (_req, res) => {
    const readiness = await getDatabaseReadiness();
    res
      .status(readiness.ready ? 200 : 503)
      .json({ status: readiness.ready ? "ready" : "not_ready" });
  });
  app.get("/sitemap.xml", async (req, res) => {
    const origin = configuredCanonicalOrigin();
    if (!origin) return res.status(503).type("text/plain").send("Sitemap is not configured.");
    try {
      const context = await createContext({ req, res } as Parameters<typeof createContext>[0]);
      const caller = appRouter.createCaller(context);
      const [guidePosts, policies] = await Promise.all([
        caller.publicContent.guidePosts(),
        caller.publicContent.policies(),
      ]);
      const xml = buildSitemapXml({ origin, guidePosts, policies });
      return res.status(200).set("Cache-Control", "public, max-age=300").type("application/xml").send(xml);
    } catch (error) {
      console.error("[Sitemap] generation failed:", error instanceof Error ? error.message : "unknown error");
      return res.status(503).type("text/plain").send("Sitemap is temporarily unavailable.");
    }
  });
  app.get("/blog/rss.xml", async (req, res) => {
    const origin = configuredCanonicalOrigin();
    if (!origin) return res.status(503).type("text/plain").send("Blog feed is not configured.");
    try {
      const context = await createContext({ req, res } as Parameters<typeof createContext>[0]);
      const caller = appRouter.createCaller(context);
      const articles = await caller.publicContent.guidePosts();
      return res.status(200).set("Cache-Control", "public, max-age=300").type("application/rss+xml").send(buildBlogRssXml(origin, articles));
    } catch (error) {
      console.error("[Blog RSS] generation failed:", error instanceof Error ? error.message : "unknown error");
      return res.status(503).type("text/plain").send("Blog feed is temporarily unavailable.");
    }
  });
  // Meta verifies this public endpoint with a challenge. It is deliberately
  // not behind staff authentication, but it requires the server-only verify
  // token and never reveals configuration details.
  app.get("/api/webhooks/whatsapp", (req, res) => {
    const challenge = verifyMetaWebhookChallenge(req.query);
    if (!challenge) return res.status(403).send("Forbidden");
    return res.status(200).type("text/plain").send(challenge);
  });

  // Register the raw route before JSON parsing: Meta's HMAC covers the exact
  // original bytes, not a reserialized JSON object. The 3 MB cap matches the
  // documented webhook payload maximum and is isolated from public tRPC input.
  app.post("/api/webhooks/whatsapp", express.raw({ type: "application/json", limit: "3mb" }), async (req, res) => {
    const config = getMetaWhatsAppConfig();
    const rawBody = Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0);
    if (!config || !verifyMetaWebhookSignature(rawBody, req.header("x-hub-signature-256") ?? undefined, config.appSecret)) {
      return res.status(401).json({ error: "Invalid webhook signature" });
    }
    const payload = parseMetaWebhookPayload(rawBody);
    if (!payload) return res.status(400).json({ error: "Invalid WhatsApp webhook payload" });
    try {
      await ingestMetaWhatsAppWebhook({ fingerprint: metaWebhookFingerprint(rawBody), payload });
      return res.status(200).json({ received: true });
    } catch (error) {
      console.error("[WhatsApp webhook] processing failed", error instanceof Error ? error.message : "unknown error");
      return res.status(500).json({ error: "Webhook processing failed" });
    }
  });

  // CMS media is decoded and constrained to 10 MB by its protected procedure.
  // Its base64 JSON envelope is larger than the binary file, so this narrowly
  // scoped parser must run before the default tRPC body limit. Other API routes
  // retain the lower transport ceiling below.
  app.use("/api/trpc/cms.uploadMedia", express.json({ limit: "14mb" }));

  // Standard tRPC payloads are individually validated below 1 MB. A 2 MB
  // transport ceiling accommodates JSON envelopes without accepting oversized
  // bodies across every other route.
  app.use(express.json({ limit: "2mb" }));
  app.use(express.urlencoded({ limit: "2mb", extended: true }));
  // This callback is intentionally dormant until an owner configures the
  // project heartbeat and saves its task UID in the protected WhatsApp setup.
  // It never accepts a task identifier from the HTTP body.
  app.post("/api/scheduled/whatsapp-automation", async (req, res) => {
    const user = await sdk.authenticateRequest(req).catch(() => null);
    if (!user?.isCron || !user.taskUid) return res.status(403).json({ error: "cron-only" });
    try {
      const result = await runDueWhatsAppAutomation(user.taskUid);
      return res.status(200).json({ ok: true, ...result });
    } catch {
      return res.status(500).json({
        error: "WhatsApp automation scheduler failed.",
        context: { path: "/api/scheduled/whatsapp-automation" },
        timestamp: new Date().toISOString(),
      });
    }
  });
  registerStorageProxy(app);
  registerOAuthRoutes(app);
  registerGoogleBusinessOAuthRoutes(app);
  registerCanonicalRedirects(app);
  registerRedirectMiddleware(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const { port: preferredPort, requireExactPort } = resolveRuntimePort();
  const port = requireExactPort ? preferredPort : await findAvailablePort(preferredPort);

  if (!requireExactPort && port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  await new Promise<void>((resolve, reject) => {
    server.once("error", reject);
    server.listen(port, () => {
      server.off("error", reject);
      resolve();
    });
  });
  console.log(`Server running on http://localhost:${port}/`);
}

startServer().catch(console.error);
