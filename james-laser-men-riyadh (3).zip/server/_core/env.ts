export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  // The managed clinic application remains on its existing MySQL/TiDB source.
  // PostgreSQL is reserved for the paused, explicit migration tooling.
  databaseUrl:
    process.env.MYSQL_URL ??
    (process.env.NODE_ENV === "production" ? "" : process.env.DATABASE_URL ?? ""),
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
  googleBusinessClientId: process.env.GOOGLE_BUSINESS_CLIENT_ID ?? "",
  googleBusinessClientSecret: process.env.GOOGLE_BUSINESS_CLIENT_SECRET ?? "",
  googleBusinessRedirectUri: process.env.GOOGLE_BUSINESS_REDIRECT_URI ?? "",
  googleBusinessTokenEncryptionKey: process.env.GOOGLE_BUSINESS_TOKEN_ENCRYPTION_KEY ?? "",
};
