import express, { type Express } from "express";
import fs from "fs";
import { type Server } from "http";
import { nanoid } from "nanoid";
import path from "path";
import { createServer as createViteServer } from "vite";
import superjson from "superjson";
import viteConfig from "../../vite.config";
import { configuredCanonicalOrigin } from "../canonical";
import { buildSsrPrefetch } from "./ssrCaller";
import type { AlternateLink, FaqSchemaItem, HeadMeta } from "../../client/src/ssr/prefetch";

const FALLBACK_SITE_NAME = "James Laser Hair Removal for Men Riyadh @ New Look Clinic";
const FALLBACK_DESCRIPTION = "Men’s laser hair removal information and appointment requests in Riyadh, Saudi Arabia.";
const FALLBACK_IMAGE = "/manus-storage/laser-treatment-male-clinic_c5465b0d.jpeg";
const SOCIAL_PROFILE_FIELDS = {
  instagramUrl: ["instagram.com", "www.instagram.com"],
  tiktokUrl: ["tiktok.com", "www.tiktok.com"],
  snapchatUrl: ["snapchat.com", "www.snapchat.com"],
  facebookUrl: ["facebook.com", "www.facebook.com"],
  youtubeUrl: ["youtube.com", "www.youtube.com", "m.youtube.com"],
  xUrl: ["x.com", "www.x.com", "twitter.com", "www.twitter.com"],
} as const;

type SocialProfileSettings = Partial<Record<keyof typeof SOCIAL_PROFILE_FIELDS, string | null | undefined>>;

function escapeHtml(value: string) {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

function compactText(value: string, maximum: number) {
  const compact = value.replace(/\s+/g, " ").trim();
  if (compact.length <= maximum) return compact;
  const boundary = compact.lastIndexOf(" ", maximum);
  return `${compact.slice(0, boundary > maximum * 0.6 ? boundary : maximum).trim()}…`;
}

function absoluteUrl(value: string | undefined, origin: string | null) {
  if (!value) return undefined;
  if (value.startsWith("//")) return `https:${value}`;
  if (value.startsWith("/")) return origin ? `${origin}${value}` : undefined;
  try {
    const parsed = new URL(value);
    return parsed.protocol === "https:" || parsed.protocol === "http:" ? parsed.toString() : undefined;
  } catch {
    return undefined;
  }
}

function jsonLd(value: unknown) {
  return JSON.stringify(value).replace(/</g, "\\u003c");
}

function verifiedSocialProfiles(settings: unknown) {
  if (!settings || typeof settings !== "object") return [];
  const profileSettings = settings as SocialProfileSettings;
  const profiles = Object.entries(SOCIAL_PROFILE_FIELDS).flatMap(([field, allowedHosts]) => {
    const rawUrl = profileSettings[field as keyof typeof SOCIAL_PROFILE_FIELDS];
    if (!rawUrl?.trim()) return [];
    try {
      const parsed = new URL(rawUrl);
      return parsed.protocol === "https:" && allowedHosts.includes(parsed.hostname.toLowerCase() as never) ? [parsed.toString()] : [];
    } catch {
      return [];
    }
  });
  return Array.from(new Set(profiles));
}

function breadcrumbSchema(origin: string, breadcrumbs: HeadMeta["breadcrumbs"]) {
  if (!breadcrumbs?.length) return null;
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: breadcrumbs.map((crumb, index) => ({ "@type": "ListItem", position: index + 1, name: crumb.name, item: `${origin}${crumb.path}` })),
  };
}

function faqSchema(faqItems: FaqSchemaItem[] | undefined) {
  if (!faqItems?.length) return null;
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqItems.map(item => ({ "@type": "Question", name: item.question, acceptedAnswer: { "@type": "Answer", text: item.answer } })),
  };
}

function websiteSchema(origin: string, language: "en" | "ar", socialProfiles: string[]) {
  return {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "LocalBusiness",
        "@id": `${origin}/#business`,
        name: FALLBACK_SITE_NAME,
        description: "Men’s laser hair removal service at New Look Clinic in Al Sahafah, Riyadh, Saudi Arabia.",
        url: `${origin}/`,
        telephone: "+966557401562",
        image: `${origin}${FALLBACK_IMAGE}`,
        address: { "@type": "PostalAddress", streetAddress: "New Look Clinic, Al Sahafah", addressLocality: "Riyadh", addressCountry: "SA" },
        areaServed: { "@type": "City", name: "Riyadh" },
        ...(socialProfiles.length ? { sameAs: socialProfiles } : {}),
        hasOfferCatalog: {
          "@type": "OfferCatalog",
          name: "Men's laser hair removal consultations",
          itemListElement: [{ "@type": "Offer", itemOffered: { "@type": "Service", name: "Laser hair removal consultation for men", serviceType: "Men's laser hair removal", areaServed: "Riyadh, Saudi Arabia" } }],
        },
      },
      { "@type": "WebSite", "@id": `${origin}/#website`, url: `${origin}/`, name: FALLBACK_SITE_NAME, inLanguage: language === "ar" ? "ar-SA" : "en-SA" },
    ],
  };
}

function alternateTags(origin: string, alternates: AlternateLink[] | undefined) {
  return (alternates ?? []).map(alternate => `<link rel="alternate" hreflang="${alternate.hrefLang}" href="${escapeHtml(`${origin}${alternate.path}`)}" />`).join("\n");
}

function buildHeadTags(head: HeadMeta, socialProfiles: string[] = []) {
  const origin = configuredCanonicalOrigin();
  const title = escapeHtml(compactText(head.title || FALLBACK_SITE_NAME, 70));
  const description = escapeHtml(compactText(head.description || FALLBACK_DESCRIPTION, 200));
  const canonical = head.canonicalPath && origin ? `${origin}${head.canonicalPath}` : undefined;
  const image = absoluteUrl(head.ogImage ?? FALLBACK_IMAGE, origin);
  const locale = head.locale ?? "en_SA";
  const language = head.documentLanguage ?? "en";
  const tags = [
    `<title>${title}</title>`,
    `<meta name="description" content="${description}" />`,
    `<meta name="robots" content="${head.noindex || head.notFound ? "noindex, follow, noarchive" : "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1"}" />`,
    `<meta property="og:type" content="${head.ogType ?? "website"}" />`,
    `<meta property="og:site_name" content="${escapeHtml(process.env.SITE_NAME || FALLBACK_SITE_NAME)}" />`,
    `<meta property="og:title" content="${title}" />`,
    `<meta property="og:description" content="${description}" />`,
    `<meta property="og:locale" content="${locale}" />`,
    `<meta name="twitter:card" content="${image ? "summary_large_image" : "summary"}" />`,
    `<meta name="twitter:title" content="${title}" />`,
    `<meta name="twitter:description" content="${description}" />`,
  ];
  if (canonical && origin) {
    tags.push(`<link rel="canonical" href="${escapeHtml(canonical)}" />`);
    tags.push(`<meta property="og:url" content="${escapeHtml(canonical)}" />`);
    tags.push(`<meta name="twitter:url" content="${escapeHtml(canonical)}" />`);
    tags.push(alternateTags(origin, head.alternates));
  }
  if (image) {
    tags.push(`<meta property="og:image" content="${escapeHtml(image)}" />`);
    tags.push(`<meta property="og:image:alt" content="${escapeHtml(head.ogImageAlt || FALLBACK_SITE_NAME)}" />`);
    tags.push(`<meta name="twitter:image" content="${escapeHtml(image)}" />`);
  }
  if (head.ogType === "article") {
    if (head.articlePublishedTime) tags.push(`<meta property="article:published_time" content="${escapeHtml(head.articlePublishedTime)}" />`);
    if (head.articleModifiedTime) tags.push(`<meta property="article:modified_time" content="${escapeHtml(head.articleModifiedTime)}" />`);
    if (head.articleSection) tags.push(`<meta property="article:section" content="${escapeHtml(head.articleSection)}" />`);
    for (const tag of head.articleTags ?? []) tags.push(`<meta property="article:tag" content="${escapeHtml(tag)}" />`);
  }
  if (origin && !head.noindex && !head.notFound) {
    tags.push(`<script type="application/ld+json">${jsonLd(websiteSchema(origin, language, socialProfiles))}</script>`);
    const breadcrumb = breadcrumbSchema(origin, head.breadcrumbs);
    if (breadcrumb) tags.push(`<script type="application/ld+json">${jsonLd(breadcrumb)}</script>`);
    const faq = faqSchema(head.faqItems);
    if (faq) tags.push(`<script type="application/ld+json">${jsonLd(faq)}</script>`);
    if (head.contentSchema) tags.push(`<script type="application/ld+json">${jsonLd(head.contentSchema)}</script>`);
  }
  return tags.filter(Boolean).join("\n");
}

function composeHtml(template: string, appHtml: string, head: HeadMeta, dehydratedState: unknown, socialProfiles: string[] = []) {
  const language = head.documentLanguage ?? "en";
  const direction = language === "ar" ? "rtl" : "ltr";
  const state = JSON.stringify(superjson.serialize(dehydratedState)).replace(/</g, "\\u003c");
  return template
    .replace("<html lang=\"en\">", () => `<html lang="${language}" dir="${direction}">`)
    .replace("</body>", () => `<script id="__RQ_STATE__" type="application/json">${state}</script></body>`)
    .replace("<!--app-head-->", () => buildHeadTags(head, socialProfiles))
    .replace("<!--app-html-->", () => appHtml);
}

function fallbackHtml(template: string) {
  return composeHtml(template, "", { title: "Service temporarily unavailable", description: FALLBACK_DESCRIPTION, noindex: true }, {});
}

const VITE_PREVIEW_CLIENT_SHIM = [
  "const noop = () => {};",
  "const hot = { accept: noop, acceptExports: noop, dispose: noop, prune: noop, invalidate: noop, on: noop, off: noop, send: noop, data: {} };",
  "export const createHotContext = () => hot;",
  "export const injectQuery = (url) => url;",
  "export const updateStyle = noop;",
  "export const removeStyle = noop;",
  "export const waitForSuccessfulPing = async () => {};",
  "export const ErrorOverlay = class {};",
  "export const createErrorOverlay = () => null;",
].join("\n");

function stripViteDevClient(template: string) {
  // Vite injects this client during transformIndexHtml even when HMR is disabled.
  // The managed preview gateway is HTTP-only, so the injected client would retry
  // an unreachable WebSocket and surface a browser-console error on every load.
  return template.replace(/<script\b[^>]*\bsrc=["']\/@vite\/client(?:\?[^"']*)?["'][^>]*>\s*<\/script>\s*/gi, "");
}

export async function setupVite(app: Express, server: Server) {
  // The managed preview gateway proxies HTTP to this Express server but does
  // not expose Vite's internal HMR socket. Disable the development-only client
  // websocket instead of advertising an unreachable localhost connection.
  const vite = await createViteServer({ ...viteConfig, configFile: false, server: { middlewareMode: true, hmr: false, ws: false, allowedHosts: true as const }, appType: "custom" });
  // A preview page opened before a server restart can still request Vite's client.
  // Serve a harmless compatibility module so that stale requests cannot open an
  // unreachable HMR WebSocket through the managed HTTP-only gateway.
  app.get("/@vite/client", (_req, res) => {
    res.status(200).set("Cache-Control", "no-store").type("application/javascript").send(VITE_PREVIEW_CLIENT_SHIM);
  });
  app.use(vite.middlewares);
  app.use("*", async (req, res, next) => {
    try {
      const clientTemplate = path.resolve(import.meta.dirname, "../..", "client", "index.html");
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(`src="/src/entry-client.tsx"`, `src="/src/entry-client.tsx?v=${nanoid()}"`);
      template = await vite.transformIndexHtml(req.originalUrl, template);
      template = stripViteDevClient(template);
      template = template.replace("</head>", `<link rel="stylesheet" href="/src/index.css?direct" data-ssr-dev-css></head>`);
      const { render } = await vite.ssrLoadModule("/src/entry-server.tsx");
      const prefetch = await buildSsrPrefetch(req, res);
      const { html, dehydratedState, head } = await render(req.originalUrl, prefetch);
      const socialProfiles = verifiedSocialProfiles(await prefetch.clinicSettings());
      res.status(head.notFound ? 404 : 200).set("Cache-Control", "no-cache").type("html").end(composeHtml(template, html, head, dehydratedState, socialProfiles));
    } catch (error) {
      vite.ssrFixStacktrace(error as Error);
      console.error("[SSR] development render failed:", error);
      next(error);
    }
  });
}

export function serveStatic(app: Express) {
  const distPath = process.env.NODE_ENV === "development" ? path.resolve(import.meta.dirname, "../..", "dist", "public") : path.resolve(import.meta.dirname, "public");
  if (!fs.existsSync(distPath)) console.error(`Could not find the build directory: ${distPath}, make sure to build the client first`);
  const staticFiles = express.static(distPath, { index: false, redirect: false });
  // Keep the canonical root request out of the static middleware so it reaches
  // the SSR handler below. Static assets remain served directly.
  app.use((req, res, next) => req.path === "/" ? next() : staticFiles(req, res, next));
  const templatePath = path.resolve(distPath, "index.html");
  const serverEntryPath = process.env.NODE_ENV === "development" ? path.resolve(import.meta.dirname, "../..", "dist", "server-ssr", "entry-server.js") : path.resolve(import.meta.dirname, "server-ssr", "entry-server.js");
  app.use("*", async (req, res) => {
    try {
      const [template, ssrModule] = await Promise.all([fs.promises.readFile(templatePath, "utf-8"), import(serverEntryPath)]);
      const prefetch = await buildSsrPrefetch(req, res);
      const { html, dehydratedState, head } = await ssrModule.render(req.originalUrl, prefetch);
      const socialProfiles = verifiedSocialProfiles(await prefetch.clinicSettings());
      res.status(head.notFound ? 404 : 200).set("Cache-Control", "no-cache").type("html").end(composeHtml(template, html, head, dehydratedState, socialProfiles));
    } catch (error) {
      console.error("[SSR] render failed, serving client shell:", error);
      const template = await fs.promises.readFile(templatePath, "utf-8");
      res.status(503).set("Cache-Control", "no-store").type("html").end(fallbackHtml(template));
    }
  });
}
