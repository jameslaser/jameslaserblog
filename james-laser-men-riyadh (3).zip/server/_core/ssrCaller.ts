import type { Request, Response } from "express";
import type { SsrPrefetch } from "../../client/src/ssr/prefetch";
import { appRouter } from "../routers";
import { createContext } from "./context";

/**
 * Builds an allowlisted, in-process caller for public SSR data. It avoids a
 * loopback HTTP request and intentionally excludes all mutations and private
 * procedures from the rendering path.
 */
export async function buildSsrPrefetch(req: Request, res: Response): Promise<SsrPrefetch> {
  const context = await createContext({ req, res } as Parameters<typeof createContext>[0]);
  const caller = appRouter.createCaller(context);
  const clinicSettings = caller.publicContent.clinicSettings();
  return {
    clinicSettings: () => clinicSettings,
    homepageSections: () => caller.publicContent.homepageSections(),
    policies: () => caller.publicContent.policies(),
    treatments: () => caller.publicContent.treatments(),
    promotions: () => caller.publicContent.promotions(),
    reviews: () => caller.publicContent.reviews(),
    resultCases: () => caller.publicContent.resultCases(),
    guidePosts: () => caller.publicContent.guidePosts(),
    guidePostBySlug: (slug: string) => caller.publicContent.guidePostBySlug({ slug }),
    faqs: () => caller.publicContent.faqs(),
  };
}
