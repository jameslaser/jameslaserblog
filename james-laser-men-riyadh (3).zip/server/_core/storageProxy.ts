import type { Express } from "express";
import { ENV } from "./env";
import { ORIGINAL_CONSENT_DOCUMENTS } from "../../shared/originalConsent";

const PUBLIC_STORAGE_PREFIXES = ["cms-media/", "public-home/"] as const;
const PUBLIC_STORAGE_KEYS = new Set([
  ...ORIGINAL_CONSENT_DOCUMENTS.map(document => document.url.replace("/manus-storage/", "")),
  "james-laser-mens-facial-laser-hair-removal-riyadh_fb2a3e42.mp4",
  "nurse-james-laser-hair-removal-specialist-riyadh_f79913ca.jpg",
  "male-laser-back-treatment_3bb98402.jpg",
  "deka-again-riyadh-photo_ac4f0d6e.jpeg",
  "gentle-promax-riyadh-photo_30349ffb.jpeg",
  "duetto-machine-riyadh-photo_03e9b4c8.jpeg",
]);

export function isPublicStorageKey(key: string): boolean {
  return PUBLIC_STORAGE_KEYS.has(key) || PUBLIC_STORAGE_PREFIXES.some(prefix => key.startsWith(prefix));
}

function isSafeStorageKey(key: string): boolean {
  return Boolean(key) && !key.startsWith("/") && !key.includes("\\") && key.split("/").every(segment => segment !== "" && segment !== "." && segment !== "..");
}

export function registerStorageProxy(app: Express) {
  app.get("/manus-storage/*", async (req, res) => {
    const key = (req.params as Record<string, string>)[0];
    if (!key || !isSafeStorageKey(key)) {
      res.status(400).send("Invalid storage key");
      return;
    }

    if (!isPublicStorageKey(key)) {
      res.status(404).send("Storage object not found");
      return;
    }

    if (!ENV.forgeApiUrl || !ENV.forgeApiKey) {
      res.status(500).send("Storage proxy not configured");
      return;
    }

    try {
      const forgeUrl = new URL(
        "v1/storage/presign/get",
        ENV.forgeApiUrl.replace(/\/+$/, "") + "/",
      );
      forgeUrl.searchParams.set("path", key);

      const forgeResp = await fetch(forgeUrl, {
        headers: { Authorization: `Bearer ${ENV.forgeApiKey}` },
      });

      if (!forgeResp.ok) {
        const body = await forgeResp.text().catch(() => "");
        console.error(`[StorageProxy] forge error: ${forgeResp.status} ${body}`);
        res.status(502).send("Storage backend error");
        return;
      }

      const { url } = (await forgeResp.json()) as { url: string };
      if (!url) {
        res.status(502).send("Empty signed URL from backend");
        return;
      }

      res.set("Cache-Control", "no-store");
      res.redirect(307, url);
    } catch (err) {
      console.error("[StorageProxy] failed:", err);
      res.status(502).send("Storage proxy error");
    }
  });
}
