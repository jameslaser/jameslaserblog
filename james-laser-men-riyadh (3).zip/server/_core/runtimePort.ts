export function resolveRuntimePort(env: NodeJS.ProcessEnv = process.env) {
  const rawPort = env.PORT;
  const isProduction = env.NODE_ENV === "production";

  if (isProduction && !rawPort) {
    throw new Error("Managed production requires the PORT environment variable.");
  }

  const port = Number.parseInt(rawPort || "3000", 10);
  if (!Number.isInteger(port) || port <= 0 || port > 65535) {
    throw new Error("PORT must be a valid TCP port number.");
  }

  return { port, requireExactPort: isProduction } as const;
}
