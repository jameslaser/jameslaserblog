import { createHmac } from "node:crypto";

/** Immutable clinic WhatsApp identity. Do not change without explicit authorization. */
export const CANONICAL_WABA_ID = "1833666484124208";
export const CANONICAL_WABA_NAME = "James Laser Hair Removal WhatsApp Business App";
export const CANONICAL_BUSINESS_PORTFOLIO = "JAMES LASER";

type MetaWhatsAppConfig = {
  appId: string;
  appSecret: string;
  accessToken: string;
  phoneNumberId: string;
  businessAccountId: string;
  webhookVerifyToken: string;
  graphApiVersion: string;
};

type MetaGraphError = { error?: { message?: string; error_user_msg?: string; code?: number | string; error_subcode?: number | string; type?: string } };
export type MetaWhatsAppRequestError = Error & {
  code: string;
  httpStatus: number;
  providerErrorType: string | null;
};

const REQUIRED_ENV = [
  "META_APP_ID",
  "META_APP_SECRET",
  "WHATSAPP_ACCESS_TOKEN",
  "WHATSAPP_PHONE_NUMBER_ID",
  "WHATSAPP_BUSINESS_ACCOUNT_ID",
  "WHATSAPP_WEBHOOK_VERIFY_TOKEN",
  "META_GRAPH_API_VERSION",
] as const;

export function getMetaWhatsAppConfig(): MetaWhatsAppConfig | null {
  const values = Object.fromEntries(REQUIRED_ENV.map(key => [key, process.env[key]?.trim() ?? ""])) as Record<(typeof REQUIRED_ENV)[number], string>;
  if (REQUIRED_ENV.some(key => !values[key])) return null;
  // A valid token for another Business Account must never activate this clinic's
  // sender, template sync, or webhook processing.
  if (values.WHATSAPP_BUSINESS_ACCOUNT_ID !== CANONICAL_WABA_ID) return null;
  return {
    appId: values.META_APP_ID,
    appSecret: values.META_APP_SECRET,
    accessToken: values.WHATSAPP_ACCESS_TOKEN,
    phoneNumberId: values.WHATSAPP_PHONE_NUMBER_ID,
    businessAccountId: values.WHATSAPP_BUSINESS_ACCOUNT_ID,
    webhookVerifyToken: values.WHATSAPP_WEBHOOK_VERIFY_TOKEN,
    graphApiVersion: values.META_GRAPH_API_VERSION,
  };
}

export function metaWhatsAppConfigured() {
  return Boolean(getMetaWhatsAppConfig());
}

function configuredMetaWhatsApp(): MetaWhatsAppConfig {
  const config = getMetaWhatsAppConfig();
  if (!config) throw new Error("WhatsApp Cloud API is not configured. An authorized owner must complete Manus-managed server-side secret setup.");
  return config;
}

function graphUrl(config: MetaWhatsAppConfig, resource: string, accessToken = config.accessToken) {
  const url = new URL(`https://graph.facebook.com/${encodeURIComponent(config.graphApiVersion)}/${resource}`);
  // Meta's server-side Graph API policy requires HMAC-SHA256(access token,
  // app secret) as appsecret_proof when the app has that protection enabled.
  // The proof is request-scoped and never exposed to the browser or persisted.
  url.searchParams.set("appsecret_proof", createHmac("sha256", config.appSecret).update(accessToken).digest("hex"));
  return url.toString();
}

function safeMetaError(payload: unknown) {
  const error = payload as MetaGraphError;
  const code = error?.error?.code;
  const subcode = error?.error?.error_subcode;
  const type = error?.error?.type?.replace(/[^a-zA-Z0-9_.-]/g, "").slice(0, 160) || null;
  const rawMessage = error?.error?.error_user_msg || error?.error?.message;
  const message = rawMessage?.replace(/Bearer\s+\S+|access[_ -]?token\S*|verify[_ -]?token\S*/gi, "[redacted]").slice(0, 800);
  return { code: [code, subcode].filter(value => value !== undefined).join(".") || "meta_request_failed", type, message: message || "Meta rejected the WhatsApp request." };
}

async function graphRequest<T>(path: string, init: RequestInit, accessToken?: string): Promise<T> {
  const config = configuredMetaWhatsApp();
  const requestToken = accessToken ?? config.accessToken;
  const response = await fetch(graphUrl(config, path, requestToken), {
    ...init,
    headers: {
      Authorization: `Bearer ${requestToken}`,
      "Content-Type": "application/json",
      ...init.headers,
    },
  });
  const payload = await response.json().catch(() => null);
  if (!response.ok) {
    const error = safeMetaError(payload);
    const failure = new Error(error.message) as MetaWhatsAppRequestError;
    failure.code = error.code;
    failure.httpStatus = response.status;
    failure.providerErrorType = error.type;
    throw failure;
  }
  return payload as T;
}

export type MetaSendResponse = { messages?: Array<{ id?: string }> };

/** Sends an allowed free-form service message through the official Cloud API. */
export async function sendMetaWhatsAppText(input: { to: string; body: string; replyToMetaMessageId?: string | null }) {
  const config = configuredMetaWhatsApp();
  const payload: Record<string, unknown> = {
    messaging_product: "whatsapp",
    recipient_type: "individual",
    to: input.to.replace(/\D/g, ""),
    type: "text",
    text: { preview_url: false, body: input.body },
  };
  if (input.replyToMetaMessageId) payload.context = { message_id: input.replyToMetaMessageId };
  return graphRequest<MetaSendResponse>(`${encodeURIComponent(config.phoneNumberId)}/messages`, { method: "POST", body: JSON.stringify(payload) });
}

/** Sends an approved Meta template; template status is separately synchronized and enforced by the service layer. */
export async function sendMetaWhatsAppTemplate(input: { to: string; name: string; language: string; components?: unknown[] }) {
  const config = configuredMetaWhatsApp();
  const payload: Record<string, unknown> = {
    messaging_product: "whatsapp",
    to: input.to.replace(/\D/g, ""),
    type: "template",
    template: {
      name: input.name,
      language: { code: input.language },
      ...(input.components?.length ? { components: input.components } : {}),
    },
  };
  return graphRequest<MetaSendResponse>(`${encodeURIComponent(config.phoneNumberId)}/messages`, { method: "POST", body: JSON.stringify(payload) });
}

export type MetaTemplateRecord = {
  id?: string;
  name?: string;
  language?: string;
  category?: string;
  status?: string;
  components?: Array<{ type?: string; text?: string; example?: unknown }>;
};

/** Fetches current template metadata. Credentials remain server-side and the raw response is not forwarded to the browser. */
export async function fetchMetaWhatsAppTemplates() {
  const config = configuredMetaWhatsApp();
  const fields = encodeURIComponent("id,name,language,category,status,components");
  try {
    return await graphRequest<{ data?: MetaTemplateRecord[] }>(`${encodeURIComponent(config.businessAccountId)}/message_templates?fields=${fields}`, { method: "GET" });
  } catch (error) {
    const failure = error as MetaWhatsAppRequestError;
    // Some shared WABA libraries restrict component visibility. Status synchronization
    // can still proceed safely; exact-body mapping remains intentionally unavailable.
    if (failure.code !== "200") throw error;
    const basicFields = encodeURIComponent("id,name,language,category,status");
    return graphRequest<{ data?: MetaTemplateRecord[] }>(`${encodeURIComponent(config.businessAccountId)}/message_templates?fields=${basicFields}`, { method: "GET" });
  }
}

export type MetaWebhookSubscriptionResponse = { success?: boolean; data?: Array<{ override_callback_uri?: string }> };
export type MetaWebhookSubscriptionInfo = { object?: string; callback_url?: string; active?: boolean; fields?: Array<{ name?: string }> };

/**
 * Subscribes the configured app to the clinic WABA through the official Graph API.
 * The verification token stays in Manus-managed server-side secret storage and is
 * never returned to the portal, persisted, or placed in a request URL.
 */
export async function registerMetaWhatsAppWebhook(callbackUrl: string) {
  const config = configuredMetaWhatsApp();
  if (!/^https:\/\/[a-z0-9.-]+\/api\/webhooks\/whatsapp$/i.test(callbackUrl)) {
    throw new Error("A secure canonical WhatsApp callback URL is required.");
  }
  const appAccessToken = `${config.appId}|${config.appSecret}`;
  const appSubscription = await graphRequest<MetaWebhookSubscriptionResponse>(`${encodeURIComponent(config.appId)}/subscriptions`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      object: "whatsapp_business_account",
      callback_url: callbackUrl,
      fields: "messages",
      verify_token: config.webhookVerifyToken,
    }).toString(),
  }, appAccessToken);
  if (!appSubscription.success) throw new Error("Meta did not confirm the app-level WhatsApp callback subscription.");
  const wabaSubscription = await graphRequest<MetaWebhookSubscriptionResponse>(`${encodeURIComponent(config.businessAccountId)}/subscribed_apps`, {
    method: "POST",
    body: JSON.stringify({
      override_callback_uri: callbackUrl,
      verify_token: config.webhookVerifyToken,
    }),
  });
  if (!wabaSubscription.success) throw new Error("Meta did not confirm the WhatsApp Business Account subscription.");
  return wabaSubscription;
}

/** Retrieves non-secret WABA subscription metadata for post-registration verification. */
export async function getMetaWhatsAppWebhookSubscriptions() {
  const config = configuredMetaWhatsApp();
  return graphRequest<{ data?: MetaWebhookSubscriptionInfo[] }>(`${encodeURIComponent(config.businessAccountId)}/subscribed_apps`, { method: "GET" });
}

export type MetaTemplateSubmission = {
  name: string;
  language: string;
  category: "UTILITY";
  components: Array<Record<string, unknown>>;
};

export type MetaTemplateSubmissionResponse = { id?: string; status?: string; category?: string };

/** Submits a reviewed utility template for Meta approval; it does not send a message. */
export async function submitMetaWhatsAppUtilityTemplate(input: MetaTemplateSubmission) {
  const config = configuredMetaWhatsApp();
  if (!/^[a-z0-9_]{1,512}$/.test(input.name)) throw new Error("Meta template names must use lowercase letters, digits, and underscores only.");
  if (!input.components.some(component => component.type === "BODY")) throw new Error("A WhatsApp utility template requires a BODY component.");
  return graphRequest<MetaTemplateSubmissionResponse>(`${encodeURIComponent(config.businessAccountId)}/message_templates`, {
    method: "POST",
    body: JSON.stringify({ name: input.name, language: input.language, category: "UTILITY", components: input.components }),
  });
}
