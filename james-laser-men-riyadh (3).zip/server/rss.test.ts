import { describe, expect, it } from "vitest";
import { buildBlogRssXml } from "./rss";

describe("blog RSS feed", () => {
  it("uses canonical blog URLs and safely escapes editorial text", () => {
    const xml = buildBlogRssXml("https://www.jameslaserformen.com/", [{
      slug: "chest-and-back",
      titleEn: "Chest & Back <Guide>",
      summaryEn: "Preparation & realistic expectations.",
      authorName: "Nurse James",
      category: "Treatment areas",
      publishedAt: new Date("2026-09-01T09:00:00Z"),
      updatedAt: new Date("2026-09-02T09:00:00Z"),
    }]);
    expect(xml).toContain("https://www.jameslaserformen.com/en/blog/chest-and-back");
    expect(xml).toContain("Chest &amp; Back &lt;Guide&gt;");
    expect(xml).toContain("<dc:creator>Nurse James</dc:creator>");
    expect(xml).toContain("<category>Treatment areas</category>");
  });
});
