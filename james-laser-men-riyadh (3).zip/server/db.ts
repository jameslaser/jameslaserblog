import { and, asc, count, desc, eq, gt, gte, inArray, isNull, like, lte, or, sql } from "drizzle-orm";
import { createHash } from "node:crypto";
import { drizzle } from "drizzle-orm/mysql2";
import { activityLogs, appointments, consultationRequests, consentSignatureSessions, enquiries, followUps, hmsImportBatches, InsertConsultationRequest, InsertUser, machines, patients, settingsChangeAudits, users } from "../drizzle/schema";
import { ENV } from "./_core/env";
import { ORIGINAL_CONSENT_DOCUMENTS, ORIGINAL_CONSENT_SET_REFERENCE } from "@shared/originalConsent";
import { PUBLIC_PRIVACY_NOTICE_VERSION } from "@shared/privacyNotice";
import { HmsPreviewRow, hmsAppointmentIdentityKey, markHmsPreviewDuplicates, parseHmsReportCsv } from "./hmsCsv";
import { resolveSinglePatientFile } from "./patientIdentity";
import { buildAttentionFindings } from "./attentionAgent";
import { appointmentEndTime, clinicDurationMinutes, hasAppointmentConflict } from "@shared/appointmentScheduling";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && ENV.databaseUrl) {
    try {
      _db = drizzle(ENV.databaseUrl);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'owner';
      updateSet.role = 'owner';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/** Return the minimum staff directory needed for owner-only access management. */
export async function listStaffUsers() {
  const db = await getDb();
  if (!db) throw new Error("The user directory is temporarily unavailable.");
  return db.select({ id: users.id, name: users.name, email: users.email, role: users.role, lastSignedIn: users.lastSignedIn, createdAt: users.createdAt }).from(users).orderBy(users.name);
}

/** The owner may change internal staff roles; no public procedure exposes this action. */
export async function updateStaffRole(userId: number, role: "admin" | "content_editor" | "reception" | "user", actor: { id: number; name: string | null }) {
  const db = await getDb();
  if (!db) throw new Error("The user directory is temporarily unavailable.");
  const target = await db.select({ role: users.role }).from(users).where(eq(users.id, userId)).limit(1);
  if (!target[0]) throw new Error("Staff account not found.");
  if (target[0].role === "owner") throw new Error("The owner role cannot be changed here.");
  if (target[0].role === role) return;
  await db.transaction(async tx => {
    await tx.update(users).set({ role }).where(eq(users.id, userId));
    await tx.insert(settingsChangeAudits).values({
      actorUserId: actor.id,
      actorName: actor.name ?? "Clinic owner",
      settingArea: "Staff & RBAC",
      changedFieldsJson: JSON.stringify(["role"]),
      previousValuesJson: JSON.stringify({ role: target[0].role }),
      newValuesJson: JSON.stringify({ role }),
    });
    await tx.insert(activityLogs).values({
      actorUserId: actor.id,
      actorName: actor.name ?? "Clinic owner",
      action: `Changed staff role from ${target[0].role} to ${role}`,
      subjectType: "staff_rbac",
      subjectId: userId,
    });
  });
}

/** Store a public client request without requiring the requester to authenticate. */
export async function createConsultationRequest(request: InsertConsultationRequest) {
  const db = await getDb();
  if (!db) {
    throw new Error("The request service is temporarily unavailable.");
  }

  const result = await db.insert(consultationRequests).values(request);
  return { id: Number(result[0].insertId) };
}

export function normalizeMobileNumber(value: string) {
  const digits = value.replace(/\D/g, "");
  if (digits.startsWith("00")) return `+${digits.slice(2)}`;
  if (digits.startsWith("966")) return `+${digits}`;
  if (digits.startsWith("0") && digits.length === 10) return `+966${digits.slice(1)}`;
  if (value.trim().startsWith("+")) return `+${digits}`;
  return `+${digits}`;
}

/**
 * Records a staff-initiated WhatsApp Business Web launch without retaining a
 * telephone number, patient name, message, or other chat content.
 */
export async function recordManualWhatsAppLaunch(
  input: { subjectType: "patient" | "appointment" | "follow_up"; subjectId: number },
  actor: { id: number; name: string | null },
) {
  const db = await getDb();
  if (!db) throw new Error("The activity-log service is temporarily unavailable.");

  const subject = input.subjectType === "patient"
    ? await db.select({ id: patients.id }).from(patients).where(eq(patients.id, input.subjectId)).limit(1)
    : input.subjectType === "appointment"
      ? await db.select({ id: appointments.id }).from(appointments).where(eq(appointments.id, input.subjectId)).limit(1)
      : await db.select({ id: followUps.id }).from(followUps).where(eq(followUps.id, input.subjectId)).limit(1);

  if (!subject[0]) throw new Error("The record for this WhatsApp launch was not found.");

  await db.insert(activityLogs).values({
    actorUserId: actor.id,
    actorName: actor.name,
    action: "Opened manual WhatsApp Business Web chat",
    subjectType: input.subjectType,
    subjectId: input.subjectId,
  });
}

export type PublicAppointmentRequest = {
  clientSubmissionId: string;
  fullName: string;
  whatsapp: string;
  nationality?: string | null;
  preferredDate: string;
  preferredTime: string;
  visitType: "session" | "retouch";
  treatmentAreas: string[];
  previousLaser: boolean;
  lastLaserSession?: string | null;
  takingMedication?: boolean;
  medicationTypes?: string[];
  medicationDetails?: string | null;
  medicationLastTaken?: string | null;
  medicationDosage?: string | null;
  recentExposures?: Array<"tanning" | "hammam" | "skin_treatment">;
  recentExposureDate?: string | null;
  hasSkinCondition?: boolean;
  skinConditionDetails?: string | null;
  notes?: string | null;
  appointmentAcknowledgement: true;
  originalConsentAcknowledgement: true;
  informationAccuracyAcknowledgement?: boolean;
  privacyConsent: true;
  healthScreeningConsent?: boolean;
  marketingConsent: boolean;
  language: "en" | "ar";
  source: string;
  signatureDataUrl?: string;
};

/** Stores a simple public appointment request; it never creates a confirmed appointment or patient file. */
export async function findPublicAppointmentRequestBySubmissionId(clientSubmissionId: string) {
  const db = await getDb();
  if (!db) throw new Error("The request service is temporarily unavailable.");
  const rows = await db.select({ id: consultationRequests.id, publicRequestId: consultationRequests.publicRequestId, isPotentialDuplicate: consultationRequests.isPotentialDuplicate }).from(consultationRequests).where(eq(consultationRequests.clientSubmissionId, clientSubmissionId)).limit(1);
  return rows[0]?.publicRequestId ? rows[0] : null;
}

export async function createPublicAppointmentRequest(input: PublicAppointmentRequest) {
  const db = await getDb();
  if (!db) throw new Error("The request service is temporarily unavailable.");
  const alreadyStored = await db.select({ id: consultationRequests.id, publicRequestId: consultationRequests.publicRequestId, isPotentialDuplicate: consultationRequests.isPotentialDuplicate }).from(consultationRequests).where(eq(consultationRequests.clientSubmissionId, input.clientSubmissionId)).limit(1);
  if (alreadyStored[0]?.publicRequestId) return { ...alreadyStored[0], reused: true as const };
  const normalizedWhatsapp = normalizeMobileNumber(input.whatsapp);
  const summary = input.treatmentAreas.join(", ").slice(0, 120);
  const possibleDuplicate = await db.select({ id: consultationRequests.id }).from(consultationRequests).where(and(
    eq(consultationRequests.normalizedWhatsapp, normalizedWhatsapp),
    eq(consultationRequests.preferredDate, input.preferredDate),
    eq(consultationRequests.preferredTime, input.preferredTime),
  )).limit(1);
  const signature = input.signatureDataUrl ? await (async () => {
    const { storePublicRequestSignatureEvidence } = await import("./consentSignature");
    return storePublicRequestSignatureEvidence({ clientSubmissionId: input.clientSubmissionId, signerName: input.fullName, signatureDataUrl: input.signatureDataUrl!, language: input.language });
  })() : null;
  const medicationTypes = input.medicationTypes ?? [];
  const recent = new Set(input.recentExposures ?? []);
  let inserted;
  try {
    inserted = await db.insert(consultationRequests).values({
      clientSubmissionId: input.clientSubmissionId,
      fullName: input.fullName,
      nationality: input.nationality?.trim() || "Not provided",
      whatsapp: normalizedWhatsapp,
      normalizedWhatsapp,
      treatmentArea: summary,
      treatmentAreas: JSON.stringify(input.treatmentAreas),
      preferredContact: "WhatsApp",
      preferredDate: input.preferredDate,
      preferredTime: input.preferredTime,
      visitType: input.visitType,
      firstTime: !input.previousLaser,
      lastLaserSession: input.previousLaser ? input.lastLaserSession || null : null,
      takingMedication: input.takingMedication ?? null,
      medicationDetails: input.takingMedication ? input.medicationDetails || null : null,
      medicationTypes: input.takingMedication ? JSON.stringify(medicationTypes) : null,
      medicationLastTaken: input.takingMedication ? input.medicationLastTaken || null : null,
      medicationDosage: input.takingMedication ? input.medicationDosage || null : null,
      tookVitaminD: input.takingMedication === undefined ? null : input.takingMedication && medicationTypes.includes("Vitamin D"),
      vitaminDLastTaken: medicationTypes.includes("Vitamin D") ? input.medicationLastTaken || null : null,
      takingIron: input.takingMedication === undefined ? null : input.takingMedication && medicationTypes.includes("Iron"),
      ironLastTaken: medicationTypes.includes("Iron") ? input.medicationLastTaken || null : null,
      tannedPastThreeMonths: input.recentExposures ? recent.has("tanning") : null,
      hadMoroccanBathLastSevenDays: input.recentExposures ? recent.has("hammam") : null,
      hadSkinTreatment: input.recentExposures ? recent.has("skin_treatment") : null,
      skinTreatmentDetails: recent.has("skin_treatment") ? "Other skin treatment / exfoliation" : null,
      hadSevereSunExposure: input.recentExposures ? recent.has("tanning") : null,
      recentExposureDate: recent.size ? input.recentExposureDate || null : null,
      hasSkinCondition: input.hasSkinCondition ?? null,
      skinConditionDetails: input.hasSkinCondition ? input.skinConditionDetails || null : null,
      notes: input.notes || null,
      consentRead: true,
      privacyConsent: true,
      privacyNoticeVersion: PUBLIC_PRIVACY_NOTICE_VERSION,
      healthScreeningConsent: input.healthScreeningConsent ?? false,
      healthScreeningConsentAt: input.healthScreeningConsent ? new Date() : null,
      appointmentAcknowledgement: true,
      informationAccuracyAcknowledgedAt: input.informationAccuracyAcknowledgement ? signature?.signedAt ?? new Date() : null,
      originalConsentSetReference: ORIGINAL_CONSENT_SET_REFERENCE,
      originalConsentDocuments: JSON.stringify(ORIGINAL_CONSENT_DOCUMENTS),
      originalConsentAcknowledgedAt: signature?.signedAt ?? new Date(),
      originalConsentLanguage: input.language,
      consentSignatureStatus: signature ? "received" : "required",
      consentSignatureReference: signature?.signatureReference ?? null,
      consentSignatureEvidenceKey: signature?.signatureEvidenceKey ?? null,
      marketingConsent: input.marketingConsent,
      language: input.language,
      source: input.source,
      isPotentialDuplicate: possibleDuplicate.length > 0,
      status: "pending",
    });
  } catch (error) {
    if ((error as { code?: string }).code !== "ER_DUP_ENTRY") throw error;
    const concurrent = await db.select({ id: consultationRequests.id, publicRequestId: consultationRequests.publicRequestId, isPotentialDuplicate: consultationRequests.isPotentialDuplicate }).from(consultationRequests).where(eq(consultationRequests.clientSubmissionId, input.clientSubmissionId)).limit(1);
    if (concurrent[0]?.publicRequestId) return { ...concurrent[0], reused: true as const };
    throw error;
  }
  const id = Number(inserted[0].insertId);
  const publicRequestId = `JR-${new Date().getUTCFullYear()}-${String(id).padStart(6, "0")}`;
  await db.update(consultationRequests).set({ publicRequestId }).where(eq(consultationRequests.id, id));
  await db.insert(activityLogs).values({
    action: "Created public appointment request",
    subjectType: "consultation_request",
    subjectId: id,
  });
  return { id, publicRequestId, isPotentialDuplicate: possibleDuplicate.length > 0, reused: false as const };
}

type RequestStatus = "pending" | "contacted" | "clarification_requested" | "approved" | "rejected" | "transferred" | "completed" | "cancelled";
type RequestWorkflowStatus = Exclude<RequestStatus, "pending" | "approved">;
type ClinicMachine = "DEKA AGAIN" | "CLARITY 2" | "GENTLE PROMAX" | "DUETTO MACHINE";
type AttendanceStatus = "arrived" | "no-show" | "cancelled";
type WaitingStatus = "waiting" | "arrived";
type VisitType = "session" | "retouch";
type FollowUpType = "session" | "retouch";
type AppointmentApprovalDetails = {
  fullName: string;
  whatsapp: string;
  nationality: string;
  mrn: string;
  appointmentDate: string;
  appointmentTime: string;
  treatmentArea: string;
  treatmentAreas: string[];
  machine: ClinicMachine;
  visitType: VisitType;
  finalizedNotes: string | null;
  assignedStaff: string | null;
  durationMinutes: number | null;
};

const clinicMachines: Array<{ name: ClinicMachine; machineNumber: string }> = [
  { name: "DEKA AGAIN", machineNumber: "JL-M-001" },
  { name: "CLARITY 2", machineNumber: "JL-M-002" },
  { name: "GENTLE PROMAX", machineNumber: "JL-M-003" },
  { name: "DUETTO MACHINE", machineNumber: "JL-M-004" },
];

async function ensureMachineInventory() {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");
  for (const machine of clinicMachines) {
    await db.insert(machines).values(machine).onDuplicateKeyUpdate({ set: { name: machine.name } });
  }
  return db;
}

export async function listMachineInventory() {
  const db = await ensureMachineInventory();
  return db.select().from(machines).orderBy(asc(machines.name));
}

/** Public presentation exposes names only and never creates or changes inventory. */
export async function listPublicMachineInventory() {
  const db = await getDb();
  if (!db) throw new Error("The public machine information is temporarily unavailable.");
  return db.select({ name: machines.name }).from(machines).where(inArray(machines.name, clinicMachines.map(machine => machine.name))).orderBy(asc(machines.name));
}

export async function updateMachineNumber(name: ClinicMachine, machineNumber: string) {
  const db = await ensureMachineInventory();
  const result = await db.update(machines).set({ machineNumber }).where(eq(machines.name, name));
  if (result[0].affectedRows !== 1) throw new Error("The machine inventory record was not found.");
}

function riyadhDate() {
  return new Intl.DateTimeFormat("sv-SE", {
    timeZone: "Asia/Riyadh",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
}

export async function getAdminDashboardStats() {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");

  const [pending, transferred, cancelled, today] = await Promise.all([
    db.select({ total: count() }).from(consultationRequests).where(eq(consultationRequests.status, "pending")),
    db.select({ total: count() }).from(consultationRequests).where(eq(consultationRequests.status, "transferred")),
    db.select({ total: count() }).from(consultationRequests).where(eq(consultationRequests.status, "cancelled")),
    db.select({ total: count() }).from(appointments).where(and(eq(appointments.appointmentDate, riyadhDate()), eq(appointments.status, "confirmed"), eq(appointments.source, "hms_csv"))),
  ]);

  return {
    pendingRequests: Number(pending[0]?.total ?? 0),
    transferredRequests: Number(transferred[0]?.total ?? 0),
    cancelledRequests: Number(cancelled[0]?.total ?? 0),
    appointmentsToday: Number(today[0]?.total ?? 0),
  };
}

/** Aggregate-only, deterministic clinic workflow scan used by the protected zero-credit attention workspace. */
export async function getAdminAttentionFindings() {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");
  const activeRequestStatuses: RequestStatus[] = ["pending", "contacted", "clarification_requested"];
  const [pending, clarification, duplicates, signatureOutstanding, expiredSignatures, newEnquiries, hmsWarningBatches] = await Promise.all([
    db.select({ total: count() }).from(consultationRequests).where(eq(consultationRequests.status, "pending")),
    db.select({ total: count() }).from(consultationRequests).where(eq(consultationRequests.status, "clarification_requested")),
    db.select({ total: count() }).from(consultationRequests).where(and(eq(consultationRequests.isPotentialDuplicate, true), inArray(consultationRequests.status, activeRequestStatuses))),
    db.select({ total: count() }).from(consultationRequests).where(and(eq(consultationRequests.consentSignatureStatus, "required"), inArray(consultationRequests.status, activeRequestStatuses))),
    db.select({ total: count() }).from(consentSignatureSessions).where(eq(consentSignatureSessions.status, "expired")),
    db.select({ total: count() }).from(enquiries).where(eq(enquiries.status, "new")),
    db.select({ total: count() }).from(hmsImportBatches).where(gt(hmsImportBatches.warningCount, 0)),
  ]);
  const findings = buildAttentionFindings({
    pendingRequests: Number(pending[0]?.total ?? 0),
    clarificationRequests: Number(clarification[0]?.total ?? 0),
    potentialDuplicates: Number(duplicates[0]?.total ?? 0),
    signatureOutstanding: Number(signatureOutstanding[0]?.total ?? 0),
    expiredSignatures: Number(expiredSignatures[0]?.total ?? 0),
    newEnquiries: Number(newEnquiries[0]?.total ?? 0),
    hmsWarningBatches: Number(hmsWarningBatches[0]?.total ?? 0),
  });
  return { checkedAt: new Date(), findings };
}

export async function recordAdminAttentionRun(actorName: string | null) {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");
  await db.insert(activityLogs).values({ actorName, action: "Ran zero-credit Admin Attention Agent", subjectType: "attention_agent", subjectId: null });
}

export type ConsultationRequestFilters = {
  status?: RequestStatus;
  query?: string;
  visitType?: VisitType;
  language?: "en" | "ar";
  dateFrom?: string;
  dateTo?: string;
  treatment?: string;
};

export async function listConsultationRequests(filters: ConsultationRequestFilters = {}) {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");
  const conditions = [];
  if (filters.status) conditions.push(eq(consultationRequests.status, filters.status));
  if (filters.visitType) conditions.push(eq(consultationRequests.visitType, filters.visitType));
  if (filters.language) conditions.push(eq(consultationRequests.language, filters.language));
  if (filters.dateFrom) conditions.push(gte(consultationRequests.preferredDate, filters.dateFrom));
  if (filters.dateTo) conditions.push(lte(consultationRequests.preferredDate, filters.dateTo));
  if (filters.treatment) conditions.push(like(consultationRequests.treatmentArea, `%${filters.treatment}%`));
  if (filters.query) {
    const pattern = `%${filters.query}%`;
    conditions.push(or(like(consultationRequests.fullName, pattern), like(consultationRequests.whatsapp, pattern), like(consultationRequests.publicRequestId, pattern))!);
  }
  const query = db.select().from(consultationRequests);
  return conditions.length ? query.where(and(...conditions)).orderBy(desc(consultationRequests.createdAt)) : query.orderBy(desc(consultationRequests.createdAt));
}

export async function approveConsultationRequest(requestId: number, details: AppointmentApprovalDetails, reviewedBy: string | null) {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");

  return db.transaction(async tx => {
    const existing = await tx.select().from(consultationRequests).where(eq(consultationRequests.id, requestId)).limit(1);
    const request = existing[0];
    if (!request) throw new Error("The consultation request was not found.");
    if (request.status !== "pending" && request.status !== "contacted" && request.status !== "clarification_requested") throw new Error("Only active consultation requests can be transferred to appointments.");

    const finalizedWhatsapp = normalizeMobileNumber(details.whatsapp);
    const durationMinutes = clinicDurationMinutes(details.treatmentAreas, details.visitType);
    const finalizedAppointmentEndTime = appointmentEndTime(details.appointmentTime, durationMinutes);
    const schedulingConflicts = await tx.select({ id: appointments.id, appointmentTime: appointments.appointmentTime, appointmentEndTime: appointments.appointmentEndTime, durationMinutes: appointments.durationMinutes, whatsapp: appointments.whatsapp, machine: appointments.machine }).from(appointments).where(and(
      eq(appointments.appointmentDate, details.appointmentDate),
      inArray(appointments.status, ["confirmed", "waiting", "arrived"]),
    ));
    const overlappingConflicts = schedulingConflicts.map(conflict => hasAppointmentConflict({ appointmentTime: details.appointmentTime, appointmentEndTime: finalizedAppointmentEndTime, whatsapp: finalizedWhatsapp, machine: details.machine }, conflict));
    if (overlappingConflicts.some(conflict => conflict.mobile)) {
      throw new Error("A scheduled appointment already overlaps this mobile number.");
    }
    if (overlappingConflicts.some(conflict => conflict.machine)) {
      throw new Error("The selected machine is already assigned during the selected appointment time.");
    }

    const existingWhatsapp = await tx.select({ id: patients.id }).from(patients).where(eq(patients.whatsapp, finalizedWhatsapp)).limit(1);
    const existingMrn = details.mrn ? await tx.select({ id: patients.id }).from(patients).where(eq(patients.mrn, details.mrn)).limit(1) : [];
    const matchingPatientId = resolveSinglePatientFile({
      mobilePatientId: existingWhatsapp[0]?.id ?? null,
      mrnPatientId: existingMrn[0]?.id ?? null,
    });
    const matchedBy = existingWhatsapp[0] && existingMrn[0]
      ? "both"
      : existingMrn[0]
        ? "mrn"
        : existingWhatsapp[0]
          ? "whatsapp"
          : null;
    let patientId = matchingPatientId;
    let existingPatientFound = Boolean(matchingPatientId);

    if (!patientId) {
      const createdPatient = await tx.insert(patients).values({
        fullName: details.fullName,
        mrn: details.mrn,
        whatsapp: finalizedWhatsapp,
        email: request.email,
        nationality: details.nationality,
        treatmentArea: details.treatmentArea,
        preferredContact: request.preferredContact,
        firstTime: request.firstTime,
        lastLaserSession: request.lastLaserSession,
        takingMedication: request.takingMedication,
        medicationDetails: request.medicationDetails,
        tookVitaminD: request.tookVitaminD,
        vitaminDLastTaken: request.vitaminDLastTaken,
        takingIron: request.takingIron,
        ironLastTaken: request.ironLastTaken,
        tannedPastThreeMonths: request.tannedPastThreeMonths,
        hadMoroccanBathLastSevenDays: request.hadMoroccanBathLastSevenDays,
        hadSkinTreatment: request.hadSkinTreatment,
        skinTreatmentDetails: request.skinTreatmentDetails,
        hadSevereSunExposure: request.hadSevereSunExposure,
        notes: request.notes,
      });
      patientId = Number(createdPatient[0].insertId);
      existingPatientFound = false;
    }

    const created = await tx.insert(appointments).values({
      consultationRequestId: request.id,
      patientId,
      patientName: details.fullName,
      whatsapp: finalizedWhatsapp,
      mrn: details.mrn,
      appointmentDate: details.appointmentDate,
      appointmentTime: details.appointmentTime,
      appointmentEndTime: finalizedAppointmentEndTime,
      treatmentArea: details.treatmentArea,
      treatmentAreas: JSON.stringify(details.treatmentAreas),
      machine: details.machine,
      visitType: details.visitType,
      internalNotes: details.finalizedNotes,
      assignedStaff: details.assignedStaff,
      durationMinutes,
      originalConsentSetReference: request.originalConsentSetReference,
      originalConsentAcknowledgedAt: request.originalConsentAcknowledgedAt,
      originalConsentLanguage: request.originalConsentLanguage,
      consentSignatureStatus: request.consentSignatureStatus,
      consentSignatureReference: request.consentSignatureReference,
      whatsappAutomationInitializedAt: new Date(),
      whatsappAutomationVersion: 1,
      status: "confirmed",
    });
    const appointmentId = Number(created[0].insertId);

    await tx.update(consultationRequests).set({
      status: "transferred",
      finalizedFullName: details.fullName,
      finalizedWhatsapp,
      finalizedNationality: details.nationality,
      finalizedMrn: details.mrn,
      finalizedAppointmentDate: details.appointmentDate,
      finalizedAppointmentTime: details.appointmentTime,
      finalizedTreatmentAreas: JSON.stringify(details.treatmentAreas),
      finalizedMachine: details.machine,
      finalizedVisitType: details.visitType,
      finalizedNotes: details.finalizedNotes,
      assignedStaff: details.assignedStaff,
      appointmentDurationMinutes: details.durationMinutes,
      finalizedBy: reviewedBy,
      finalizedAt: new Date(),
      reviewedBy,
      reviewedAt: new Date(),
    }).where(eq(consultationRequests.id, requestId));
    await tx.insert(activityLogs).values({ actorName: reviewedBy, action: "Approved and transferred request to appointment", subjectType: "consultation_request", subjectId: requestId });

    return { appointmentId, patientId, existingPatientFound, matchedBy };
  });
}

export async function cancelConsultationRequest(requestId: number, reviewedBy: string | null) {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");

  await updateConsultationRequestWorkflow(requestId, "cancelled", reviewedBy, undefined);
}

/** Update a request without creating or modifying an appointment or patient file. */
export type ConsultationRequestDetailsUpdate = {
  requestId: number;
  fullName: string;
  whatsapp: string;
  nationality: string;
  preferredDate: string;
  preferredTime: string | null;
  treatmentAreas: string[];
  visitType: VisitType;
  notes: string | null;
};

/** Updates request details only; consent, signatures, and any finalized appointment snapshot remain immutable. */
export async function updateConsultationRequestDetails(input: ConsultationRequestDetailsUpdate, updatedBy: string | null) {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");
  const normalizedWhatsapp = normalizeMobileNumber(input.whatsapp);
  if (!input.treatmentAreas.length) throw new Error("Select at least one treatment area.");
  return db.transaction(async tx => {
    const current = await tx.select({ id: consultationRequests.id, status: consultationRequests.status }).from(consultationRequests).where(eq(consultationRequests.id, input.requestId)).limit(1);
    const request = current[0];
    if (!request) throw new Error("The consultation request was not found.");
    if (["rejected", "transferred", "completed", "cancelled"].includes(request.status)) throw new Error("Closed or transferred requests cannot be edited here.");
    const duplicate = await tx.select({ id: consultationRequests.id }).from(consultationRequests).where(and(
      eq(consultationRequests.normalizedWhatsapp, normalizedWhatsapp),
      eq(consultationRequests.preferredDate, input.preferredDate),
      input.preferredTime === null ? isNull(consultationRequests.preferredTime) : eq(consultationRequests.preferredTime, input.preferredTime),
    )).limit(2);
    if (duplicate.some(row => row.id !== input.requestId)) throw new Error("A request already exists for this mobile number, date, and time.");
    await tx.update(consultationRequests).set({
      fullName: input.fullName,
      whatsapp: normalizedWhatsapp,
      normalizedWhatsapp,
      nationality: input.nationality,
      preferredDate: input.preferredDate,
      preferredTime: input.preferredTime,
      treatmentArea: input.treatmentAreas.join(", ").slice(0, 120),
      treatmentAreas: JSON.stringify(input.treatmentAreas),
      visitType: input.visitType,
      notes: input.notes,
    }).where(eq(consultationRequests.id, input.requestId));
    await tx.insert(activityLogs).values({ actorName: updatedBy, action: "Updated consultation request details", subjectType: "consultation_request", subjectId: input.requestId });
  });
}

export async function updateConsultationRequestWorkflow(requestId: number, status: RequestWorkflowStatus, reviewedBy: string | null, internalNotes?: string | null) {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");
  if (status === "transferred") throw new Error("Use the approved transfer action to create a linked appointment before marking a request transferred.");
  const row = await db.select({ status: consultationRequests.status }).from(consultationRequests).where(eq(consultationRequests.id, requestId)).limit(1);
  const current = row[0];
  if (!current) throw new Error("The consultation request was not found.");
  if (current.status === "approved") throw new Error("Approved requests are managed through their confirmed appointment record.");
  if (["rejected", "transferred", "completed", "cancelled"].includes(current.status)) throw new Error("This consultation request is already closed.");
  const result = await db.update(consultationRequests).set({ status, internalNotes: internalNotes === undefined ? undefined : internalNotes, reviewedBy, reviewedAt: new Date() }).where(eq(consultationRequests.id, requestId));
  if (result[0].affectedRows !== 1) throw new Error("The consultation request could not be updated.");
  await db.insert(activityLogs).values({ actorName: reviewedBy, action: `Set consultation request status to ${status}`, subjectType: "consultation_request", subjectId: requestId });
}

/**
 * Retain request history instead of physically deleting it. Linked appointments
 * and signed-evidence requests are immutable workflow history and cannot be
 * reclassified through this action.
 */
export async function deleteConsultationRequest(requestId: number, reviewedBy: string | null) {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");

  await db.transaction(async tx => {
    const [existing, linkedAppointment, signedEvidence] = await Promise.all([
      tx.select({ status: consultationRequests.status }).from(consultationRequests).where(eq(consultationRequests.id, requestId)).limit(1),
      tx.select({ id: appointments.id }).from(appointments).where(eq(appointments.consultationRequestId, requestId)).limit(1),
      tx.select({ id: consentSignatureSessions.id }).from(consentSignatureSessions).where(and(eq(consentSignatureSessions.consultationRequestId, requestId), eq(consentSignatureSessions.status, "signed"))).limit(1),
    ]);
    const request = existing[0];
    if (!request) throw new Error("The consultation request was not found.");
    if (linkedAppointment[0] || request.status === "transferred" || request.status === "approved") {
      throw new Error("Requests linked to appointments are retained as immutable clinic history.");
    }
    if (signedEvidence[0]) throw new Error("Requests with signed consent evidence are retained as immutable clinic history.");
    if (request.status === "cancelled") return;

    await tx.update(consultationRequests).set({
      status: "cancelled",
      reviewedBy,
      reviewedAt: new Date(),
    }).where(eq(consultationRequests.id, requestId));
    await tx.insert(activityLogs).values({
      actorName: reviewedBy,
      action: "Retained request history and cancelled active request",
      subjectType: "consultation_request",
      subjectId: requestId,
    });
  });
}

const appointmentCompatibilitySelect = {
  id: appointments.id,
  consultationRequestId: appointments.consultationRequestId,
  patientId: appointments.patientId,
  patientName: appointments.patientName,
  contactNumber: appointments.contactNumber,
  whatsapp: appointments.whatsapp,
  email: appointments.email,
  mrn: appointments.mrn,
  appointmentDate: appointments.appointmentDate,
  appointmentTime: appointments.appointmentTime,
  appointmentEndTime: appointments.appointmentEndTime,
  treatmentArea: appointments.treatmentArea,
  treatmentAreas: appointments.treatmentAreas,
  machine: appointments.machine,
  visitType: sql<"session" | "retouch" | "unknown">`appointmentVisitType`,
  whatsappConsentStatus: sql<"unknown" | "opted_in" | "opted_out">`'unknown'`,
  whatsappConsentSource: sql<string | null>`NULL`,
  whatsappConsentAt: sql<Date | null>`NULL`,
  whatsappConsentVersion: sql<string | null>`NULL`,
  whatsappOptedOutAt: sql<Date | null>`NULL`,
  whatsappAttendanceConfirmation: sql<"awaiting_response" | "confirmed" | "cannot_attend">`'awaiting_response'`,
  whatsappAttendanceConfirmedAt: sql<Date | null>`NULL`,
  whatsappCannotAttendAt: sql<Date | null>`NULL`,
  whatsappAutomationInitializedAt: sql<Date | null>`NULL`,
  whatsappAutomationVersion: sql<number>`1`,
  nextFollowUpDate: appointments.nextFollowUpDate,
  nextFollowUpType: sql<"session" | "retouch" | null>`appointmentFollowUpType`,
  internalNotes: appointments.internalNotes,
  assignedStaff: appointments.assignedStaff,
  durationMinutes: appointments.durationMinutes,
  originalConsentSetReference: appointments.originalConsentSetReference,
  originalConsentAcknowledgedAt: appointments.originalConsentAcknowledgedAt,
  originalConsentLanguage: sql<"en" | "ar" | null>`appointmentOriginalConsentLanguage`,
  consentSignatureStatus: sql<"not_applicable" | "required" | "received">`appointmentConsentSignatureStatus`,
  consentSignatureReference: appointments.consentSignatureReference,
  source: appointments.source,
  sourceRowNumber: appointments.sourceRowNumber,
  importBatchId: appointments.importBatchId,
  importFingerprint: appointments.importFingerprint,
  hmsImportIdentityKey: appointments.hmsImportIdentityKey,
  originalAppointmentDate: appointments.originalAppointmentDate,
  originalAppointmentStartTime: appointments.originalAppointmentStartTime,
  originalAppointmentEndTime: appointments.originalAppointmentEndTime,
  originalTelephone: appointments.originalTelephone,
  originalSex: appointments.originalSex,
  normalizedSex: appointments.normalizedSex,
  originalAge: appointments.originalAge,
  normalizedAge: appointments.normalizedAge,
  nationality: appointments.nationality,
  remarks: appointments.remarks,
  originalRowData: appointments.originalRowData,
  status: sql<"confirmed" | "waiting" | "arrived" | "completed" | "cancelled" | "no-show">`appointmentStatus`,
  createdAt: appointments.createdAt,
  updatedAt: appointments.updatedAt,
};

export async function listAppointmentsForDate(date: string) {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");

  return db.select(appointmentCompatibilitySelect).from(appointments)
    .where(and(eq(appointments.appointmentDate, date), eq(appointments.source, "hms_csv"), sql`appointmentStatus = 'confirmed'`))
    .orderBy(asc(appointments.appointmentTime), asc(appointments.id));
}

export async function listAppointmentsForDateRange(startDate: string, endDate: string) {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(startDate) || !/^\d{4}-\d{2}-\d{2}$/.test(endDate) || startDate > endDate) {
    throw new Error("A valid appointment date range is required.");
  }
  return db.select(appointmentCompatibilitySelect).from(appointments)
    .where(and(gte(appointments.appointmentDate, startDate), lte(appointments.appointmentDate, endDate), sql`appointmentStatus IN ('confirmed', 'waiting', 'cancelled')`))
    .orderBy(asc(appointments.appointmentDate), asc(appointments.appointmentTime));
}

const MAX_HMS_CSV_BYTES = 1_000_000;

export type HmsImportPreview = {
  fileSha256: string;
  fileAlreadyImported: boolean;
  batchId: number | null;
  fatalErrors: string[];
  providerAttestationRequired: boolean;
  providerVerifiedFromSource: boolean;
  sourceProvider: string | null;
  normalizedProviderCode: "NR011" | null;
  normalizedProviderLabel: "NR011 JAMES FLORES" | null;
  rows: HmsPreviewRow[];
  summary: { total: number; ready: number; warnings: number; duplicates: number; errors: number };
};

function hmsFileSha256(csvText: string) {
  return createHash("sha256").update(csvText, "utf8").digest("hex");
}

function hmsSummary(rows: HmsPreviewRow[]) {
  return rows.reduce((summary, row) => {
    if (row.validation === "READY") summary.ready += 1;
    if (row.validation === "WARNING") summary.warnings += 1;
    if (row.validation === "DUPLICATE") summary.duplicates += 1;
    if (row.validation === "ERROR") summary.errors += 1;
    summary.total += 1;
    return summary;
  }, { total: 0, ready: 0, warnings: 0, duplicates: 0, errors: 0 });
}

/** Parses and validates an HMS CSV without writing appointments, requests, patients, or storage objects. */
export async function previewHmsCsvImport(csvText: string): Promise<HmsImportPreview> {
  if (Buffer.byteLength(csvText, "utf8") > MAX_HMS_CSV_BYTES) throw new Error("The HMS CSV is larger than the 1 MB protected preview limit.");
  const parsed = parseHmsReportCsv(csvText);
  const fileSha256 = hmsFileSha256(csvText);
  if (parsed.fatalErrors.length) return { fileSha256, fileAlreadyImported: false, batchId: null, ...parsed, summary: hmsSummary(parsed.rows) };

  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");
  const importIdentityRows = parsed.rows.map(row => ({
    mrn: row.mrn,
    whatsapp: row.normalizedWhatsapp,
    appointmentDate: row.appointmentDate,
    appointmentTime: row.appointmentStartTime,
  })).filter(row => hmsAppointmentIdentityKey({
    mrn: row.mrn,
    normalizedWhatsapp: row.whatsapp,
    appointmentDate: row.appointmentDate,
    appointmentStartTime: row.appointmentTime,
  }));
  const importMrns = Array.from(new Set(importIdentityRows.map(row => row.mrn).filter((value): value is string => Boolean(value))));
  const importPhones = Array.from(new Set(importIdentityRows.map(row => row.whatsapp).filter((value): value is string => Boolean(value))));
  const [existingBatch, existingFingerprintRows, existingIdentityRows] = await Promise.all([
    db.select({ id: hmsImportBatches.id }).from(hmsImportBatches).where(eq(hmsImportBatches.fileSha256, fileSha256)).limit(1),
    parsed.rows.length
      ? db.select({ importFingerprint: appointments.importFingerprint }).from(appointments).where(inArray(appointments.importFingerprint, parsed.rows.map(row => row.fingerprint)))
      : Promise.resolve([]),
    importMrns.length && importPhones.length
      ? db.select({ mrn: appointments.mrn, whatsapp: appointments.whatsapp, appointmentDate: appointments.appointmentDate, appointmentTime: appointments.appointmentTime }).from(appointments).where(and(inArray(appointments.mrn, importMrns), inArray(appointments.whatsapp, importPhones)))
      : Promise.resolve([]),
  ]);
  const existingFingerprints = new Set(existingFingerprintRows.map(row => row.importFingerprint).filter((value): value is string => Boolean(value)));
  const existingIdentityKeys = new Set(existingIdentityRows.map(row => hmsAppointmentIdentityKey({
    mrn: row.mrn,
    normalizedWhatsapp: row.whatsapp,
    appointmentDate: row.appointmentDate,
    appointmentStartTime: row.appointmentTime,
  })).filter((value): value is string => Boolean(value)));
  const fileAlreadyImported = Boolean(existingBatch[0]);
  const rows = markHmsPreviewDuplicates(parsed.rows, fileAlreadyImported, existingFingerprints, existingIdentityKeys);
  return {
    fileSha256,
    fileAlreadyImported,
    batchId: existingBatch[0]?.id ?? null,
    fatalErrors: [],
    providerAttestationRequired: parsed.providerAttestationRequired,
    providerVerifiedFromSource: parsed.providerVerifiedFromSource,
    sourceProvider: parsed.sourceProvider,
    normalizedProviderCode: parsed.normalizedProviderCode,
    normalizedProviderLabel: parsed.normalizedProviderLabel,
    rows,
    summary: hmsSummary(rows),
  };
}

export type HmsCsvImportInput = {
  csvText: string;
  originalFileName: string;
  confirm: true;
  importedByUserId: number;
  importedByName: string | null;
};

/** Explicitly imports only server-reparsed, non-duplicate HMS rows; it never creates public requests or patient files. */
export async function importHmsCsvAppointments(input: HmsCsvImportInput) {
  const preview = await previewHmsCsvImport(input.csvText);
  if (preview.fatalErrors.length) throw new Error(preview.fatalErrors.join(" "));
  if (preview.fileAlreadyImported) throw new Error("This exact HMS file has already been imported and cannot be imported again.");
  if (!preview.providerVerifiedFromSource || preview.normalizedProviderCode !== "NR011") throw new Error("The HMS source provider could not be verified as NR011 JAMES FLORES.");
  const importable = preview.rows.filter(row => row.validation === "READY" || row.validation === "WARNING");
  if (!importable.length) throw new Error("No valid, non-duplicate HMS appointments are available to sync.");

  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");
  return db.transaction(async tx => {
    const priorBatch = await tx.select({ id: hmsImportBatches.id }).from(hmsImportBatches).where(eq(hmsImportBatches.fileSha256, preview.fileSha256)).limit(1);
    if (priorBatch[0]) throw new Error("This exact HMS file has already been imported and cannot be imported again.");
    const importIdentityRows = importable.map(row => ({
      row,
      identityKey: hmsAppointmentIdentityKey(row),
    })).filter((entry): entry is { row: HmsPreviewRow; identityKey: string } => Boolean(entry.identityKey));
    const importMrns = Array.from(new Set(importIdentityRows.map(entry => entry.row.mrn).filter((value): value is string => Boolean(value))));
    const importPhones = Array.from(new Set(importIdentityRows.map(entry => entry.row.normalizedWhatsapp).filter((value): value is string => Boolean(value))));
    const [fingerprintRows, existingIdentityRows] = await Promise.all([
      tx.select({ importFingerprint: appointments.importFingerprint }).from(appointments).where(inArray(appointments.importFingerprint, importable.map(row => row.fingerprint))),
      importMrns.length && importPhones.length
        ? tx.select({ mrn: appointments.mrn, whatsapp: appointments.whatsapp, appointmentDate: appointments.appointmentDate, appointmentTime: appointments.appointmentTime }).from(appointments).where(and(inArray(appointments.mrn, importMrns), inArray(appointments.whatsapp, importPhones)))
        : Promise.resolve([]),
    ]);
    const existingFingerprints = new Set(fingerprintRows.map(row => row.importFingerprint).filter((value): value is string => Boolean(value)));
    const existingIdentityKeys = new Set(existingIdentityRows.map(row => hmsAppointmentIdentityKey({
      mrn: row.mrn,
      normalizedWhatsapp: row.whatsapp,
      appointmentDate: row.appointmentDate,
      appointmentStartTime: row.appointmentTime,
    })).filter((value): value is string => Boolean(value)));
    const rowsToImport = importable.filter(row => !existingFingerprints.has(row.fingerprint) && !existingIdentityKeys.has(hmsAppointmentIdentityKey(row) ?? ""));
    const concurrentDuplicateCount = importable.length - rowsToImport.length;
    if (!rowsToImport.length) throw new Error("All selected appointments are already present. Refresh the preview to review the skipped duplicates.");
    const batchInsert = await tx.insert(hmsImportBatches).values({
      source: "hms_csv",
      originalFileName: input.originalFileName,
      fileSha256: preview.fileSha256,
      sourceFileKey: null,
      providerCode: "NR011",
      providerLabel: "NR011 JAMES FLORES",
      rowCount: preview.summary.total,
      importedCount: rowsToImport.length,
      skippedDuplicateCount: preview.summary.duplicates + concurrentDuplicateCount,
      warningCount: preview.summary.warnings,
      errorCount: preview.summary.errors,
      importedByUserId: input.importedByUserId,
    });
    const batchId = Number(batchInsert[0].insertId);
    for (const row of rowsToImport) {
      await tx.insert(appointments).values({
        consultationRequestId: null, patientId: null, patientName: row.patientName, whatsapp: row.normalizedWhatsapp, mrn: row.mrn,
        appointmentDate: row.appointmentDate!, appointmentTime: row.appointmentStartTime!, appointmentEndTime: row.appointmentEndTime,
        treatmentArea: null, treatmentAreas: null, machine: row.suggestedMachine, visitType: "unknown", internalNotes: null, assignedStaff: null, durationMinutes: null,
        originalConsentSetReference: null, originalConsentAcknowledgedAt: null, originalConsentLanguage: null, consentSignatureStatus: "not_applicable", consentSignatureReference: null,
        source: "hms_csv", sourceRowNumber: row.sourceRowNumber, importBatchId: batchId, importFingerprint: row.fingerprint, hmsImportIdentityKey: hmsAppointmentIdentityKey(row),
        originalAppointmentDate: row.raw.Datasp_RPTAllAppointment_Screen_APPTDATE, originalAppointmentStartTime: row.raw.Datasp_RPTAllAppointment_Screen_FirstAppointment, originalAppointmentEndTime: row.raw.Datasp_RPTAllAppointment_Screen_LastAppointment,
        originalTelephone: row.originalTelephone, originalSex: row.originalSex, normalizedSex: row.normalizedSex, originalAge: row.originalAge, normalizedAge: row.normalizedAge,
        nationality: row.nationality, remarks: row.remarks, originalRowData: JSON.stringify(row.raw), status: "confirmed",
      });
    }
    await tx.insert(activityLogs).values({ actorName: input.importedByName, action: `Imported HMS appointment batch ${batchId}: ${rowsToImport.length} appointments; skipped ${preview.summary.duplicates + concurrentDuplicateCount} duplicates`, subjectType: "hms_import_batch", subjectId: batchId });
    return { batchId, importedCount: rowsToImport.length, skippedDuplicateCount: preview.summary.duplicates + concurrentDuplicateCount, warningCount: preview.summary.warnings, errorCount: preview.summary.errors };
  });
}

function csvCell(value: unknown) {
  const raw = value === null || value === undefined ? "" : String(value);
  const safe = /^[=+@-]/.test(raw.trimStart()) ? `'${raw}` : raw;
  return `"${safe.replace(/"/g, '""')}"`;
}

/**
 * Builds a transient CSV download from the protected HMS appointment mirror.
 * Only batches explicitly attested as NR011 are included; internal workflow
 * records and raw source JSON are intentionally excluded from this export.
 */
export async function exportHmsClinicRecordsCsv() {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");
  const rows = await db.select({
    recordId: appointments.id,
    patientName: appointments.patientName,
    mrn: appointments.mrn,
    whatsapp: appointments.whatsapp,
    appointmentDate: appointments.appointmentDate,
    appointmentTime: appointments.appointmentTime,
    appointmentEndTime: appointments.appointmentEndTime,
    status: appointments.status,
    nationality: appointments.nationality,
    originalTelephone: appointments.originalTelephone,
    originalSex: appointments.originalSex,
    originalAge: appointments.originalAge,
    remarks: appointments.remarks,
    visitType: appointments.visitType,
    sourceRowNumber: appointments.sourceRowNumber,
    importBatchId: appointments.importBatchId,
    providerCode: hmsImportBatches.providerCode,
    providerLabel: hmsImportBatches.providerLabel,
  }).from(appointments)
    .innerJoin(hmsImportBatches, eq(appointments.importBatchId, hmsImportBatches.id))
    .where(and(eq(appointments.source, "hms_csv"), eq(hmsImportBatches.providerCode, "NR011")))
    .orderBy(asc(appointments.appointmentDate), asc(appointments.appointmentTime), asc(appointments.id));

  const headers = [
    "Clinic Record ID", "Provider Code", "Provider Label", "Patient Name", "MRN", "WhatsApp",
    "Appointment Date", "Start Time", "End Time", "Status", "Nationality", "Original Telephone",
    "Original Sex", "Original Age", "Visit Type", "HMS Source Row", "HMS Import Batch", "Remarks",
  ];
  const values = rows.map(row => [
    row.recordId, row.providerCode, row.providerLabel, row.patientName, row.mrn, row.whatsapp,
    row.appointmentDate, row.appointmentTime, row.appointmentEndTime, row.status, row.nationality,
    row.originalTelephone, row.originalSex, row.originalAge, row.visitType, row.sourceRowNumber,
    row.importBatchId, row.remarks,
  ]);
  return [headers, ...values].map(row => row.map(csvCell).join(",")).join("\\r\\n") + "\\r\\n";
}

export type ManualPatientEntry = {
  fullName: string;
  mrn: string | null;
  nationality: string;
  contactNumber: string | null;
  whatsapp: string;
  email: string | null;
  treatmentArea: string;
  notes: string | null;
};

/** Creates a protected patient file from staff-entered details only; it never creates a public request or appointment. */
export async function createManualPatient(input: ManualPatientEntry, createdBy: string | null) {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");
  const normalizedWhatsapp = normalizeMobileNumber(input.whatsapp);
  return db.transaction(async tx => {
    const existingWhatsapp = await tx.select({ id: patients.id }).from(patients).where(eq(patients.whatsapp, normalizedWhatsapp)).limit(1);
    if (existingWhatsapp[0]) throw new Error("A patient file already exists for this WhatsApp number.");
    if (input.mrn) {
      const existingMrn = await tx.select({ id: patients.id }).from(patients).where(eq(patients.mrn, input.mrn)).limit(1);
      if (existingMrn[0]) throw new Error("This manual MRN is already assigned to another patient file.");
    }
    const created = await tx.insert(patients).values({
      fullName: input.fullName,
      mrn: input.mrn,
      contactNumber: input.contactNumber,
      whatsapp: normalizedWhatsapp,
      email: input.email,
      nationality: input.nationality,
      treatmentArea: input.treatmentArea,
      preferredContact: "WhatsApp",
      source: "manual_admin",
      firstTime: null,
      lastLaserSession: null,
      takingMedication: null,
      medicationDetails: null,
      tookVitaminD: null,
      vitaminDLastTaken: null,
      takingIron: null,
      ironLastTaken: null,
      tannedPastThreeMonths: null,
      hadMoroccanBathLastSevenDays: null,
      hadSkinTreatment: null,
      skinTreatmentDetails: null,
      hadSevereSunExposure: null,
      notes: input.notes,
    });
    const patientId = Number(created[0].insertId);
    await tx.insert(activityLogs).values({ actorName: createdBy, action: "Created manual patient file", subjectType: "patient", subjectId: patientId });
    return { patientId };
  });
}

export type ManualAppointmentEntry = {
  fullName: string;
  mrn: string | null;
  nationality: string;
  contactNumber: string | null;
  whatsapp: string;
  email: string | null;
  appointmentDate: string;
  appointmentTime: string;
  treatmentAreas: string[];
  machine: ClinicMachine;
  visitType: VisitType;
  nextFollowUpDate?: string | null;
  nextFollowUpType?: FollowUpType | null;
  notes: string | null;
};

/** Creates a staff-entered appointment record without creating a public request, patient file, consent record, or signature session. */
export async function createManualAppointment(input: ManualAppointmentEntry, createdBy: string | null) {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");
  const normalizedWhatsapp = normalizeMobileNumber(input.whatsapp);
  return db.transaction(async tx => {
    const durationMinutes = clinicDurationMinutes(input.treatmentAreas, input.visitType);
    const finalizedAppointmentEndTime = appointmentEndTime(input.appointmentTime, durationMinutes);
    const schedulingConflicts = await tx.select({ id: appointments.id, appointmentTime: appointments.appointmentTime, appointmentEndTime: appointments.appointmentEndTime, durationMinutes: appointments.durationMinutes, whatsapp: appointments.whatsapp, machine: appointments.machine }).from(appointments).where(and(
      eq(appointments.appointmentDate, input.appointmentDate),
      inArray(appointments.status, ["confirmed", "waiting", "arrived"]),
    ));
    const overlappingConflicts = schedulingConflicts.map(conflict => hasAppointmentConflict({ appointmentTime: input.appointmentTime, appointmentEndTime: finalizedAppointmentEndTime, whatsapp: normalizedWhatsapp, machine: input.machine }, conflict));
    if (overlappingConflicts.some(conflict => conflict.mobile)) throw new Error("A scheduled appointment already overlaps this mobile number.");
    if (overlappingConflicts.some(conflict => conflict.machine)) throw new Error("The selected machine is already assigned during the selected appointment time.");
    const existingWhatsapp = await tx.select({ id: patients.id }).from(patients).where(eq(patients.whatsapp, normalizedWhatsapp)).limit(1);
    const existingMrn = input.mrn ? await tx.select({ id: patients.id }).from(patients).where(eq(patients.mrn, input.mrn)).limit(1) : [];
    const matchingPatientId = resolveSinglePatientFile({ mobilePatientId: existingWhatsapp[0]?.id ?? null, mrnPatientId: existingMrn[0]?.id ?? null });
    const created = await tx.insert(appointments).values({
      consultationRequestId: null,
      patientId: matchingPatientId,
      patientName: input.fullName,
      contactNumber: input.contactNumber,
      whatsapp: normalizedWhatsapp,
      email: input.email,
      mrn: input.mrn,
      appointmentDate: input.appointmentDate,
      appointmentTime: input.appointmentTime,
      appointmentEndTime: finalizedAppointmentEndTime,
      treatmentArea: input.treatmentAreas[0],
      treatmentAreas: JSON.stringify(input.treatmentAreas),
      machine: input.machine,
      visitType: input.visitType,
      nextFollowUpDate: input.nextFollowUpDate || null,
      nextFollowUpType: input.nextFollowUpType || null,
      internalNotes: input.notes,
      assignedStaff: createdBy,
      durationMinutes,
      originalConsentSetReference: null,
      originalConsentAcknowledgedAt: null,
      originalConsentLanguage: null,
      consentSignatureStatus: "not_applicable",
      consentSignatureReference: null,
      source: "manual_admin",
      sourceRowNumber: null,
      importBatchId: null,
      importFingerprint: null,
      originalAppointmentDate: null,
      originalAppointmentStartTime: null,
      originalAppointmentEndTime: null,
      originalTelephone: null,
      originalSex: null,
      normalizedSex: null,
      originalAge: null,
      normalizedAge: null,
      nationality: input.nationality,
      remarks: null,
      originalRowData: null,
      whatsappAutomationInitializedAt: new Date(),
      whatsappAutomationVersion: 1,
      status: "confirmed",
    });
    const appointmentId = Number(created[0].insertId);
    await tx.insert(activityLogs).values({ actorName: createdBy, action: "Created manual appointment", subjectType: "appointment", subjectId: appointmentId });
    return { appointmentId, patientId: matchingPatientId };
  });
}

export type PatientFileUpdate = {
  patientId: number;
  fullName: string;
  mrn: string | null;
  nationality: string;
  contactNumber: string | null;
  whatsapp: string;
  email: string | null;
  treatmentArea: string;
  notes: string | null;
};

/** Updates editable clinic profile details only; source intake/safety history stays retained. */
export async function updatePatientFile(input: PatientFileUpdate, updatedBy: string | null) {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");
  const normalizedWhatsapp = normalizeMobileNumber(input.whatsapp);
  return db.transaction(async tx => {
    const current = await tx.select({ id: patients.id }).from(patients).where(eq(patients.id, input.patientId)).limit(1);
    if (!current[0]) throw new Error("The patient file was not found.");
    const byWhatsapp = await tx.select({ id: patients.id }).from(patients).where(eq(patients.whatsapp, normalizedWhatsapp)).limit(1);
    const byMrn = input.mrn ? await tx.select({ id: patients.id }).from(patients).where(eq(patients.mrn, input.mrn)).limit(1) : [];
    if (byWhatsapp[0] && byWhatsapp[0].id !== input.patientId) throw new Error("A different patient file already uses this mobile number.");
    if (byMrn[0] && byMrn[0].id !== input.patientId) throw new Error("A different patient file already uses this MRN.");
    await tx.update(patients).set({
      fullName: input.fullName,
      mrn: input.mrn,
      nationality: input.nationality,
      contactNumber: input.contactNumber,
      whatsapp: normalizedWhatsapp,
      email: input.email,
      treatmentArea: input.treatmentArea,
      notes: input.notes,
    }).where(eq(patients.id, input.patientId));
    await tx.insert(activityLogs).values({ actorName: updatedBy, action: "Updated patient file profile", subjectType: "patient", subjectId: input.patientId });
  });
}

export type AppointmentDetailsUpdate = {
  appointmentId: number;
  fullName: string;
  mrn: string | null;
  nationality: string;
  contactNumber: string | null;
  whatsapp: string;
  email: string | null;
  appointmentDate: string;
  appointmentTime: string;
  treatmentAreas: string[];
  machine: ClinicMachine;
  visitType: VisitType;
  nextFollowUpDate?: string | null;
  nextFollowUpType?: FollowUpType | null;
  notes: string | null;
};

/** Updates local working details without modifying HMS source/audit fields or consent evidence. */
export async function updateAppointmentDetails(input: AppointmentDetailsUpdate, updatedBy: string | null) {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");
  const normalizedWhatsapp = normalizeMobileNumber(input.whatsapp);
  return db.transaction(async tx => {
    const current = await tx.select().from(appointments).where(eq(appointments.id, input.appointmentId)).limit(1);
    const appointment = current[0];
    if (!appointment) throw new Error("The appointment was not found.");
    const durationMinutes = clinicDurationMinutes(input.treatmentAreas, input.visitType);
    const finalizedAppointmentEndTime = appointmentEndTime(input.appointmentTime, durationMinutes);
    const schedulingConflicts = await tx.select({ id: appointments.id, appointmentTime: appointments.appointmentTime, appointmentEndTime: appointments.appointmentEndTime, durationMinutes: appointments.durationMinutes, whatsapp: appointments.whatsapp, machine: appointments.machine }).from(appointments).where(and(
      eq(appointments.appointmentDate, input.appointmentDate),
      inArray(appointments.status, ["confirmed", "waiting", "arrived"]),
    ));
    const overlappingConflicts = schedulingConflicts.filter(conflict => conflict.id !== input.appointmentId).map(conflict => hasAppointmentConflict({ appointmentTime: input.appointmentTime, appointmentEndTime: finalizedAppointmentEndTime, whatsapp: normalizedWhatsapp, machine: input.machine }, conflict));
    if (overlappingConflicts.some(conflict => conflict.mobile)) throw new Error("A scheduled appointment already overlaps this mobile number.");
    if (overlappingConflicts.some(conflict => conflict.machine)) throw new Error("The selected machine is already assigned during the selected appointment time.");
    const byWhatsapp = await tx.select({ id: patients.id }).from(patients).where(eq(patients.whatsapp, normalizedWhatsapp)).limit(1);
    const byMrn = input.mrn ? await tx.select({ id: patients.id }).from(patients).where(eq(patients.mrn, input.mrn)).limit(1) : [];
    const matchingPatientId = resolveSinglePatientFile({ mobilePatientId: byWhatsapp[0]?.id ?? null, mrnPatientId: byMrn[0]?.id ?? null, linkedPatientId: appointment.patientId });
    const scheduleChanged = appointment.appointmentDate !== input.appointmentDate || appointment.appointmentTime !== input.appointmentTime;
    await tx.update(appointments).set({
      patientId: matchingPatientId,
      patientName: input.fullName,
      mrn: input.mrn,
      nationality: input.nationality,
      contactNumber: input.contactNumber,
      whatsapp: normalizedWhatsapp,
      email: input.email,
      appointmentDate: input.appointmentDate,
      appointmentTime: input.appointmentTime,
      appointmentEndTime: finalizedAppointmentEndTime,
      treatmentArea: input.treatmentAreas[0],
      treatmentAreas: JSON.stringify(input.treatmentAreas),
      machine: input.machine,
      visitType: input.visitType,
      durationMinutes,
      nextFollowUpDate: input.nextFollowUpDate || null,
      nextFollowUpType: input.nextFollowUpType || null,
      internalNotes: input.notes,
      ...(scheduleChanged ? {
        whatsappAutomationInitializedAt: new Date(),
        whatsappAutomationVersion: sql`${appointments.whatsappAutomationVersion} + 1`,
      } : {}),
    }).where(eq(appointments.id, input.appointmentId));
    await tx.insert(activityLogs).values({ actorName: updatedBy, action: appointment.source === "hms_csv" ? "Updated HMS appointment local details; source evidence preserved" : "Updated appointment details", subjectType: "appointment", subjectId: input.appointmentId });
  });
}

/** A selected operational date retains appointments after every recorded staff outcome. */
export type ReminderStatus = "due" | "upcoming" | "overdue" | "missing";

function getReminderStatus(date: string | null): ReminderStatus {
  if (!date) return "missing";
  const today = riyadhDate();
  if (date < today) return "overdue";
  if (date === today) return "due";
  return "upcoming";
}

/** Lists confirmed operational records with explicit staff-entered next follow-up details. */
export async function listSessionRetouchReminders() {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");
  const rows = await db.select().from(appointments)
    .where(inArray(appointments.status, ["confirmed", "arrived", "completed"]))
    .orderBy(asc(appointments.nextFollowUpDate), desc(appointments.appointmentDate), asc(appointments.appointmentTime));
  return rows.map(appointment => ({ ...appointment, reminderStatus: getReminderStatus(appointment.nextFollowUpDate) }));
}

export async function listTodayWaitingList(date = riyadhDate()) {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");

  return db.select().from(appointments)
    .where(and(
      eq(appointments.appointmentDate, date),
      inArray(appointments.status, ["confirmed", "waiting", "arrived", "no-show", "completed", "cancelled"]),
    ))
    .orderBy(asc(appointments.appointmentTime));
}

export type ArrivalDetailsEntry = {
  appointmentId: number;
  fullName: string;
  mrn: string | null;
  nationality: string;
  contactNumber: string;
  whatsapp: string;
  email: string | null;
  treatmentAreas: string[];
  machine: ClinicMachine;
  visitType: VisitType;
  nurseNotes: string;
};

/**
 * Records waiting or arrival and creates/links the patient file in one transaction.
 * HMS source fields and source audit evidence remain unchanged; local nurse notes
 * and the patient link are clinic-owned fields.
 */
async function recordWaitingListPatient(input: ArrivalDetailsEntry, recordedBy: string | null, targetStatus: WaitingStatus) {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");
  const normalizedWhatsapp = normalizeMobileNumber(input.whatsapp);

  return db.transaction(async tx => {
    const rows = await tx.select().from(appointments).where(eq(appointments.id, input.appointmentId)).limit(1);
    const appointment = rows[0];
    if (!appointment) throw new Error("The appointment was not found.");
    if (appointment.appointmentDate !== riyadhDate()) throw new Error(`Only today’s Riyadh appointments can be marked ${targetStatus}.`);
    if (appointment.status !== "confirmed") throw new Error("Only a confirmed appointment can enter the waiting-list intake workflow.");

    const byWhatsapp = await tx.select({ id: patients.id, mrn: patients.mrn, email: patients.email }).from(patients).where(eq(patients.whatsapp, normalizedWhatsapp)).limit(1);
    const byMrn = input.mrn ? await tx.select({ id: patients.id, mrn: patients.mrn, email: patients.email }).from(patients).where(eq(patients.mrn, input.mrn)).limit(1) : [];
    let patientId = resolveSinglePatientFile({
      mobilePatientId: byWhatsapp[0]?.id ?? null,
      mrnPatientId: byMrn[0]?.id ?? null,
      linkedPatientId: appointment.patientId,
    });
    let createdPatient = false;

    if (!patientId) {
      const created = await tx.insert(patients).values({
        fullName: input.fullName,
        mrn: input.mrn,
        contactNumber: input.contactNumber,
        whatsapp: normalizedWhatsapp,
        email: input.email,
        nationality: input.nationality,
        treatmentArea: input.treatmentAreas[0],
        preferredContact: "WhatsApp",
        source: "waiting_list_intake",
        firstTime: null,
        lastLaserSession: null,
        takingMedication: null,
        medicationDetails: null,
        tookVitaminD: null,
        vitaminDLastTaken: null,
        takingIron: null,
        ironLastTaken: null,
        tannedPastThreeMonths: null,
        hadMoroccanBathLastSevenDays: null,
        hadSkinTreatment: null,
        skinTreatmentDetails: null,
        hadSevereSunExposure: null,
        notes: null,
      });
      patientId = Number(created[0].insertId);
      createdPatient = true;
    } else {
      await tx.update(patients).set({
        fullName: input.fullName,
        mrn: input.mrn ?? byWhatsapp[0]?.mrn ?? byMrn[0]?.mrn ?? null,
        contactNumber: input.contactNumber,
        whatsapp: normalizedWhatsapp,
        email: input.email ?? byWhatsapp[0]?.email ?? byMrn[0]?.email ?? null,
        nationality: input.nationality,
        treatmentArea: input.treatmentAreas[0],
      }).where(eq(patients.id, patientId));
    }

    const clinicOwnedAppointmentFields = appointment.source === "hms_csv" ? {} : {
      patientName: input.fullName,
      mrn: input.mrn,
      nationality: input.nationality,
      contactNumber: input.contactNumber,
      whatsapp: normalizedWhatsapp,
      email: input.email,
    };
    const updated = await tx.update(appointments).set({
      ...clinicOwnedAppointmentFields,
      patientId,
      treatmentArea: input.treatmentAreas[0],
      treatmentAreas: JSON.stringify(input.treatmentAreas),
      machine: input.machine,
      visitType: input.visitType,
      status: targetStatus,
      internalNotes: input.nurseNotes,
      assignedStaff: appointment.assignedStaff ?? recordedBy,
    }).where(and(
      eq(appointments.id, input.appointmentId),
      eq(appointments.appointmentDate, riyadhDate()),
      eq(appointments.status, "confirmed"),
    ));
    if (updated[0].affectedRows !== 1) throw new Error("The waiting-list update could not be saved because the appointment changed. Refresh and try again.");

    await tx.insert(activityLogs).values({
      actorName: recordedBy,
      action: createdPatient ? `Marked ${targetStatus} and created patient file` : `Marked ${targetStatus} and linked patient file`,
      subjectType: "appointment",
      subjectId: input.appointmentId,
    });
    return { patientId, createdPatient };
  });
}

/** Creates or links the patient record while placing a confirmed appointment in the waiting queue. */
export async function markAppointmentWaiting(input: ArrivalDetailsEntry, recordedBy: string | null) {
  return recordWaitingListPatient(input, recordedBy, "waiting");
}

/** Confirms physical arrival and creates or links the patient record in one protected transaction. */
export async function confirmAppointmentArrival(input: ArrivalDetailsEntry, recordedBy: string | null) {
  return recordWaitingListPatient(input, recordedBy, "arrived");
}

export async function markAppointmentAttendance(appointmentId: number, status: AttendanceStatus) {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");

  const permittedSourceStatus = status === "arrived" ? "waiting" : "confirmed";
  const result = await db.update(appointments).set({ status })
    .where(and(
      eq(appointments.id, appointmentId),
      eq(appointments.appointmentDate, riyadhDate()),
      eq(appointments.status, permittedSourceStatus),
    ));

  if (result[0].affectedRows !== 1) {
    throw new Error(status === "arrived"
      ? "Only today’s waiting appointments can be marked arrived."
      : "Only today’s confirmed appointments can be updated with this outcome.");
  }
}

export async function listPatients(search?: string) {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");

  const normalized = search?.trim();
  const query = db.select().from(patients);
  if (!normalized) return query.orderBy(desc(patients.updatedAt)).limit(100);

  const pattern = `%${normalized}%`;
  return query.where(or(like(patients.fullName, pattern), like(patients.whatsapp, pattern), like(patients.mrn, pattern))).orderBy(desc(patients.updatedAt)).limit(100);
}

export async function getPatientFile(patientId: number) {
  const db = await getDb();
  if (!db) throw new Error("The admin service is temporarily unavailable.");

  const result = await db.select().from(patients).where(eq(patients.id, patientId)).limit(1);
  const patient = result[0];
  if (!patient) throw new Error("The patient file was not found.");

  const history = await db.select().from(appointments).where(eq(appointments.patientId, patient.id)).orderBy(desc(appointments.appointmentDate), desc(appointments.appointmentTime));
  return { patient, appointments: history };
}
