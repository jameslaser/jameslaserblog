import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const cloudBuild = readFileSync(resolve(process.cwd(), "cloudbuild.yaml"), "utf8");

describe("Cloud Run-only build configuration", () => {
  it("builds and deploys the Cloud Run image without obsolete hosting assumptions", () => {
    expect(cloudBuild).toContain("Dockerfile.cloudrun");
    expect(cloudBuild).toContain("gcloud");
    expect(cloudBuild).toContain("run");
    expect(cloudBuild).toContain("--port=8080");
    expect(cloudBuild).toContain("--no-invoker-iam-check");
    expect(cloudBuild).not.toContain("--allow-unauthenticated");
    expect(cloudBuild).not.toMatch(/web\.app|firebaseapp\.com|firebase deploy/i);
  });

  it("contains no obsolete managed-hosting configuration artifacts", () => {
    for (const artifact of ["firebase.json", "server/firebaseDeploymentConfig.test.ts", "FIREBASE_CLOUD_RUN_DEPLOYMENT.md", "FIREBASE_COMPATIBILITY.md", "FIREBASE_LOCAL_VALIDATION.md", "FIREBASE_OWNER_PROJECT_STATUS.md"]) {
      expect(existsSync(resolve(process.cwd(), artifact))).toBe(false);
    }
  });
});
