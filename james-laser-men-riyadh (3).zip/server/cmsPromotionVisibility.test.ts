import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const source = readFileSync(resolve(process.cwd(), "server/cms.ts"), "utf8");

describe("CMS promotion visibility", () => {
  it("counts only published promotions currently within their public display window", () => {
    const dashboard = source.slice(source.indexOf("export async function cmsDashboardStats"), source.indexOf("export async function recentCmsActivity"));
    expect(dashboard).toContain('eq(promotions.status, "published")');
    expect(dashboard).toContain("isNull(promotions.startsAt), lte(promotions.startsAt, now)");
    expect(dashboard).toContain("isNull(promotions.endsAt), gte(promotions.endsAt, now)");
  });

  it("uses the same date-window conditions when selecting public promotions", () => {
    const publicList = source.slice(source.indexOf("export async function listPromotions"), source.indexOf("export async function savePromotion"));
    expect(publicList).toContain("isNull(promotions.startsAt), lte(promotions.startsAt, now)");
    expect(publicList).toContain("isNull(promotions.endsAt), gte(promotions.endsAt, now)");
  });
});
