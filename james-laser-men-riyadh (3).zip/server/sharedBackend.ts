import { and, asc, desc, eq, gte, gt, lt } from "drizzle-orm";
import { analyticsEvents, consultationRequests, enquiries, guidePosts, promotions, publicFormSecurityEvents, redirects, reviews, treatments } from "../drizzle/schema";
import { getDb } from "./db";
import { logCmsActivity } from "./cms";

type Actor = { id: number; name: string | null };
type PublicFormType = "consultation_request" | "enquiry" | "web_chat";
type DeviceType = "desktop" | "mobile" | "tablet" | "unknown";
type AnalyticsEventType = "page_view" | "whatsapp_click" | "appointment_click" | "appointment_form_start" | "appointment_form_submit" | "treatment_view" | "guide_view" | "social_click";

async function database() {
  const db = await getDb();
  if (!db) throw new Error("The shared website service is temporarily unavailable.");
  return db;
}

export async function guardPublicSubmission(formType: PublicFormType, fingerprint: string, trustedSignalFingerprint: string) {
  const db = await database();
  const now = new Date();
  const duplicateCutoff = new Date(now.getTime() - 20 * 60 * 1000);
  const rateCutoff = new Date(now.getTime() - 10 * 60 * 1000);
  const retentionCutoff = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  const [duplicates, recent] = await Promise.all([
    db.select({ id: publicFormSecurityEvents.id }).from(publicFormSecurityEvents).where(and(eq(publicFormSecurityEvents.formType, formType), eq(publicFormSecurityEvents.fingerprint, fingerprint), gt(publicFormSecurityEvents.createdAt, duplicateCutoff))).limit(1),
    db.select({ id: publicFormSecurityEvents.id }).from(publicFormSecurityEvents).where(and(eq(publicFormSecurityEvents.formType, formType), eq(publicFormSecurityEvents.fingerprint, trustedSignalFingerprint), gt(publicFormSecurityEvents.createdAt, rateCutoff))),
  ]);
  if (duplicates.length) throw new Error("A matching submission was received recently. Please wait before sending it again.");
  if (recent.length >= 5) throw new Error("Too many submissions from this browser. Please wait a few minutes and try again.");
  await db.insert(publicFormSecurityEvents).values([{ formType, fingerprint }, { formType, fingerprint: trustedSignalFingerprint }]);
  await db.delete(publicFormSecurityEvents).where(lt(publicFormSecurityEvents.createdAt, retentionCutoff));
}

/** Apply trusted-signal throttling without rejecting a possibly legitimate matching appointment preference. */
export async function guardAppointmentRequestRate(formType: PublicFormType, trustedSignalFingerprint: string) {
  const db = await database();
  const now = new Date();
  const rateCutoff = new Date(now.getTime() - 10 * 60 * 1000);
  const retentionCutoff = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  const recent = await db.select({ id: publicFormSecurityEvents.id }).from(publicFormSecurityEvents).where(and(eq(publicFormSecurityEvents.formType, formType), eq(publicFormSecurityEvents.fingerprint, trustedSignalFingerprint), gt(publicFormSecurityEvents.createdAt, rateCutoff)));
  if (recent.length >= 5) throw new Error("Too many submissions from this browser. Please wait a few minutes and try again.");
  await db.insert(publicFormSecurityEvents).values({ formType, fingerprint: trustedSignalFingerprint });
  await db.delete(publicFormSecurityEvents).where(lt(publicFormSecurityEvents.createdAt, retentionCutoff));
}

export async function createEnquiry(input: typeof enquiries.$inferInsert) {
  const db = await database();
  const [result] = await db.insert(enquiries).values(input).$returningId();
  if (!result) throw new Error("Enquiry could not be created.");
  return { id: result.id };
}

export async function listEnquiries() {
  const db = await database();
  return db.select().from(enquiries).orderBy(desc(enquiries.createdAt));
}

export async function updateEnquiry(id: number, values: Pick<typeof enquiries.$inferInsert, "status" | "internalNotes">, actor: Actor) {
  const db = await database();
  const changes: Partial<typeof enquiries.$inferInsert> = {};
  if (values.status !== undefined) changes.status = values.status;
  if (values.internalNotes !== undefined) changes.internalNotes = values.internalNotes;
  await db.update(enquiries).set(changes).where(eq(enquiries.id, id));
  const result = await db.select({ id: enquiries.id }).from(enquiries).where(eq(enquiries.id, id)).limit(1);
  if (result.length !== 1) throw new Error("Enquiry not found.");
  await logCmsActivity(actor, `Updated enquiry status to ${values.status ?? "unchanged"}`, "enquiry", id);
}

export async function recordAnalyticsEvent(input: { eventType: AnalyticsEventType; path?: string | null; locale?: "en" | "ar-SA" | null; source?: string | null; deviceType: DeviceType; treatmentSlug?: string | null; contentSlug?: string | null }) {
  const db = await database();
  await db.insert(analyticsEvents).values(input);
}

export async function analyticsOverview() {
  const db = await database();
  const from = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const rows = await db.select().from(analyticsEvents).where(gte(analyticsEvents.createdAt, from));
  const count = (type: AnalyticsEventType) => rows.filter(row => row.eventType === type).length;
  const rank = (values: Array<string | null>) => Object.entries(values.filter((value): value is string => Boolean(value)).reduce<Record<string, number>>((total, value) => { total[value] = (total[value] ?? 0) + 1; return total; }, {})).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([label, total]) => ({ label, total }));
  const pageViews = count("page_view");
  const formStarts = count("appointment_form_start");
  const formSubmissions = count("appointment_form_submit");
  return {
    windowDays: 30,
    pageViews,
    whatsappClicks: count("whatsapp_click"),
    appointmentClicks: count("appointment_click"),
    socialClicks: count("social_click"),
    formStarts,
    formSubmissions,
    conversionRate: formStarts ? Number(((formSubmissions / formStarts) * 100).toFixed(1)) : 0,
    languageUsage: rank(rows.filter(row => row.eventType === "page_view").map(row => row.locale)),
    deviceTypes: rank(rows.map(row => row.deviceType)),
    trafficSources: rank(rows.map(row => row.source)),
    popularTreatments: rank(rows.filter(row => row.eventType === "treatment_view").map(row => row.treatmentSlug)),
    popularGuidePosts: rank(rows.filter(row => row.eventType === "guide_view").map(row => row.contentSlug)),
    socialPlatforms: rank(rows.filter(row => row.eventType === "social_click").map(row => row.contentSlug)),
  };
}

function normalizeRedirectPath(path: string) {
  const trimmed = path.trim();
  if (!trimmed.startsWith("/") || trimmed.startsWith("//") || trimmed.includes("://") || trimmed.includes("\\") || trimmed.includes("?" ) || trimmed.includes("#")) throw new Error("Redirect paths must be safe site-relative paths without a query or fragment.");
  const normalized = trimmed.length > 1 ? trimmed.replace(/\/+$/, "") : "/";
  if (normalized.startsWith("/api/") || normalized.startsWith("/admin") || normalized.startsWith("/manus-storage")) throw new Error("Redirects cannot target protected, API, or storage paths.");
  return normalized;
}

export async function listRedirects() {
  const db = await database();
  return db.select().from(redirects).orderBy(asc(redirects.fromPath));
}

export async function getRedirectDestination(fromPath: string) {
  const db = await getDb();
  if (!db) return null;
  const record = await db.select({ toPath: redirects.toPath }).from(redirects).where(and(eq(redirects.fromPath, fromPath), eq(redirects.isActive, true))).limit(1);
  return record[0]?.toPath ?? null;
}

export async function saveRedirect(input: { fromPath: string; toPath: string; isActive: boolean }, actor: Actor) {
  const db = await database();
  const fromPath = normalizeRedirectPath(input.fromPath);
  const toPath = normalizeRedirectPath(input.toPath);
  if (fromPath === toPath) throw new Error("A redirect cannot point to itself.");
  const existing = await db.select().from(redirects).where(eq(redirects.isActive, true));
  const graph = new Map(existing.filter(item => item.fromPath !== fromPath).map(item => [item.fromPath, item.toPath]));
  graph.set(fromPath, toPath);
  let cursor = toPath;
  const visited = new Set<string>([fromPath]);
  while (graph.has(cursor)) {
    if (visited.has(cursor)) throw new Error("This redirect would create a loop.");
    visited.add(cursor);
    cursor = graph.get(cursor)!;
  }
  await db.insert(redirects).values({ fromPath, toPath, isActive: input.isActive }).onDuplicateKeyUpdate({ set: { toPath, isActive: input.isActive, updatedAt: new Date() } });
  const record = await db.select().from(redirects).where(eq(redirects.fromPath, fromPath)).limit(1);
  if (!record[0]) throw new Error("Redirect could not be saved.");
  await logCmsActivity(actor, input.isActive ? "Saved permanent redirect" : "Saved inactive redirect", "redirect", record[0].id);
  return record[0];
}

export async function deleteRedirect(id: number, actor: Actor) {
  const db = await database();
  await db.delete(redirects).where(eq(redirects.id, id));
  await logCmsActivity(actor, "Deleted permanent redirect", "redirect", id);
}

export type ExportKind = "appointment_requests" | "treatments" | "promotions" | "reviews" | "guide_posts" | "enquiries";
export async function exportRows(kind: ExportKind) {
  const db = await database();
  if (kind === "appointment_requests") return db.select().from(consultationRequests).orderBy(desc(consultationRequests.createdAt));
  if (kind === "treatments") return db.select().from(treatments).orderBy(asc(treatments.nameEn));
  if (kind === "promotions") return db.select().from(promotions).orderBy(desc(promotions.updatedAt));
  if (kind === "reviews") return db.select().from(reviews).orderBy(desc(reviews.createdAt));
  if (kind === "guide_posts") return db.select().from(guidePosts).orderBy(desc(guidePosts.updatedAt));
  return db.select().from(enquiries).orderBy(desc(enquiries.createdAt));
}
