import { describe, expect, it } from "vitest";
import {
  whatsappActivationPrerequisites,
  whatsappAutomationJobs,
  whatsappAutomationLogs,
  whatsappAutomationTemplateDefinitions,
  whatsappContacts,
  whatsappConversations,
  whatsappMessages,
  whatsappRetouchRequests,
  whatsappSettings,
  whatsappTemplates,
  whatsappWebhookEvents,
} from "../drizzle/schema";
import { getDb } from "./db";
import { listWhatsAppAutomationWorkspace } from "./whatsappAutomation";

const canReadActiveDatabase = Boolean(process.env.DATABASE_URL);

describe.skipIf(!canReadActiveDatabase)("active WhatsApp database read readiness", () => {
  it("allows the application data layer to read every required WhatsApp table without mutating records", async () => {
    const db = await getDb();
    expect(db).not.toBeNull();
    if (!db) return;

    const results = await Promise.all([
      db.select({ id: whatsappSettings.id }).from(whatsappSettings).limit(1),
      db.select({ id: whatsappActivationPrerequisites.id }).from(whatsappActivationPrerequisites).limit(1),
      db.select({ id: whatsappAutomationTemplateDefinitions.id }).from(whatsappAutomationTemplateDefinitions).limit(1),
      db.select({ id: whatsappAutomationJobs.id }).from(whatsappAutomationJobs).limit(1),
      db.select({ id: whatsappWebhookEvents.id }).from(whatsappWebhookEvents).limit(1),
      db.select({ id: whatsappContacts.id }).from(whatsappContacts).limit(1),
      db.select({ id: whatsappConversations.id }).from(whatsappConversations).limit(1),
      db.select({ id: whatsappMessages.id }).from(whatsappMessages).limit(1),
      db.select({ id: whatsappTemplates.id }).from(whatsappTemplates).limit(1),
      db.select({ id: whatsappAutomationLogs.id }).from(whatsappAutomationLogs).limit(1),
      db.select({ id: whatsappRetouchRequests.id }).from(whatsappRetouchRequests).limit(1),
    ]);

    expect(results).toHaveLength(11);
    expect(results.every(Array.isArray)).toBe(true);
  });

  it("loads the protected automation workspace data contract with inactive defaults", async () => {
    const workspace = await listWhatsAppAutomationWorkspace();

    expect(workspace.settings.automationEnabled).toBe(false);
    expect(workspace.providerConfigured).toBe(true);
    expect(Array.isArray(workspace.definitions)).toBe(true);
    expect(Array.isArray(workspace.jobs)).toBe(true);
    expect(Array.isArray(workspace.retouchRequests)).toBe(true);
    expect(Array.isArray(workspace.activationPrerequisites)).toBe(true);
  });
});
