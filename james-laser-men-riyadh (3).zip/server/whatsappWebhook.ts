import { createHash, createHmac, timingSafeEqual } from "node:crypto";
import { getMetaWhatsAppConfig } from "./metaWhatsApp";

export type MetaWebhookMessage = {
  id: string;
  from: string;
  timestamp: string;
  type: string;
  text?: { body?: string };
  interactive?: {
    type?: "button_reply" | "list_reply" | string;
    button_reply?: { id?: string; title?: string };
    list_reply?: { id?: string; title?: string; description?: string };
  };
  image?: { id?: string; mime_type?: string; caption?: string };
  document?: { id?: string; mime_type?: string; filename?: string; caption?: string };
  audio?: { id?: string; mime_type?: string };
  context?: { id?: string };
};

export type MetaWebhookStatus = {
  id: string;
  status: "sent" | "delivered" | "read" | "failed" | string;
  timestamp?: string;
  recipient_id?: string;
  errors?: Array<{ code?: number | string; title?: string; message?: string }>;
};

export type MetaWebhookChange = {
  field?: string;
  value?: {
    metadata?: { phone_number_id?: string; display_phone_number?: string };
    contacts?: Array<{ wa_id?: string; profile?: { name?: string } }>;
    messages?: MetaWebhookMessage[];
    statuses?: MetaWebhookStatus[];
  };
};

export type MetaWebhookPayload = {
  object?: string;
  entry?: Array<{ id?: string; changes?: MetaWebhookChange[] }>;
};

export function metaWebhookFingerprint(rawBody: Buffer) {
  return createHash("sha256").update(rawBody).digest("hex");
}

export function verifyMetaWebhookSignature(rawBody: Buffer, signatureHeader: string | undefined, appSecret: string) {
  if (!signatureHeader?.startsWith("sha256=") || !appSecret) return false;
  const expected = `sha256=${createHmac("sha256", appSecret).update(rawBody).digest("hex")}`;
  const actual = signatureHeader.trim();
  const expectedBuffer = Buffer.from(expected);
  const actualBuffer = Buffer.from(actual);
  return expectedBuffer.length === actualBuffer.length && timingSafeEqual(expectedBuffer, actualBuffer);
}

export function verifyMetaWebhookChallenge(query: Record<string, unknown>) {
  const config = getMetaWhatsAppConfig();
  if (!config) return null;
  const mode = query["hub.mode"];
  const verifyToken = query["hub.verify_token"];
  const challenge = query["hub.challenge"];
  const provided = typeof verifyToken === "string" ? Buffer.from(verifyToken) : null;
  const expected = Buffer.from(config.webhookVerifyToken);
  if (mode === "subscribe" && provided && provided.length === expected.length && timingSafeEqual(provided, expected) && typeof challenge === "string") return challenge;
  return null;
}

export function parseMetaWebhookPayload(rawBody: Buffer): MetaWebhookPayload | null {
  try {
    const payload = JSON.parse(rawBody.toString("utf8")) as MetaWebhookPayload;
    if (payload?.object !== "whatsapp_business_account" || !Array.isArray(payload.entry)) return null;
    return payload;
  } catch {
    return null;
  }
}

export function safeWebhookSummary(payload: MetaWebhookPayload) {
  const messages = payload.entry?.flatMap(entry => entry.changes?.flatMap(change => change.value?.messages ?? []) ?? []) ?? [];
  const statuses = payload.entry?.flatMap(entry => entry.changes?.flatMap(change => change.value?.statuses ?? []) ?? []) ?? [];
  return `messages=${messages.length};statuses=${statuses.length}`;
}

export function metaTimestamp(value: string | undefined) {
  const seconds = Number(value);
  if (!Number.isFinite(seconds) || seconds <= 0) return new Date();
  return new Date(seconds * 1000);
}
