import { sql } from "drizzle-orm";
import { getDb } from "./db";

export async function getDatabaseReadiness(): Promise<{ ready: boolean }> {
  const db = await getDb();
  if (!db) return { ready: false };

  try {
    await db.execute(sql`SELECT 1`);
    return { ready: true };
  } catch {
    return { ready: false };
  }
}
