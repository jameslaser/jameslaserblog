export type AttentionSeverity = "urgent" | "attention" | "review";

export type AttentionSignals = {
  pendingRequests: number;
  clarificationRequests: number;
  potentialDuplicates: number;
  signatureOutstanding: number;
  expiredSignatures: number;
  newEnquiries: number;
  hmsWarningBatches: number;
};

export type AttentionFinding = {
  id: string;
  severity: AttentionSeverity;
  title: string;
  summary: string;
  count: number;
  linkPath: string;
};

/**
 * Deterministic zero-credit rules. Inputs are aggregate counts only; no names,
 * contact details, clinical answers, notes, signatures, or raw HMS values are
 * returned to the agent or its UI.
 */
export function buildAttentionFindings(signals: AttentionSignals): AttentionFinding[] {
  const findings: AttentionFinding[] = [];
  if (signals.expiredSignatures > 0) findings.push({ id: "expired-signatures", severity: "urgent", title: "Expired consent signatures", summary: "Protected signature sessions expired before completion and require staff review.", count: signals.expiredSignatures, linkPath: "/admin/requests" });
  if (signals.potentialDuplicates > 0) findings.push({ id: "potential-duplicates", severity: "urgent", title: "Possible duplicate requests", summary: "Active requests have a matching-identity warning. Review before creating or linking records.", count: signals.potentialDuplicates, linkPath: "/admin/requests" });
  if (signals.pendingRequests > 0) findings.push({ id: "pending-requests", severity: "attention", title: "Requests awaiting first review", summary: "New appointment requests remain in the private review queue.", count: signals.pendingRequests, linkPath: "/admin/requests" });
  if (signals.clarificationRequests > 0) findings.push({ id: "clarification-requests", severity: "attention", title: "Requests awaiting clarification", summary: "Staff requested more information before an appointment can be finalized.", count: signals.clarificationRequests, linkPath: "/admin/requests" });
  if (signals.signatureOutstanding > 0) findings.push({ id: "signature-outstanding", severity: "attention", title: "Consent signatures outstanding", summary: "Active requests still require the approved signature workflow before staff can record a completed signature.", count: signals.signatureOutstanding, linkPath: "/admin/requests" });
  if (signals.newEnquiries > 0) findings.push({ id: "new-enquiries", severity: "attention", title: "General enquiries awaiting review", summary: "Website enquiries are waiting in the protected enquiry inbox.", count: signals.newEnquiries, linkPath: "/admin/enquiries" });
  if (signals.hmsWarningBatches > 0) findings.push({ id: "hms-warning-batches", severity: "review", title: "HMS import warnings recorded", summary: "One or more imported HMS batches retain source warnings for protected staff review. No source values were changed.", count: signals.hmsWarningBatches, linkPath: "/admin/appointments" });
  return findings;
}
