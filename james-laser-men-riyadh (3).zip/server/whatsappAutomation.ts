import { and, asc, desc, eq, inArray, lte, sql } from "drizzle-orm";
import { randomUUID } from "node:crypto";
import {
  activityLogs,
  appointments,
  clinicSettings,
  patients,
  whatsappAutomationJobs,
  whatsappAutomationLogs,
  whatsappActivationPrerequisites,
  whatsappAutomationTemplateDefinitions,
  whatsappContacts,
  whatsappConversations,
  whatsappMessages,
  whatsappRetouchRequests,
  whatsappSettings,
  whatsappTemplates,
} from "../drizzle/schema";
import { getDb, normalizeMobileNumber } from "./db";
import { createStaffNotification, listStaffNotifications } from "./notifications";
import { getMetaWhatsAppConfig, sendMetaWhatsAppTemplate } from "./metaWhatsApp";
import { createHeartbeatJob } from "./_core/heartbeat";

export type AutomationLanguage = "en" | "ar" | "unknown";
export type AutomationJobType = "session_reminder" | "session_reminder_2h" | "retouch_invitation" | "retouch_date_options" | "retouch_time_options" | "retouch_request_received" | "retouch_confirmation" | "cannot_attend_acknowledgement" | "appointment_confirmation" | "appointment_reminder_24h" | "appointment_final_reminder" | "appointment_rescheduled" | "appointment_cancellation" | "appointment_completed_follow_up" | "appointment_no_show_follow_up";
export type AutomationJobStatus = "scheduled" | "queued" | "claimed" | "provider_not_connected" | "blocked_consent" | "blocked_template" | "provider_accepted" | "sent" | "delivered" | "read" | "failed" | "cancelled" | "skipped";
export type RetouchRequestStatus = "awaiting_patient_preference" | "awaiting_patient_time" | "awaiting_clinic_confirmation" | "confirmed" | "alternative_time_suggested" | "declined" | "patient_declined";

type StaffActor = { id: number; name: string | null };
type Db = NonNullable<Awaited<ReturnType<typeof getDb>>>;

const DAY_MS = 24 * 60 * 60 * 1000;
const ACTIVE_JOB_STATUSES: AutomationJobStatus[] = ["scheduled", "queued", "claimed", "provider_not_connected", "blocked_consent", "blocked_template"];
const AUTO_TEMPLATE_KEYS: Record<AutomationJobType, string> = {
  session_reminder: "session_reminder",
  session_reminder_2h: "session_reminder_2h",
  retouch_invitation: "retouch_invitation",
  retouch_date_options: "retouch_date_options",
  retouch_time_options: "retouch_time_options",
  retouch_request_received: "retouch_request_received",
  retouch_confirmation: "retouch_confirmation",
  cannot_attend_acknowledgement: "cannot_attend_acknowledgement",
  appointment_confirmation: "appointment_confirmation",
  appointment_reminder_24h: "appointment_reminder_24h",
  appointment_final_reminder: "appointment_final_reminder",
  appointment_rescheduled: "appointment_rescheduled",
  appointment_cancellation: "appointment_cancellation",
  appointment_completed_follow_up: "appointment_completed_follow_up",
  appointment_no_show_follow_up: "appointment_no_show_follow_up",
};

const ACTIVATION_PREREQUISITES = [
  "migration_applied",
  "meta_business_configuration_completed",
  "production_credentials_configured",
  "approved_templates_mapped",
  "webhook_configured",
  "webhook_verified",
  "test_number_configured",
  "controlled_test_message_completed",
  "appointment_confirmation_tested",
  "reminder_tested",
  "reschedule_tested",
  "cancellation_tested",
  "consent_tested",
  "owner_activation_approval_recorded",
] as const;
type ActivationPrerequisiteKey = typeof ACTIVATION_PREREQUISITES[number];

const QUEUEABLE_JOB_STATUSES: AutomationJobStatus[] = ["scheduled", "provider_not_connected", "blocked_consent", "blocked_template", "failed"];

const TEMPLATE_DEFINITIONS = [
  {
    templateKey: "session_reminder",
    language: "en" as const,
    suggestedName: "james_session_reminder_en",
    bodyPreview: "Hello {{1}}. This is a reminder for your laser hair removal appointment with Nurse James at New Look Clinic on {{2}} at {{3}} for {{4}}. Will you be attending?",
    interactiveLabels: JSON.stringify(["YES_SESSION", "NO_SESSION"]),
  },
  {
    templateKey: "session_reminder",
    language: "ar" as const,
    suggestedName: "james_session_reminder_ar",
    bodyPreview: "مرحبًا {{1}}. هذا تذكير بموعد إزالة الشعر بالليزر مع الممرض جيمس في عيادة نيو لوك بتاريخ {{2}} الساعة {{3}} لمنطقة {{4}}. هل ستتمكن من الحضور؟",
    interactiveLabels: JSON.stringify(["YES_SESSION", "NO_SESSION"]),
  },
  {
    templateKey: "session_reminder_2h",
    language: "en" as const,
    suggestedName: "james_session_reminder_2h_en",
    bodyPreview: "Hello {{1}}. This is a reminder that your laser hair removal appointment with Nurse James at New Look Clinic is in about two hours, on {{2}} at {{3}}, for {{4}}. Will you be attending?",
    interactiveLabels: JSON.stringify(["YES_SESSION", "NO_SESSION"]),
  },
  {
    templateKey: "session_reminder_2h",
    language: "ar" as const,
    suggestedName: "james_session_reminder_2h_ar",
    bodyPreview: "مرحبًا {{1}}. موعد إزالة الشعر بالليزر مع الممرض جيمس في عيادة نيو لوك سيكون بعد نحو ساعتين اليوم الساعة {{2}} لمنطقة {{3}}. هل ستتمكن من الحضور؟",
    interactiveLabels: JSON.stringify(["YES_SESSION", "NO_SESSION"]),
  },
  {
    templateKey: "retouch_invitation",
    language: "en" as const,
    suggestedName: "james_retouch_invitation_en",
    bodyPreview: "Hello {{1}}. Your retouch period after your laser session is approaching. Your recommended retouch window is {{2}} to {{3}}. Would you like to request a retouch appointment? A request is not an appointment confirmation.",
    interactiveLabels: JSON.stringify(["YES_RETOUCH", "NO_RETOUCH"]),
  },
  {
    templateKey: "retouch_invitation",
    language: "ar" as const,
    suggestedName: "james_retouch_invitation_ar",
    bodyPreview: "مرحبًا {{1}}. تقترب فترة الرتوش بعد جلسة الليزر. الفترة المقترحة للرتوش من {{2}} إلى {{3}}. هل ترغب في طلب موعد رتوش؟ الطلب ليس تأكيدًا للموعد.",
    interactiveLabels: JSON.stringify(["YES_RETOUCH", "NO_RETOUCH"]),
  },
  {
    templateKey: "retouch_request_received",
    language: "en" as const,
    suggestedName: "james_retouch_request_received_en",
    bodyPreview: "Thank you, {{1}}. We received your retouch appointment request for {{2}} at {{3}} for {{4}}. Your appointment is not confirmed yet. Please wait for the clinic’s confirmation message.",
    interactiveLabels: null,
  },
  {
    templateKey: "retouch_request_received",
    language: "ar" as const,
    suggestedName: "james_retouch_request_received_ar",
    bodyPreview: "شكرًا لك {{1}}. استلمنا طلب موعد الرتوش بتاريخ {{2}} الساعة {{3}} لمنطقة {{4}}. موعدك غير مؤكد بعد. يرجى انتظار رسالة تأكيد العيادة.",
    interactiveLabels: null,
  },
  {
    templateKey: "retouch_confirmation",
    language: "en" as const,
    suggestedName: "james_retouch_confirmed_en",
    bodyPreview: "Hello {{1}}. Your retouch appointment has been confirmed for {{2}} at {{3}} for {{4}} at New Look Clinic – As Sahafah, Riyadh. Preparation: {{5}} Please follow these instructions before your visit.",
    interactiveLabels: null,
  },
  {
    templateKey: "retouch_confirmation",
    language: "ar" as const,
    suggestedName: "james_retouch_confirmed_ar",
    bodyPreview: "مرحبًا {{1}}. تم تأكيد موعد الرتوش بتاريخ {{2}} الساعة {{3}} لمنطقة {{4}} في عيادة نيو لوك – الصحافة، الرياض. التعليمات: {{5}} يرجى اتباعها قبل الزيارة.",
    interactiveLabels: null,
  },
  {
    templateKey: "cannot_attend_acknowledgement",
    language: "en" as const,
    suggestedName: "james_cannot_attend_acknowledgement_en",
    bodyPreview: "Thank you, {{1}}. We recorded that you cannot attend. Your appointment has not been cancelled automatically. The clinic will review the next step with you.",
    interactiveLabels: null,
  },
  {
    templateKey: "cannot_attend_acknowledgement",
    language: "ar" as const,
    suggestedName: "james_cannot_attend_acknowledgement_ar",
    bodyPreview: "شكرًا لك {{1}}. تم تسجيل عدم تمكنك من الحضور. لم يتم إلغاء الموعد تلقائيًا، وسيراجع فريق العيادة الخطوة التالية معك.",
    interactiveLabels: null,
  },
  {
    templateKey: "retouch_date_options",
    language: "en" as const,
    suggestedName: "james_retouch_date_options_en",
    bodyPreview: "Please choose a preferred retouch date within your eligible window.",
    interactiveLabels: JSON.stringify(["RET_DATE_YYYY-MM-DD"]),
  },
  {
    templateKey: "retouch_date_options",
    language: "ar" as const,
    suggestedName: "james_retouch_date_options_ar",
    bodyPreview: "يرجى اختيار تاريخ الرتوش المفضل ضمن الفترة المؤهلة.",
    interactiveLabels: JSON.stringify(["RET_DATE_YYYY-MM-DD"]),
  },
  {
    templateKey: "retouch_time_options",
    language: "en" as const,
    suggestedName: "james_retouch_time_options_en",
    bodyPreview: "What time would you prefer? Available or requestable times are subject to clinic review.",
    interactiveLabels: JSON.stringify(["RET_TIME_HH:MM"]),
  },
  {
    templateKey: "retouch_time_options",
    language: "ar" as const,
    suggestedName: "james_retouch_time_options_ar",
    bodyPreview: "ما الوقت الذي تفضله؟ الأوقات المتاحة أو القابلة للطلب تخضع لمراجعة العيادة.",
    interactiveLabels: JSON.stringify(["RET_TIME_HH:MM"]),
  },
  {
    templateKey: "appointment_confirmation",
    language: "en" as const,
    suggestedName: "newlook_appointment_confirmation_en",
    bodyPreview: "Hello {{1}}. Your appointment at New Look Clinic has been confirmed for {{2}} at {{3}} for {{4}}. We look forward to seeing you.",
    interactiveLabels: null,
  },
  {
    templateKey: "appointment_confirmation",
    language: "ar" as const,
    suggestedName: "newlook_appointment_confirmation_ar",
    bodyPreview: "مرحبًا {{1}}. تم تأكيد موعدك في عيادة نيو لوك بتاريخ {{2}} الساعة {{3}} لمنطقة {{4}}. نتطلع إلى زيارتك.",
    interactiveLabels: null,
  },
  {
    templateKey: "appointment_reminder_24h",
    language: "en" as const,
    suggestedName: "newlook_appointment_reminder_24h_en",
    bodyPreview: "Hello {{1}}. This is a reminder of your appointment tomorrow, {{2}}, at {{3}} for {{4}}. Reply if you need the clinic team to review your appointment.",
    interactiveLabels: JSON.stringify(["YES_SESSION", "NO_SESSION"]),
  },
  {
    templateKey: "appointment_reminder_24h",
    language: "ar" as const,
    suggestedName: "newlook_appointment_reminder_24h_ar",
    bodyPreview: "مرحبًا {{1}}. هذا تذكير بموعدك غدًا {{2}} الساعة {{3}} لمنطقة {{4}}. رد علينا إذا احتجت إلى أن يراجع فريق العيادة موعدك.",
    interactiveLabels: JSON.stringify(["YES_SESSION", "NO_SESSION"]),
  },
  {
    templateKey: "appointment_final_reminder",
    language: "en" as const,
    suggestedName: "newlook_appointment_final_reminder_en",
    bodyPreview: "Hello {{1}}. Your appointment is today, {{2}}, at {{3}} for {{4}}. Please plan to arrive on time. Reply if you need the clinic team to review your appointment.",
    interactiveLabels: JSON.stringify(["YES_SESSION", "NO_SESSION"]),
  },
  {
    templateKey: "appointment_final_reminder",
    language: "ar" as const,
    suggestedName: "newlook_appointment_final_reminder_ar",
    bodyPreview: "مرحبًا {{1}}. موعدك اليوم {{2}} الساعة {{3}} لمنطقة {{4}}. يرجى الحضور في الموعد. رد علينا إذا احتجت إلى أن يراجع فريق العيادة موعدك.",
    interactiveLabels: JSON.stringify(["YES_SESSION", "NO_SESSION"]),
  },
  {
    templateKey: "appointment_rescheduled",
    language: "en" as const,
    suggestedName: "newlook_appointment_rescheduled_en",
    bodyPreview: "Hello {{1}}. Your appointment at New Look Clinic has been rescheduled to {{2}} at {{3}} for {{4}}. Please contact the clinic if you need assistance.",
    interactiveLabels: null,
  },
  {
    templateKey: "appointment_rescheduled",
    language: "ar" as const,
    suggestedName: "newlook_appointment_rescheduled_ar",
    bodyPreview: "مرحبًا {{1}}. تم تعديل موعدك في عيادة نيو لوك إلى {{2}} الساعة {{3}} لمنطقة {{4}}. تواصل مع العيادة إذا احتجت إلى مساعدة.",
    interactiveLabels: null,
  },
  {
    templateKey: "appointment_cancellation",
    language: "en" as const,
    suggestedName: "newlook_appointment_cancellation_en",
    bodyPreview: "Hello {{1}}. Your appointment at New Look Clinic on {{2}} at {{3}} for {{4}} has been cancelled. Please contact the clinic if you would like the team to review a new appointment request.",
    interactiveLabels: null,
  },
  {
    templateKey: "appointment_cancellation",
    language: "ar" as const,
    suggestedName: "newlook_appointment_cancellation_ar",
    bodyPreview: "مرحبًا {{1}}. تم إلغاء موعدك في عيادة نيو لوك بتاريخ {{2}} الساعة {{3}} لمنطقة {{4}}. تواصل مع العيادة إذا رغبت أن يراجع الفريق طلب موعد جديد.",
    interactiveLabels: null,
  },
  {
    templateKey: "appointment_completed_follow_up",
    language: "en" as const,
    suggestedName: "newlook_appointment_completed_follow_up_en",
    bodyPreview: "Hello {{1}}. Thank you for visiting New Look Clinic on {{2}} at {{3}} for {{4}}. If you have a non-urgent question about your visit, please reply and the clinic team will review it.",
    interactiveLabels: null,
  },
  {
    templateKey: "appointment_completed_follow_up",
    language: "ar" as const,
    suggestedName: "newlook_appointment_completed_follow_up_ar",
    bodyPreview: "مرحبًا {{1}}. شكرًا لزيارتك عيادة نيو لوك بتاريخ {{2}} الساعة {{3}} لمنطقة {{4}}. إذا كان لديك سؤال غير عاجل عن زيارتك، رد على هذه الرسالة وسيقوم فريق العيادة بمراجعته.",
    interactiveLabels: null,
  },
  {
    templateKey: "appointment_no_show_follow_up",
    language: "en" as const,
    suggestedName: "newlook_appointment_no_show_follow_up_en",
    bodyPreview: "Hello {{1}}. We missed you at your New Look Clinic appointment on {{2}} at {{3}} for {{4}}. Please contact the clinic if you would like the team to review your next appointment request.",
    interactiveLabels: null,
  },
  {
    templateKey: "appointment_no_show_follow_up",
    language: "ar" as const,
    suggestedName: "newlook_appointment_no_show_follow_up_ar",
    bodyPreview: "مرحبًا {{1}}. لم نتمكن من استقبالكم في موعد عيادة نيو لوك بتاريخ {{2}} الساعة {{3}} لمنطقة {{4}}. تواصل مع العيادة إذا رغبت أن يراجع الفريق طلب موعدك القادم.",
    interactiveLabels: null,
  },
];

function unavailable() {
  return new Error("The WhatsApp automation service is temporarily unavailable.");
}

function riyadhDate(now = new Date()) {
  return new Intl.DateTimeFormat("sv-SE", { timeZone: "Asia/Riyadh", year: "numeric", month: "2-digit", day: "2-digit" }).format(now);
}

export function addRiyadhDays(date: string, days: number) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error("A valid appointment date is required.");
  const value = new Date(`${date}T12:00:00.000Z`);
  value.setUTCDate(value.getUTCDate() + days);
  return value.toISOString().slice(0, 10);
}

export function retouchScheduleFor(originalSessionDate: string) {
  return {
    reminderDate: addRiyadhDays(originalSessionDate, 7),
    eligibleStartDate: addRiyadhDays(originalSessionDate, 10),
    eligibleEndDate: addRiyadhDays(originalSessionDate, 14),
  };
}

function scheduledAt(date: string, time: string) {
  const value = new Date(`${date}T${time}:00+03:00`);
  if (Number.isNaN(value.getTime())) throw new Error("A valid Riyadh reminder time is required.");
  return value;
}

function scheduledAtHoursBefore(date: string, time: string, hours: number) {
  const value = scheduledAt(date, time);
  value.setTime(value.getTime() - hours * 60 * 60 * 1000);
  return value;
}

function isTime(value: string) {
  const match = /^(\d{2}):(\d{2})$/.exec(value);
  if (!match) return false;
  const hours = Number(match[1]);
  const minutes = Number(match[2]);
  return minutes % 15 === 0 && hours >= 13 && hours <= 22 && !(hours === 22 && minutes > 0);
}

function treatmentSummary(appointment: { treatmentAreas: string | null; treatmentArea: string | null }) {
  try {
    const values = appointment.treatmentAreas ? JSON.parse(appointment.treatmentAreas) as string[] : [];
    if (values.length) return values.join(", ");
  } catch {
    // Existing legacy values safely fall back to the primary area.
  }
  return appointment.treatmentArea || "treatment area";
}

function languageFor(value: AutomationLanguage | null | undefined, defaultLanguage: "en" | "ar") {
  return value === "en" || value === "ar" ? value : defaultLanguage;
}

/** The appointment/request language is the explicit patient preference; a known contact language is only a fallback. */
export function resolveAutomationLanguage(appointmentLanguage: AutomationLanguage | null | undefined, contactLanguage: AutomationLanguage | null | undefined, defaultLanguage: "en" | "ar") {
  if (appointmentLanguage === "en" || appointmentLanguage === "ar") return appointmentLanguage;
  return languageFor(contactLanguage, defaultLanguage);
}

function hasValidWhatsAppNumber(value: string | null | undefined) {
  if (!value) return false;
  return /^\+\d{8,15}$/.test(normalizeMobileNumber(value));
}

function jobKey(type: AutomationJobType, appointmentId: number, discriminator: string) {
  return `${type}:${appointmentId}:${discriminator}`.slice(0, 180);
}

async function settingsFor(db: Db) {
  const existing = await db.select().from(whatsappSettings).orderBy(desc(whatsappSettings.updatedAt)).limit(1);
  if (existing[0]) return existing[0];
  await db.insert(whatsappSettings).values({
    reminderSendingTime: "10:00",
    automationEnabled: false,
    retouchPreparationEn: "Do not shave the treatment area before your retouch appointment unless Nurse James or the clinic has instructed otherwise.",
    retouchPreparationAr: "لا تحلق منطقة العلاج قبل موعد الرتوش إلا إذا وجّهك الممرض جيمس أو فريق العيادة إلى ذلك.",
  });
  const created = await db.select().from(whatsappSettings).orderBy(desc(whatsappSettings.updatedAt)).limit(1);
  if (!created[0]) throw unavailable();
  return created[0];
}

async function defaultClinicLanguage(db: Db) {
  const [clinic] = await db.select({ defaultLanguage: clinicSettings.defaultLanguage }).from(clinicSettings).limit(1);
  return clinic?.defaultLanguage === "ar" ? "ar" as const : "en" as const;
}

async function seedTemplateDefinitions(db: Db) {
  for (const definition of TEMPLATE_DEFINITIONS) {
    await db.insert(whatsappAutomationTemplateDefinitions).values(definition).onDuplicateKeyUpdate({
      set: {
        suggestedName: definition.suggestedName,
        category: "utility",
        bodyPreview: definition.bodyPreview,
        interactiveLabels: definition.interactiveLabels,
      },
    });
  }
}

/** Refreshes the reviewed local bilingual template catalog without queueing or sending any messages. */
export async function syncWhatsAppAutomationTemplateDefinitions() {
  const db = await getDb();
  if (!db) throw unavailable();
  await seedTemplateDefinitions(db);
  return db.select().from(whatsappAutomationTemplateDefinitions).orderBy(asc(whatsappAutomationTemplateDefinitions.templateKey), asc(whatsappAutomationTemplateDefinitions.language));
}

async function seedActivationPrerequisites(db: Db) {
  for (const prerequisiteKey of ACTIVATION_PREREQUISITES) {
    await db.insert(whatsappActivationPrerequisites).values({ prerequisiteKey, status: "pending" }).onDuplicateKeyUpdate({
      set: { prerequisiteKey: sql`${whatsappActivationPrerequisites.prerequisiteKey}` },
    });
  }
}

async function activationPrerequisitesFor(db: Db) {
  await seedActivationPrerequisites(db);
  return db.select().from(whatsappActivationPrerequisites).orderBy(asc(whatsappActivationPrerequisites.prerequisiteKey));
}

async function allMappedTemplatesAreApproved(db: Db) {
  const definitions = await db.select().from(whatsappAutomationTemplateDefinitions);
  if (!definitions.length || definitions.some(definition => !definition.providerTemplateName || (definition.language !== "en" && definition.language !== "ar"))) return false;
  for (const definition of definitions) {
    const templates = await db.select({ language: whatsappTemplates.language }).from(whatsappTemplates)
      .where(and(eq(whatsappTemplates.templateName, definition.providerTemplateName!), eq(whatsappTemplates.status, "approved"))).limit(8);
    const languageMatched = templates.some(template => definition.language === "ar" ? ["ar", "ar_SA"].includes(template.language) : ["en", "en_US"].includes(template.language));
    if (!languageMatched) return false;
  }
  return true;
}

async function validateActivationPrerequisite(db: Db, prerequisiteKey: ActivationPrerequisiteKey) {
  const settings = await settingsFor(db);
  if (prerequisiteKey === "production_credentials_configured" && !getMetaWhatsAppConfig()) throw new Error("Server-side Meta credentials are not configured. No prerequisite was recorded.");
  if (prerequisiteKey === "approved_templates_mapped" && !await allMappedTemplatesAreApproved(db)) throw new Error("Every English and Arabic automation template must be mapped to an approved Meta template before this prerequisite can be recorded.");
  if (prerequisiteKey === "webhook_configured" && !settings.webhookConfigured) throw new Error("A verified inbound Meta webhook receipt is required before this prerequisite can be recorded.");
  if (prerequisiteKey === "webhook_verified" && !settings.lastWebhookReceivedAt) throw new Error("A verified inbound Meta webhook receipt timestamp is required before this prerequisite can be recorded.");
}

async function insertJob(db: Db, input: {
  appointmentId: number;
  conversationId?: number | null;
  retouchRequestId?: number | null;
  jobType: AutomationJobType;
  scheduleKey: string;
  scheduledFor: Date;
  language: AutomationLanguage;
  manualReason?: string | null;
}) {
  await db.insert(whatsappAutomationJobs).values({
    appointmentId: input.appointmentId,
    conversationId: input.conversationId ?? null,
    retouchRequestId: input.retouchRequestId ?? null,
    jobType: input.jobType,
    scheduleKey: input.scheduleKey,
    scheduledFor: input.scheduledFor,
    language: input.language,
    templateKey: AUTO_TEMPLATE_KEYS[input.jobType],
    manualReason: input.manualReason ?? null,
    status: "scheduled",
  }).onDuplicateKeyUpdate({ set: { scheduleKey: sql`${whatsappAutomationJobs.scheduleKey}` } });
  await db.update(whatsappAutomationJobs).set({
    scheduledFor: input.scheduledFor,
    conversationId: input.conversationId ?? null,
    language: input.language,
  }).where(and(eq(whatsappAutomationJobs.scheduleKey, input.scheduleKey), eq(whatsappAutomationJobs.status, "scheduled")));
}

async function log(db: Db, input: { appointmentId?: number | null; conversationId?: number | null; actor?: StaffActor | null; type: Parameters<typeof db.insert>[0] extends never ? never : string; outcome: string; details: string }) {
  await db.insert(whatsappAutomationLogs).values({
    conversationId: input.conversationId ?? null,
    actorUserId: input.actor?.id ?? null,
    automationType: input.type as typeof whatsappAutomationLogs.$inferInsert["automationType"],
    outcome: input.outcome,
    details: input.details,
  });
  if (input.appointmentId) {
    await db.insert(activityLogs).values({
      actorUserId: input.actor?.id ?? null,
      actorName: input.actor?.name ?? "Automation",
      action: input.details.slice(0, 180),
      subjectType: "appointment",
      subjectId: input.appointmentId,
    });
  }
}

async function matchingConversation(db: Db, whatsapp: string) {
  const normalized = normalizeMobileNumber(whatsapp);
  const rows = await db.select({ conversationId: whatsappConversations.id, language: whatsappContacts.language })
    .from(whatsappContacts)
    .innerJoin(whatsappConversations, eq(whatsappConversations.contactId, whatsappContacts.id))
    .where(eq(whatsappContacts.normalizedPhone, normalized))
    .limit(2);
  return rows.length === 1 ? rows[0] : null;
}

async function cancelObsoleteJobs(db: Db, appointmentId: number, allowedScheduleKeys: string[], reason: string) {
  const active = await db.select({ id: whatsappAutomationJobs.id, scheduleKey: whatsappAutomationJobs.scheduleKey })
    .from(whatsappAutomationJobs)
    .where(and(eq(whatsappAutomationJobs.appointmentId, appointmentId), inArray(whatsappAutomationJobs.status, ACTIVE_JOB_STATUSES)));
  for (const job of active) {
    if (!allowedScheduleKeys.includes(job.scheduleKey)) {
      await db.update(whatsappAutomationJobs).set({ status: "cancelled", cancelledAt: new Date(), cancelledReason: reason, claimToken: null }).where(eq(whatsappAutomationJobs.id, job.id));
    }
  }
}

function scheduleInFuture(date: string, time: string, hoursBefore: number) {
  const planned = scheduledAtHoursBefore(date, time, hoursBefore);
  return planned.getTime() > Date.now() ? planned : null;
}

async function scheduleLifecycleJob(db: Db, input: {
  appointment: typeof appointments.$inferSelect;
  contact: Awaited<ReturnType<typeof matchingConversation>>;
  language: AutomationLanguage;
  type: AutomationJobType;
  scheduledFor: Date;
  allowed: string[];
}) {
  const version = input.appointment.whatsappAutomationVersion;
  const key = jobKey(input.type, input.appointment.id, `v${version}:${input.language}`);
  input.allowed.push(key);
  await insertJob(db, {
    appointmentId: input.appointment.id,
    conversationId: input.contact?.conversationId ?? null,
    jobType: input.type,
    scheduleKey: key,
    scheduledFor: input.scheduledFor,
    language: input.language,
  });
}

/** Reconciles deterministic, non-sending reminder jobs. It is safe to call repeatedly from the workspace or scheduler. */
export async function reconcileWhatsAppAutomation() {
  const db = await getDb();
  if (!db) throw unavailable();
  const [settings, defaultLanguage] = await Promise.all([settingsFor(db), defaultClinicLanguage(db), seedTemplateDefinitions(db)]).then(([saved, language]) => [saved, language] as const);
  const allAppointments = await db.select().from(appointments).orderBy(asc(appointments.appointmentDate), asc(appointments.appointmentTime));
  const today = riyadhDate();
  let sessionJobs = 0;
  let retouchJobs = 0;
  let cancelled = 0;

  for (const appointment of allAppointments) {
    if (!appointment.whatsapp || !["confirmed", "completed", "cancelled", "no-show"].includes(appointment.status)) {
      const before = await db.select({ id: whatsappAutomationJobs.id }).from(whatsappAutomationJobs).where(and(eq(whatsappAutomationJobs.appointmentId, appointment.id), inArray(whatsappAutomationJobs.status, ACTIVE_JOB_STATUSES)));
      await cancelObsoleteJobs(db, appointment.id, [], "Appointment is cancelled, inactive, or has no WhatsApp number.");
      cancelled += before.length;
      continue;
    }

    const contact = await matchingConversation(db, appointment.whatsapp);
    const language = resolveAutomationLanguage(appointment.originalConsentLanguage, contact?.language, defaultLanguage);
    const allowed: string[] = [];
    const eligibleForLifecycleAutomation = Boolean(appointment.whatsappAutomationInitializedAt);

    // A NULL marker is the rollout boundary. Historical records and their legacy jobs are preserved but cannot be sent after activation.
    if (!eligibleForLifecycleAutomation) {
      const activeBefore = await db.select({ id: whatsappAutomationJobs.id }).from(whatsappAutomationJobs)
        .where(and(eq(whatsappAutomationJobs.appointmentId, appointment.id), inArray(whatsappAutomationJobs.status, ACTIVE_JOB_STATUSES)));
      await cancelObsoleteJobs(db, appointment.id, [], "Appointment predates the controlled WhatsApp automation rollout.");
      cancelled += activeBefore.length;
      continue;
    }

    if (eligibleForLifecycleAutomation && appointment.status === "confirmed" && appointment.appointmentDate >= today) {
      const confirmation = new Date(appointment.whatsappAutomationInitializedAt!);
      if (settings.appointmentConfirmationEnabled && appointment.whatsappAutomationVersion === 1) {
        await scheduleLifecycleJob(db, { appointment, contact, language, type: "appointment_confirmation", scheduledFor: confirmation, allowed });
      }
      if (settings.appointmentRescheduleEnabled && appointment.whatsappAutomationVersion > 1) {
        await scheduleLifecycleJob(db, { appointment, contact, language, type: "appointment_rescheduled", scheduledFor: confirmation, allowed });
      }
      if (settings.appointmentReminder24hEnabled) {
        const reminder = scheduleInFuture(appointment.appointmentDate, appointment.appointmentTime, settings.appointmentReminder24hHours);
        if (reminder) await scheduleLifecycleJob(db, { appointment, contact, language, type: "appointment_reminder_24h", scheduledFor: reminder, allowed });
      }
      if (settings.appointmentFinalReminderEnabled) {
        const finalReminder = scheduleInFuture(appointment.appointmentDate, appointment.appointmentTime, settings.appointmentFinalReminderHours);
        if (finalReminder) await scheduleLifecycleJob(db, { appointment, contact, language, type: "appointment_final_reminder", scheduledFor: finalReminder, allowed });
      }
    }
    if (eligibleForLifecycleAutomation && appointment.status === "cancelled" && settings.appointmentCancellationEnabled) {
      await scheduleLifecycleJob(db, { appointment, contact, language, type: "appointment_cancellation", scheduledFor: new Date(), allowed });
    }
    if (eligibleForLifecycleAutomation && appointment.status === "completed" && settings.appointmentCompletionFollowUpEnabled) {
      await scheduleLifecycleJob(db, { appointment, contact, language, type: "appointment_completed_follow_up", scheduledFor: new Date(), allowed });
    }
    if (eligibleForLifecycleAutomation && appointment.status === "no-show" && settings.appointmentNoShowFollowUpEnabled) {
      await scheduleLifecycleJob(db, { appointment, contact, language, type: "appointment_no_show_follow_up", scheduledFor: new Date(), allowed });
    }
    if (appointment.visitType === "session" && appointment.status === "completed") {
      const schedule = retouchScheduleFor(appointment.appointmentDate);
      const key = jobKey("retouch_invitation", appointment.id, schedule.reminderDate);
      allowed.push(key);
      const now = new Date();
      const status: AutomationJobStatus = today > schedule.eligibleEndDate ? "skipped" : "scheduled";
      await db.insert(whatsappAutomationJobs).values({
        appointmentId: appointment.id,
        conversationId: contact?.conversationId ?? null,
        jobType: "retouch_invitation",
        scheduleKey: key,
        scheduledFor: scheduledAt(schedule.reminderDate, settings.reminderSendingTime),
        language,
        templateKey: AUTO_TEMPLATE_KEYS.retouch_invitation,
        status,
        ...(status === "skipped" ? { cancelledAt: now, cancelledReason: "The original retouch eligibility window has expired." } : {}),
      }).onDuplicateKeyUpdate({ set: { scheduleKey: sql`${whatsappAutomationJobs.scheduleKey}` } });
      retouchJobs += 1;
    }
    const activeBefore = await db.select({ id: whatsappAutomationJobs.id, scheduleKey: whatsappAutomationJobs.scheduleKey })
      .from(whatsappAutomationJobs)
      .where(and(eq(whatsappAutomationJobs.appointmentId, appointment.id), inArray(whatsappAutomationJobs.status, ACTIVE_JOB_STATUSES)));
    await cancelObsoleteJobs(db, appointment.id, allowed, "Appointment date, status, or visit type changed.");
    cancelled += activeBefore.filter(job => !allowed.includes(job.scheduleKey)).length;
  }
  return { sessionJobs, retouchJobs, cancelled, automationEnabled: settings.automationEnabled };
}

async function queueInstantJob(db: Db, input: { appointmentId: number; conversationId: number | null; retouchRequestId?: number | null; type: AutomationJobType; language: AutomationLanguage }) {
  const discriminator = input.retouchRequestId ? String(input.retouchRequestId) : "response";
  await insertJob(db, {
    appointmentId: input.appointmentId,
    conversationId: input.conversationId,
    retouchRequestId: input.retouchRequestId ?? null,
    jobType: input.type,
    scheduleKey: jobKey(input.type, input.appointmentId, discriminator),
    scheduledFor: new Date(),
    language: input.language,
  });
}

function replyToken(input: { type: string; text?: { body?: string }; interactive?: { button_reply?: { id?: string; title?: string }; list_reply?: { id?: string; title?: string } } }) {
  return [input.interactive?.button_reply?.id, input.interactive?.list_reply?.id, input.interactive?.button_reply?.title, input.interactive?.list_reply?.title, input.text?.body]
    .find(value => Boolean(value?.trim()))?.trim().toUpperCase() ?? "";
}

function selectedDate(token: string) {
  const match = /(?:RET_DATE[_:\s-]*)?(\d{4}-\d{2}-\d{2})/.exec(token);
  return match?.[1] ?? null;
}

function selectedTime(token: string) {
  const match = /(?:RET_TIME[_:\s-]*)?(\d{2}:\d{2})/.exec(token);
  return match?.[1] ?? null;
}

async function notificationOnce(title: string, message: string, linkPath: string) {
  const current = await listStaffNotifications();
  if (!current.some(item => !item.isRead && item.title === title && item.linkPath === linkPath)) {
    await createStaffNotification({ type: "system", title, message, linkPath });
  }
}

/** Applies only an authenticated provider reply that references a stored automation message. No inbound reply creates an appointment. */
export async function processWhatsAppAutomationReply(db: Db, input: {
  conversationId: number;
  messageId: number;
  message: { type: string; context?: { id?: string }; text?: { body?: string }; interactive?: { button_reply?: { id?: string; title?: string }; list_reply?: { id?: string; title?: string } } };
}) {
  const reference = input.message.context?.id;
  if (!reference) return { applied: false as const, reason: "no_automation_context" };
  const [job] = await db.select().from(whatsappAutomationJobs).where(eq(whatsappAutomationJobs.providerMessageId, reference)).limit(1);
  if (!job || job.conversationId !== input.conversationId) return { applied: false as const, reason: "not_an_automation_reply" };
  const [appointment] = await db.select().from(appointments).where(eq(appointments.id, job.appointmentId)).limit(1);
  if (!appointment) return { applied: false as const, reason: "appointment_missing" };
  const token = replyToken(input.message);
  const now = new Date();

  if (job.jobType === "session_reminder" || job.jobType === "session_reminder_2h") {
    if (/^(YES_SESSION|YES|CONFIRM|CONFIRMED)/.test(token)) {
      if (!["cancelled", "completed", "no-show"].includes(appointment.status)) {
        await db.update(appointments).set({ whatsappAttendanceConfirmation: "confirmed", whatsappAttendanceConfirmedAt: now, whatsappCannotAttendAt: null }).where(eq(appointments.id, appointment.id));
        await log(db, { appointmentId: appointment.id, conversationId: input.conversationId, type: "attendance_confirmed", outcome: "patient_confirmed", details: "Recorded patient WhatsApp attendance confirmation; appointment time and machine were not changed." });
      }
      return { applied: true as const, action: "attendance_confirmed" };
    }
    if (/^(NO_SESSION|NO|CANNOT_ATTEND|CANNOT COME|CANT ATTEND)/.test(token)) {
      if (!["cancelled", "completed", "no-show"].includes(appointment.status)) {
        await db.update(appointments).set({ whatsappAttendanceConfirmation: "cannot_attend", whatsappCannotAttendAt: now }).where(eq(appointments.id, appointment.id));
        await queueInstantJob(db, { appointmentId: appointment.id, conversationId: input.conversationId, type: "cannot_attend_acknowledgement", language: job.language });
        await notificationOnce("WhatsApp attendance review needed", "A patient reported that they cannot attend. Staff review is required; the appointment was not cancelled automatically.", "/admin/whatsapp");
        await log(db, { appointmentId: appointment.id, conversationId: input.conversationId, type: "cannot_attend", outcome: "staff_review_required", details: "Recorded patient cannot-attend response without cancelling the appointment." });
      }
      return { applied: true as const, action: "cannot_attend" };
    }
  }

  if (job.jobType === "retouch_invitation") {
    const schedule = retouchScheduleFor(appointment.appointmentDate);
    const [existing] = await db.select().from(whatsappRetouchRequests).where(eq(whatsappRetouchRequests.originalSessionAppointmentId, appointment.id)).limit(1);
    if (/^(YES_RETOUCH|YES|REQUEST RETOUCH)/.test(token)) {
      if (!existing) {
        const created = await db.insert(whatsappRetouchRequests).values({
          originalSessionAppointmentId: appointment.id,
          patientId: appointment.patientId,
          patientName: appointment.patientName,
          mrn: appointment.mrn,
          whatsapp: appointment.whatsapp || "",
          treatmentAreas: appointment.treatmentAreas,
          originalSessionDate: appointment.appointmentDate,
          eligibleStartDate: schedule.eligibleStartDate,
          eligibleEndDate: schedule.eligibleEndDate,
          status: "awaiting_patient_preference" as RetouchRequestStatus,
          patientRespondedAt: now,
        }).$returningId();
        const retouchRequestId = Number(created[0]?.id);
        if (!retouchRequestId) throw new Error("The retouch preference could not be created.");
        await queueInstantJob(db, { appointmentId: appointment.id, conversationId: input.conversationId, retouchRequestId, type: "retouch_date_options", language: job.language });
        await log(db, { appointmentId: appointment.id, conversationId: input.conversationId, type: "retouch_interest", outcome: "awaiting_date_selection", details: "Recorded retouch interest and queued eligible date options. No appointment was created." });
      }
      return { applied: true as const, action: "retouch_interest" };
    }
    if (/^(NO_RETOUCH|NO|NOT NOW)/.test(token)) {
      if (!existing) {
        await db.insert(whatsappRetouchRequests).values({
          originalSessionAppointmentId: appointment.id,
          patientId: appointment.patientId,
          patientName: appointment.patientName,
          mrn: appointment.mrn,
          whatsapp: appointment.whatsapp || "",
          treatmentAreas: appointment.treatmentAreas,
          originalSessionDate: appointment.appointmentDate,
          eligibleStartDate: schedule.eligibleStartDate,
          eligibleEndDate: schedule.eligibleEndDate,
          status: "patient_declined" as RetouchRequestStatus,
          patientRespondedAt: now,
        });
      }
      await log(db, { appointmentId: appointment.id, conversationId: input.conversationId, type: "retouch_interest", outcome: "patient_declined", details: "Recorded that the patient declined the retouch invitation." });
      return { applied: true as const, action: "retouch_declined" };
    }
  }

  if (job.jobType === "retouch_date_options") {
    const date = selectedDate(token);
    const [request] = await db.select().from(whatsappRetouchRequests).where(eq(whatsappRetouchRequests.id, Number(job.retouchRequestId))).limit(1);
    if (request && date && date >= request.eligibleStartDate && date <= request.eligibleEndDate) {
      await db.update(whatsappRetouchRequests).set({ preferredDate: date, status: "awaiting_patient_time" as RetouchRequestStatus }).where(eq(whatsappRetouchRequests.id, request.id));
      await queueInstantJob(db, { appointmentId: appointment.id, conversationId: input.conversationId, retouchRequestId: request.id, type: "retouch_time_options", language: job.language });
      await log(db, { appointmentId: appointment.id, conversationId: input.conversationId, type: "retouch_request_created", outcome: "awaiting_time_selection", details: "Recorded a patient-selected retouch date within the original day 10–14 window." });
      return { applied: true as const, action: "retouch_date_selected" };
    }
  }

  if (job.jobType === "retouch_time_options") {
    const time = selectedTime(token);
    const [request] = await db.select().from(whatsappRetouchRequests).where(eq(whatsappRetouchRequests.id, Number(job.retouchRequestId))).limit(1);
    if (request && time && isTime(time)) {
      await db.update(whatsappRetouchRequests).set({ preferredTime: time, status: "awaiting_clinic_confirmation" as RetouchRequestStatus }).where(eq(whatsappRetouchRequests.id, request.id));
      await queueInstantJob(db, { appointmentId: appointment.id, conversationId: input.conversationId, retouchRequestId: request.id, type: "retouch_request_received", language: job.language });
      await notificationOnce("Retouch request awaiting clinic confirmation", "A patient-selected retouch date and time requires staff availability review. No appointment has been created.", "/admin/whatsapp");
      await log(db, { appointmentId: appointment.id, conversationId: input.conversationId, type: "retouch_request_created", outcome: "awaiting_clinic_confirmation", details: "Created a WhatsApp retouch request after a valid date and time selection. No appointment was created." });
      return { applied: true as const, action: "retouch_request_created" };
    }
  }
  return { applied: false as const, reason: "unrecognized_or_invalid_reply" };
}

async function claimJob(db: Db, jobId: number) {
  const token = randomUUID();
  const result = await db.update(whatsappAutomationJobs).set({ status: "claimed", claimToken: token, claimedAt: new Date(), attemptCount: sql`${whatsappAutomationJobs.attemptCount} + 1` })
    .where(and(eq(whatsappAutomationJobs.id, jobId), inArray(whatsappAutomationJobs.status, ["scheduled", "queued", "provider_not_connected", "blocked_consent", "blocked_template"])));
  return result[0].affectedRows === 1 ? token : null;
}

async function templateForJob(db: Db, job: typeof whatsappAutomationJobs.$inferSelect, language: "en" | "ar") {
  const [definition] = await db.select().from(whatsappAutomationTemplateDefinitions)
    .where(and(eq(whatsappAutomationTemplateDefinitions.templateKey, job.templateKey), eq(whatsappAutomationTemplateDefinitions.language, language))).limit(1);
  if (!definition?.providerTemplateName) return null;
  const templates = await db.select().from(whatsappTemplates)
    .where(and(eq(whatsappTemplates.templateName, definition.providerTemplateName), eq(whatsappTemplates.status, "approved"))).limit(8);
  const template = templates.find(candidate => language === "ar"
    ? ["ar", "ar_SA"].includes(candidate.language)
    : ["en", "en_US"].includes(candidate.language));
  return template ? { name: template.templateName, language: template.language } : null;
}

export function jobParameters(job: typeof whatsappAutomationJobs.$inferSelect, appointment: typeof appointments.$inferSelect, retouch: typeof whatsappRetouchRequests.$inferSelect | null, preparation?: string | null) {
  const areas = treatmentSummary(appointment);
  if (["appointment_confirmation", "appointment_reminder_24h", "appointment_final_reminder", "appointment_rescheduled", "appointment_cancellation"].includes(job.jobType)) return [appointment.patientName, appointment.appointmentDate, appointment.appointmentTime, areas];
  if (["appointment_completed_follow_up", "appointment_no_show_follow_up"].includes(job.jobType)) return [appointment.patientName, appointment.appointmentDate, appointment.appointmentTime, areas];
  if (job.jobType === "session_reminder") return [appointment.patientName, appointment.appointmentDate, appointment.appointmentTime, areas];
  if (job.jobType === "session_reminder_2h") return job.language === "ar" ? [appointment.patientName, appointment.appointmentTime, areas] : [appointment.patientName, appointment.appointmentDate, appointment.appointmentTime, areas];
  if (job.jobType === "retouch_invitation") return [appointment.patientName, retouch?.eligibleStartDate ?? addRiyadhDays(appointment.appointmentDate, 10), retouch?.eligibleEndDate ?? addRiyadhDays(appointment.appointmentDate, 14)];
  if (job.jobType === "retouch_request_received") return [appointment.patientName, retouch?.preferredDate ?? "", retouch?.preferredTime ?? "", areas];
  if (job.jobType === "retouch_confirmation") return [appointment.patientName, retouch?.suggestedDate ?? retouch?.preferredDate ?? "", retouch?.suggestedTime ?? retouch?.preferredTime ?? "", areas, preparation || "Follow the clinic’s preparation instructions."];
  if (job.jobType === "cannot_attend_acknowledgement") return [appointment.patientName];
  return [];
}

function isJobEligibleForAppointment(job: typeof whatsappAutomationJobs.$inferSelect, appointment: typeof appointments.$inferSelect) {
  if (!appointment.whatsapp || !appointment.whatsappAutomationInitializedAt) return false;
  if (["session_reminder", "session_reminder_2h"].includes(job.jobType)) return false;
  if (["appointment_confirmation", "appointment_reminder_24h", "appointment_final_reminder", "appointment_rescheduled", "cannot_attend_acknowledgement"].includes(job.jobType)) return appointment.status === "confirmed";
  if (job.jobType === "appointment_cancellation") return appointment.status === "cancelled";
  if (job.jobType === "appointment_completed_follow_up") return appointment.status === "completed";
  if (job.jobType === "appointment_no_show_follow_up") return appointment.status === "no-show";
  return appointment.status === "completed";
}

export function classifyProviderFailure(input: unknown) {
  const error = input as Error & { code?: string | number; httpStatus?: number; providerErrorType?: string | null; response?: { status?: number } };
  const httpStatus = Number.isInteger(error.httpStatus) ? error.httpStatus : error.response?.status;
  const code = error.code ? String(error.code).slice(0, 80) : httpStatus ? `http_${httpStatus}` : "provider_submission_failed";
  const primaryCode = code.split(".", 1)[0];
  const providerErrorType = error.providerErrorType ? String(error.providerErrorType).slice(0, 160) : null;
  // Meta documents codes as the primary error signal. Combine documented temporary/throttling codes with HTTP status;
  // an outcome with no authoritative provider response remains terminal pending reconciliation to preserve at-most-once sending.
  const documentedRetryableCode = ["2", "4", "80007", "130429", "131056", "131064"].includes(primaryCode);
  const retryable = documentedRetryableCode || httpStatus === 429 || Boolean(httpStatus && httpStatus >= 500);
  return { code, httpStatus: httpStatus ?? null, providerErrorType, retryable, message: (error.message || "Provider submission failed.").replace(/Bearer\s+\S+|access[_ -]?token\S*/gi, "[redacted]").slice(0, 1000) };
}

/** Claims due jobs atomically. It does not send until provider configuration, approved mappings, explicit opt-in, and automation enablement all exist. */
export async function runDueWhatsAppAutomation(taskUid?: string | null) {
  const db = await getDb();
  if (!db) throw unavailable();
  const settings = await settingsFor(db);
  if (taskUid && settings.schedulerTaskUid !== taskUid) return { skipped: "unknown_scheduler" as const, processed: 0 };
  if (taskUid && !settings.schedulerVerifiedAt) {
    await db.update(whatsappSettings).set({ schedulerVerifiedAt: new Date() }).where(eq(whatsappSettings.id, settings.id));
  }
  await reconcileWhatsAppAutomation();
  if (!settings.automationEnabled) return { skipped: "automation_disabled" as const, processed: 0 };

  const due = await db.select().from(whatsappAutomationJobs)
    .where(and(inArray(whatsappAutomationJobs.status, ["scheduled", "queued", "provider_not_connected", "blocked_consent", "blocked_template"]), lte(whatsappAutomationJobs.scheduledFor, new Date())))
    .orderBy(asc(whatsappAutomationJobs.scheduledFor)).limit(100);
  let processed = 0;
  for (const candidate of due) {
    const claimToken = await claimJob(db, candidate.id);
    if (!claimToken) continue;
    const [job] = await db.select().from(whatsappAutomationJobs).where(and(eq(whatsappAutomationJobs.id, candidate.id), eq(whatsappAutomationJobs.claimToken, claimToken))).limit(1);
    const [appointment] = await db.select().from(appointments).where(eq(appointments.id, candidate.appointmentId)).limit(1);
    if (!job || !appointment || !isJobEligibleForAppointment(job, appointment)) {
      await db.update(whatsappAutomationJobs).set({ status: "cancelled", cancelledAt: new Date(), cancelledReason: "The related appointment is no longer eligible for this reminder.", claimToken: null }).where(eq(whatsappAutomationJobs.id, candidate.id));
      continue;
    }
    if (appointment.whatsappConsentStatus !== "opted_in" || appointment.whatsappOptedOutAt) {
      await db.update(whatsappAutomationJobs).set({ status: "blocked_consent", claimToken: null, lastError: appointment.whatsappConsentStatus === "opted_out" ? "Patient opted out of WhatsApp communication." : "WhatsApp consent requires verification." }).where(eq(whatsappAutomationJobs.id, candidate.id));
      continue;
    }
    if (!getMetaWhatsAppConfig()) {
      await db.update(whatsappAutomationJobs).set({ status: "provider_not_connected", claimToken: null, lastError: "Provider connection required. The message was not submitted or sent." }).where(eq(whatsappAutomationJobs.id, candidate.id));
      await log(db, { appointmentId: appointment.id, conversationId: job.conversationId, type: "automation_provider_required", outcome: "provider_not_connected", details: "A due WhatsApp automation job is ready but the provider connection is not configured." });
      continue;
    }
    const language = languageFor(job.language, await defaultClinicLanguage(db));
    const template = await templateForJob(db, job, language);
    if (!template) {
      await db.update(whatsappAutomationJobs).set({ status: "blocked_template", claimToken: null, lastError: "An approved provider template mapping is required before this job can be sent." }).where(eq(whatsappAutomationJobs.id, candidate.id));
      continue;
    }
    const [retouch] = job.retouchRequestId ? await db.select().from(whatsappRetouchRequests).where(eq(whatsappRetouchRequests.id, job.retouchRequestId)).limit(1) : [];
    const preparation = language === "ar" ? settings.retouchPreparationAr : settings.retouchPreparationEn;
    const parameters = jobParameters(job, appointment, retouch ?? null, preparation);
    let providerAccepted = false;
    try {
      const conversationId = job.conversationId ?? await ensureAutomationConversation(db, appointment);
      const response = await sendMetaWhatsAppTemplate({
        to: appointment.whatsapp!,
        name: template.name,
        language: template.language,
        components: parameters.length ? [{ type: "body", parameters: parameters.map(text => ({ type: "text", text })) }] : undefined,
      });
      const providerMessageId = response.messages?.[0]?.id;
      if (!providerMessageId) throw new Error("Meta did not return a message identifier.");
      providerAccepted = true;
      const [stored] = await db.transaction(async tx => {
        const storedMessage = await tx.insert(whatsappMessages).values({
          conversationId,
          metaMessageId: providerMessageId,
          direction: "outbound",
          messageType: "template",
          templateName: template.name,
          templateLanguage: template.language,
          status: "sending",
        }).$returningId();
        const updated = await tx.update(whatsappAutomationJobs).set({ status: "provider_accepted", conversationId, providerMessageId, providerAcceptedAt: new Date(), queuedAt: new Date(), claimToken: null })
          .where(and(eq(whatsappAutomationJobs.id, candidate.id), eq(whatsappAutomationJobs.claimToken, claimToken)));
        if (updated[0].affectedRows !== 1) throw new Error("Provider acceptance could not be recorded safely.");
        return storedMessage;
      });
      await log(db, { appointmentId: appointment.id, conversationId, type: "automation_claimed", outcome: `provider_accepted:${stored?.id ?? "stored"}`, details: "The provider accepted an automation template submission. Sent, delivered, and read states require a later provider webhook." });
      processed += 1;
    } catch (error) {
      const failure = classifyProviderFailure(error);
      const uncertainAcceptance = providerAccepted;
      await db.update(whatsappAutomationJobs).set({
        status: "failed",
        failedAt: new Date(),
        claimToken: null,
        // At-most-once safety: after Meta has accepted a submission, local persistence trouble is never retried as a new send.
        retryable: uncertainAcceptance ? false : failure.retryable,
        lastErrorCode: uncertainAcceptance ? "provider_acceptance_persistence_uncertain" : failure.code,
        lastErrorHttpStatus: failure.httpStatus,
        lastProviderErrorType: failure.providerErrorType,
        lastError: uncertainAcceptance ? "Meta accepted this message but local persistence was interrupted. Do not retry; reconcile with provider status evidence." : failure.message,
      }).where(and(eq(whatsappAutomationJobs.id, candidate.id), eq(whatsappAutomationJobs.claimToken, claimToken)));
      await log(db, { appointmentId: appointment.id, conversationId: job.conversationId, type: "appointment_automation_failed", outcome: uncertainAcceptance ? "provider_accepted_reconciliation_required" : failure.retryable ? "failed_retryable" : "failed_manual_correction_required", details: uncertainAcceptance ? "Meta accepted the message but local persistence was interrupted. The job is terminal to prevent duplicate provider submission." : "A provider submission failed; no sent, delivered, or read state was recorded." });
    }
  }
  return { skipped: null, processed };
}

/** Creates the single dormant authenticated worker. Sending remains disabled until later activation checks are passed. */
export async function configureWhatsAppAutomationScheduler(userSession: string, actor: StaffActor) {
  const db = await getDb();
  if (!db) throw unavailable();
  const settings = await settingsFor(db);
  if (settings.schedulerTaskUid) return { taskUid: settings.schedulerTaskUid, created: false as const };
  const job = await createHeartbeatJob({
    name: "whatsapp-automation-dispatch",
    cron: "0 */5 * * * *",
    path: "/api/scheduled/whatsapp-automation",
    method: "POST",
    description: "Dormant WhatsApp appointment automation worker. It sends nothing until explicit owner activation.",
  }, userSession);
  await db.update(whatsappSettings).set({ schedulerTaskUid: job.taskUid, schedulerVerifiedAt: null, automationEnabled: false }).where(eq(whatsappSettings.id, settings.id));
  await db.insert(activityLogs).values({ actorUserId: actor.id, actorName: actor.name, action: "Configured dormant WhatsApp automation scheduler", subjectType: "whatsapp_automation_scheduler" });
  return { taskUid: job.taskUid, created: true as const, nextExecutionAt: job.nextExecutionAt ?? null };
}

/** Changes internal queue timing, workflow flags, and preparation copy only; it cannot enable outbound automation. */
export async function updateWhatsAppAutomationSettings(input: { reminderSendingTime: string; retouchPreparationEn: string | null; retouchPreparationAr: string | null; appointmentConfirmationEnabled: boolean; appointmentReminder24hEnabled: boolean; appointmentFinalReminderEnabled: boolean; appointmentRescheduleEnabled: boolean; appointmentCancellationEnabled: boolean; appointmentCompletionFollowUpEnabled: boolean; appointmentNoShowFollowUpEnabled: boolean; appointmentReminder24hHours: number; appointmentFinalReminderHours: number }, actor: StaffActor) {
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(input.reminderSendingTime)) throw new Error("Use a valid 24-hour reminder sending time.");
  if (!Number.isInteger(input.appointmentReminder24hHours) || !Number.isInteger(input.appointmentFinalReminderHours) || input.appointmentReminder24hHours < 1 || input.appointmentReminder24hHours > 168 || input.appointmentFinalReminderHours < 1 || input.appointmentFinalReminderHours >= input.appointmentReminder24hHours) throw new Error("Use valid reminder offsets, with the final reminder closer to the appointment.");
  const db = await getDb();
  if (!db) throw unavailable();
  const settings = await settingsFor(db);
  await db.update(whatsappSettings).set({
    reminderSendingTime: input.reminderSendingTime,
    retouchPreparationEn: input.retouchPreparationEn,
    retouchPreparationAr: input.retouchPreparationAr,
    appointmentConfirmationEnabled: input.appointmentConfirmationEnabled,
    appointmentReminder24hEnabled: input.appointmentReminder24hEnabled,
    appointmentFinalReminderEnabled: input.appointmentFinalReminderEnabled,
    appointmentRescheduleEnabled: input.appointmentRescheduleEnabled,
    appointmentCancellationEnabled: input.appointmentCancellationEnabled,
    appointmentCompletionFollowUpEnabled: input.appointmentCompletionFollowUpEnabled,
    appointmentNoShowFollowUpEnabled: input.appointmentNoShowFollowUpEnabled,
    appointmentReminder24hHours: input.appointmentReminder24hHours,
    appointmentFinalReminderHours: input.appointmentFinalReminderHours,
    automationEnabled: settings.automationEnabled,
  }).where(eq(whatsappSettings.id, settings.id));
  await db.insert(activityLogs).values({ actorUserId: actor.id, actorName: actor.name, action: "Updated WhatsApp automation timing and preparation copy", subjectType: "whatsapp_automation_settings" });
  return reconcileWhatsAppAutomation();
}

/** Records owner-attested, non-secret evidence. Prerequisites remain separate from automation state. */
export async function recordWhatsAppActivationPrerequisite(input: { prerequisiteKey: ActivationPrerequisiteKey; evidenceReference: string }, actor: StaffActor) {
  const db = await getDb();
  if (!db) throw unavailable();
  await seedTemplateDefinitions(db);
  await seedActivationPrerequisites(db);
  await validateActivationPrerequisite(db, input.prerequisiteKey);
  const now = new Date();
  await db.update(whatsappActivationPrerequisites).set({
    status: "verified",
    evidenceReference: input.evidenceReference.trim().slice(0, 500),
    verifiedAt: now,
    verifiedByUserId: actor.id,
    verifiedByName: actor.name,
  }).where(eq(whatsappActivationPrerequisites.prerequisiteKey, input.prerequisiteKey));
  await db.insert(activityLogs).values({ actorUserId: actor.id, actorName: actor.name, action: `Recorded WhatsApp activation prerequisite: ${input.prerequisiteKey}`, subjectType: "whatsapp_automation_activation" });
  return activationPrerequisitesFor(db);
}

/** Permits sending only after every explicitly recorded prerequisite and every live server-side safety check passes. */
export async function setWhatsAppAutomationActivation(input: { enable: boolean }, actor: StaffActor) {
  const db = await getDb();
  if (!db) throw unavailable();
  await seedTemplateDefinitions(db);
  const [settings, prerequisites, templatesApproved] = await Promise.all([
    settingsFor(db),
    activationPrerequisitesFor(db),
    allMappedTemplatesAreApproved(db),
  ]);
  const verified = new Set(prerequisites.filter(item => item.status === "verified" && item.verifiedAt && item.evidenceReference && item.verifiedByUserId).map(item => item.prerequisiteKey));
  const allPrerequisitesVerified = ACTIVATION_PREREQUISITES.every(key => verified.has(key));
  const ready = Boolean(
    getMetaWhatsAppConfig()
    && settings.webhookConfigured
    && settings.schedulerTaskUid
    && settings.schedulerVerifiedAt
    && templatesApproved
    && allPrerequisitesVerified,
  );
  if (input.enable && !ready) throw new Error("Automation cannot be enabled until all fourteen owner-evidenced activation prerequisites, approved language-matched templates, a verified webhook, scheduler callback, and server-side provider configuration are complete.");
  await db.update(whatsappSettings).set({ automationEnabled: input.enable }).where(eq(whatsappSettings.id, settings.id));
  await db.insert(activityLogs).values({ actorUserId: actor.id, actorName: actor.name, action: input.enable ? "Enabled verified WhatsApp automation" : "Paused WhatsApp automation", subjectType: "whatsapp_automation_settings" });
  return { enabled: input.enable, ready, prerequisites };
}

async function ensureAutomationConversation(db: Db, appointment: typeof appointments.$inferSelect) {
  const normalizedPhone = normalizeMobileNumber(appointment.whatsapp || "");
  await db.insert(whatsappContacts).values({
    waId: normalizedPhone.replace(/\D/g, ""),
    phoneNumber: appointment.whatsapp || normalizedPhone,
    normalizedPhone,
    displayName: appointment.patientName,
    language: appointment.originalConsentLanguage ?? "unknown",
    patientId: appointment.patientId,
    patientRequestId: appointment.consultationRequestId,
  }).onDuplicateKeyUpdate({ set: { phoneNumber: appointment.whatsapp || normalizedPhone, displayName: appointment.patientName, patientId: appointment.patientId, patientRequestId: appointment.consultationRequestId } });
  const [contact] = await db.select().from(whatsappContacts).where(eq(whatsappContacts.normalizedPhone, normalizedPhone)).limit(1);
  if (!contact) throw unavailable();
  await db.insert(whatsappConversations).values({ contactId: contact.id, status: "open", linkedRequestId: appointment.consultationRequestId, linkedPatientId: appointment.patientId, linkedAppointmentId: appointment.id }).onDuplicateKeyUpdate({ set: { linkedRequestId: appointment.consultationRequestId, linkedPatientId: appointment.patientId, linkedAppointmentId: appointment.id } });
  const [conversation] = await db.select().from(whatsappConversations).where(eq(whatsappConversations.contactId, contact.id)).limit(1);
  if (!conversation) throw unavailable();
  return conversation.id;
}

export async function syncProviderMessageStatus(providerMessageId: string, status: "sent" | "delivered" | "read" | "failed", occurredAt: Date) {
  const db = await getDb();
  if (!db) throw unavailable();
  const [job] = await db.select().from(whatsappAutomationJobs).where(eq(whatsappAutomationJobs.providerMessageId, providerMessageId)).limit(1);
  if (!job) return false;
  if (status === "failed") {
    await db.update(whatsappAutomationJobs).set({ status: "failed", failedAt: occurredAt, retryable: true, lastErrorCode: "meta_delivery_failed", lastError: "Meta reported delivery failure." }).where(eq(whatsappAutomationJobs.id, job.id));
  } else if (status === "sent" || status === "delivered" || status === "read") {
    await db.update(whatsappAutomationJobs).set({ status, ...(status === "sent" ? { sentAt: occurredAt } : {}) }).where(eq(whatsappAutomationJobs.id, job.id));
  }
  return true;
}

export async function listWhatsAppAutomationWorkspace() {
  const db = await getDb();
  if (!db) throw unavailable();
  const [settings, definitions, jobs, requests, activationPrerequisites] = await Promise.all([
    settingsFor(db),
    (async () => { await seedTemplateDefinitions(db); return db.select().from(whatsappAutomationTemplateDefinitions).orderBy(asc(whatsappAutomationTemplateDefinitions.templateKey), asc(whatsappAutomationTemplateDefinitions.language)); })(),
    db.select({ job: whatsappAutomationJobs, appointment: appointments }).from(whatsappAutomationJobs).innerJoin(appointments, eq(whatsappAutomationJobs.appointmentId, appointments.id)).orderBy(desc(whatsappAutomationJobs.scheduledFor)).limit(300),
    db.select().from(whatsappRetouchRequests).orderBy(desc(whatsappRetouchRequests.createdAt)).limit(200),
    activationPrerequisitesFor(db),
  ]);
  const normalizedJobs = jobs.map(({ job, appointment }) => ({
    ...job,
    patientName: appointment.patientName,
    whatsapp: appointment.whatsapp,
    appointmentDate: appointment.appointmentDate,
    appointmentTime: appointment.appointmentTime,
    appointmentStatus: appointment.status,
    treatmentAreas: treatmentSummary(appointment),
    machine: appointment.machine,
    visitType: appointment.visitType,
    consentStatus: appointment.whatsappConsentStatus,
    attendanceConfirmation: appointment.whatsappAttendanceConfirmation,
  }));
  const counters = normalizedJobs.reduce<Record<string, number>>((result, job) => {
    result.total += 1;
    result[job.status] = (result[job.status] ?? 0) + 1;
    if (job.jobType === "session_reminder") result.sessionReminders += 1;
    if (job.jobType === "retouch_invitation") result.retouchReminders += 1;
    return result;
  }, { total: 0, sessionReminders: 0, retouchReminders: 0 });
  return { settings, providerConfigured: Boolean(getMetaWhatsAppConfig()), definitions, jobs: normalizedJobs, retouchRequests: requests, activationPrerequisites, counters };
}

/** Returns only the selected protected appointment's own automation and provider-observed delivery state. */
export async function getAppointmentWhatsAppAutomationStatus(appointmentId: number) {
  const db = await getDb();
  if (!db) throw unavailable();
  const [appointment, settings, jobs] = await Promise.all([
    db.select({ id: appointments.id, whatsappConsentStatus: appointments.whatsappConsentStatus, whatsappOptedOutAt: appointments.whatsappOptedOutAt, whatsappAttendanceConfirmation: appointments.whatsappAttendanceConfirmation, whatsappAutomationVersion: appointments.whatsappAutomationVersion }).from(appointments).where(eq(appointments.id, appointmentId)).limit(1),
    settingsFor(db),
    db.select().from(whatsappAutomationJobs).where(eq(whatsappAutomationJobs.appointmentId, appointmentId)).orderBy(desc(whatsappAutomationJobs.scheduledFor)).limit(100),
  ]);
  if (!appointment[0]) throw new Error("The appointment was not found.");
  const providerIds = jobs.map(job => job.providerMessageId).filter((value): value is string => Boolean(value));
  const messages = providerIds.length ? await db.select({ metaMessageId: whatsappMessages.metaMessageId, status: whatsappMessages.status, sentAt: whatsappMessages.sentAt, deliveredAt: whatsappMessages.deliveredAt, readAt: whatsappMessages.readAt, failedAt: whatsappMessages.failedAt, errorCode: whatsappMessages.errorCode, errorMessage: whatsappMessages.errorMessage }).from(whatsappMessages).where(inArray(whatsappMessages.metaMessageId, providerIds)) : [];
  const byProviderId = new Map(messages.map(message => [message.metaMessageId, message]));
  return {
    appointment: appointment[0],
    providerConfigured: Boolean(getMetaWhatsAppConfig()),
    automationEnabled: settings.automationEnabled,
    jobs: jobs.map(job => ({ ...job, providerStatus: job.providerMessageId ? byProviderId.get(job.providerMessageId)?.status ?? null : null, providerStatusAt: job.providerMessageId ? byProviderId.get(job.providerMessageId)?.readAt ?? byProviderId.get(job.providerMessageId)?.deliveredAt ?? byProviderId.get(job.providerMessageId)?.sentAt ?? byProviderId.get(job.providerMessageId)?.failedAt ?? null : null, providerError: job.providerMessageId ? byProviderId.get(job.providerMessageId)?.errorMessage ?? null : null })),
  };
}

export async function queueWhatsAppAutomationJob(jobId: number, reason: string, actor: StaffActor) {
  const db = await getDb();
  if (!db) throw unavailable();
  const [job] = await db.select().from(whatsappAutomationJobs).where(eq(whatsappAutomationJobs.id, jobId)).limit(1);
  if (!job) throw new Error("The automation job was not found.");
  if (["sent", "delivered", "read", "provider_accepted", "claimed"].includes(job.status)) throw new Error("This reminder cannot be queued again after provider submission or a recorded delivery state.");
  if (!QUEUEABLE_JOB_STATUSES.includes(job.status)) throw new Error("Only an unsent, active reminder may be queued. Cancelled and completed records remain immutable.");
  if (job.status === "failed" && !job.retryable) throw new Error("This message requires a provider, recipient, or template correction before it can be retried.");
  const [appointment] = await db.select().from(appointments).where(eq(appointments.id, job.appointmentId)).limit(1);
  if (!appointment) throw new Error("The related appointment no longer exists. No reminder was queued.");
  if (!isJobEligibleForAppointment(job, appointment)) throw new Error("The related appointment is not eligible for this reminder. No reminder was queued.");
  if (!hasValidWhatsAppNumber(appointment.whatsapp)) throw new Error("A valid WhatsApp number is required before this reminder can be queued.");
  const [contact] = await db.select({ id: whatsappContacts.id, language: whatsappContacts.language }).from(whatsappContacts).where(eq(whatsappContacts.normalizedPhone, normalizeMobileNumber(appointment.whatsapp!))).limit(1);
  if (!appointment.patientId && !contact) throw new Error("A linked patient or verified WhatsApp contact is required before this reminder can be queued.");
  if (appointment.whatsappConsentStatus !== "opted_in" || appointment.whatsappOptedOutAt) throw new Error("Verified WhatsApp opt-in is required before this reminder can be queued.");
  if (!getMetaWhatsAppConfig()) throw new Error("The secure WhatsApp provider configuration is required before this reminder can be queued.");
  const language = resolveAutomationLanguage(appointment.originalConsentLanguage, contact?.language, await defaultClinicLanguage(db));
  const template = await templateForJob(db, job, language);
  if (!template) throw new Error("An approved WhatsApp template for the appointment language is required before this reminder can be queued.");
  const queuedAt = new Date();
  const result = await db.update(whatsappAutomationJobs).set({ status: "queued", scheduledFor: queuedAt, queuedAt, language, manualReason: reason.slice(0, 500), cancelledAt: null, cancelledReason: null, lastErrorCode: null, lastErrorHttpStatus: null, lastProviderErrorType: null, lastError: null })
    .where(and(eq(whatsappAutomationJobs.id, jobId), inArray(whatsappAutomationJobs.status, QUEUEABLE_JOB_STATUSES)));
  if (result[0].affectedRows !== 1) throw new Error("This reminder was changed by another action and was not queued again.");
  await log(db, { appointmentId: job.appointmentId, conversationId: job.conversationId, actor, type: "manual_reminder_queued", outcome: "queued_for_provider", details: "An authorized staff member manually queued an automation reminder with a recorded reason." });
}

export async function cancelWhatsAppAutomationJob(jobId: number, reason: string, actor: StaffActor) {
  const db = await getDb();
  if (!db) throw unavailable();
  const [job] = await db.select().from(whatsappAutomationJobs).where(eq(whatsappAutomationJobs.id, jobId)).limit(1);
  if (!job) throw new Error("The automation job was not found.");
  if (["sent", "delivered", "read", "provider_accepted"].includes(job.status)) throw new Error("A provider-submitted message cannot be cancelled from the queue. Review the message history instead.");
  await db.update(whatsappAutomationJobs).set({ status: "cancelled", cancelledAt: new Date(), cancelledReason: reason.slice(0, 500), claimToken: null }).where(eq(whatsappAutomationJobs.id, jobId));
  await log(db, { appointmentId: job.appointmentId, conversationId: job.conversationId, actor, type: "automation_cancelled", outcome: "staff_cancelled", details: "An authorized staff member cancelled a scheduled WhatsApp automation job with a recorded reason." });
}

export async function updateWhatsAppConsent(input: { appointmentId: number; status: "opted_in" | "opted_out"; source: string; version: string | null }, actor: StaffActor) {
  const db = await getDb();
  if (!db) throw unavailable();
  const [appointment] = await db.select().from(appointments).where(eq(appointments.id, input.appointmentId)).limit(1);
  if (!appointment || !appointment.whatsapp) throw new Error("The appointment and its WhatsApp number are required.");
  const now = new Date();
  const values = {
    whatsappConsentStatus: input.status,
    whatsappConsentSource: input.source,
    whatsappConsentAt: now,
    whatsappConsentVersion: input.version,
    whatsappOptedOutAt: input.status === "opted_out" ? now : null,
  } as const;
  await db.transaction(async tx => {
    await tx.update(appointments).set(values).where(eq(appointments.id, input.appointmentId));
    if (appointment.patientId) await tx.update(patients).set(values).where(eq(patients.id, appointment.patientId));
    if (input.status === "opted_out") {
      await tx.update(whatsappAutomationJobs).set({ status: "cancelled", cancelledAt: now, cancelledReason: "Patient opted out of WhatsApp communication.", claimToken: null })
        .where(and(eq(whatsappAutomationJobs.appointmentId, appointment.id), inArray(whatsappAutomationJobs.status, ACTIVE_JOB_STATUSES)));
    }
  });
  await log(db, { appointmentId: appointment.id, actor, type: "consent_updated", outcome: input.status, details: "An authorized staff member recorded WhatsApp communication consent with source and version." });
}

export async function mapWhatsAppAutomationTemplate(input: { definitionId: number; providerTemplateName: string; providerTemplateId?: string | null }, actor: StaffActor) {
  const db = await getDb();
  if (!db) throw unavailable();
  const [definition] = await db.select().from(whatsappAutomationTemplateDefinitions).where(eq(whatsappAutomationTemplateDefinitions.id, input.definitionId)).limit(1);
  if (!definition) throw new Error("The automation template definition was not found.");
  const templateRows = await db.select().from(whatsappTemplates).where(and(eq(whatsappTemplates.templateName, input.providerTemplateName), eq(whatsappTemplates.status, "approved"))).limit(4);
  if (!templateRows.length) throw new Error("Only an approved Meta template may be mapped to automation.");
  await db.update(whatsappAutomationTemplateDefinitions).set({ providerTemplateName: input.providerTemplateName, providerTemplateId: input.providerTemplateId ?? templateRows[0]?.metaTemplateId ?? null }).where(eq(whatsappAutomationTemplateDefinitions.id, input.definitionId));
  await db.insert(activityLogs).values({ actorUserId: actor.id, actorName: actor.name, action: "Mapped approved Meta template to WhatsApp automation", subjectType: "whatsapp_template", subjectId: input.definitionId });
}

export async function reviewWhatsAppRetouchRequest(input: { requestId: number; action: "confirm" | "suggest" | "decline"; machine?: "DEKA AGAIN" | "CLARITY 2" | "GENTLE PROMAX" | "DUETTO MACHINE"; date?: string; time?: string }, actor: StaffActor) {
  const db = await getDb();
  if (!db) throw unavailable();
  const [request] = await db.select().from(whatsappRetouchRequests).where(eq(whatsappRetouchRequests.id, input.requestId)).limit(1);
  if (!request) throw new Error("The retouch request was not found.");
  if (request.status !== "awaiting_clinic_confirmation") throw new Error("Only a completed patient retouch request can be reviewed.");
  const selectedDate = input.date ?? request.preferredDate;
  const selectedTime = input.time ?? request.preferredTime;
  if (!selectedDate || !selectedTime || selectedDate < request.eligibleStartDate || selectedDate > request.eligibleEndDate || !isTime(selectedTime)) throw new Error("Choose a valid 15-minute appointment time within the original day 10–14 retouch window.");
  if (input.action === "decline") {
    await db.update(whatsappRetouchRequests).set({ status: "declined" as RetouchRequestStatus, reviewedAt: new Date(), reviewedByUserId: actor.id }).where(eq(whatsappRetouchRequests.id, request.id));
    await log(db, { appointmentId: request.originalSessionAppointmentId, actor, type: "retouch_request_reviewed", outcome: "declined", details: "An authorized staff member declined a retouch request; no appointment was created." });
    return { action: "declined" as const, appointmentId: null };
  }
  if (input.action === "suggest") {
    await db.update(whatsappRetouchRequests).set({ status: "alternative_time_suggested" as RetouchRequestStatus, suggestedDate: selectedDate, suggestedTime: selectedTime, reviewedAt: new Date(), reviewedByUserId: actor.id }).where(eq(whatsappRetouchRequests.id, request.id));
    await log(db, { appointmentId: request.originalSessionAppointmentId, actor, type: "retouch_request_reviewed", outcome: "alternative_time_suggested", details: "An authorized staff member suggested an alternative retouch time; no appointment was created." });
    return { action: "suggested" as const, appointmentId: null };
  }
  if (!input.machine) throw new Error("Choose the machine before confirming a retouch appointment.");
  return db.transaction(async tx => {
    const [original] = await tx.select().from(appointments).where(eq(appointments.id, request.originalSessionAppointmentId)).limit(1);
    if (!original || original.status !== "completed" || original.visitType !== "session") throw new Error("The original completed session is required before confirming a retouch.");
    if (!original.patientId) throw new Error("Link the original completed session to a patient file before confirming a retouch appointment.");
    const conflicts = await tx.select({ id: appointments.id, whatsapp: appointments.whatsapp, machine: appointments.machine }).from(appointments).where(and(eq(appointments.appointmentDate, selectedDate), eq(appointments.appointmentTime, selectedTime), inArray(appointments.status, ["confirmed", "waiting", "arrived"])));
    if (conflicts.some(row => row.whatsapp === original.whatsapp)) throw new Error("A scheduled appointment already exists for this WhatsApp number at the selected date and time.");
    if (conflicts.some(row => row.machine === input.machine)) throw new Error("The selected machine is already assigned at the selected date and time.");
    const created = await tx.insert(appointments).values({
      consultationRequestId: null,
      patientId: original.patientId,
      patientName: original.patientName,
      contactNumber: original.contactNumber,
      whatsapp: original.whatsapp,
      email: original.email,
      mrn: original.mrn,
      appointmentDate: selectedDate,
      appointmentTime: selectedTime,
      appointmentEndTime: null,
      treatmentArea: original.treatmentArea,
      treatmentAreas: original.treatmentAreas,
      machine: input.machine,
      visitType: "retouch",
      whatsappConsentStatus: original.whatsappConsentStatus,
      whatsappConsentSource: original.whatsappConsentSource,
      whatsappConsentAt: original.whatsappConsentAt,
      whatsappConsentVersion: original.whatsappConsentVersion,
      whatsappOptedOutAt: original.whatsappOptedOutAt,
      whatsappAttendanceConfirmation: "awaiting_response",
      whatsappAttendanceConfirmedAt: null,
      whatsappCannotAttendAt: null,
      whatsappAutomationInitializedAt: new Date(),
      whatsappAutomationVersion: 1,
      nextFollowUpDate: null,
      nextFollowUpType: null,
      internalNotes: `WhatsApp retouch request #${request.id}; original session #${original.id}.`,
      assignedStaff: actor.name,
      durationMinutes: original.durationMinutes,
      originalConsentSetReference: original.originalConsentSetReference,
      originalConsentAcknowledgedAt: original.originalConsentAcknowledgedAt,
      originalConsentLanguage: original.originalConsentLanguage,
      consentSignatureStatus: original.consentSignatureStatus,
      consentSignatureReference: original.consentSignatureReference,
      source: "whatsapp_retouch",
      sourceRowNumber: null,
      importBatchId: null,
      importFingerprint: null,
      originalAppointmentDate: null,
      originalAppointmentStartTime: null,
      originalAppointmentEndTime: null,
      originalTelephone: null,
      originalSex: null,
      normalizedSex: null,
      originalAge: null,
      normalizedAge: null,
      nationality: original.nationality,
      remarks: null,
      originalRowData: null,
      status: "confirmed",
    }).$returningId();
    const appointmentId = Number(created[0]?.id);
    if (!appointmentId) throw new Error("The retouch appointment could not be created.");
    await tx.update(whatsappRetouchRequests).set({ status: "confirmed" as RetouchRequestStatus, appointmentId, suggestedDate: selectedDate, suggestedTime: selectedTime, reviewedAt: new Date(), reviewedByUserId: actor.id }).where(eq(whatsappRetouchRequests.id, request.id));
    await tx.insert(activityLogs).values({ actorUserId: actor.id, actorName: actor.name, action: "Confirmed WhatsApp retouch request and created appointment", subjectType: "whatsapp_retouch_request", subjectId: request.id });
    return { action: "confirmed" as const, appointmentId };
  });
}

export async function recordConfirmedRetouchNotification(requestId: number) {
  const db = await getDb();
  if (!db) throw unavailable();
  const [request] = await db.select().from(whatsappRetouchRequests).where(eq(whatsappRetouchRequests.id, requestId)).limit(1);
  if (!request?.appointmentId) return;
  const contact = await matchingConversation(db, request.whatsapp);
  await queueInstantJob(db, { appointmentId: request.appointmentId, conversationId: contact?.conversationId ?? null, retouchRequestId: request.id, type: "retouch_confirmation", language: contact?.language ?? "unknown" });
}
