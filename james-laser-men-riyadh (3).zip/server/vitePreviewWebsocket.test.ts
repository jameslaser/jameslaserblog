import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const viteBridge = readFileSync(resolve(process.cwd(), "server/_core/vite.ts"), "utf8");

describe("managed preview Vite transport", () => {
  it("does not advertise an internal HMR websocket through the HTTP-only preview gateway", () => {
    expect(viteBridge).toContain("hmr: false");
    expect(viteBridge).toContain("ws: false");
    expect(viteBridge).toContain("function stripViteDevClient");
    expect(viteBridge).toContain("template = stripViteDevClient(template);");
    expect(viteBridge).toContain("VITE_PREVIEW_CLIENT_SHIM");
    expect(viteBridge).toContain('app.get("/@vite/client"');
    expect(viteBridge).not.toContain("hmr: { server }");
  });
});
