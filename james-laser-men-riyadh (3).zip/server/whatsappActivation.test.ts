import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
import { validateWhatsAppEnvironment } from "../scripts/whatsapp-preflight.mjs";

const root = resolve(import.meta.dirname, "..");

describe("WhatsApp activation tooling", () => {
  it("rejects incomplete configuration without exposing values", () => {
    const result = validateWhatsAppEnvironment({ META_APP_ID: "123" });
    expect(result.ok).toBe(false);
    expect(result.missing).toContain("WHATSAPP_ACCESS_TOKEN");
    expect(result.errors.join(" ")).not.toContain("123");
  });

  it("accepts correctly shaped owner configuration", () => {
    const result = validateWhatsAppEnvironment({
      META_APP_ID: "123456789",
      META_APP_SECRET: "a".repeat(32),
      WHATSAPP_ACCESS_TOKEN: "EAA" + "a".repeat(32),
      WHATSAPP_PHONE_NUMBER_ID: "987654321",
      WHATSAPP_BUSINESS_ACCOUNT_ID: "1833666484124208",
      WHATSAPP_WEBHOOK_VERIFY_TOKEN: "verify-token-123456",
      META_GRAPH_API_VERSION: "v23.0",
    });
    expect(result).toEqual({ ok: true, required: result.required, present: result.required, missing: [], errors: [] });
  });

  it("rejects a WABA ID other than the canonical clinic account", () => {
    const result = validateWhatsAppEnvironment({
      META_APP_ID: "123456789",
      META_APP_SECRET: "a".repeat(32),
      WHATSAPP_ACCESS_TOKEN: "EAA" + "a".repeat(32),
      WHATSAPP_PHONE_NUMBER_ID: "987654321",
      WHATSAPP_BUSINESS_ACCOUNT_ID: "456789123",
      WHATSAPP_WEBHOOK_VERIFY_TOKEN: "verify-token-123456",
      META_GRAPH_API_VERSION: "v23.0",
    });
    expect(result.ok).toBe(false);
    expect(result.errors).toContain("WHATSAPP_BUSINESS_ACCOUNT_ID does not match the canonical clinic WABA.");
  });

  it("keeps replay dry-run as the default and requires explicit staging confirmation", () => {
    const source = readFileSync(resolve(root, "scripts/whatsapp-webhook-replay.mjs"), "utf8");
    expect(source).toContain('process.argv.includes("--confirm-staging")');
    expect(source).toContain('mode: "dry-run"');
    expect(source).toContain("networkRequestMade: false");
  });
});
