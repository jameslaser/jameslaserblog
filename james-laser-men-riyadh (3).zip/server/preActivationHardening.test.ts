import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const root = resolve(import.meta.dirname, "..");
const read = (path: string) => readFileSync(resolve(root, path), "utf8");

describe("Phase 2 pre-activation hardening contract", () => {
  it("keeps Meta API acceptance distinct from authoritative sent status", () => {
    const service = read("server/whatsappService.ts");
    expect(service).toContain("await db.update(whatsappMessages).set({ metaMessageId })");
    expect(service).not.toContain('set({ metaMessageId, status: "sent"');
    expect(service).toContain("shouldApplyMetaStatus");
    expect(service).toContain("shouldReprocessWebhookEvent");
    expect(service).toContain("recordWebhookReceipt");
    expect(service).toContain("recordWebhookFailure");
  });

  it("does not pass Forge credentials through Vite or Cloud Build", () => {
    const cloudBuild = read("cloudbuild.yaml");
    const dockerfile = read("Dockerfile.cloudrun");
    const map = read("client/src/components/Map.tsx");
    const variables = read("ENVIRONMENT_VARIABLES.md");
    for (const source of [cloudBuild, dockerfile, map, variables]) expect(source).not.toContain("VITE_FRONTEND_FORGE_API_KEY");
    expect(cloudBuild).not.toContain("VITE_FRONTEND_FORGE_API_URL");
    expect(dockerfile).toContain("VITE_PUBLIC_MAPS_SCRIPT_URL");
    expect(map).toContain("credential-free HTTPS script URL");
  });

  it("requires validated text-only template body variables in the protected send procedure", () => {
    const router = read("server/routers.ts");
    const workspace = read("client/src/pages/WhatsAppWorkspace.tsx");
    expect(router).toContain("whatsappTemplateTextParameterInput");
    expect(router).toContain('type: z.literal("body")');
    expect(workspace).toContain("Template variables");
    expect(workspace).toContain("selectedTemplateVariableCount");
  });
});
