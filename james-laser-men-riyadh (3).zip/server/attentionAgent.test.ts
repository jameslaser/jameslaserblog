import { describe, expect, it } from "vitest";
import { buildAttentionFindings } from "./attentionAgent";

describe("zero-credit Admin Attention Agent rules", () => {
  it("returns no findings when aggregate clinic attention signals are clear", () => {
    expect(buildAttentionFindings({ pendingRequests: 0, clarificationRequests: 0, potentialDuplicates: 0, signatureOutstanding: 0, expiredSignatures: 0, newEnquiries: 0, hmsWarningBatches: 0 })).toEqual([]);
  });

  it("prioritizes expired signatures and duplicate-risk findings without exposing patient data", () => {
    const findings = buildAttentionFindings({ pendingRequests: 2, clarificationRequests: 1, potentialDuplicates: 1, signatureOutstanding: 3, expiredSignatures: 1, newEnquiries: 2, hmsWarningBatches: 1 });
    expect(findings.slice(0, 2).map(item => item.id)).toEqual(["expired-signatures", "potential-duplicates"]);
    expect(findings.every(item => !item.summary.includes("+966") && !item.summary.includes("@"))).toBe(true);
  });
});
