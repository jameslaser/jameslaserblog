import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const root = resolve(import.meta.dirname, "..");
const migration = readFileSync(resolve(root, "drizzle/migrations/0030_restore_whatsapp_settings_table.sql"), "utf8");

describe("WhatsApp settings persistence restoration", () => {
  it("uses an additive, idempotent table migration with automation disabled by default", () => {
    expect(migration).toContain("CREATE TABLE IF NOT EXISTS `whatsappSettings`");
    expect(migration).toContain("`automationEnabled` boolean NOT NULL DEFAULT false");
    expect(migration).toContain("`appointmentConfirmationEnabled` boolean NOT NULL DEFAULT true");
    expect(migration).toContain("`appointmentNoShowFollowUpEnabled` boolean NOT NULL DEFAULT false");
    expect(migration).toContain("no appointment, patient, provider credential, consent, activation, or communication data is modified");
  });
});
