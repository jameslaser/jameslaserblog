const requiredSecrets = [
  "META_APP_ID",
  "META_APP_SECRET",
  "WHATSAPP_ACCESS_TOKEN",
  "WHATSAPP_PHONE_NUMBER_ID",
  "WHATSAPP_BUSINESS_ACCOUNT_ID",
  "WHATSAPP_WEBHOOK_VERIFY_TOKEN",
  "META_GRAPH_API_VERSION",
];
const CANONICAL_WABA_ID = "1833666484124208";

const isNonEmpty = value => typeof value === "string" && value.trim().length > 0;
const isDigits = value => /^\d+$/.test(value);

export function validateWhatsAppEnvironment(environment = process.env) {
  const errors = [];
  const present = [];
  const missing = [];

  for (const name of requiredSecrets) {
    if (isNonEmpty(environment[name])) present.push(name);
    else missing.push(name);
  }

  if (missing.length) errors.push(`Missing required server configuration: ${missing.join(", ")}`);
  if (isNonEmpty(environment.META_APP_ID) && !isDigits(environment.META_APP_ID.trim())) errors.push("META_APP_ID must contain digits only.");
  if (isNonEmpty(environment.WHATSAPP_PHONE_NUMBER_ID) && !isDigits(environment.WHATSAPP_PHONE_NUMBER_ID.trim())) errors.push("WHATSAPP_PHONE_NUMBER_ID must contain digits only.");
  if (isNonEmpty(environment.WHATSAPP_BUSINESS_ACCOUNT_ID) && !isDigits(environment.WHATSAPP_BUSINESS_ACCOUNT_ID.trim())) errors.push("WHATSAPP_BUSINESS_ACCOUNT_ID must contain digits only.");
  if (isNonEmpty(environment.WHATSAPP_BUSINESS_ACCOUNT_ID) && environment.WHATSAPP_BUSINESS_ACCOUNT_ID.trim() !== CANONICAL_WABA_ID) errors.push("WHATSAPP_BUSINESS_ACCOUNT_ID does not match the canonical clinic WABA.");
  if (isNonEmpty(environment.META_APP_SECRET) && environment.META_APP_SECRET.trim().length < 16) errors.push("META_APP_SECRET is shorter than the minimum accepted shape.");
  if (isNonEmpty(environment.WHATSAPP_ACCESS_TOKEN) && environment.WHATSAPP_ACCESS_TOKEN.trim().length < 20) errors.push("WHATSAPP_ACCESS_TOKEN is shorter than the minimum accepted shape.");
  if (isNonEmpty(environment.WHATSAPP_WEBHOOK_VERIFY_TOKEN) && environment.WHATSAPP_WEBHOOK_VERIFY_TOKEN.trim().length < 16) errors.push("WHATSAPP_WEBHOOK_VERIFY_TOKEN must be at least 16 characters.");
  if (isNonEmpty(environment.META_GRAPH_API_VERSION) && !/^v\d+\.\d+$/.test(environment.META_GRAPH_API_VERSION.trim())) errors.push("META_GRAPH_API_VERSION must use the vNN.N shape.");

  return { ok: errors.length === 0, required: requiredSecrets, present, missing, errors };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const result = validateWhatsAppEnvironment();
  const output = {
    ok: result.ok,
    requiredCount: result.required.length,
    present: result.present,
    missing: result.missing,
    errors: result.errors,
    note: "Values are intentionally never printed.",
  };
  console.log(JSON.stringify(output, null, 2));
  process.exitCode = result.ok ? 0 : 1;
}
