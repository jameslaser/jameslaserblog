import { createHmac } from "node:crypto";
import { readFile } from "node:fs/promises";

function argument(name) {
  const index = process.argv.indexOf(name);
  return index >= 0 ? process.argv[index + 1] : undefined;
}

const fixturePath = argument("--file");
const endpoint = argument("--endpoint");
const confirmed = process.argv.includes("--confirm-staging");

if (!fixturePath || !endpoint) {
  console.error("Usage: node scripts/whatsapp-webhook-replay.mjs --file <fixture.json> --endpoint <staging-webhook-url> [--confirm-staging]");
  process.exitCode = 2;
} else {
  const rawBody = await readFile(fixturePath, "utf8");
  const secret = process.env.META_APP_SECRET;
  const signature = secret ? `sha256=${createHmac("sha256", secret).update(rawBody).digest("hex")}` : undefined;
  const summary = { endpoint, fixtureBytes: Buffer.byteLength(rawBody), signaturePresent: Boolean(signature), networkRequestMade: false };

  if (!confirmed) {
    console.log(JSON.stringify({ ...summary, mode: "dry-run", note: "No network request was made. Add --confirm-staging to send this signed fixture." }, null, 2));
  } else if (!secret) {
    console.error("META_APP_SECRET is required only in the owner-controlled staging shell; its value is never printed.");
    process.exitCode = 1;
  } else {
    const response = await fetch(endpoint, { method: "POST", headers: { "content-type": "application/json", "x-hub-signature-256": signature }, body: rawBody });
    console.log(JSON.stringify({ ...summary, networkRequestMade: true, mode: "staging", httpStatus: response.status, responseBody: (await response.text()).slice(0, 500) }, null, 2));
    if (!response.ok) process.exitCode = 1;
  }
}
