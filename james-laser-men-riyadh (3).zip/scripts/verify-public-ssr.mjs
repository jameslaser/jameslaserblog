import assert from "node:assert/strict";
import { render } from "../dist/server-ssr/entry-server.js";

const clinic = {
  businessName: "James Laser Hair Removal for Men Riyadh @ New Look Clinic",
  clinicName: "New Look Clinic",
  whatsapp: "+966557401562",
  workingHours: "1:00 PM – 10:00 PM",
  appointmentFormEnabled: true,
};
const guide = {
  id: 1,
  slug: "laser-preparation",
  postType: "blog",
  titleEn: "Laser preparation for men",
  titleAr: "التحضير لجلسة الليزر للرجال",
  summaryEn: "Practical preparation guidance before a men’s laser appointment in Riyadh.",
  summaryAr: "إرشادات عملية للتحضير قبل موعد إزالة الشعر بالليزر للرجال في الرياض.",
  contentEn: "Use only clinic-reviewed preparation instructions.",
  contentAr: "استخدم تعليمات التحضير التي راجعتها العيادة فقط.",
  seoTitle: "Laser preparation for men in Riyadh",
  metaDescription: "Clinic-reviewed preparation guidance for men’s laser hair removal appointments in Riyadh.",
  category: "Preparation",
  tags: "men's laser, Riyadh, preparation",
  socialCaptionEn: "Read the clinic-reviewed preparation guide before requesting an assessment.",
  socialHashtags: "#MensLaser #Riyadh",
  publishedAt: new Date("2026-09-01T00:00:00.000Z"),
  updatedAt: new Date("2026-09-02T00:00:00.000Z"),
};

const publicData = {
  clinicSettings: async () => clinic,
  homepageSections: async () => [],
  policies: async () => [],
  treatments: async () => [],
  promotions: async () => [],
  reviews: async () => [],
  resultCases: async () => [],
  guidePosts: async () => [guide],
  guidePostBySlug: async slug => slug === guide.slug ? guide : null,
  faqs: async () => [],
};

const home = await render("/", publicData);
assert.equal(home.head.canonicalPath, "/");
assert.match(home.html, /A clear conversation before every next step/);
assert.match(home.html, /Practical preparation guidance before a men’s laser appointment in Riyadh/);
assert.match(home.html, /FAQ/);
assert.equal(home.head.faqItems?.length, 3);

const blogIndex = await render("/en/blog", publicData);
assert.equal(blogIndex.head.canonicalPath, "/en/blog");
assert.match(blogIndex.html, /Laser preparation for men/);

const guidePage = await render("/en/blog/laser-preparation", publicData);
assert.equal(guidePage.head.canonicalPath, "/en/blog/laser-preparation");
assert.equal(guidePage.head.ogType, "article");
assert.equal(guidePage.head.contentSchema?.["@type"], "BlogPosting");
assert.equal(guidePage.head.contentSchema?.mainEntityOfPage?.["@id"], "https://www.jameslaserformen.com/en/blog/laser-preparation");
assert.deepEqual(guidePage.head.articleTags, ["men's laser", "Riyadh", "preparation"]);
assert.match(guidePage.html, /Use only clinic-reviewed preparation instructions/);

const arabicGuide = await render("/ar/blog/laser-preparation", publicData);
assert.equal(arabicGuide.head.documentLanguage, "ar");
assert.equal(arabicGuide.head.canonicalPath, "/ar/blog/laser-preparation");
assert.match(arabicGuide.html, /استخدم تعليمات التحضير/);

const privatePage = await render("/admin", publicData);
assert.equal(privatePage.head.noindex, true);
assert.equal(privatePage.html, "");

const missingPage = await render("/not-a-public-route", publicData);
assert.equal(missingPage.head.notFound, true);
assert.match(missingPage.html, /This page is not here/);

console.log("SSR public route verification passed.");
