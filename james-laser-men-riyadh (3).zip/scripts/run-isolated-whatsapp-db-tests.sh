#!/usr/bin/env bash
set -euo pipefail

# Disposable localhost-only database for lifecycle regression tests. Never accepts a production URL.
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TEST_ROOT="$(sudo -u mysql mktemp -d /tmp/newlook-whatsapp-test.XXXXXX)"
DATA_DIR="$TEST_ROOT/data"
SOCKET="$DATA_DIR/mariadb.sock"
PID_FILE="$DATA_DIR/mariadb.pid"
PORT="3317"
DB_NAME="whatsapp_lifecycle_test"
MIGRATION_DB="whatsapp_migration_fixture_test"
DB_USER="whatsapp_test"
DB_PASSWORD="$(openssl rand -hex 24)"
MYSQL_URL="mysql://${DB_USER}:${DB_PASSWORD}@127.0.0.1:${PORT}/${DB_NAME}"

cleanup() {
  if sudo test -f "$PID_FILE"; then
    local pid
    pid="$(sudo cat "$PID_FILE")"
    if sudo kill -0 "$pid" 2>/dev/null; then
      sudo kill "$pid" 2>/dev/null || true
      for _ in {1..20}; do sudo kill -0 "$pid" 2>/dev/null || break; sleep 0.2; done
    fi
  fi
  sudo rm -rf "$TEST_ROOT"
}
trap cleanup EXIT

if [[ "${MYSQL_URL}" != *"/${DB_NAME}" ]]; then
  echo "Refusing to run outside the isolated WhatsApp lifecycle test database." >&2
  exit 1
fi

sudo -u mysql mkdir -p "$DATA_DIR"
sudo -u mysql mariadb-install-db --user=mysql --datadir="$DATA_DIR" --skip-test-db >/dev/null
sudo -u mysql mariadbd \
  --datadir="$DATA_DIR" \
  --socket="$SOCKET" \
  --pid-file="$PID_FILE" \
  --port="$PORT" \
  --bind-address=127.0.0.1 \
  --skip-name-resolve \
  --log-error="$DATA_DIR/mariadb.log" &

for _ in {1..50}; do
  if sudo mariadb --protocol=socket --socket="$SOCKET" -uroot -e "SELECT 1" >/dev/null 2>&1; then break; fi
  sleep 0.2
done
sudo mariadb --protocol=socket --socket="$SOCKET" -uroot -e "SELECT 1" >/dev/null
sudo mariadb --protocol=socket --socket="$SOCKET" -uroot <<SQL
CREATE DATABASE \`${DB_NAME}\`;
CREATE DATABASE \`${MIGRATION_DB}\`;
CREATE USER '${DB_USER}'@'127.0.0.1' IDENTIFIED BY '${DB_PASSWORD}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'127.0.0.1';
FLUSH PRIVILEGES;
SQL

cd "$ROOT_DIR"
# Exercise the additive SQL itself against a minimal pre-0027 schema. The fixture deliberately contains no production data.
sudo mariadb --protocol=socket --socket="$SOCKET" -uroot "$MIGRATION_DB" <<'SQL'
CREATE TABLE `users` (`id` int NOT NULL AUTO_INCREMENT, PRIMARY KEY (`id`));
CREATE TABLE `whatsappAutomationJobs` (`id` int NOT NULL AUTO_INCREMENT, `lastErrorCode` varchar(80) NULL, PRIMARY KEY (`id`));
CREATE TABLE `whatsappWebhookEvents` (`id` int NOT NULL AUTO_INCREMENT, `whatsappWebhookProcessingStatus` enum('received','processed','ignored','failed') NOT NULL DEFAULT 'received', PRIMARY KEY (`id`));
INSERT INTO `users` (`id`) VALUES (1);
INSERT INTO `whatsappAutomationJobs` (`id`, `lastErrorCode`) VALUES (1, 'existing_error');
INSERT INTO `whatsappWebhookEvents` (`id`, `whatsappWebhookProcessingStatus`) VALUES (1, 'processed');
SQL
sudo mariadb --protocol=socket --socket="$SOCKET" -uroot "$MIGRATION_DB" < drizzle/migrations/0027_add_whatsapp_activation_evidence.sql
MIGRATION_ASSERTIONS="$(sudo mariadb --protocol=socket --socket="$SOCKET" -uroot -N -e "SELECT (SELECT COUNT(*) FROM \`${MIGRATION_DB}\`.\`whatsappAutomationJobs\` WHERE id = 1 AND lastErrorCode = 'existing_error' AND lastErrorHttpStatus IS NULL AND lastProviderErrorType IS NULL), (SELECT whatsappWebhookProcessingStatus = 'processed' FROM \`${MIGRATION_DB}\`.\`whatsappWebhookEvents\` WHERE id = 1), (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = '${MIGRATION_DB}' AND TABLE_NAME = 'whatsappActivationPrerequisites' AND COLUMN_NAME = 'evidenceReference'), (SELECT COLUMN_TYPE LIKE '%processing%' FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = '${MIGRATION_DB}' AND TABLE_NAME = 'whatsappWebhookEvents' AND COLUMN_NAME = 'whatsappWebhookProcessingStatus')")"
read -r migration_job_preserved migration_webhook_preserved migration_evidence_created migration_processing_state_added <<< "$MIGRATION_ASSERTIONS"
if [[ "$migration_job_preserved" != "1" || "$migration_webhook_preserved" != "1" || "$migration_evidence_created" != "1" || "$migration_processing_state_added" != "1" ]]; then
  echo "The isolated WhatsApp readiness migration fixture validation failed: $MIGRATION_ASSERTIONS" >&2
  exit 1
fi
MYSQL_URL="$MYSQL_URL" pnpm drizzle-kit push --force >/dev/null
WHATSAPP_TEST_DB=1 MYSQL_URL="$MYSQL_URL" pnpm vitest run server/whatsappProductionReadiness.db.test.ts
