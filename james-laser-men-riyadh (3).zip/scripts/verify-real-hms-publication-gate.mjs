import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const root = process.cwd();
const evidencePath = resolve(root, "docs/evidence/REAL_HMS_VALIDATION_2026-09-07.json");
const digestPath = `${evidencePath}.sha256`;

function fail(message) {
  console.error(`PUBLICATION GATE: FAIL — ${message}`);
  process.exit(1);
}

let evidenceBytes;
let evidence;
let expectedDigest;
try {
  evidenceBytes = readFileSync(evidencePath);
  evidence = JSON.parse(evidenceBytes.toString("utf8"));
  expectedDigest = readFileSync(digestPath, "utf8").trim().split(/\s+/u)[0];
} catch (error) {
  fail(`mandatory real-HMS evidence is missing or unreadable: ${error instanceof Error ? error.message : String(error)}`);
}

const actualDigest = createHash("sha256").update(evidenceBytes).digest("hex");
if (actualDigest !== expectedDigest) fail("the immutable evidence digest does not match.");
if (evidence.evidenceType !== "real_hms_read_only_publication_validation") fail("evidence type is not the mandatory real-HMS validation.");
if (evidence.readOnly !== true) fail("the validation was not read-only.");
if (evidence.connection?.success !== true) fail("real HMS connection did not succeed.");
if (evidence.report?.success !== true || evidence.report?.httpStatus !== 200) fail("a genuine HMS report was not fetched successfully.");
if (evidence.report?.sourceReportIdentifier !== "DBAL.LoadAllAppointment") fail("the source report identifier is not approved.");
if (evidence.report?.providerScope !== "NR011") fail("the exact NR011 source restriction is not present.");
if (!Number.isInteger(evidence.report?.rawRecordCount) || evidence.report.rawRecordCount <= 0) fail("raw record count is empty.");
if (!Number.isInteger(evidence.report?.acceptedRecordCount) || evidence.report.acceptedRecordCount <= 0) fail("accepted record count must be greater than zero.");
if (!Number.isInteger(evidence.report?.rejectedRecordCount) || evidence.report.rejectedRecordCount <= 0) fail("rejected record count must be greater than zero.");
if (evidence.report.acceptedRecordCount + evidence.report.rejectedRecordCount !== evidence.report.rawRecordCount) fail("accepted and rejected counts do not reconcile to raw records.");
if (!Array.isArray(evidence.report?.rejectionCategories) || evidence.report.rejectionCategories.length === 0 || evidence.report.rejectionCategories.some(item => !item.reason || !Number.isInteger(item.count) || item.count <= 0 || !Array.isArray(item.evidenceRecordHashes) || item.evidenceRecordHashes.length === 0)) fail("exact privacy-safe rejection evidence is incomplete.");
if (!Array.isArray(evidence.report?.acceptedEvidenceRecordHashes) || evidence.report.acceptedEvidenceRecordHashes.length === 0) fail("privacy-safe accepted-record evidence is missing.");
if (evidence.report?.parsedPayloadPartsRejected !== 0) fail("the fetched HMS payload contained unparsed response parts.");
if (!evidence.report?.payloadSha256 || !evidence.immutableEvidenceId || !evidence.worker?.sourceSha256) fail("immutable source and payload hashes are incomplete.");
const fetchedAt = Date.parse(evidence.fetchedAt);
if (!Number.isFinite(fetchedAt) || fetchedAt > Date.now() + 5 * 60_000 || Date.now() - fetchedAt > 24 * 60 * 60_000) fail("the real-HMS evidence is invalid or older than 24 hours.");
if (evidence.validationResult !== "PASS") fail("the recorded validation result is not PASS.");
const integrity = evidence.dataIntegrityChecks;
if (!integrity || Object.values(integrity).some(value => value !== true)) fail("one or more data-integrity protections did not pass.");

console.log("REAL HMS CONNECTION: PASS");
console.log("REAL REPORT FETCH: PASS");
console.log(`RAW RECORDS: ${evidence.report.rawRecordCount}`);
console.log(`ACCEPTED RECORDS: ${evidence.report.acceptedRecordCount}`);
console.log(`REJECTED RECORDS: ${evidence.report.rejectedRecordCount}`);
console.log("REJECTION EVIDENCE: PASS");
for (const category of evidence.report.rejectionCategories) console.log(`- ${category.reason}: ${category.count}`);
console.log("DATA-INTEGRITY CHECKS: PASS");
console.log("PUBLICATION GATE: PASS");
