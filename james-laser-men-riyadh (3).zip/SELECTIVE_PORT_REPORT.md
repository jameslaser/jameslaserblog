# Selective Port Report

## Authoritative baseline

The current James Laser Hair Removal for Men Riyadh application remains authoritative. The donor archive was used only as a reference and source for compatible revenue logic. No wholesale replacement occurred.

## Ported batch

The first approved batch ports and adapts the donor HMS revenue workflow into the existing protected Admin Portal. It includes the dependency-free revenue CSV parser, protected preview/import procedures, daily/monthly and date-filtered reporting, revenue by patient, service reporting, import history, and duplicate protection.

The current application uses the built-in MySQL/TiDB database through `MYSQL_URL`. Two additive tables were added: `revenueImportBatches` for immutable import metadata and `revenueTransactions` for one immutable service-row transaction per imported row. The migration is `drizzle/migrations/0025_add_revenue_tables.sql`. The managed database was inspected after migration and both new tables contain zero rows; no test or seed revenue data was inserted.

The Revenue workspace is available at `/admin/revenue` behind the existing `DashboardLayout`, Manus OAuth, owner/admin authorization boundary, and current navigation. The route is registered in `client/src/App.tsx`, the workspace is `client/src/pages/RevenueWorkspace.tsx`, and the protected procedures are in the current `server/routers.ts` and `server/revenue.ts`.

## Retained or excluded donor features

The current HMS appointment importer remains authoritative, including its NR011 provider boundary and source-evidence rules. The current Patients, Waiting List, Session/Retouch Reminders, and structured arrival workflows were retained because they are already more complete and clinic-specific than the donor equivalents. The current responsive web shell and mobile bottom navigation were retained; donor native Android/iOS, Capacitor, mobile authentication, and native storage code were excluded.

The current Manus OAuth, cookies, RBAC, routes, branding, deployment configuration, and database architecture were retained. PostgreSQL, Cloud SQL, Firebase, Cloud Run, environment files, secrets, wholesale package changes, and conflicting authentication or routing were excluded.

## Validation

Focused selective-port tests passed. Full validation passed with 59 test files and 200 tests, TypeScript, production build, protected desktop screenshots for Revenue/Dashboard/Appointments, and a 375px mobile review of Revenue/Dashboard with the existing mobile navigation. Revenue-specific regression coverage verifies the workspace contract, protected route, owner/admin boundary, MySQL/TiDB table names, and current-router integration. The full build reported only the existing large-client-chunk advisory; no compilation failure occurred.

No patient, appointment, request, consent, HMS, or existing financial record was modified. No revenue data was imported. The first port batch is ready for review; further donor integration should remain incremental and should not begin until this batch is accepted.
