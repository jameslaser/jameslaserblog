# HMS CSV Export

The protected Admin Portal HMS workspace now includes **Download clinic records CSV**. The control calls the admin-only `admin.hmsExportCsv` procedure on demand and creates a browser download in memory. The generated file is not written to S3, the database, or portal storage.

## Export scope

The server joins imported appointment records to their HMS import batch and includes only appointments whose source is `hms_csv` and whose import batch is explicitly attested with provider code `NR011`. This preserves the project’s provider boundary for `NR011 — JAMES FLORES`. Public consultation requests, manually created appointments, internal notes, raw source JSON, and unapproved provider data are excluded.

| Column group | Exported fields |
| --- | --- |
| Identity | Clinic Record ID, Patient Name, MRN, WhatsApp |
| Provider/source | Provider Code, Provider Label, HMS Source Row, HMS Import Batch |
| Schedule | Appointment Date, Start Time, End Time, Status |
| Patient context | Nationality, Original Telephone, Original Sex, Original Age |
| Clinic classification | Visit Type |
| Source note | Remarks |

CSV values are quoted and double quotes are escaped. Values beginning with common spreadsheet formula characters are prefixed with an apostrophe to reduce formula-injection risk when opened in spreadsheet software. The file name includes the Riyadh date and is downloaded locally through the browser.

The export is a read-only operation. It does not create, update, delete, import, merge, or migrate any clinic record. Authorized staff should keep the downloaded file secure and delete it when it is no longer needed.
