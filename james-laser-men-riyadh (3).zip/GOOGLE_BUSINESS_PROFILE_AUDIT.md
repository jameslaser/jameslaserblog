# Google Business Profile Integration Audit

**Scope.** This audit compares the attached requirements checklist with the current James Laser application after the latest source fast-forward. The existing application remains authoritative. No Google account, connector, credential, clinic record, database record, or external post was changed during this audit.

## Summary

| Status | Count | Interpretation |
|---|---:|---|
| ✅ Complete | 9 grouped areas | Existing CMS, bilingual content, media registration, protected admin/RBAC, built-in MySQL/TiDB, activity logs, notifications, heartbeat infrastructure, and regression coverage are present and tested. |
| 🟡 Partial | 6 grouped areas | The application has GBP-ready editorial planning fields and owner-authorization flags, but no direct Google API connection, location selector, publication record, or external publishing workflow. |
| 🔴 Missing | 5 grouped areas | OAuth callback/token exchange, account/location selection, Local Post client, bilingual publication linkage, idempotent publish controls, and GBP admin controls are not implemented. |
| ⚠️ Blocked | 4 grouped areas | Live integration requires owner-controlled Google Cloud Business Profile API approval, OAuth client/consent configuration, verified listing access, secure credentials, and final external authorization. |

## Requirement-by-Requirement Matrix

| Requirement | Current status | What exists | What changes now | Test/result |
|---|---|---|---|---|
| Preserve current architecture and data | ✅ Complete | React/Vite, Express/tRPC, Drizzle MySQL/TiDB, Manus OAuth, existing CMS and RBAC are active. | No replacement or migration planned. | Existing TypeScript/build/regression baseline remains the reference. |
| Official Google Business Profile API | ⚠️ Blocked | No direct GBP client or GBP connector is configured. | Requires approved Google Cloud project/API access and OAuth credentials. | Official setup docs confirm approval and OAuth are required [1]. |
| Secure OAuth with `business.manage` | 🔴 Missing / owner-dependent | Existing Manus OAuth protects the clinic app, but does not authorize GBP. | Add server-side Google OAuth flow only after client ID/secret and redirect URI are available. | No OAuth callback or token exchange exists; no tokens were requested or exposed. |
| Protected GBP settings area | 🟡 Partial | Protected CMS Manager/settings and role middleware exist. | Add a truthful configuration/connection surface; never show “connected” without API success. | Existing owner/admin boundary is covered by router tests. |
| Account and location selection | 🔴 Missing / blocked | No GBP account/location data source exists. | Implement list-and-select flow; never auto-select if multiple locations exist. | Cannot test until authorized GBP account access exists. |
| Existing owner approval workflow | ✅ Complete | Content calendar has idea/draft/review/scheduled/published states and owner-authorization flags. | Reuse these states; do not bypass approval. | Existing CMS tests verify protected editorial planning. |
| English and Arabic posts linked to one campaign | 🟡 Partial | Calendar supports `en`, `ar`, and `both`; bilingual CMS content exists. | Add separate language publication records linked to one content item. | No Google-specific language records currently exist. |
| Text, CTA, destination URL, media, scheduling | 🟡 Partial | Calendar has topic, CTA, target page, planned date, content brief, and media system. | Add Google-specific validation and preview before API submission. | No Google field validation or Local Post request builder exists. |
| Reuse existing media | ✅ Complete locally / ⚠️ Google validation blocked | CMS mediaItems and S3/proxy storage exist. | Reuse URLs and validate public reachability/Google-supported media before publish. | Existing media upload/proxy tests pass; Google acceptance is unverified. |
| Duplicate-publish protection | 🔴 Missing | Existing CMS save flows do not create GBP post records. | Add unique content/language/location publication key and server-side idempotency. | No GBP duplicate record currently exists. |
| Publication/audit record | 🟡 Partial | `activityLogs` records CMS actions. | Extend/add one GBP publication entity only if schema review confirms no equivalent exists; store no tokens. | No GBP post ID/status record exists. |
| Admin publish controls | 🔴 Missing | CMS Manager can manage content/calendar records but has no GBP publish controls. | Add owner/admin-only preview, publish, schedule, cancel, retry, and details controls. | Cannot exercise real publish until API access exists. |
| Preview | 🟡 Partial | Existing CMS preview/content fields exist. | Add a truthful GBP preview with language, text, media, CTA, destination, schedule, and selected location. | No GBP preview component exists. |
| Scheduling | 🟡 Partial | Heartbeat endpoint and UTC scheduling patterns exist; Riyadh is the clinic timezone. | Reuse the scheduler only after the GBP job contract is defined and API access exists. | No GBP scheduler job or retry queue exists. |
| Error handling | 🟡 Partial | Existing tRPC errors, activity logs, and notifications exist. | Map OAuth, permission, location, media, validation, rate-limit, network, and service errors to safe admin messages. | No GBP error mapping exists. |
| Token/reconnect/disconnect | 🔴 Missing / blocked | No Google token storage/connection entity exists. | Implement secure server-side refresh-token handling and reconnect/disconnect after credentials/API approval. | Cannot test without OAuth configuration. |
| RBAC | ✅ Complete locally / 🟡 GBP controls missing | owner/admin/content_editor/reception/user boundaries exist. | Restrict connect/disconnect/select/publish/schedule/retry/logs to owner/admin; staff remains view/submit only. | Existing role tests pass; GBP-specific controls are not yet present. |
| Audit trail | ✅ Complete locally / 🟡 GBP events missing | `activityLogs` exists and CMS actions are logged. | Log connect, location selection, approval, publish attempt/success/failure, scheduling, cancellation, retry. | No GBP events currently emitted. |
| Security | ✅ Complete baseline / ⚠️ Google setup blocked | Server-side secrets and protected procedures are established. | Never place Google tokens in frontend, URLs, localStorage, CMS, public DB, logs, or analytics. | No Google token path exists to test; baseline secret policy remains intact. |
| No fake integration | ✅ Complete | Existing system does not claim GBP connection or fabricate post IDs. | Keep blocked state truthful until Google confirms success. | No external publication was attempted. |
| Configuration help | 🟡 Partial | Environment documentation and CMS settings exist. | Add exact Google Cloud/API/OAuth/redirect/scope/location prerequisites to the integration help screen. | Official docs provide the requirements [1] [2]. |
| OAuth/content/workflow testing | 🟡 Partial | Broad app regression suite exists. | Add unit/contract tests for callback state, permissions, validation, idempotency, and no-publish behavior; live tests require owner authorization. | Current full baseline is healthy; GBP tests are absent. |
| Regression protection | ✅ Complete baseline | CMS, Arabic/English, media, auth/RBAC, appointments, patients, notifications, and database compatibility are covered. | Run again after any additive GBP change. | No existing workflows were altered during audit. |
| Final deployment/publication | ⚠️ Blocked | Managed hosting and custom domain are active. | Deploy code only after validation; publish externally only after explicit approval of exact post and target location. | Google API production access remains owner-dependent. |

## Safe implementation boundary

The application can safely add a truthful, owner/admin-only GBP setup/help surface, local draft/preview data handling, validation contracts, publication-state tests, and a server-side integration seam without posting externally. Real OAuth, location selection, token exchange, Local Post creation, scheduling, and publication-status confirmation require the owner-controlled Google Cloud/API prerequisites below.

## Owner-controlled prerequisites

The owner must have a Google Cloud project with Business Profile API access approval, the required Business Profile APIs enabled, an OAuth consent configuration, a web OAuth client, the application redirect URI registered, the `https://www.googleapis.com/auth/business.manage` scope approved, and access to the verified clinic Business Profile location. Credentials must be entered through secure environment/secret management and never sent in chat. Google documents that Business Profile APIs have no sandbox; validation-only requests are available only where the endpoint supports them [1].

## References

[1]: https://developers.google.com/my-business/content/basic-setup — Google Business Profile APIs, Basic setup.
[2]: https://developers.google.com/my-business/content/implement-oauth — Google Business Profile OAuth implementation.
[3]: https://developers.google.com/my-business/reference/rest/v4/accounts.locations.localPosts — Google Business Profile Local Posts reference.
