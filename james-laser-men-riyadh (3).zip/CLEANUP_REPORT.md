# In-Project Cleanup and Built-in Database Report

## Scope and outcome

The project was audited using the requested **inspect → verify unused → remove → test** sequence. The active application remains a React/Vite + Express/tRPC + Drizzle clinic application running on the managed Manus/WebDev platform. The sole active persistence layer is the built-in MySQL/TiDB-compatible database accessed through `MYSQL_URL`.

No Cloud Run service, Google Cloud resource, custom domain, DNS record, PostgreSQL database, Cloud SQL instance, external database migration, authentication setting, policy record, staff record, appointment record, patient record, consent record, audit record, or media object was changed.

## Files removed

| Removed file | Verification and reason |
| --- | --- |
| `server/postgresMigration.ts` | Used only by the removed migration-preflight test; no active runtime import. |
| `server/postgresMigration.test.ts` | Covered only the paused PostgreSQL migration helper; no active application dependency. |
| `scripts/postgres-migration-preflight.mjs` | Exposed only a PostgreSQL migration command removed from the package manifest. |
| `scripts/migrate-mysql-to-postgres.mjs` | Performed only an owner-controlled MySQL-to-PostgreSQL copy and was never run. |

No data-bearing file, active schema, consent file, policy file, audit file, authentication file, clinic asset, or operational record was deleted.

## Dependencies and active database contract

The active package manifest no longer contains `pg`, `@types/pg`, `postgres:preflight`, or `postgres:migrate`. The lockfile was regenerated after the manifest change. `mysql2`, Drizzle’s MySQL adapter, the active schema, and all current clinic workflows were retained.

A new regression test, `server/builtinDatabaseContract.test.ts`, verifies that the runtime uses `drizzle-orm/mysql2`, the schema uses `drizzle-orm/mysql-core`, `MYSQL_URL` is part of the active environment contract, and the removed PostgreSQL package/script entries are not reintroduced.

## Built-in database inventory and preservation

A read-only database inventory connected successfully to the managed database and returned 26 active tables. The inventory included `users`, `appointments`, `consultationRequests`, `patients`, `hmsImportBatches`, `consentSignatureSessions`, `clinicSettings`, `homepageSections`, `treatments`, `promotions`, `reviews`, `resultCases`, `guidePosts`, `faqs`, `mediaItems`, `policies`, `seoSettings`, `contentCalendarItems`, `activityLogs`, `notifications`, `enquiries`, `analyticsEvents`, `publicFormSecurityEvents`, `redirects`, `machines`, and the migration ledger. Approximate table counts showed existing records in appointments, requests, patients, policies, promotions, treatments, audit activity, notifications, analytics, and related clinic modules. No write query was executed.

The attachment refers to IPC governance tables such as CAPA, ICRA, surveillance, HESN, incidents, water quality, suppliers, and communicable disease records. Those tables are not part of this project’s current 26-table clinic schema, so they were not invented, seeded, migrated, or represented as present. They remain outside the verified scope and require a separate owner-authorized project/schema decision if they are actually intended for this application.

## Retained legacy and paused artifacts

Historical Cloud Run, Firebase, Cloud SQL, PostgreSQL, WhatsApp, deployment, audit, and pause documents were retained because they record owner decisions and deployment boundaries. They are documentation and do not load as application database adapters. `template.json` was retained because it is scaffold metadata; its embedded historical static template mentions the original `server/index.ts` entrypoint. The legacy `server/index.ts` was therefore retained rather than deleted to avoid making scaffold metadata inconsistent. The active scripts build and run `server/_core/index.ts`.

## Validation

| Check | Result |
| --- | --- |
| TypeScript | Pass: `pnpm check` completed with no errors. |
| Vitest | Pass: 55 test files and 176 tests passed. |
| Production build | Pass: Vite and the bundled server build completed successfully. A non-blocking large-client-chunk warning remains. |
| Health endpoint | Pass: `/healthz` returned HTTP 200 and `{"status":"ok"}`. |
| Readiness endpoint | Pass: `/readyz` returned HTTP 200 and `{"status":"ready"}`. |
| Database contract | Pass: read-only managed-database inventory connected through the built-in database; the production-readiness test confirmed `MYSQL_URL` usage. |
| Public routes | Pass by mobile smoke review for `/` and `/appointment`. |
| Protected clinic routes | Pass by authenticated mobile smoke review for `/admin`, `/admin/patients`, `/admin/appointments`, and `/admin/reminders`. |
| Security and RBAC | Existing protected-route, role-boundary, consent, source, provider, machine, and appointment-separation tests remained passing. |
| Data integrity | Pass for non-destructive cleanup: no inserts, updates, deletes, imports, merges, resets, or migrations were performed. |

## Remaining technical debt and limitations

The managed project contains historical deployment documentation that mentions paused PostgreSQL and Cloud Run paths. These documents are intentionally retained for auditability. The scaffold metadata also contains an embedded historical static template referencing `server/index.ts`; this is not active runtime code but should be updated only as a separate scaffold-maintenance task.

The current schema is a men’s laser clinic schema, not an IPC governance schema. The requested IPC modules and 40-policy inventory cannot be truthfully validated against this project because corresponding tables and records were not present in the inspected database. No attempt was made to create them or to infer their contents.

The production bundle reports a non-blocking client chunk-size warning. The current managed application also retains a warning that the local pnpm configuration keys are deprecated in the installed pnpm version. Neither warning blocked typecheck, tests, build, health checks, or route smoke review.

## Final status

**PASS for the requested in-project cleanup and built-in-database standardization, with the IPC-schema limitation and intentionally retained historical artifacts documented above.** External Cloud Run, Google Cloud, custom-domain/DNS, PostgreSQL, Cloud SQL, and external database work remains paused exactly as instructed.
