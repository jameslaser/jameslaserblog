# Custom-Domain Browser Evidence

Audit baseline: managed application checkpoint `1a5d9e75`.

On 2026-09-03, `https://jameslaserhairremovall.com/` loaded the public James Laser / New Look Clinic homepage over HTTPS. The browser final URL remained the apex hostname. The page exposed the public English/Arabic selector, public treatment/navigation links, appointment request, WhatsApp, map, robots/SEO-linked public content, and no protected portal content.

On 2026-09-03, `https://www.jameslaserhairremovall.com/` also loaded the public homepage over HTTPS. The browser final URL remained the `www` hostname; no redirect to the apex was observed during this browser navigation. Both hosts presented the public site successfully, so canonical-host behavior still requires direct HTTP header and metadata inspection before any DNS recommendation.

No DNS or registrar record was changed. MX/email records were not touched.
