# Google Cloud Project Identification Report

**Scope:** Read-only identification of the existing Google Cloud project, if any, that is already associated with the James Laser application or Google Business Profile.

**Date:** 2026-09-07

**Safety boundary:** No project was selected as the integration target. No API was enabled or disabled. No OAuth credential was created, edited, deleted, or opened for secret values. No billing, IAM, Business Profile, deployment, or application setting was changed. No password, API key, client secret, access token, refresh token, or private key was recorded.

## Evidence standard

A project name alone is weak evidence. Strong evidence requires an existing Business Profile API configuration, an OAuth application clearly associated with the clinic, a Maps/Business Profile application relationship, or a clear clinic-domain relationship. Maps APIs and generic OAuth are medium evidence only when they do not identify the clinic or Business Profile location.

## Candidate comparison

| Project | Evidence observed | Business Profile relevance | Confidence | Recommendation |
|---|---|---|---|---|
| `compelling-pen-393311` — **My Maps Project** | Multiple Maps API keys, a web OAuth client named `Web client 2` created Aug 3, 2026, and service-account metadata with names resembling `james-laser-gmb` and `hms`. The API library search exposed Business Profile Performance API but not the core Local Posts API set. No clinic-domain redirect or location relationship was safely confirmed. | **Medium–high**, because Maps and recent OAuth evidence exists; not strong enough to prove Business Profile ownership or app association. | Medium | Do not select yet. It is the leading candidate for a future owner-confirmed verification step, but needs a safe match to the clinic domain, OAuth redirect URI, and verified location. |
| `wix-managed-11cd9953` — **Wix LASER HAIR REMOVAL** | The API dashboard showed an explicit additional-access error. The project could not be inspected by the signed-in account. The Wix-related name is not sufficient evidence. | **Unknown / blocked**. It may belong to Wix-managed infrastructure rather than the James Laser application. | Low | Do not modify or request access automatically. Treat as Wix-managed or owner-controlled until the owner confirms otherwise. |
| `intense-vault-420023` — **My First Project** | Generic services including Analytics Hub, BigQuery, Cloud Datastore, Cloud Logging, Cloud Monitoring, Cloud SQL, and Cloud Storage. No visible Maps, Business Profile, clinic OAuth, or domain evidence. | Low. | Low | Do not select. |
| `gen-lang-client-0125948820` — **Gemini API** | Generic AI/cloud services, a Generative Language API key, and an `hms-17@...` service account. No visible Business Profile API or web OAuth client. | Low. This appears AI/HMS-related rather than Business Profile-related. | Low–medium | Do not select. |
| `ordinal-avatar-395615` — **My First Project** | Directions, Distance Matrix, Geocoding, Geolocation, Maps Elevation, and Maps Embed APIs were visible. No core Business Profile API or clinic OAuth/domain relationship was identified. | Medium for Maps, low for Business Profile. | Medium | Do not select solely from Maps APIs. |
| `pacific-destiny-431307-r1` — **My First Project** | Generic enabled-services view with no visible Maps, Business Profile, OAuth, clinic-domain, or application evidence. | Low. | Low | Do not select. |

## Result

### OPTION B — No existing project can be confidently identified

No project can safely be selected from the available evidence. `compelling-pen-393311` is the leading candidate because it contains recent web OAuth and multiple Maps credentials, but that remains **insufficient proof** of association with the current James Laser production application or the verified Google Business Profile location. The Wix-named project is not inspectable and must not be modified based on its name.

The next safe step requires owner confirmation of the intended project and a non-secret match, such as the authorized redirect URI for `Web client 2` matching the current clinic application domain, or a verified Business Profile/API configuration visible in that project. Until that evidence is supplied, the process is stopped as required.

## Configuration status

No configuration work has started. API enablement, OAuth client creation, billing changes, IAM changes, Business Profile connection, application deployment, and website code changes remain paused. The application’s existing Google Business Profile integration request is therefore **blocked at project identification**, not completed.

## References

[1]: https://developers.google.com/my-business/content/basic-setup — Google Business Profile APIs: basic setup.
[2]: https://developers.google.com/my-business/content/implement-oauth — Google Business Profile OAuth implementation guidance.
[3]: https://developers.google.com/my-business/reference/rest/v4/accounts.locations.localPosts — Google Business Profile Local Posts API reference.
