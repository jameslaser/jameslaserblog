# Cloud Run and Cloud SQL PostgreSQL Deployment

The approved external deployment path is **GitHub `main` → Cloud Build → Artifact Registry → Cloud Run → Cloud SQL PostgreSQL**. The application remains a full-stack Node service: React/Vite assets build to `dist/public`, while Express/tRPC serves dynamic routes, `/api` endpoints, OAuth callbacks, protected storage, the Meta WhatsApp webhook, health checks, and the SPA fallback.

| Repository file | Cloud Run responsibility |
| --- | --- |
| `Dockerfile.cloudrun` | Produces the locked, multi-stage Node image and runs it as an unprivileged user. |
| `cloudbuild.yaml` | Builds the image and deploys the Cloud Run service with the Cloud SQL socket, dedicated runtime service account, bounded connections, and Secret Manager references. |
| `drizzle-pg/` | Holds the isolated PostgreSQL migration history that is applied through the approved database change process before deployment. |
| `ENVIRONMENT_VARIABLES.md` | Defines variable names and scopes. It contains no secret values. |
| `PHASE1_CLOUD_RUN_DEPLOYMENT.md` | Provides the PostgreSQL and Cloud Run owner setup sequence. |
| `PHASE2_WHATSAPP_DEPLOYMENT.md` | Provides the Meta, Secret Manager, callback verification, template, and controlled-test sequence. |

The checked-in Cloud Build configuration deliberately contains non-secret placeholder substitutions for `_SERVICE_ACCOUNT`, `_CLOUDSQL_INSTANCE`, `_VITE_PUBLIC_SITE_ORIGIN`, `_OAUTH_SERVER_URL`, and `_VITE_APP_ID`. No source-controlled workflow supplies their real values. An authorized owner must configure each substitution directly in the Cloud Build trigger or the approved deployment invocation before a production build is submitted.

Cloud Run is configured as a public web service by disabling the Invoker IAM check with `--no-invoker-iam-check`; application session and tRPC authorization controls remain responsible for protected routes. This avoids the broad `allUsers` IAM binding route that can be blocked by organization policy. [1]

No DNS, custom-domain, billing, IAM, Secret Manager, Cloud SQL, OAuth, Meta, or production-data operation is performed from this repository. Follow the owner-controlled runbooks before connecting a custom domain or activating Meta production.

## Reference

[1]: https://docs.cloud.google.com/run/docs/authenticating/public "Cloud Run — Allowing public (unauthenticated) access"
