# HMS In-Page Workspace

The protected Admin Portal route `/admin/hms` now keeps HMS access inside the page. Staff enter the official HTTPS HMS address, select **Load HMS inside page**, and the provider sign-in/workspace is rendered in an embedded frame. No new tab or `window.open` launcher is used by the HMS workspace.

HMS credentials are entered only into the provider’s own embedded login form. The clinic portal does not collect, submit, persist, or send HMS usernames or passwords to the built-in database or clinic API. The URL is held only in the current page state and is cleared when the workspace is closed or the page is reloaded.

Some HMS providers intentionally send browser security headers such as `X-Frame-Options` or a restrictive Content-Security-Policy that prevents framing. If that happens, the embedded area may be blank or refused. This is a provider-controlled limitation; the clinic portal does not bypass it and does not open a new tab. The provider must support embedded access, or the HMS administrator must provide an approved same-page-compatible endpoint.

The HMS source boundary is unchanged. HMS-imported appointments remain source-controlled, are not edited inside the clinic appointment workflow, and continue to require the protected NR011-attested CSV import process. Only the approved provider identity is accepted by that import workflow; unrelated doctors, test rows, duplicates, and unverified records remain excluded.
