# New Look Clinics Authenticated Interface Redesign

**Release status:** Ready for checkpoint  
**Prepared by:** Manus AI  
**Validation date:** 6 September 2026

## Executive summary

The authenticated clinic administration experience has been redesigned as a premium, mobile-first bilingual medical interface while retaining the existing application architecture, routes, authentication, role enforcement, database contracts, queries, mutations, audit boundaries, HMS workflow, waiting-list workflow, appointment separation, WhatsApp controls, and public/private boundary. The redesign uses the established ivory, ink, copper, and white clinic language rather than introducing a separate product identity.[1]

No database table, migration, backend procedure, external connector, credential, provider configuration, or public-site visual system was changed. Existing protected records were not rewritten or translated. The Arabic layer localizes static interface copy and explicitly excludes names, email addresses, timestamps, machine identities, WhatsApp message bodies, and other record-derived values.[1]

## Delivered interface

| Area | Delivered result |
|---|---|
| Application shell | Collapsible and resizable desktop sidebar, compact sticky header, authorized global search, notification access, public-site access, profile menu, and role-filtered navigation. |
| Mobile navigation | Four primary role-filtered destinations plus **More**, safe-area spacing, 44-pixel interaction targets, and a single-column protected workspace. |
| Localization | Presentation-only English and Arabic control, mirrored RTL shell, Arabic interface labels, isolated LTR phone/email/date/time/number fields, and untranslated protected record content. |
| Navigation hierarchy | Overview, Clinic, Communication, Content, and Management groups while retaining all existing destinations and role filters. |
| Shared components | Page headers, surfaces, metrics, filters, loading states, empty states, error/retry states, status treatments, forms, tables, tabs, and bounded dialogs. |
| Clinic workflows | Dashboard, requests, appointments, HMS workspace, waiting list, patients, machines, revenue, reminders, and attention tasks retain their existing data and actions. |
| Communication | WhatsApp inbox, provider setup, templates, service-window rules, automations, webhook logs, enquiries, and staff notifications retain their protected controls. |
| Content and management | CMS, treatments, promotions, reviews, before/after, guide, calendar, FAQs, media, policies, SEO, language readiness, analytics, backup/export, redirects, activity, users/security, and settings use the unified interface. |

## Preserved safety and governance

The redesign keeps Appointment Requests, finalized Appointments, and the Waiting List as separate workflows. A request cannot enter Appointments without the existing review and transfer process. Waiting and arrival controls remain tied to confirmed appointments and the current Riyadh operational date. The strict HMS provider contract and existing NR011 normalization/rejection tests remain passing. Server-side RBAC remains authoritative; interface visibility is supplementary and was not treated as authorization.[2] [3]

The WhatsApp interface retains its approved-template and 24-hour service-window boundaries. Provider activation remains controlled by the existing owner workflow and server-side configuration. Persisted customer names, numbers, message bodies, and timestamps are protected from presentation localization.[4]

## Verification results

| Verification | Final result |
|---|---:|
| TypeScript | Passed |
| Complete Vitest suite | **68 files passed** |
| Automated tests | **266 passed** |
| Production build | Passed |
| Focused bilingual/responsive suite | **44 tests passed** |
| Targeted auth/RBAC/HMS/W-List/security preservation run | **110 tests passed** |
| Visual evidence | English and Arabic desktop/mobile contact sheets reviewed |

Deterministic tests render the actual appointment calendar, waiting list, machine inventory, appointment settings, notifications, users/security, activity log, SEO, language readiness, media library, and policies under loading, error, empty, and loaded data states. Additional tests verify static Arabic copy, role-filtered mobile navigation, safe-area behavior, touch targets, RTL layout, status/error semantics, and protected-record no-translation attributes.[5] [6]

The final production build emits the existing advisory that the main JavaScript bundle exceeds Vite’s default 500 kB warning threshold. This is not a build failure and does not change runtime behavior. Route-level code splitting remains an optional future performance task; it was intentionally excluded from this UI-only release to avoid an unrelated architectural refactor.

## Visual evidence

The attached desktop and mobile contact sheets show representative authenticated English and Arabic routes. Their dimensions, SHA-256 hashes, route coverage, and screenshot-harness limitations are recorded separately.[7]

| Artifact | Purpose |
|---|---|
| `authenticated-desktop-en-ar.png` | Desktop shell, operational hierarchy, requests, appointments, waiting list, WhatsApp, security, machines, and settings. |
| `authenticated-mobile-en-ar.png` | Mobile header, safe-area navigation, single-column forms/cards, RTL layout, real protected records, and responsive controls. |

## Remaining decisions

No functional blocker remains for this UI-only release. Optional future work may include route-level bundle splitting and deeper editorial review of additional Arabic helper text as clinic terminology evolves. Database content should continue to remain untranslated unless the clinic deliberately stores a reviewed Arabic field; automatic translation of patient, staff, appointment, or message records is not recommended.

## References

[1]: ./ADMIN_DESIGN_SYSTEM.md "Admin Design System"
[2]: ./client/src/pages/AdminPortal.tsx "Authenticated Admin Portal"
[3]: ./server/hmsCsv.test.ts "HMS Provider Boundary Tests"
[4]: ./client/src/pages/WhatsAppWorkspace.tsx "Protected WhatsApp Workspace"
[5]: ./client/src/pages/AdminManagementRuntime.test.ts "Management Runtime State Tests"
[6]: ./client/src/components/AdminBilingualResponsive.test.ts "Bilingual Responsive Evidence Tests"
[7]: ./ADMIN_VISUAL_EVIDENCE.md "Authenticated Visual Evidence"
