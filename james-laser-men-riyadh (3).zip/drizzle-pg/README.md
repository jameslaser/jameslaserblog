# PostgreSQL Migration Workspace

This directory is the **independent PostgreSQL migration history** for the Phase 1 Cloud SQL target. It is intentionally separate from `drizzle/`, which remains the historical applied MySQL/TiDB migration record and must not be altered or reused against PostgreSQL.

`0000_phase1_postgresql_baseline.sql` creates the PostgreSQL enum types, all application tables, identity columns, unique constraints, and the non-cascading foreign keys required for appointment, patient, consent-signature, audit, content-calendar, and HMS import relationships.

Apply this migration only to a new, empty PostgreSQL target. Do not apply it to the existing MySQL/TiDB source, and do not use destructive schema-reset commands. After the baseline is applied, use the dry-run and reconciliation process described in [`../POSTGRESQL_DATA_MIGRATION.md`](../POSTGRESQL_DATA_MIGRATION.md) before any owner-approved data import.

The production application runtime uses `DATABASE_URL` with PostgreSQL. `MYSQL_SOURCE_URL` is used only by the controlled offline migration utility and is never required by the Cloud Run application process.
