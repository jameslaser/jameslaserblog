# Public WhatsApp Page Release Notes

**Release scope.** This release adds a public, bilingual WhatsApp conversion journey for James Laser Hair Removal for Men in Riyadh. It is intentionally separate from the private Meta Cloud API workspace: it uses the existing published click-to-chat destination and does not activate webhooks, automation, templates, bulk messaging, or any external CRM.

## Delivered public experience

| Area | Delivered behavior |
|---|---|
| Public routes | English is available at `/whatsapp` and `/en/whatsapp`; Arabic is available at `/ar/whatsapp`. |
| Contact options | The page offers service questions, prices and offers, availability checks, callback requests, general enquiries, and a private appointment request. |
| Real WhatsApp handoff | All contact options open the visitor’s real WhatsApp application through the clinic’s canonical `wa.me` destination. Message text is generated locally, normalized, and URL encoded. |
| Appointment handoff | Only the appointment form creates a protected request, using the existing `appointmentRequest.create` contract. It remains an unconfirmed request until authorized clinic staff explicitly review and approve it. |
| Privacy and consent | The page identifies the real WhatsApp handoff, asks for consent before user-provided values are placed in a WhatsApp draft, requires appointment and privacy acknowledgements for the private request, and requires the existing original consent documents to be opened before appointment submission. |
| Localization and accessibility | The experience supports English and Arabic, changes the document direction for RTL, preserves correct LTR display for working hours, provides associated labels, keyboard-reachable controls, visible focus states, and no fabricated chat activity, staff availability, testimonials, or response-time claims. Non-appointment handoff controls provide incomplete-form feedback and a polite live status confirmation after launch, with published WhatsApp and telephone fallback actions. |
| Local QR code | A QR code is rendered locally from the clinic’s canonical WhatsApp URL via the installed browser dependency; no QR provider receives visitor data. |
| Navigation and discovery | Relevant public WhatsApp calls to action route to the new page. Localized canonical, Open Graph, description, alternate-language metadata, and sitemap entries are included. A floating launcher appears on public pages but is excluded from the dedicated page, consent-signature flow, and protected admin paths. |

## Protected workflow and data safeguards

The appointment form reuses the existing server-side validation, normalized mobile handling, anti-spam guard, clinic-setting checks, staff notification, protected request queue, and optional conversation linking. It sends the localized source values `whatsapp_page_en` or `whatsapp_page_ar`, preserving traceability without a second persistence model.

Every new public appointment request now writes a non-sensitive activity record tied only to the protected consultation-request identifier. The existing authorized request workspace displays a safe source label, such as **WhatsApp page · English** or **WhatsApp page · Arabic**. No patient record, confirmed appointment, waiting-list entry, or HMS record is created by a public WhatsApp-page action.

> The public page does not offer emergency care or medical triage. It directs visitors with urgent concerns to local emergency services or an emergency department.

## Verification evidence

| Verification | Result |
|---|---|
| TypeScript check | Passed. |
| Focused WhatsApp tests | Passed: 3 files and 11 tests covering URL encoding, localized message generation, route wiring, privacy boundaries, source attribution, and sitemap discovery. |
| Full automated test suite | Passed: 63 test files and 226 tests. |
| Production build | Passed. The bundler retained an existing advisory about a minified client chunk above 500 kB; it did not prevent the build. |
| Desktop visual review | English and Arabic pages were reviewed at 1280 × 900. The hero, QR code, contact cards, selected action panel, privacy notice, emergency notice, and footer rendered correctly. |
| Mobile visual review | English and Arabic pages were reviewed at 375 × 812. The responsive card stack, controls, text hierarchy, and RTL layout rendered correctly. The Arabic working-hours range was corrected to display in LTR order. |

The final public-boundary review covered the route registry, production sitemap, public launcher exclusions, source-level privacy assertions, and recent browser/network diagnostic records. The public WhatsApp page does not request protected Admin routes or use any private Meta API credentials in the browser.

Each enabled non-appointment contact action now includes dedicated **Open WhatsApp again** and, where a clinic telephone is configured, **Call the clinic** fallback controls. A live-browser review confirmed the rendered service-question control exposes its encoded `wa.me` URL and both fallbacks. The canonical `wa.me` destination was checked with a header-only request and redirected to WhatsApp’s official send endpoint without sending a message or submitting visitor data.

## Operational boundary

The private WhatsApp Cloud API workflow remains unconfigured in this runtime because its required server-side Meta values are not present. This release is therefore ready for public click-to-chat and secure appointment-request conversion, but does not represent activation of provider-side WhatsApp Business messaging.
