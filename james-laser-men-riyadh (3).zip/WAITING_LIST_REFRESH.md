# Waiting List Refresh Verification

## Scope

This change adds only a guarded fallback refresh to the existing protected Waiting List query. It does not rebuild the Waiting List, change HMS integration, change appointment or patient workflows, alter NR011 filtering, change source separation, or write clinic records.

## Implementation

The existing `trpc.admin.waitingList.useQuery({ date })` call now uses React Query's built-in options:

- `refetchInterval: canUpdateAttendance ? 5000 : false` keeps the live five-second fallback limited to the current Riyadh date.
- `refetchIntervalInBackground: false` pauses polling while the browser tab is backgrounded.
- `staleTime: 0` keeps the queue eligible for fresh data on the existing query lifecycle.
- No new library, WebSocket, external service, `setInterval`, or `setTimeout` was introduced.
- React Query owns one observer interval and cleans it up when the Waiting List component is unmounted or the selected date changes.

The existing server query, appointment-date validation, NR011 provider/source rules, loading state, error state, and read-only historical-date behavior remain unchanged.

## Validation Evidence

The focused Waiting List workflow test passed with five tests, including the exact five-second today-only fallback contract, background pause, and absence of manually-created timers. The full suite passed with 60 test files and 209 tests. TypeScript validation passed, the production build passed, and `/healthz` and `/readyz` each returned HTTP 200 after a fresh managed-service restart.

The attempted protected browser review could not open because the temporary browser window was unavailable; no form was submitted and no clinic record was changed. The runtime/network scan contained verbose historical public-page payloads but no identified Waiting List refresh failure. A production bundle-size warning remains non-blocking and unrelated to this minimal change.

## Files Changed

- `client/src/pages/AdminPortal.tsx`: existing Waiting List query options only.
- `server/waitingListWorkflow.test.ts`: focused refresh regression assertions.
- `WAITING_LIST_REFRESH.md`: this verification record.
- `todo.md`: checklist history.
