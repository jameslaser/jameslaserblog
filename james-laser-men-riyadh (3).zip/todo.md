# Project TODO

- [x] Define the data model and secure public procedure for consultation requests.
- [x] Build the premium, responsive public homepage for James Laser Hair Removal for Men Riyadh.
- [x] Add a branded header, hero, benefits, treatment process, education, and request-form sections.
- [x] Use the uploaded clinical images with accessible alternatives and polished responsive crop behavior.
- [x] Build the accessible, validated consultation request form with submitted-state feedback.
- [x] Add focused unit tests for request validation and submission.
- [x] Verify desktop and mobile presentation, build health, and request-form behavior.
- [x] Save a final checkpoint with all completed work tracked.
- [x] Extend the consultation request data model with identity, scheduling, treatment, and clinical-screening fields.
- [x] Add conditional clinical questions for previous treatment, medication, supplements, tanning, Moroccan bath, skin treatments, and severe sun exposure.
- [x] Add the requested nationality, preferred date/time, and expanded treatment-area choices including mini full body and full body.
- [x] Create a consent-read gate that prevents submission until the user-provided consent text has been reviewed and accepted.
- [x] Test all required fields, conditional screening branches, and the consent gate before saving a new checkpoint.
- [x] Receive and add the clinic consent document or final consent wording to activate form submissions.
- [x] Extract and consolidate all information from the three uploaded clinic documents into one clear consent and intake file.
- [x] Add a dedicated client and clinic signature panel to the consolidated document.
- [x] Integrate the reviewed consent wording into the request form and activate the consent-read gate.
- [x] Verify the combined document and request-form consent flow before releasing the update.
- [x] Save the updated consent document and active request flow as a release checkpoint.
- [x] Audit and improve title, description, canonical URL, local SEO copy, and social sharing metadata for the public homepage.
- [x] Add valid local business and service structured data for James Laser in Riyadh.
- [x] Add crawl directives and sitemap support for public search indexing.
- [x] Validate the rendered metadata, structured data, and production build before publishing the SEO update.
- [x] Save the public-homepage SEO improvements as a release checkpoint.
- [x] Inventory all uploaded images and videos, remove duplicates, and select suitable original assets for the public homepage.
- [x] Upload the selected media to durable project storage with accessible descriptions and responsive delivery URLs.
- [x] Integrate the curated media into the public homepage without altering the validated consultation request flow or SEO content.
- [x] Verify the image and video presentation on desktop and mobile, then save the media update as a release checkpoint.
- [x] Save the original-media homepage update as a release checkpoint.
- [x] Audit the current public homepage for visual quality, media presentation, local SEO, and client request readiness.
- [x] Deliver prioritized recommendations for any remaining high-impact homepage improvements.
- [x] Replace public homepage image and video filenames with accurate, search-friendly descriptive names.
- [x] Update media references, validate delivery and rendering, and save the filename update as a release checkpoint.
- [x] Add Arabic titles and captions to every homepage image and video, with accurate Riyadh-focused descriptions.
- [x] Verify bilingual media captions across desktop and mobile, then save the Arabic media update as a release checkpoint.
- [x] Save the Arabic media caption update as a release checkpoint.
- [x] Define protected request-to-appointment workflow rules that keep pending requests separate from approved appointments.
- [x] Extend the schema and protected server procedures for admin-only request approval, cancellation, deletion, and appointment records.
- [x] Build a secure admin dashboard with linked patient-request and appointments pages using the existing dashboard layout.
- [x] Add approved-request movement into appointments and show patient name, phone, date, time, treatment area, and machine on each appointment.
- [x] Test admin authorization, request actions, data separation, and responsive portal presentation before saving a release checkpoint.
- [x] Save the secure admin portal as a release checkpoint.
- [x] Define protected today-waiting-list rules that keep pending requests separate from confirmed appointment records.
- [x] Add admin-only arrived and not-arrived status actions for today’s confirmed appointments.
- [x] Build a linked Waiting List page that displays today’s appointment queue with clear check and X controls beside each patient.
- [x] Test the status updates, today-only filtering, role protection, and responsive Waiting List presentation before releasing the update.
- [x] Save the secure Waiting List update as a release checkpoint.
- [x] Define one-patient-per-file rules and preserve only approved patient records with their relevant intake details.
- [x] Add protected patient-record persistence and search procedures with duplicate protection by WhatsApp number.
- [x] Build a linked Patients page with search and a complete patient-detail view for owner review.
- [x] Test patient creation, search, authorization, duplicate protection, and responsive presentation before saving the patient-record release.
- [x] Save the Waiting List and patient-record release as a combined checkpoint.
- [x] Add protected editable appointment fields to patient requests: manual MRN, appointment date/time, machine, treatment area, and session or retouch type.
- [x] Persist approved appointment details and patient records with strict allowed machine and visit-type validation.
- [x] Build editable controls in the patient-request page before the approval action.
- [x] Test protected editing, approval persistence, validation, and responsive request-review presentation before saving the release.
- [x] Save the editable patient-request approval workflow as a release checkpoint.
- [x] Define a protected machine inventory with one manual machine ID number per allowed clinic machine.
- [x] Add machine inventory persistence and replace editable treatment-area options with the specified clinic list.
- [x] Build a linked Machines page with manual ID editing and revised patient-request treatment-area controls.
- [x] Test machine ID validation, treatment-area validation, authorization, and responsive presentation before saving the release.
- [x] Save the Machines page and treatment-area update as a release checkpoint.
- [x] Define and migrate the secure CMS data model for central clinic settings, homepage sections, treatments, promotions, reviews, results, guide posts, FAQ, media, policies, SEO, and audit activity.
- [x] Expand owner/admin/content-editor/reception permissions while keeping patient and administrative data private.
- [x] Build mobile-friendly admin management pages for clinic information, website content, treatments, promotions, reviews, before-and-after cases, guide posts, FAQs, media, policies, SEO, activity, notifications, and settings.
- [x] Add draft, preview, and publish controls that only expose approved public content and never fabricate reviews, prices, promotions, or clinical outcomes.
- [x] Connect managed clinic details and approved content to the existing public homepage without rebuilding its visual design or auto-confirming appointments.
- [x] Verify public/admin data boundaries, route protection, content lifecycle, mobile layouts, and core management workflows before saving the CMS release.
- [x] Add a separate, protected enquiry inbox with server-side validation, status workflow, and internal notes.
- [x] Add privacy-conscious first-party event aggregation and an owner/admin Analytics workspace without visitor identity storage.
- [x] Add owner/admin Data & Backup exports for appropriate records and guidance to the supported platform backup mechanism.
- [x] Add protected 301 redirect management with loop prevention and server-side enforcement.
- [x] Harden public forms with backend rate limits, honeypot checks, duplicate-submission protection, input sanitization, and retained secure media limits.
- [x] Verify all new public/private boundaries, routes, exports, redirects, form protections, desktop/mobile management workflows, and release build.
- [x] Add and test a real trusted-signal public-form throttle that also rejects varied repeat submissions.
- [x] Document and test server-side text normalization plus CMS media upload size/type limits.
- [x] Exercise CSV export and 301 redirect behavior end to end, then review every new admin route on mobile.
- [x] Add a hidden honeypot and server rejection path to the public consultation-request workflow, with regression coverage.
- [x] Add browser-equivalent download integration coverage for the protected CSV export action.
- [x] With owner confirmation, exercise one protected live CSV export from Data & Backup without retaining or sharing any downloaded clinic data.
- [x] Create, verify, and remove a temporary protected 301 redirect without changing customer or patient data.
- [x] Repair the AdminPortal reload regression caused by a missing Download icon import and operations-page type narrowing.
- [x] Audit every final specification phase against the live persisted implementation and record satisfied versus missing requirements.
- [x] Expand the appointment-request lifecycle with protected contacted, clarification, rejected, transferred, completed, and internal-note actions while preserving approval-to-confirmed-appointment separation.
- [x] Upgrade the dashboard with real CMS and operational metrics plus linked quick actions.
- [x] Complete remaining connected administration controls for media search/rename/copy URL, promotion duplication, treatment ordering/archive, settings, notifications, and activity reporting.
- [x] Complete safe bilingual/RTL presentation and SEO route controls without inventing Arabic content or exposing private data.
- [x] Validate the non-production public-to-private-admin contract using owner-approved clinic configuration and document owner input needed for an optional genuine live workflow exercise.
- [x] Audit the existing consultation request workflow against the new bilingual public appointment-request specification.
- [x] Extend request persistence with normalized mobile, stable public request ID, visit type, selected treatment areas, prior laser, operational consent, marketing consent, source, and language fields.
- [x] Build mobile-first English and Arabic appointment request routes with accessible 15-minute preference times, grouped multi-area choices, natural RTL copy, and availability-only confirmation.
- [x] Connect appointment-page requests securely to the private Admin → Patient Requests workflow with internal notes kept private and editable WhatsApp follow-up links.
- [x] Validate English/Arabic form errors, public privacy boundaries, duplicate protection, confirmation behavior, mobile layout, and protected admin visibility without creating patient records.
- [x] Add a requirement-by-requirement audit artifact for the bilingual appointment-request specification and retain its documented search-metadata limitation.
- [x] Provide localized retry and WhatsApp fallback actions after appointment-form submission failure.
- [x] Exercise English and Arabic confirmation and recovery views in a non-production test harness without creating a request record.
- [x] Verify localized invalid mobile/date/time responses and confirm form-state recovery does not clear entered data after a failed request.
- [x] Add a non-production client/component test for English and Arabic appointment confirmation views without creating a request record.
- [x] Add a non-production client/component test for English and Arabic failure recovery, including Retry and WhatsApp actions.
- [x] Assert localized English and Arabic invalid mobile, date, and time responses through the public contract.
- [x] Add a client-level form-state-retention check for failed appointment submission behavior.
- [x] Surface localized invalid mobile, date, and time errors in the client recovery UI.
- [x] Render field-specific localized invalid mobile, date, and time errors in English and Arabic within the non-production component test harness.
- [x] Mount the appointment form in a non-production test and verify entered values persist after a failed submission.
- [x] Add client-side route metadata for appointment and policy pages while documenting the SSR/crawler limitation.
- [x] Add Arabic-aware public policy routes that render only available published Arabic policy content and fall back transparently when it is absent.
- [x] Record a safe non-production public-request-to-private-admin contract validation and the owner input required for an optional live workflow exercise.
- [x] Audit and restructure the secure Admin Portal navigation into the requested role-aware clinic-management information architecture.
- [x] Upgrade the desktop/mobile sidebar, sticky header, account menu, and public-site preview affordances without weakening authentication or authorization.
- [x] Improve the dashboard with attention-focused request data, recent request handling, quick actions, concise activity, and accessible status badges.
- [x] Rework appointment request review into responsive desktop and mobile workflows with search, filters, compact actions, privacy-safe details, and staff-visible audit context.
- [x] Enhance connected CMS, media, promotion, guide, FAQ, analytics, notification, settings, and activity interfaces with practical mobile-first controls and safe empty/error states.
- [x] Add a role-aware global admin search that never exposes protected records outside the current user’s permissions.
- [x] Validate authenticated desktop and iPhone navigation, role restrictions, connected interactions, and public/private data boundaries against the new UI/UX specification.
- [x] Correct the mobile media-library upload control overflow observed during authenticated portal review.
- [x] Add explicit loading, error, and empty states to the remaining connected CMS workspaces and their catalogue/education subpages.
- [x] Revalidate CMS, media, analytics, notifications, settings, and activity workspaces on desktop and iPhone after state-handling improvements.
- [x] Add explicit loading and empty states to the moderated Reviews workspace.
- [x] Add explicit loading and empty states to the consent-controlled Before & After result-case workspace.
- [x] Add an explicit empty-state fallback to the owner-only Users & Security workspace.
- [x] Re-run desktop and iPhone validation after the final CMS state-handling changes for notifications, settings/clinic, activity, analytics, media, and key CMS editors.
- [x] Re-run desktop validation after the CMS state-handling changes for treatments, promotions, guide, FAQs, and security.
- [x] Add CMS-driven public English and Arabic website routes for treatments, offers, results, FAQ, and Men’s Laser Guide using only published/approved content.
- [x] Add public navigation and localized browser metadata/hreflang controls for the new CMS-driven content routes without exposing drafts or private CMS data.
- [x] Add persistent protected notification-inbox records with unread/read/mark-all-read controls, generated only from appropriate admin workflow events.
- [x] Expand secure clinic settings for available request days, treatment choices, visit-type options, and default language while preserving the existing no-availability-confirmation rule.
- [x] Add practical protected appointment-request filters for visit type, language, preferred-date range, and treatment without exposing request data publicly.
- [x] Add a focused master-spec audit that distinguishes completed persistent functionality, newly implemented functionality, and owner-dependent external setup.
- [x] Validate the new public-to-CMS publication loop, notification permissions, appointment filters, desktop/mobile routes, and public/private data boundaries without creating artificial customer or patient records.
- [x] Correct the mixed-direction Riyadh working-hours label on Arabic public CMS content pages after mobile review.
- [x] Implement a visible, semantically readable Arabic working-hours presentation sourced from the central clinic setting.
- [x] Re-run type checks, full regression tests, production build, and targeted mobile validation after the final Arabic public-content hours change.
- [x] Audit live public routes, navigation, localization, media, links, policies, metadata, sitemap, robots, and responsive presentation.
- [x] Audit protected authentication, logged-out boundaries, roles, dashboard data contracts, notifications, activity, analytics, and export boundaries.
- [x] Audit public appointment validation and privacy with non-production contracts, without inserting a fabricated customer or patient record.
- [x] Audit CMS publication, content lifecycle, media validation, and published-only public visibility without creating fabricated public content.
- [x] Fix any verified in-project defects discovered during the final production audit and add regression coverage where appropriate.
- [x] Complete final desktop/mobile, type, test, build, and clean-runtime checks; publish the audited release with PASS/attention status.
- [x] Repair the verified live `/ar` public homepage 404 so Arabic language links have a functioning route.
- [x] Add an explicit robots crawl restriction for protected `/admin` routes identified during the live SEO audit.
- [x] Add regression coverage to prevent the repaired public `/ar` and `/en` landing routes from disappearing from the route registry.
- [x] Expand the static sitemap to include indexable public English and Arabic routes while continuing to exclude protected admin paths.
- [x] Deploy and verify the expanded sitemap on the live production domain before closing the audit release.

# Custom-Domain Launch Specification

- [x] Audit current custom-domain DNS and hosting state without changing records or guessing provider values.
- [x] Replace temporary Manus-domain SEO references with environment-safe final-domain configuration where appropriate.
- [x] Update sitemap and robots.txt to use the final production domain while excluding protected and private routes.
- [x] Verify admin noindex/private boundaries, authentication origin handling, and secure error behavior for custom-domain launch.
- [x] Audit public route links, metadata, structured data, social tags, media URLs, favicon/branding, and responsive performance for launch.
- [x] Verify custom-domain readiness and document exact DNS/SSL changes only if Manus supplies them; do not change DNS blindly.
- [x] Validate final launch route matrix and complete an evidence-based production report with owner-dependent actions clearly separated.
- [x] Re-run type checks, tests, production build, and responsive checks after launch-focused changes.

# GitHub External Deployment

- [x] Inspect the existing GitHub repository, full-stack runtime, external dependencies, and provider compatibility without duplicating the application.
- [x] Add secure external-host deployment configuration, SPA routing, and environment-variable documentation without committing secrets.
- [x] Validate the external-host build and existing public/admin/API/storage contracts locally.
- [x] Prepare an external-host deployment handoff with provider-generated DNS requirements and no changes to email-related records.
- [ ] Verify the external deployment and custom-domain route matrix after the owner authorizes the selected provider and DNS updates.
- [x] Complete the GitHub production-readiness audit for all existing public, appointment, CMS, and protected admin modules without introducing duplicate systems or fabricated records.
- [x] Add GitHub Actions continuous validation for type checks, tests, and the production build on the external-host deployment branch and pull request.
- [x] Fix the GitHub Actions workflow so pnpm is available before the cache-dependent Node setup step and verify the remote run passes.
- [x] Retire the Railway-screen review because the owner selected the Google Cloud deployment path instead; no Railway configuration was applied.
- [x] Retire Railway preview verification because the owner selected the Google Cloud deployment path instead; no Railway deployment was created.
- [x] Standardize the external-production database environment contract on `MYSQL_URL` and update runtime, documentation, tests, and Railway guidance without exposing a connection value.
- [x] Fix the production-readiness integration test process-shadowing defect and rerun secure database validation.

# Superseded alternative-platform compatibility assessment

- [x] Assess the now-retired alternative managed-service path against the existing Express, tRPC, Drizzle/MySQL, Manus OAuth, and Forge storage architecture.
- [x] Define an owner-approved, non-destructive alternative-platform assessment that preserves existing appointment, CMS, protected-admin, and data-privacy contracts.

# Superseded legacy hosting planning record

- [x] Audit the existing production server and build output for the superseded legacy hosting path without changing application architecture.
- [x] Add non-secret Docker, legacy rewrite, Cloud Build, and deployment documentation files for the existing GitHub main branch.
- [ ] Validate the container build, health endpoint, direct Cloud Run configuration, and direct-route production behavior locally.
- [ ] Guide the owner through Google Cloud authorization, billing, Secret Manager, and temporary preview deployment without changing DNS.
- [ ] Verify the temporary direct Cloud Run deployment’s health, public/admin/API/OAuth/storage/database contracts before custom-domain work.
- [ ] Review the owner-provided Cloud Run Build configuration screen and provide exact non-secret selections for the merged GitHub main branch.

# Final CMS Content Population

- [x] Map the complete owner-provided English and Arabic content specification to existing CMS schemas and public-page components without redesigning the architecture.
- [x] Populate verified bilingual homepage, treatment, guide, FAQ, policy, and contact content with conservative clinical wording and approved publication states.
- [x] Save the supplied promotions as drafts unless their active status is explicitly confirmed by an authorized administrator.
- [x] Preserve empty-state behavior for reviews, results, and other user-generated content unless real approved records are supplied.
- [x] Validate public English/Arabic pages, CMS visibility boundaries, SEO metadata, WhatsApp contact links, and mobile presentation after content population.
- [x] Expose published treatment preparation/aftercare and guide-post educational content within the existing public CMS cards without adding a new site architecture.
- [x] Add the owner-provided New Look Clinic address, hours, phone, and WhatsApp conversion link to the existing public footer.

# Google Search Console, Business Profile, and Local SEO Launch

- [x] Review the full owner-provided Google Search Console, Google Business Profile, local SEO, schema, and search-reporting launch specification.
- [x] Audit the current production-domain indexability, robots, sitemap, canonicals, hreflang, structured data, local business consistency, and public content coverage.
- [x] Implement only verified in-project local SEO, sitemap, structured-data, Search Console reporting, and local-content improvements without keyword stuffing or false claims.
- [x] Prepare the owner-authorized Google Search Console verification and sitemap-submission steps using only Google-provided values.
- [x] Prepare Google Business Profile website, appointment, description, services, hours, photo, review-response, and category guidance without creating or misrepresenting a listing.
- [x] Validate production/public local SEO artifacts and report audited PASS/attention status with external account actions separated clearly.
- [x] Add a verified public location action for New Look Clinic without guessing coordinates or creating a duplicate location page.
- [x] Refine public structured data to a verified LocalBusiness profile with consistent name, address, telephone, and no invented ratings, coordinates, or day-by-day hours.
- [x] Audit the current admin SEO workspace and add only the requested configuration-derived SEO overview indicators that do not fabricate Google metrics.
- [x] Keep the sitemap restricted to existing indexable public routes; do not list guide or treatment detail URLs until they have real public routes.
- [x] Align the Firebase deployment configuration regression test with the current public Cloud Run access flag and rerun the full validation suite.
- [x] Replace public policy route canonicals that inherit the runtime host with configured production-domain URLs and add regression coverage.

# 90-Day SEO, Blog, Google Business, and Content Growth Plan

- [x] Map the owner-provided 90-day growth plan to the existing CMS, guide, analytics, and approval controls without fabricating performance or external actions.
- [x] Add protected editorial-calendar persistence and owner/admin/content-editor contracts with reviewable non-publishing statuses.
- [x] Create the owner-supplied 12-week article, GBP-ready, and social-repurposing plan as internal calendar records that require editorial review before publication.
- [x] Build a mobile-friendly Admin Content Calendar with date, content type, topic, language, intent, CTA, target page, and lifecycle controls.
- [x] Add data-boundary, authorization, calendar, and build regression coverage; validate the protected workspace on desktop and mobile.
- [x] Record the external Google Search Console, Google Business Profile, social publication, and performance-reporting actions that remain owner-authorized and unperformed.
- [x] Correct the editorial-calendar validation declaration order and re-run type checks before continuing implementation.
- [x] Correct the focused Content Calendar external-action safeguard assertion and rerun the workspace regression checks.

# GitHub Repository Completion and Safe Review

- [x] Inspect the connected GitHub repository identity, default branch, current worktree state, README, package scripts, environment documentation, architecture, deployment files, and CI without overwriting remote work.
- [x] Produce a factual repository gap matrix covering existing public, bilingual, appointment, CMS, admin, backend, database, authentication, storage, SEO, analytics, security, and deployment modules.
- [x] Compare the requested production checklist against the existing implementation and resolve only verified in-project gaps without duplicating established systems or fabricating data.
- [x] Audit README, environment-variable documentation, gitignore, routes, imports, and GitHub Actions; add only necessary maintenance documentation or corrections.
- [x] Validate the completed repository with supported type checks, tests, build, public/protected route checks, and responsive bilingual review.
- [x] Commit and push reviewed changes to a dedicated GitHub development branch without force-pushing or merging into the production branch automatically.
- [x] Prepare a transparent GitHub handoff that distinguishes completed repository work from owner-authorized Firebase, DNS, Google, OAuth, storage, and external verification tasks.
- [x] Correct the repository setup documentation so it does not reference an unavailable tracked environment template and instead uses the approved non-secret variable guide.
- [x] Replace the generic 404 view with a branded bilingual recovery page offering Home, Treatments, Request Appointment, and WhatsApp actions without exposing private routes.
- [x] Localize the remaining 404 status and recovery-panel labels for Arabic RTL presentation after mobile review.

# Original Consent Document Workflow

- [x] Inventory the newly supplied and existing consent-related original files without deleting, merging, rewriting, or replacing any file.
- [x] Identify the authoritative original appointment consent and verify its pages, signature requirement, version/reference, and display constraints from the source document.
- [x] Preserve the exact original consent as the customer-facing document and store a secure immutable reference/version without generating replacement wording.
- [x] Extend appointment-request persistence with original-consent reference, acknowledgement timestamp, selected language, and secure signature-status/reference fields while keeping requests separate from confirmed appointments.
- [x] Add bilingual View Consent Form and Open Full Consent controls, plus a required opened-and-read acknowledgement, without treating it as a substitute for any original signature requirement.
- [x] Add protected admin visibility for consent completion, original document, version/reference, acknowledgement timestamp, and signature status/reference using the same authoritative file.
- [x] Validate original-file preservation, public and protected data boundaries, request lifecycle separation, responsive document access, and regression coverage without creating customer or patient records.
- [x] Record any owner decision required for the original signature method or approved durable original-file storage before activating a live signing workflow.
- [x] Treat `FILENO3(1).pdf`, `NewLookDentalandDermatologyClinicsComplex3(1).pdf`, and `CLINICPOLICYAGREEMENT3(1).pdf` as one required original consent set that customers must be able to open and read before acknowledgement.
- [x] Require an explicit customer selection for each original consent file; do not count an automatically loaded document as opened.
- [x] Resolve the original-consent appointment-page TypeScript error and rerun focused checks before broader validation.
- [x] Narrow the protected original-consent source regression so it tests for direct browser networking without rejecting the existing query-cache refetch helper.
- [x] Replace the blank embedded-PDF region observed in visual review with a robust explicit opening flow that preserves all three exact original documents.
- [x] Update the appointment recovery interaction fixtures to explicitly open all three original documents before exercising the submission-error path.
- [x] Correct the recovery fixture selector to target the explicit consent document links rather than buttons.

# Approved E-Signature Foundation

- [x] Define the approved e-signature workflow boundaries so all original PDFs remain immutable and signed derivatives never replace source files.
- [x] Add a private consent-signature session model with expiry, request binding, consent-set reference, source hashes, lifecycle status, and signed-derivative storage reference.
- [x] Add protected staff controls to create, revoke, and review signature sessions for pending appointment requests without confirming appointments or creating patient records.
- [x] Add a customer-facing signing route that validates a private session token and displays the exact original consent set before signature capture.
- [x] Store signed-derivative references and audit metadata securely; do not fabricate, create, or retain any test signature.
- [x] Add protected admin visibility for e-signature session state, signed-derivative reference, and audit timestamps on the same appointment request.
- [x] Validate authorization, expiry, request-versus-appointment separation, original-file preservation, responsive signing access, and regression coverage without customer data.
- [x] Document any remaining provider selection, external legal, identity-verification, retention, or production signature-service decision before live activation.
- [x] Harden signed-evidence access so staff obtain a short-lived authorized download URL from the stored derivative key instead of receiving a stored public-style URL.

# Required Appointment Request and Transfer Workflow

- [x] Audit the public request, Patient Requests review, approval/transfer, Appointments page, consent, signature, and original-request reference behavior against the owner-required production sequence.
- [x] Add additive finalized-appointment fields for selected treatment areas, internal notes, assigned staff/provider, duration, original request reference, and carried consent/signature references without overwriting the public submission.
- [x] Change approved-transfer persistence so an explicit admin action creates a linked appointment only after validating active request status, required final details, duplicate mobile/time conflicts, and machine availability.
- [x] Change transferred request status and protected UI language to make Patient Requests → explicit approved transfer → Appointments separation visible and unambiguous.
- [x] Add private admin editing for permitted finalized appointment details before transfer while retaining the original public request values and audit trail.
- [x] Enhance the protected Appointments presentation with source request ID, finalized treatment areas, MRN, contact, notes, consent/signature continuity, and allowed appointment statuses only.
- [x] Add regression coverage for the required workflow, request persistence, protected transfer authorization, duplicate/machine conflict prevention, consent continuity, and no public auto-appointment creation.
- [x] Validate desktop/mobile public and protected routes, database migration, request-versus-appointment separation, and full build without creating customer or patient test records.
- [x] Update protected request-review draft types and transfer submissions to satisfy the expanded finalized appointment contract.
- [x] Align the compiled legacy request-review fallback with the validated finalized appointment transfer contract and remove its status-only transfer control.
- [x] Remove the residual legacy status-only transfer control so no compiled request-review path can suggest transfer without validated appointment creation.
- [x] Block server-side status-only transfer updates so only the validated appointment-creation procedure can mark a request transferred.
- [x] Align the protected dashboard’s transferred-request aggregate and label with the new explicit appointment transfer status.

# Final Appointment Workflow Completion Audit

- [x] Audit every compiled request-review path for residual status-only transfer controls and remove any path that could suggest transfer without linked appointment creation.
- [x] Verify final request-to-appointment linkage, consent/signature continuity, status safeguards, and clean runtime behavior without altering clinic operational records.
- [x] Complete final type, regression, production-build, desktop, and mobile checks for the required public request → Patient Requests → explicit transfer → Appointments workflow.

# HMS CSV Appointment Import

- [x] Locate and inspect the owner-supplied `Report.csv` to confirm the exact headers, UTF-8 encoding, delimiter, date/time values, row behavior, and source-data edge cases without importing records.
- [x] Extend the existing appointment model with additive HMS source fields, raw/original CSV values, normalized scheduling/search values, source row number, and import batch reference while keeping public-request linkage nullable for HMS rows.
- [x] Build server-side CSV parsing and validation for the exact supplied HMS headers, DD/MM/YYYY dates, 12-hour times, MRN zero handling, Arabic/mixed names, raw telephone preservation, and complete remarks preservation.
- [x] Add protected Admin → Appointments upload, parse, reviewable preview, validation summary, and explicit import controls without automatic saving on file selection.
- [x] Add explicit duplicate prevention and import batch audit controls that keep HMS rows separate from Patient Requests and never overwrite a manually finalized appointment.
- [x] Display imported HMS appointments within the normal protected Appointments page with source, import metadata, original remarks, and stored scheduling data.
- [x] Add parser, authorization, source-preservation, duplicate, preview, and UI regression coverage using non-persistent fixtures; do not import the real owner CSV without explicit final authorization.
- [x] Validate protected desktop/mobile import presentation, schema migration, type checks, full tests, build, and health endpoints without creating or changing operational appointment records.

# Manual Admin Patient and Appointment Entry

- [x] Add an owner/admin-only Add Patient action with manual MRN, patient identity/contact details, nationality, treatment area, and private notes, without creating a public request or appointment automatically.
- [x] Add an owner/admin-only Add Appointment action with manual MRN, identity/contact details, date, 1:00 PM–10:00 PM time choices, treatment-area and machine dropdowns, session/retouch type, notes, duplicate checks, and a confirmed appointment record.
- [x] Build responsive admin forms, validate authorization and data separation, run full regression/visual checks, and checkpoint the update without creating test operational records.

# Current-Code Full Application Audit and Verified Fixes

- [x] Inventory the current `main`-equivalent project worktree, package scripts, deployment artifacts, migrations, routes, assets, tests, and environment documentation without relying on prior completion claims.
- [x] Audit public routes, the single production appointment-request path, clinical-data unknown-state handling, original consent, e-signature, and public-versus-private storage access.
- [x] Audit protected requests, validated transfer, appointments, manual patient/appointment entry, waiting list, machines, CMS, SEO, analytics, security, backup, and administrative authorization boundaries.
- [x] Fix only verified in-project defects, including any backend enforcement or regression coverage required for safety and data integrity; do not fabricate operational or clinical records.
- [x] Re-run route, type, test, build, direct-runtime, responsive, and security checks; create an evidence-based PASS/attention report that separates owner-authorized Firebase, Google, DNS, OAuth, and live-data actions.

# Owner-Authorized Integration Preparation

- [x] Add a no-credential PWA web-app manifest and mobile-install metadata, then validate that it does not alter private clinical-data behavior or introduce offline caching of protected routes.
- [x] Prepare a documented, non-sending Meta WhatsApp Business integration boundary with exact credential and webhook requirements; do not activate delivery, webhooks, or automated messages without owner authorization and valid Meta credentials.

# Owner-Authorized Temporary Firebase and Cloud Run Deployment

- [ ] Confirm the selected Google Cloud project, billing state, Cloud Run API access, and repository connection without creating a service or changing DNS.
- [ ] Review the GitHub repository build configuration for the temporary Cloud Run service, including the existing Cloud Build and health-check artifacts, before deployment.
- [ ] Collect and validate owner-approved Secret Manager/runtime configuration and OAuth callback requirements without exposing secret values.
- [ ] Create only after explicit final confirmation, then test a temporary direct Cloud Run service without migrating records or connecting the custom domain.

# Cloud Run-Only and Cloud SQL PostgreSQL Migration

- [x] Record the owner-directed pause of all Cloud Run, Google Billing, external deployment, Cloud SQL/PostgreSQL migration, database cutover, DNS, and domain work while preserving the current managed platform and existing data.

- [x] Inventory every Firebase reference, hosting rewrite, deployment document, package, script, and environment instruction; classify each as remove, replace, or unused without disrupting the current runnable application.
- [x] Audit MySQL/TiDB-specific Drizzle schema, migrations, database helpers, driver dependencies, generated SQL, queries, transactions, upserts, and ID assumptions; publish a reversible PostgreSQL conversion and data-migration plan before changing the active database.
- [ ] Remove obsolete Firebase production architecture references only after Cloud Run-only full-stack delivery artifacts are verified, while preserving direct-route SPA fallback, API routing, OAuth, health/readiness endpoints, and protected application behavior.
- [ ] Prepare PostgreSQL-compatible source, migration tooling, validation, backup, rollback, count-verification, and Cloud SQL connection guidance without creating, modifying, or deleting live patient, appointment, consent, or signature records.
- [x] Add an isolated PostgreSQL migration configuration guard and synthetic-only preflight harness that cannot fall back to or modify the active MySQL/TiDB source.
- [ ] Create and configure a new Cloud SQL PostgreSQL target only after owner approval of region, instance, access, Secret Manager values, data-migration window, and final production cutover.
- [x] Make production startup bind only the exact Cloud Run `PORT` value and fail clearly if unavailable, while retaining local development fallback behavior.
- [x] Replace the legacy temporary-origin Cloud Build assumption without configuring DNS or a final domain.
- [ ] Create the owner-authorized temporary Cloud Run service `james-laser-web` in `me-central1` from GitHub `main`, with no Cloud SQL migration and no DNS changes.
- [ ] Recheck the selected Google Cloud project’s Cloud Run billing/API prerequisite without creating a service, trigger, image, secret, database, domain mapping, or DNS change.
- [ ] Verify the owner-reported Google Cloud billing resolution on the Cloud Run service form before continuing the authorized temporary deployment.
- [ ] Perform one final non-destructive Cloud Run billing-modal verification before attempting any service creation.
- [ ] Inspect the selected project’s Google Cloud Billing overview in read-only mode to identify the external linkage blocker without changing account settings.
- [ ] Reopen the owner-approved closed Google Cloud billing account and verify Cloud Run eligibility before creating any deployment resource.
- [ ] Inspect available Google Cloud billing accounts in read-only mode to determine whether an eligible alternative exists; do not relink the project without a separate confirmation.
- [ ] Open the owner-confirmed Google Cloud Billing account-creation flow and pause before any payment, identity, or final financial submission step.
- [ ] Set Saudi Arabia as the owner-specified billing-account country, then pause before payment, address, identity, or final financial submission fields.
- [ ] Set the owner-specified billing account name `jameslaserhairremovallmanus` and Saudi Arabia country before advancing only to any owner-required financial step.
- [ ] Submit the owner-confirmed final activation for `jameslaserhairremovallmanus`, then verify its billing status before any separate project-linking action.
- [x] Record the verified closed-account and `OR_BACR2_44` Google Billing activation evidence; do not retry either failed account action without a changed Google status.
- [x] Enforce one patient file per matching manual MRN or normalized mobile number, without creating or merging duplicate operational records automatically.
- [x] Make protected patient names clickable to open an editable patient-file workflow with auditable duplicate safeguards.
- [x] Make protected appointment patient names clickable to open editable appointment details while preserving appointment identity, source, consent, and HMS audit fields.
- [x] Build a protected HMS workspace that opens an owner-supplied HTTPS HMS account URL in the user’s own browser without storing HMS credentials or embedding a third-party login page.
- [x] Map the existing protected request, appointment, patient, HMS, consent, notification, activity, and role signals for a zero-credit Admin Attention Agent.
- [x] Define deterministic, role-safe attention rules that identify missing, incomplete, overdue, or inconsistent clinic workflow items without using an LLM or changing operational records.
- [x] Build a protected Admin Attention Agent workspace with actionable, linked findings and explicit zero-credit/no-auto-action boundaries.
- [x] Add optional in-portal notifications only for verified attention findings, preserving current staff roles and private-data boundaries.
- [x] Validate the attention agent’s role safety, data boundaries, desktop/mobile interface, notification behavior, tests, and production build before checkpointing.
- [x] Audit every current Admin Portal page non-destructively for route availability, navigation, role boundaries, loading/error states, runtime health, and responsive presentation.
- [x] Verify protected appointment patient-name and patient-file click-through editing, preserving source, consent, signature, HMS, and duplicate safeguards.
- [x] Add a protected Waiting List date dropdown that defaults to the Riyadh current date and filters only the existing confirmed schedule for the selected date.
- [x] Validate the refined appointment, patient, and waiting-list workflows on desktop and mobile without changing operational records.
- [x] Replace Before & After result-case image URL entry with protected image upload controls that preserve required authorization and draft/publication safeguards.
- [x] Add a protected image uploader to the Prices & Promotions workspace with server-side file validation and persisted media references.
- [x] Validate result and promotion media uploads, consent/publication boundaries, desktop/mobile UI, and regressions without creating fabricated reviews, results, promotions, or patient records.
- [x] Run a final non-destructive managed-platform health verification after the latest clinic workflow and media-upload changes, with cloud and database migration work paused.
- [x] Audit the existing mobile experience and PWA install metadata, including responsive public/admin routes and the no-offline-cache boundary for protected clinic data.
- [x] Implement verified mobile usability and safe PWA install-readiness improvements without adding a service worker or offline cache for private content.
- [x] Validate responsive public/admin routes, manifest/install metadata, protected-data cache boundaries, fresh runtime health, and regression coverage before checkpointing.

# Safe In-Project Public Launch Evidence

- [x] Validate the current managed-domain public route matrix, SEO metadata, sitemap, robots rules, and protected-route privacy boundaries without using Cloud Run, billing, database migration, DNS, or any external account action.

# Public Map Destination Update

- [x] Replace all public Google Maps destination links with the exact owner-provided short URL and validate the affected public routes.

# Public API Query Failure Correction

- [x] Diagnose and fix the shared public homepage API query failures without changing clinic records or external deployment configuration.

# Custom Domain and DNS Resume

- [ ] Inspect the active managed hosting provider and prepare or connect the intended custom domain using only platform-confirmed DNS values, while leaving Cloud Run, PostgreSQL/Cloud SQL, billing, and clinic data untouched.

# Independent Cloud Run Deployment Preparation

- [x] Inventory and validate the existing GitHub application and Cloud Run deployment artifacts without enabling Cloud Run, changing DNS, migrating the database, or exposing secrets.

# Built-In Database Deployment Contract

- [x] Align the external Cloud Run deployment contract with the existing built-in MySQL/TiDB database through MYSQL_URL, without PostgreSQL/Cloud SQL migration or database resource changes.

# Managed Platform Only

- [x] Pause Google Cloud, Cloud Run, Firebase, Secret Manager, external deployment, custom DNS, and PostgreSQL/Cloud SQL migration; preserve the managed Manus app and built-in MySQL/TiDB database as the active production path.

# Patient, Appointment, Request Editing and Reminder Workspace

- [x] Add protected editable detail workflows for patient names/profiles, appointments, and appointment requests while preserving MRN/mobile duplicate safety and source/consent audit fields.
- [x] Change manual appointment treatment areas to a required multi-select supporting all applicable areas.
- [x] Add a protected Sessions & Retouch Reminders workspace that identifies which patient needs a session or retouch follow-up and when, without mixing requests with confirmed appointments.
- [x] Validate role access, provider/machine/status rules, data integrity, mobile/desktop UX, and regression tests without creating operational clinic records.

# Built-in Database Cleanup

- [x] Audit project files, dependencies, routes, and database adapters for safe cleanup candidates.
- [x] Remove verified-unused PostgreSQL migration executable code and active package entries while retaining historical deployment records.
- [x] Document the built-in MySQL/TiDB database as the sole active persistence layer and list intentionally retained paused artifacts.
- [x] Validate persistence, protected routes, RBAC, TypeScript, Vitest, production build, and representative public/admin/staff surfaces.
- [x] Save the cleaned built-in-database checkpoint with a data-preservation and technical-debt report.

# Additional requested cleanup follow-up

- [x] Confirm the final cleanup inventory and no unsafe data-bearing file deletion.
- [x] Confirm the active runtime uses MYSQL_URL and no PostgreSQL adapter is loaded.
- [x] Confirm external Cloud Run, Google Cloud, DNS, PostgreSQL, and Cloud SQL work remains paused.

# HMS In-Page Workspace

- [x] Replace the HMS new-tab launcher with an embedded in-page HMS URL/login workspace.
- [x] Keep HMS credentials and external session data out of the clinic database and portal state persistence.
- [x] Preserve the NR011-only HMS import boundary and clarify iframe/provider blocking behavior.
- [x] Add regression coverage and verify the HMS page on desktop and mobile.

# Final Managed-Platform Audit

- [x] Audit the final managed-platform route matrix across public, bilingual, appointment, protected admin, HMS, health, and readiness routes.
- [x] Verify managed-platform authentication boundaries, RBAC, provider filtering, appointment/request separation, and no mixed-content or redirect-loop evidence.
- [x] Verify representative desktop and mobile surfaces and record the evidence-based launch report.
- [x] Review non-blocking technical warnings and apply only safe in-project improvements that preserve runtime behavior.
- [x] Record all externally blocked Cloud Run, Google Cloud, billing, PostgreSQL/Cloud SQL, custom-domain, and DNS items as owner-dependent without attempting them.
- [x] Publish the final managed-platform audit checkpoint and report exact remaining blockers.

# HMS CSV Export

- [x] Define the authorized clinic-record scope and CSV columns for the HMS export.
- [x] Add a protected server-side HMS export procedure using the built-in MySQL/TiDB database and NR011-only filtering.
- [x] Add an in-page HMS export download control with transient client-side handling and clear privacy guidance.
- [x] Add regression coverage for export authorization, filtering, escaping, and download behavior.
- [x] Validate the export feature on desktop and mobile, then publish a checkpoint.

# HMS No-New-Tab Verification

- [x] Verify every HMS entry point stays inside the Admin Portal webapp and remove any remaining new-tab or external-window behavior.
- [x] Add regression coverage for the no-new-tab HMS behavior and revalidate the embedded workspace.

# Public Homepage Language Switcher

- [x] Audit the existing English and Arabic public homepage routes, copy, navigation, metadata, and direction handling.
- [x] Add an accessible English | العربية switcher that stays within the public webapp and preserves the equivalent page route.
- [x] Correct and complete the Arabic homepage language with natural Saudi-facing copy and proper RTL presentation.
- [x] Add regression coverage for language switching, Arabic document attributes, route metadata, and no private-data exposure.
- [x] Validate English and Arabic homepage behavior on desktop and mobile, then publish the bilingual checkpoint.

# Waiting List Arrival and Patient Profile Workflow

- [x] Audit the current Waiting List arrival action, appointment edit fields, patient identity matching, and Patients page persistence.
- [x] Define a protected arrival-details contract with editable visit information and a dedicated nurse’s notes field.
- [x] Make the Waiting List check action open the editable details panel before the arrival status is saved.
- [x] Create or link the patient profile only after staff confirms the arrival details, using MRN or mobile duplicate protection.
- [x] Show the saved nurse’s notes and linked appointment history in the protected Patients page without exposing them publicly.
- [x] Add regression coverage and verify authorization, source separation, duplicate handling, desktop/mobile behavior, and persistence.
- [x] Publish the validated Waiting List arrival-to-patient-profile checkpoint.

# Structured Waiting List Arrival Details

- [x] Add a required Session / Retouch dropdown to the protected arrival-details panel.
- [x] Add a required Machine used dropdown restricted to the four approved clinic machines.
- [x] Replace the single treatment-area input with a select-all-that-apply multi-area control.
- [x] Persist the visit type, approved machine, primary area, and complete treatment-area set without modifying HMS source evidence.
- [x] Show the saved visit type, machine, treatment areas, and nurse’s notes in the linked Patients history for easy sorting and review.
- [x] Add regression coverage and validate the structured arrival workflow on desktop and mobile before publishing.

# Premium Healthcare UI/UX Redesign

- [x] Audit the current shared shell, design tokens, public pages, protected pages, and existing component patterns.
- [x] Define a restrained branded design system using existing New Look Clinics branding with accessible semantic colors.
- [x] Improve the shared desktop sidebar, top header, mobile navigation, page headers, tables, and dashboard hierarchy without removing modules.
- [x] Apply consistent responsive and RTL-safe layout improvements to public and protected workflows.
- [x] Add regression coverage and validate routes, authentication boundaries, RTL, mobile, accessibility, TypeScript, tests, and production build.
- [x] Document design decisions, retained functionality, and remaining limitations, then publish the redesign checkpoint.

# Premium Healthcare UI/UX Redesign

- [x] Audit the current shared shell, design tokens, public pages, protected pages, and existing component patterns.
- [x] Define a restrained branded design system using existing New Look Clinics branding with accessible semantic colors.
- [x] Improve the shared desktop sidebar, top header, mobile navigation, page headers, tables, and dashboard hierarchy without removing modules.
- [x] Apply consistent responsive and RTL-safe layout improvements to public and protected workflows.
- [x] Add regression coverage and validate routes, authentication boundaries, RTL, mobile, accessibility, TypeScript, tests, and production build.
- [x] Document design decisions, retained functionality, and remaining limitations, then publish the redesign checkpoint.

# Scoped Custom-Domain DNS Audit

- [x] Inspect authoritative DNS records for jameslaserhairremovall.com and www without modifying any record.
- [x] Verify root/www HTTPS, HTTP-to-HTTPS redirects, canonical hostname behavior, and redirect-loop absence.
- [x] Verify public homepage, sitemap, robots, canonical, hreflang, and SEO metadata on the custom domain.
- [x] Report exact website DNS records and any required registrar action without touching MX/email records.

# Uploaded Project Archive Integration

- [x] Inventory all uploaded project archives and compare their file trees with the current baseline.
- [x] Classify archive contents into safe assets, reusable code, duplicates, and incompatible or obsolete files.
- [x] Integrate only verified relevant archive files without overwriting existing routes, data, authentication, or concurrent changes.
- [x] Validate the integrated project and document retained, excluded, and unchanged archive contents.
- [x] Publish the verified archive integration or report the exact blocker.

# Selective Port from new-look-clinics.zip

- [x] Produce the requested compatibility matrix for shared UI, revenue, patient records, session/retouch history, mobile UI, authentication UI, database layer, and reusable utilities.
- [x] Port and validate only compatible shared UI/forms/tables/cards/utilities without replacing current branding, routes, auth, or database architecture.
- [x] Port and validate the revenue workflow, including HMS CSV parsing, daily/monthly views, revenue by patient, import history, and duplicate protection with MySQL/TiDB-safe persistence and strict RBAC.
- [x] Compared donor patient-record and Session/Retouch features; retained the current authoritative implementations with no duplicate tables or record changes.
- [x] Compared donor mobile features; retained the current responsive web shell and mobile navigation, excluding native Android/iOS, Capacitor, and conflicting auth.
- [x] Run batch and full validation for TypeScript, tests, builds, MySQL/TiDB compatibility, RBAC, provider filtering, data integrity, and desktop/mobile behavior.
- [x] Document all ported, adapted, skipped, and retained files and publish only after final validation.

# Targeted Duplicate Patient Prevention

- [x] Fix approved-request appointment creation to resolve an existing patient by MRN or normalized WhatsApp before any patient write.
- [x] Preserve the existing patient profile and link the new appointment when either identifier matches.
- [x] Add an explicit existing-patient result/message without changing appointment requests, manual appointment behavior, or unrelated patient fields.
- [x] Add regression coverage for new/new, existing MRN/new phone, new MRN/existing phone, both matching, repeated appointments, patient preservation, and history.
- [x] Validate auth/RBAC, NR011 source boundaries, no unintended data changes, TypeScript, tests, production build, and publish the targeted checkpoint.

# Appointment Duplicate-Reuse Verification

- [x] Verify same MRN reuses the existing patient file and links the appointment.
- [x] Verify same phone/WhatsApp reuses the existing patient file and links the appointment.
- [x] Verify both matching identifiers reuse one existing patient without duplication.
- [x] Verify new MRN and new phone produce one new patient-file decision without writing real clinic data.
- [x] Verify divergent MRN and phone identities are rejected without relinking or overwriting.
- [x] Verify protected UI feedback, RBAC, patient preservation, history linkage, NR011 boundaries, and clean validation evidence.

# Baseline 8c785b29 Highest-Value Audit

- [x] Audit existing patient, appointment, duplicate-prevention, admin-efficiency, machine, HMS, and incomplete workflows without changing verified functionality.
- [x] Classify the highest-value finding as a necessary fix, existing incomplete feature, or new addition requiring approval.
- [ ] If a necessary fix or existing incomplete feature is selected, validate it incrementally without real clinic-data writes.

# Approved Waiting List Refresh

- [ ] Inspect the existing Waiting List data-fetching mechanism and exact lifecycle attachment point.
- [ ] Add only a guarded five-second fallback refresh with no duplicate intervals, inactive-view requests, or stale-data replacement.
- [ ] Add focused tests for cleanup, interval uniqueness, inactive behavior, NR011 filtering, and source separation.
- [ ] Run TypeScript, focused/full tests, production build, and non-submitting desktop/mobile review without changing clinic records.
- [ ] Document and publish the minimal refresh change with the exact commit/checkpoint evidence.

# PR #13 Settings Audit Migration

- [x] Re-read governance and inspect PR #13, schema, migration SQL, dependency order, and current database state.
- [x] Confirm the PR migration is additive, non-destructive, and limited to `settingsChangeAudits`.
- [x] Merge PR #13 without merging unrelated changes and sync the project.
- [x] Apply only the reviewed `settingsChangeAudits` migration through the built-in database path and verify table/indexes/constraints/journal.
- [x] Run focused settings/audit tests, full regression, TypeScript, build, health, and protected workflow checks.
- [x] Save the verified merge/migration checkpoint and report results.

# PR #13 Conflict Resolution

- [x] Re-read current shared-main files and PR #13 overlap after the fast-forward.
- [x] Preserve newer shared-main changes and port only the Settings Control Center and additive settingsChangeAudits work.
- [x] Validate the reconciled result before any merge or migration.
- [x] Merge the reconciled PR result, apply only the reviewed migration, and run final validation.

# Google OAuth Privacy URL Update

- [x] Confirm the exact verified public privacy-policy URL and current OAuth Branding value.
- [x] Update only the OAuth Branding privacy-policy URL to `https://jameslaserhairremovall.com/policies/privacy-policy`.
- [x] Read back the saved URL and verify no other OAuth, billing, credential, domain, verification, or Google Business settings changed.

# Session/Follow-Ups Compile Health Repair

- [x] Inspect synced `sessionRecords`/`followUps` schema exports, server module, component nullability, migration, and tests.
- [x] Apply only minimal compile-safe fixes without changing clinic data, OAuth settings, workflows, or migration history.
- [x] Validate TypeScript, focused/full tests, production build, health, representative protected routes, provider/source boundaries, and mobile behavior.
- [x] Save the OAuth URL and compile-health checkpoint and report remaining boundaries.

# Final Live-Site Health Check

- [x] Verify live deployment identity, hostnames, HTTPS, redirects, certificates, health/readiness, and recent checkpoint; `/readyz` returns 200, while `/healthz` is not implemented and returns 404.
- [x] Verify public bilingual routes, privacy policy, SEO metadata, appointment form behavior, and direct-route loading without submission.
- [x] Verify protected login entry points and recent Admin, Settings, Session/Follow-Ups, HMS, Waiting List, appointments, and patients routes without changing records.
- [x] Review browser console, network, runtime, desktop, and mobile health evidence; preserve the observed stale `whatsapp.settings` 500 as a release warning pending fresh authenticated reproduction.
- [x] Deliver a read-only PASS/FAIL report with exact remaining blockers and no data/settings changes.

# Healthz Endpoint

- [x] Inspect the existing `/readyz` implementation and health-test conventions; `/healthz` already exists alongside it and has dedicated source coverage.
- [x] Confirm no code addition was necessary: `/healthz` already returns `{ status: "ok" }` and `server/healthcheck.test.ts` covers its registration.
- [x] Validate local `/healthz` and `/readyz` (both HTTP 200), TypeScript, tests, and production build; the prior live-host `/healthz` 404 remains a deployment/hostname propagation warning.
- [x] Publish the verified health-route status and report the remaining live-host monitoring warning.
