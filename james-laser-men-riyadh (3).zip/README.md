# James Laser Hair Removal for Men Riyadh

This repository contains the public website and protected clinic-management portal for **James Laser Hair Removal for Men Riyadh @ New Look Clinic**. It supports bilingual public information, appointment requests that require clinic confirmation, separate general enquiries, a role-protected CMS, and clinic operational workspaces.

## Architecture

| Layer | Implementation |
|---|---|
| Client | React 19, Vite, TypeScript, Tailwind CSS, Wouter, and tRPC React Query |
| Server | Express 4 and tRPC 11 |
| Database | Built-in Manus/WebDev MySQL-compatible database through a server-only connection; active server code uses Drizzle with the MySQL dialect |
| Authentication | Existing Manus OAuth flow and role-aware procedures |
| Media | Existing protected Forge-backed storage integration |
| WhatsApp | Direct server-side Meta WhatsApp Business Platform Cloud API client, authenticated webhook, and protected operational inbox |
| Publication | Managed WebDev runtime and custom domains; publication is gated by the project checkpoint workflow and clinic release checks |

## Local development

Use Node.js 22 and pnpm. Review `ENVIRONMENT_VARIABLES.md` for the required variable names, then provide development values through the approved secret-management workflow. Do not create or commit a real environment file from this repository.

```bash
pnpm install --frozen-lockfile
pnpm dev
```

The local development server starts the Express/tRPC process, which serves the Vite application. Public routes include `/`, `/en`, `/ar`, `/appointment`, and the published content hubs. The protected clinic portal begins at `/admin`.

## Supported commands

| Command | Purpose |
|---|---|
| `pnpm dev` | Run the local full-stack development server |
| `pnpm check` | Run the TypeScript check |
| `pnpm test` | Run the Vitest regression suite |
| `pnpm build` | Build the Vite client and bundled Node server |
| `pnpm start` | Run the production bundle |
| `pnpm db:push` | Generate and apply Drizzle migrations in an approved database workflow |

There is no configured lint script. Do not invent one in automation; run the listed supported checks instead.

## Environment configuration

The active server-side database connection is supplied only by the managed WebDev environment. Never commit database URLs, OAuth credentials, session secrets, Meta values, Forge keys, or any real environment file. Historical Cloud Run and PostgreSQL migration records remain as archival project context; they are not an approved active database or publication path.

## Data, privacy, and publication controls

Public appointment submissions create **requests**, not confirmed appointments. Only protected staff review can create a confirmed appointment. General enquiries remain separate from clinical request and patient records. Reviews and treatment-result cases must be genuine, approved, and consent-controlled before they can be public. Promotions and policies remain private until their authorized publishing state is set.

The CMS calendar is internal planning only. It cannot publish an article, Google Business Profile update, social post, Search Console action, or external metric.

## Deployment

The approved publication route is the attached managed WebDev project using the built-in WebDev database. Before publication, run `pnpm check`, `pnpm test`, `pnpm build`, the read-only HMS publication gate, and live route checks. Do not restart or introduce PostgreSQL, Cloud SQL, external database adapters, or legacy Cloud Run deployment paths without explicit owner authorization. Do not change DNS until the managed deployment passes documented QA.

## GitHub workflow

Use a feature branch where repository review is required, run `pnpm check`, `pnpm test`, and `pnpm build`, review changed files for secrets, and save a managed WebDev checkpoint before publication. Do not force-push, rewrite production history, or merge directly into `main` without explicit owner authorization.
