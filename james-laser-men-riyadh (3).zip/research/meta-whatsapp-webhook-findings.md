# Official Meta WhatsApp Platform Findings

**Source reviewed:** [Meta for Developers — WhatsApp webhooks overview](https://developers.facebook.com/documentation/business-messaging/whatsapp/webhooks/overview) (updated June 26, 2026).

Meta documents webhooks as HTTPS JSON callbacks for incoming WhatsApp messages and status events for outgoing business messages. The `messages` field covers both inbound customer messages and the statuses of business-to-customer messages. The documented delivery states provide the evidence boundary for `sent`, `delivered`, `read`, and `failed`; successful API submission alone is not delivery confirmation.

Production setup requires an application webhook endpoint, relevant app permissions, and subscription to required webhook fields from the Meta App Dashboard. Meta states that webhook delivery failures can be retried for up to seven days, including duplicate notifications. The implementation must therefore authenticate callbacks and process payloads idempotently.

**Implementation consequence:** retain the existing server-side official Cloud API client and raw-payload HMAC verification. Use webhook status events as the only source for delivery/read transitions, keep unique provider message IDs and event fingerprints, and do not use WhatsApp Web/browser automation.
