# Authenticated Admin Redesign — Visual Evidence

**Reviewed:** 6 September 2026  
**Scope:** Authenticated English and Arabic desktop/mobile presentation only

## Evidence artifacts

| Artifact | Dimensions | SHA-256 |
|---|---:|---|
| `authenticated-desktop-en-ar.png` | 1440 × 704 | `07feb9b56be6492a3bdaf55febef78da55884f494ecaa7f1953ce03dd54cb203` |
| `authenticated-mobile-en-ar.png` | 1248 × 1370 | `b9b68b4d42312058f22da08fccd23cfa84619a23d36cc62fcc290d446aa0306a` |

The source artifacts are attached with the release result from `/home/ubuntu/admin-redesign-evidence/`. They combine locally saved authenticated preview captures and contain no credentials.

## Inspectable coverage

The desktop sheet covers the English dashboard, appointments, patient requests, and waiting list, followed by Arabic WhatsApp, users/security, machines, and settings. The mobile sheet covers the same eight routes at 390 × 844.

The reviewed sheets show the role-filtered shell, desktop sidebar, compact mobile header, language control, authorized search, safe-area bottom navigation, real-data metrics, appointment calendar, request filters, Arabic RTL hierarchy, staff role cards, machine cards, appointment settings, WhatsApp tab surface, and accessible loading/error surfaces. Protected names, emails, identifiers, and message bodies remain record text rather than presentation translations.

Some screenshot-harness frames captured the intended loading surface while their authenticated query was in flight, particularly waiting list and WhatsApp. These frames were not used as proof of resolved data. Resolved, empty, loading, and error branches were separately verified by deterministic tests that render the actual `Appointments`, `WaitingList`, `Machines`, `AppointmentSettings`, `Notifications`, `Security`, and CMS `Library` components. The protected request and WhatsApp workflow contracts are also covered by the full server and client suite.

## Visual result

The inspected artifacts show no unintended viewport overflow, overlapping fixed controls, clipped primary actions, illegible color contrast, fake data, or accidental public exposure. The public website visual language remains unchanged. The authenticated redesign stays within the documented ivory, ink, copper, and white clinical design system.
