# Privacy Policy Deployment Validation

Date: 2026-09-07

The bilingual privacy-policy record is published in the built-in database and renders successfully on the managed production hostname `https://jameslaser-elxrr9qk.manus.space/policies/privacy-policy` and on `https://www.jameslaserhairremovall.com/policies/privacy-policy` after deployment propagation. Both routes return HTTPS content and the public policy tRPC response contains the published `privacy-policy` record.

The required apex URL `https://jameslaserhairremovall.com/policies/privacy-policy` returns HTTP 200 but its public policy tRPC response is empty, and the browser renders the safe “Policy not currently published” fallback. This indicates the apex custom hostname is still serving a separate or stale production route/data context. No DNS record, database record, OAuth setting, or external account was changed to work around this discrepancy.

Google OAuth Branding was not updated because the exact approved apex URL is not yet verified as serving the published policy. Google verification was not submitted and no Google Business Profile post was published.

Required owner/hosting action: reconnect or propagate the apex custom hostname so it serves the same current production deployment/data context as the managed hostname and `www`. After that, revalidate the apex route and update OAuth Branding to the exact apex URL.
