# Public Privacy Policy — James Laser Hair Removal for Men, Riyadh

**Status:** Public draft for clinic and qualified privacy/legal review. This text describes the current application behavior observed in the James Laser website and portal; it is not legal certification or legal advice.

## English

### Privacy Policy

James Laser Hair Removal for Men at New Look Clinic in Riyadh uses information submitted through this website to respond to enquiries and appointment requests, review preferred appointment details, communicate with the person who submitted a request, and operate the website and clinic workflows.

### Information submitted through the appointment request

The appointment request may ask for a full name, mobile or WhatsApp number, optional nationality, preferred date and time, session or retouch preference, selected treatment areas, whether laser hair removal was previously received, and additional notes. The form also records the language used for the request and the acknowledgements required before submission. A request is not an appointment confirmation; the clinic reviews availability and contacts the requester before confirming an appointment.

The form includes a separate optional choice to receive occasional promotions or updates by WhatsApp. If this choice is not selected, the appointment request is still submitted when the required fields and acknowledgements are complete.

Please do not place confidential medical history in the additional-notes field. Information needed for treatment suitability or consent is handled through the clinic’s applicable assessment and consent processes.

### Consent and clinic records

The website records the acknowledgements required for appointment requests, including acknowledgement that the request is not automatically confirmed, the privacy-policy and appointment-policy acknowledgement, and the online acknowledgement of the original consent documents. Where the clinic provides its separate consent-signing workflow, information submitted for that workflow is handled as clinic consent evidence.

Appointment requests and related clinic records are available only through the protected clinic workflows to authorized users. The public website does not expose patient, staff, appointment, consent, or internal operational records.

### Website events and public communications

The website records limited operational event information for public-site improvement and request-flow monitoring, including page or form events, the page path, language, source host, device-type field, and, where applicable, the selected treatment identifier. The application also records the information needed to process an appointment request and communicate with the requester.

The website may provide links that open external destinations, including WhatsApp contact links, map links, and clinic consent documents. A person who follows an external link leaves this website and is subject to that destination’s own terms and privacy information. This policy does not make claims about the privacy practices of those external services.

### Public content and administrator-managed material

Authorized clinic administrators may manage public content, media references, policies, promotions, and educational material through protected clinic tools. These administrative functions are not public-access features and are not available without authentication and the appropriate clinic permission.

### Contact

For privacy questions about a website enquiry or appointment request, contact James Laser Hair Removal for Men at New Look Clinic in Riyadh through the established clinic contact channels:

- Email: jameslaserhairremoval@gmail.com
- WhatsApp: +966 55 740 1562

### Updates

The clinic may update this page when the website or its information-handling processes change. The publication date shown by the website should be checked when relying on this page.

## العربية

### سياسة الخصوصية

يستخدم جيمس ليزر لإزالة الشعر بالليزر للرجال في عيادة نيو لوك بمدينة الرياض المعلومات التي يتم إدخالها عبر هذا الموقع للرد على الاستفسارات وطلبات المواعيد، ومراجعة تفاصيل الموعد المفضلة، والتواصل مع مقدم الطلب، وتشغيل الموقع وإجراءات العيادة.

### المعلومات التي يتم إدخالها في طلب الموعد

قد يطلب نموذج الموعد الاسم الكامل، ورقم الجوال أو واتساب، والجنسية بشكل اختياري، والتاريخ والوقت المفضلين، ونوع الزيارة (جلسة أو رتوش)، ومناطق العلاج المختارة، وما إذا كان مقدم الطلب قد أجرى إزالة شعر بالليزر من قبل، وأي ملاحظات إضافية. كما يسجل النموذج اللغة المستخدمة في الطلب والإقرارات المطلوبة قبل الإرسال. لا يُعد الطلب تأكيدًا للموعد؛ تراجع العيادة التوفر وتتواصل مع مقدم الطلب قبل تأكيد الموعد.

يتضمن النموذج خيارًا منفصلًا واختياريًا لتلقي عروض أو تحديثات من حين لآخر عبر واتساب. ولا يمنع عدم اختيار هذا الخيار إرسال طلب الموعد عند استكمال الحقول والإقرارات المطلوبة.

يرجى عدم إدخال تاريخ طبي سري في خانة الملاحظات الإضافية. تتم معالجة المعلومات اللازمة لتقييم ملاءمة العلاج أو الموافقة من خلال إجراءات التقييم والموافقة المعمول بها لدى العيادة.

### الموافقات وسجلات العيادة

يسجل الموقع الإقرارات المطلوبة لطلبات المواعيد، بما في ذلك الإقرار بأن الطلب لا يتم تأكيده تلقائيًا، والإقرار بسياسة الخصوصية وسياسة المواعيد، والإقرار الإلكتروني بفتح نماذج الموافقة الأصلية. وعند توفر مسار التوقيع المنفصل للموافقة لدى العيادة، تتم معالجة المعلومات المقدمة من خلال ذلك المسار باعتبارها أدلة موافقة خاصة بالعيادة.

لا تتاح طلبات المواعيد والسجلات المرتبطة بها إلا من خلال إجراءات العيادة المحمية للمستخدمين المصرح لهم. ولا يعرض الموقع العام بيانات المرضى أو الموظفين أو المواعيد أو الموافقات أو السجلات التشغيلية الداخلية.

### أحداث الموقع والتواصل العام

يسجل الموقع معلومات تشغيلية محدودة عن الأحداث في الموقع العام لتحسين الموقع ومتابعة مسار طلب الموعد، مثل أحداث الصفحة أو النموذج، ومسار الصفحة، واللغة، ومضيف المصدر، وحقل نوع الجهاز، ومعرّف العلاج المختار عند انطباق ذلك. كما يسجل التطبيق المعلومات اللازمة لمعالجة طلب الموعد والتواصل مع مقدم الطلب.

قد يوفر الموقع روابط تفتح وجهات خارجية، بما في ذلك روابط التواصل عبر واتساب وروابط الخرائط ووثائق الموافقة الخاصة بالعيادة. عند اتباع رابط خارجي، يغادر المستخدم هذا الموقع وتطبق شروط ومعلومات الخصوصية الخاصة بالوجهة الخارجية. ولا تقدم هذه السياسة ادعاءات حول ممارسات الخصوصية في تلك الخدمات الخارجية.

### المحتوى العام والمواد التي يديرها المسؤولون

يمكن للمسؤولين المصرح لهم في العيادة إدارة المحتوى العام ومراجع الوسائط والسياسات والعروض والمعلومات التثقيفية من خلال أدوات العيادة المحمية. هذه الوظائف الإدارية ليست متاحة للعامة وتتطلب تسجيل الدخول والصلاحية المناسبة.

### التواصل

للاستفسارات المتعلقة بالخصوصية بشأن استفسار أو طلب موعد عبر الموقع، يمكن التواصل مع جيمس ليزر لإزالة الشعر بالليزر للرجال في عيادة نيو لوك بمدينة الرياض عبر قنوات التواصل المعتمدة لدى العيادة:

- البريد الإلكتروني: jameslaserhairremoval@gmail.com
- واتساب: ‎+966 55 740 1562

### التحديثات

قد تحدث العيادة هذه الصفحة عند تغير الموقع أو إجراءات التعامل مع المعلومات. يرجى مراجعة تاريخ النشر الظاهر في الموقع عند الاعتماد على هذه الصفحة.

---

## Internal implementation note — not for public display

Privacy policy requires review by the clinic’s qualified legal/privacy reviewer before being treated as final legal policy.
