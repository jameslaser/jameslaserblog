# Database Runtime Fix Evidence

## Scope

This correction restores the active managed runtime to the existing MySQL/TiDB contract. No PostgreSQL migration, Cloud Run change, schema migration, external account action, or clinic-record operation was performed.

## Root cause

The active application received the configured MySQL/TiDB connection target, but the runtime schema and database service had been switched to PostgreSQL builders and the `pg` adapter. This generated PostgreSQL-style SQL and failed at runtime with SSL/query errors.

## Correction

The active Drizzle schema uses MySQL/TiDB builders again, `server/db.ts` uses the existing MySQL driver and `MYSQL_URL` precedence, and the affected CMS, consent-signature, notification, enquiry, redirect, and WhatsApp write paths use MySQL/TiDB-compatible insert-id, duplicate-key, and follow-up-select behavior.

## Validation so far

- TypeScript compilation passes.
- Full test suite passes: 53 test files, 171 tests.
- Production build passes and produces `dist/index.js`.
- Public homepage reloads successfully and displays CMS-backed content, including treatments, offers, results, FAQ, guide, and clinic information.
- Refreshed browser console shows no current API query errors.

## Remaining validation

Fresh managed runtime health/readiness and post-restart logs must be checked before checkpointing. No operational clinic records have been created, modified, deleted, imported, or merged.

## Fresh post-restart evidence

- Managed development service restarted cleanly at 23:30:37 Asia/Riyadh.
- `/healthz` returned HTTP 200 with `{ "status": "ok" }`.
- `/readyz` returned HTTP 200 with `{ "status": "ready" }`.
- The refreshed public homepage rendered CMS-backed content after restart.
- The fresh browser console contained no output or current API query errors.
- The remaining older log entries are pre-restart PostgreSQL/SSL failures from the stale runtime and are not evidence of the corrected process.

## Responsive route evidence

Representative `/`, `/treatments`, `/offers`, and `/faq` routes were visually reviewed at desktop width 1280×720 and mobile width 390×844. Published treatments rendered correctly, the offers page showed an honest empty state with no fabricated promotions, the FAQ content rendered, and the homepage remained responsive. No private clinic data appeared on these public routes.

## Final validation

The focused MySQL/TiDB compatibility regression coverage passes alongside the complete suite: 54 test files and 173 tests passed. TypeScript compilation and the production build also pass. The only build notice is the existing large-client-bundle advisory; it is not a build failure.
