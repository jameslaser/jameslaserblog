# Candidate Project Check: My Maps OAuth metadata

Project ID: `compelling-pen-393311`

The credentials page showed one OAuth 2.0 client:

- Name: `Web client 2`
- Creation date: August 3, 2026
- Type: Web application
- Client ID prefix visible in the console: `543266508841-1e27...` (truncated; the full ID is intentionally not stored)

The page also displayed a Configure consent screen notice. Redirect URI details were not opened because the safe metadata already showed no clinic/domain name and because no credential detail should be copied without a direct evidence need.

This is strong evidence of a recent web OAuth client in a Maps-enabled project, but it is not proof that the client belongs to the current James Laser app or Google Business Profile. No secret, token, key value, or credential configuration was exposed or changed.
