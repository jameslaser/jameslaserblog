# Baseline 8c785b29 Highest-Value Audit

## Scope

This audit continued from accepted checkpoint `8c785b29` and preserved rollback baseline `41702f9c`. It inspected patient identity, appointment creation and status separation, duplicate protection, admin workflow surfaces, machines, Waiting List, HMS boundaries, and existing tests without modifying application code, database records, or external infrastructure.

## Findings

| Priority area | Evidence | Classification | Decision |
|---|---|---|---|
| Patient integrity | `server/patientIdentity.ts`, `server/patientIdentity.test.ts`, and the approved-request transaction cover MRN/phone reuse, divergent-identity rejection, patient preservation, and appointment linking. | No issue | Leave unchanged. |
| Appointment reliability | Existing request/appointment separation, confirmed-status guards, appointment linking, and protected admin-router tests are present. | No issue | Leave unchanged. |
| Duplicate prevention | Same-MRN, same-phone, both-match, new-identity, and conflict cases passed the accepted verification. | No issue | Leave unchanged. |
| Admin efficiency | Existing protected workspaces include Requests, Appointments, Waiting List, Patients, Machines, HMS, Revenue, reminders, and attention workflows. No concrete unfinished in-project item was found in the checklist. | No issue | Leave unchanged. |
| Machine/Waiting List/HMS | Approved machine allowlist, structured arrival details, today-bound Waiting List, NR011-only HMS import/export, and source-preservation guards are implemented. | No issue | Leave unchanged. |
| Real-time/five-second refresh | The source audit found no active WebSocket, `refetchInterval`, or five-second polling implementation for Waiting List/HMS. | New addition | Do not implement without owner approval. |

## Decision gate

The single highest-value candidate is a real-time Waiting List/HMS refresh with a five-second fallback. It could reduce stale queue data, but it is a **new addition**, not a necessary correction to the verified baseline. Per the uploaded instruction, implementation is paused pending explicit approval.

All remaining unchecked project items outside this audit are paused external infrastructure tasks. No Cloud Run, Cloud SQL/PostgreSQL, Google Cloud billing, Firebase, DNS, custom-domain, deployment, or database-architecture work was performed.
