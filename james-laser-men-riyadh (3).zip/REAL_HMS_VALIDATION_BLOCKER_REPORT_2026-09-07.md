# Real-HMS Publication Validation Report

**Status:** **PASS — mandatory real-HMS validation completed.**

**Validation time:** 7 September 2026 at 10:28 Asia/Riyadh

**Evidence ID:** `94a2c9f62bbaf9c81a8ee2690fd6e6008f8b9f6344d5339163bebd205f369538`

## Audited result

The existing authorized login-based worker was located in the user-authorized `jameslaser/Jameslaserappclone2` repository. The validation reused its established `GetPermGroups → CheckOTP → DBAL.LoadAllAppointment` HTTPS flow. The worker successfully authenticated and fetched a genuine `DBAL.LoadAllAppointment` report for 1–8 September 2026. The raw response remained transient and was never written to the clinic database or committed to the application repository.

The immutable evidence contains only aggregate counts, source metadata, cryptographic hashes, and rejection categories. It contains no patient names, MRNs, telephone numbers, credentials, cookies, session identifiers, or raw report rows. The evidence file is protected by a checked SHA-256 sidecar and a strict publication command that rejects missing, stale, tampered, empty, non-read-only, or incomplete evidence.

| Mandatory gate | Result |
|---|---|
| REAL HMS CONNECTION | **PASS** |
| REAL REPORT FETCH | **PASS** |
| RAW RECORDS | **1,781** |
| ACCEPTED RECORDS | **42** |
| REJECTED RECORDS | **1,739** |
| REJECTION EVIDENCE | **PASS** |
| DATA-INTEGRITY CHECKS | **PASS** |
| FULL TESTS | **PASS — 80 files, 312 tests; 1 file and 14 tests skipped by their existing conditions** |
| PUBLICATION GATE | **PASS** |

## Genuine rejection evidence

| Exact category | Count | Evidence form |
|---|---:|---|
| `provider_not_nr011` | 1,729 | Cryptographic hashes of genuine rejected source records; no row values retained |
| `outside_report_range` | 9 | Cryptographic hashes of genuine rejected source records; no row values retained |
| `duplicate_patient_appointment_slot` | 1 | Cryptographic hash of the genuine duplicate source record; no row values retained |
| **Total** | **1,739** | Reconciles exactly with the rejected-record total |

The accepted and rejected totals reconcile exactly to the 1,781 raw records. The 42 accepted records are **report-validation acceptances** inside the exact NR011 provider and requested date boundary; they are not imported appointments. Their source-status aggregates are retained only as non-identifying counts. The live Admin appointment schedule continues to enforce its separate confirmed-status-only query and does not display cancelled, completed, no-show, pending, non-NR011, request, duplicate, or unclear-source rows.

## Data-integrity controls

The validation process did not open a database connection and contained no database client, insert, update, delete, application mutation, WhatsApp activation, booking automation, or provider-worker submission. It did not modify appointments, appointment requests, revenue, patients, machines, sessions, follow-ups, settings, or any other clinic record. The raw HMS payload was held only in process memory and discarded after producing hashes and aggregate evidence.

The existing HMS-only source restriction, exact NR011 provider boundary, duplicate fingerprint protections, same-patient/date/time protections, stale public-request protections, and private/public workflow separation remain unchanged. The publication gate was run again after the full TypeScript, regression-test, and production-build suite completed successfully.

## Evidence

The canonical evidence is stored in [`docs/evidence/REAL_HMS_VALIDATION_2026-09-07.json`](docs/evidence/REAL_HMS_VALIDATION_2026-09-07.json). Its SHA-256 digest is stored in the adjacent `.sha256` file and verified by `pnpm publication:gate`.
