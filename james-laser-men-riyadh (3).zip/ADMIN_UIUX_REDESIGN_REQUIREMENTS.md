# Authenticated Admin UI/UX Redesign Requirements

## Scope boundary

This is a **visual and interaction redesign only**. The existing backend, built-in database schema and records, authentication, user roles, RBAC procedures, server routes, appointment workflow, waiting-list workflow, CMS approval workflow, notification workflow, integrations, analytics, and all business rules remain the active system of record. No production records may be deleted, reseeded, migrated, or replaced with mock data.

> **Keep the engine. Redesign the experience.**

## Design outcome

The authenticated application must present as a premium, clean, professional, medical operations platform for a men’s laser clinic. The implementation should prioritize mobile usability, clear clinical workflow hierarchy, restrained status color, readable typography, generous but efficient spacing, and first-class Arabic RTL and English LTR layouts. It must avoid generic dashboard styling, excessive animation, gradients, ornamental clutter, tiny type, dense unresponsive tables, and invented data.

## Required redesign coverage

| Surface | Required direction | Preserved system boundary |
|---|---|---|
| Application shell | Quiet desktop sidebar, concise header, role-filtered navigation, user context, mobile-specific navigation and drawers. | Existing role and route checks remain authoritative. |
| Dashboard | Operational greeting, existing summary metrics, schedule, machine status, and existing quick actions. | Use real existing records only; do not synthesize counts, revenue, or machine availability. |
| Appointments | Existing seven-day scheduling, editor/detail action, clear compact status presentation, mobile-safe cards. | No second editor, no changed appointment rules, and no changed confirmed/pending/cancelled logic. |
| Waiting list | Fast scanning of name, arrival, appointment, treatment, status, machine, and valid actions. | Preserve walk-in and waiting-list data model and state transitions. |
| Patients | Searchable records and supported details/tabs for current clinical and operational data. | Show only fields already supported and access-controlled. |
| Machines | Premium cards that surface real status, existing appointment links, availability, and blocking detail where available. | Do not fabricate availability or change synchronization. |
| Business and CMS | Revenue, content, promotions, publishing, approval, media, notifications, tasks, staff, reports, audit, settings, and integrations gain one consistent workspace language. | Existing publication approval, owner review, CRM, and integration boundaries remain unchanged. |
| Shared UI | Unified forms, tables, tabs, badges, overlays, alerts, toasts, loading and empty states. | Field meaning, API contracts, and data mutations remain unchanged. |
| Localization and accessibility | Proper full RTL/LTR layout, icon direction, alignment, focus, labels, contrast, keyboard behavior, and touch targets. | Existing localization and permission behavior remain intact. |

## Existing implementation map

| Existing route group | Current component or workspace | Redesign responsibility | Non-negotiable preservation |
|---|---|---|---|
| `/admin` | `AdminPortal` → `AdminDashboard` | Reorder real operational cards, schedule context, machine visibility where already available, quick actions, and activity presentation. | Existing `admin.dashboard`, request queue, CMS dashboard, activity queries, and links. |
| `/admin/requests` | `AppointmentRequestsWorkspace` | Improve review queue, protected request detail, consent evidence, and approval-path hierarchy. | Explicit request review and approval before appointment transfer. |
| `/admin/appointments`, `/admin/hms` | `AdminPortal` → `Appointments`, `HmsWorkspace`, editor/import panels | Improve seven-day schedule, status legend, filters, detail access, and compact mobile daily list. | Existing editor, HMS import preview, status mapping, and separation from incoming requests. |
| `/admin/waiting-list`, `/admin/patients`, `/admin/machines`, `/admin/reminders` | `AdminPortal` workspaces | Improve scanability, search/filter treatment, patient-file hierarchy, machine state cards, and mobile action layout. | Existing waiting-list states, patient record views, machine synchronization, and follow-up workflow. |
| `/admin/revenue` | `RevenueWorkspace` | Refine governed intake, KPI cards, report tabs, drilldown tables, filters, and import history. | HMS reconciliation gate, duplicate controls, immutable import semantics, and authorization. |
| `/admin/whatsapp` | `WhatsAppWorkspace` | Unify complex inbox, context, template, automation, and provider-status interfaces into the shared component system. | Service-window messaging guard, template approval, exact record linking, consent, automation gating, and owner/admin checks. |
| `/admin/enquiries`, `/admin/analytics`, `/admin/data`, `/admin/redirects` | `AdminOperations` | Apply shared headers, filters, metrics, error/empty states, and mobile cards. | Existing request handling, privacy metrics, export, and redirect safeguards. |
| `/admin/content` through `/admin/languages` | `CmsManager`, catalogues, education, calendar, uploads | Create a coherent content-management workspace with bilingual and approval states. | Existing role gates, review/publish actions, media storage paths, and author-entered Arabic content. |
| `/admin/notifications`, `/admin/activity`, `/admin/security`, `/admin/settings` | `CmsManager` | Improve management list density, action clarity, status patterns, and form grouping. | Existing notification privacy, activity evidence, owner-only user roles, and clinic setting behavior. |
| All authenticated routes | `DashboardLayout`, `index.css`, `App.tsx` | Standardize desktop sidebar, header, mobile bottom navigation, search, focus behavior, and responsive spacing. | Existing auth handling, role-filtered navigation, route paths, global search, safe-area behavior, and public/private separation. |

## Direct audit evidence and design constraints

| Audited surface | Existing pattern confirmed | Required redesign constraint |
|---|---|---|
| Shared shell | Desktop collapsible sidebar, role-filtered menu items, global protected search, user profile/logout, visible focus ring, safe-area bottom navigation, and a mobile “all sections” drawer already exist. | Extend the shared shell; do not replace its `useAuth`, role filtering, route navigation, desktop/sidebar coexistence, or mobile-safe controls. |
| Appointment and HMS workflows | Seven-day status calendar, hidden desktop-only table headers, mobile cards for HMS previews, confirmation-gated uploads, source attestation, import warnings, and non-destructive panels are implemented. | Preserve all validation gates, source metadata, provider attestation, original/raw field retention, and mobile card/table alternatives. |
| Requests, consent, and e-signature | Responsive request rows expand to protected detail panels; editing, consent evidence, signing-link creation, status updates, and explicit appointment transfer are separate controls. | Preserve the sequence of request review → final protected details → explicit transfer. Never collapse consent/signature evidence into a cosmetic-only state. |
| Waiting list and patient files | Today-only attendance actions, five-second foreground polling, arrival/waiting panels, protected patient-file selection, safety screening, edit panels, and appointment history are in place. | Retain polling, date read-only behavior, intake fields, patient matching protections, and all existing operational actions. |
| Machines | Four live machine entries are rendered as editable internal-ID cards. | Reformat cards only; do not fabricate utilization, availability, maintenance, or performance data that the current query does not provide. |
| Revenue | CSV preview, reconciliation pass/fail, duplicate detection, warning acknowledgment, immutable import, filters, tabbed reports, responsive table wrappers, and batch detail viewer are in place. | Treat these as protected financial controls. Visual simplification must not weaken or hide validation before import. |
| WhatsApp | Dense inbox, links to protected patient/request/appointment records, service-window guard, approved-template selection, consent, automation queue, retouch review, webhook metadata, and owner/admin activation controls are implemented. | Preserve every role check and provider boundary. Do not disclose secrets, claim a provider send occurred without a verified provider response, or turn staff prompts into autonomous booking. |
| Secondary operations | Enquiries, anonymous analytics, authorized CSV export, backups guidance, and server-enforced redirects include their own loading, error, empty, confirmation, and status patterns. | Reuse shared visual primitives while retaining their distinct confidentiality and destructive-action warnings. |
| CMS and management | Clinic content, services, promotions, reviews, consent-controlled results, media, policies, SEO, language readiness, activity, notification, staff security, and settings expose state-specific forms and lists. | Preserve draft/publish/approval semantics, media authorization copy, owner-only security controls, and author-entered Arabic content. |

### Audit conclusion

The authenticated application already has a technically sound functional foundation and many responsive safeguards. The redesign should therefore be a progressive, component-led visual consolidation rather than a route replacement: first strengthen the shared shell and visual tokens, then apply the shared surface, page-header, status, form, table, drawer, and mobile-card primitives to existing workspaces. A global Arabic/English control is not currently present across the private portal; it must be implemented as a presentation-layer concern without changing server contracts or attempting automatic translation of clinical or operational content.

## Acceptance criteria

The redesign will be accepted only after the full authenticated experience has been inspected and updated consistently, not only the dashboard. Existing login, RBAC, dashboard data, appointments, seven-day schedule, editor, waiting list, patients, machines, revenue, CMS, approvals, media, notifications, tasks, settings, integrations, Google Business Profile connections, and database actions must retain their current behavior.

Final verification must cover desktop and mobile screen sizes in English and Arabic, with no horizontal overflow, overlap, clipped text, broken dialogs, broken navigation, console errors, failed requests, broken permissions, or data loss. The implementation must not materially add bundle weight, API calls, database queries, images, or new dependencies without a clear need.
