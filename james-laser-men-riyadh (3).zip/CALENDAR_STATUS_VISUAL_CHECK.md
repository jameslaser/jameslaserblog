# Calendar Status Indicator Visual Check

The protected `/admin/appointments` page was reviewed at 1440×900 and 390×844. The seven-day calendar displays a visible legend and three status rows per day: blue Confirmed, amber Pending, and red Cancelled. Each row includes a dot, label, and count; each date button has an accessible status summary in its `aria-label`. The layout remains readable on mobile, wraps the legend cleanly, and preserves the existing bottom navigation, date controls, empty state, and appointment count behavior. No appointment mutation was performed during visual review.
