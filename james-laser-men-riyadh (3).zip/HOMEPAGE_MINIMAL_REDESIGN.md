# Public Homepage Minimal Redesign

## Scope

This update changes only the English public homepage implementation at `client/src/pages/Home.tsx`. The objective is a simpler, professionally elegant, male-focused presentation for James Laser Hair Removal for Men in Riyadh. It does not change private portals, authentication, authorisation, clinic records, appointment data, enquiry storage, server procedures, database schema, analytics contracts, or public content routes.

## Design direction

The page uses a restrained **deep navy, warm bone, and copper** palette. Deep navy provides a more masculine and clinical foundation, warm bone keeps the public site approachable, and copper directs attention to the primary conversion actions. Existing readable Manrope body type and DM Serif Display headings are retained, together with Noto Sans Arabic for Arabic-capable content.

The revised hierarchy is intentionally shorter: a single conversion-led hero, three trust signals, an assessment-focused approach, a concise specialist introduction, a three-step request pathway, a reduced FAQ preview, and one secure appointment call to action. General enquiries are now placed in a collapsed disclosure to keep the initial page focused while preserving the existing consent-gated enquiry flow.

## Preserved public workflows

| Workflow | Result |
| --- | --- |
| English and Arabic selector | Preserved with the existing `/en` and `/ar` routes and alternate-link logic. |
| Secure appointment request | Preserved at `/en/appointment`; the copy continues to state that a request is not an automatic confirmation. |
| WhatsApp actions | Preserved, including analytics event recording and the clinic’s supplied WhatsApp number. |
| Clinic location | Preserved with the owner-provided New Look Clinic address and exact map URL. |
| General enquiry | Preserved as a consent-gated form using the existing private enquiry mutation. |
| SEO and local content | Existing metadata, alternate links, treatment/FAQ/guide routes, and local clinic identity are untouched. |

## Validation

TypeScript checking passed. The complete Vitest suite passed: **67 test files passed, 1 skipped; 265 tests passed, 1 skipped**. The production build passed. A desktop browser preview and a 390 × 844 mobile browser capture were reviewed. Both show readable typography, visible conversion actions, responsive navigation, and no horizontal overflow in the verified viewport.

The production build retains the existing non-blocking large-client-bundle advisory. Addressing code splitting would be a separate performance task and was not mixed into this visual redesign.
