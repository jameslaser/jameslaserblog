# Managed-Domain Public Launch Evidence

**Scope.** This no-credit audit validates the current Manus-managed public domain only. It does not create or alter Cloud Run, billing, database, migration, DNS, custom-domain, Google, Firebase, OAuth, or other external-account resources.

## Initial route and boundary evidence

On 27 August 2026, the following route probes on `https://jameslaser-elxrr9qk.manus.space` returned HTTP 200: `/`, `/en`, `/ar`, `/appointment`, `/privacy`, `/terms`, `/robots.txt`, `/sitemap.xml`, and `/admin`. The public `/admin` response did not expose the searched protected patient markers (`MRN`, `patient file`, `consent signature`, or `machine appointments`); it presented only a login marker.

The public homepage rendered with the title **“Men’s Laser Hair Removal in Riyadh | New Look Clinic”**, the configured English description, canonical URL `https://jameslaserhairremovall.com/`, and an `index,follow` robots directive. Its JSON-LD contained a LocalBusiness graph that used the configured clinic name, Riyadh address, Saudi Arabia country code, telephone, area served, and a service offer catalog. The reviewed root response also emitted HSTS, CSP, `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`, a restrictive permissions policy, and a strict referrer policy.

`robots.txt` allows public crawling, disallows `/admin`, and points to the configured final-domain sitemap. The sitemap contained the expected English and Arabic public route families plus appointment routes, without protected admin routes.

## Corrected homepage alternate-language metadata

The initial root-page audit identified that no `hreflang` alternate link tags were rendered. The public homepage now declares and renders these alternate mappings through both static document metadata and route-level browser synchronization:

| Language target | Hreflang | Canonical public URL |
|---|---|---|
| English | `en` | `https://jameslaserhairremovall.com/en` |
| Arabic (Saudi Arabia) | `ar-SA` | `https://jameslaserhairremovall.com/ar` |
| Default | `x-default` | `https://jameslaserhairremovall.com/en` |

The local browser preview confirmed the expected page title, final-domain root canonical, all three alternate mappings, the crawlable robots directive, and no tested protected clinic terms in the public homepage body. Focused regression tests passed for the static document and the route-level homepage source implementation.

## Public route matrix

The following public routes rendered from the local managed preview with their intended English or Arabic layout. No forms were submitted, and no customer, appointment, consent, patient, result, promotion, or other operational data was created or changed during this review.

| Route family | Evidence status | Notes |
|---|---|---|
| `/`, `/en`, `/ar` | PASS | English and Arabic public landing experiences rendered with clear appointment-request routing. |
| `/appointment`, `/ar/appointment` | PASS | English and Arabic request forms rendered. The request is clearly described as subject to clinic confirmation. |
| `/en/treatments`, `/ar/treatments` | PASS | Published treatment catalogue rendered bilingually. |
| `/en/offers`, `/ar/offers` | PASS | No promotion was invented; both routes rendered an explicit empty state because no clinic-approved offer is published. |
| `/en/results`, `/ar/results` | PASS | No result, rating, review, or testimonial was invented; both routes rendered an explicit consent-controlled empty state. |
| `/en/faq`, `/ar/faq` | PASS | Bilingual FAQ layouts rendered. |
| `/en/guide`, `/ar/guide` | PASS | Bilingual clinic-guide listings rendered. |
| `/admin` | PASS | Public visitor response presented authentication entry only; the tested patient and clinical record markers were absent. |
| `/privacy`, `/terms` | EXPECTED 404 | These bare paths are not registered public routes and are not sitemap entries. They render the branded recovery page rather than exposing content or a server error. Published policy pages use the `/policies/:slug` route family. |

The homepage and all reviewed public listings remained readable on desktop and mobile. Arabic pages kept right-to-left composition, and no fabricated promotional, results, rating, or testimonial content was introduced.

## Remaining owner-dependent boundary

The canonical, Open Graph, social-image, robots, sitemap, and alternate URLs intentionally use the configured final domain instead of the temporary managed domain. Their final-domain reachability remains an owner-dependent custom-domain/DNS action and is not assumed in this audit.

## Validation summary

The candidate build passed TypeScript validation, **147 tests across 45 test files**, and the production build. The local managed service responded with `{"status":"ok"}` at `/healthz` and `{"status":"ready"}` at `/readyz`. A fresh error scan following the homepage change contained no application, browser, syntax, or request errors. The existing large-client-bundle advisory remains a non-failing build warning and does not indicate a runtime failure.

> **Result: PASS for the completed safe in-project public launch evidence.** The homepage alternate-language gap found during this audit was corrected and protected clinical data was not exposed during the reviewed public-route checks.

| Boundary | Status | Reason |
|---|---|---|
| Managed-domain public routes and local preview | PASS | Route, visual, metadata, sitemap, robots, headers, health, readiness, and privacy-boundary checks completed. |
| Homepage language alternatives | PASS | English, `ar-SA`, and `x-default` alternatives were added, regression-tested, and confirmed in the rendered DOM. |
| Final custom domain `jameslaserhairremovall.com` | OWNER ACTION REQUIRED | DNS/custom-domain connection and live reachability were intentionally not changed or assumed. |
| Cloud Run, Firebase, Google Billing, Cloud SQL/PostgreSQL, database migration, OAuth production callback, and external deployment | PAUSED | Explicit owner-directed pause remains in force; none of these resources or settings were touched. |
| Search Console and Business Profile verification or submission | OWNER ACTION REQUIRED | These third-party account actions were not performed. |

## References

[1] [Current Manus-managed public domain](https://jameslaser-elxrr9qk.manus.space/)

[2] [Public crawl directives](https://jameslaser-elxrr9qk.manus.space/robots.txt)

[3] [Current sitemap](https://jameslaser-elxrr9qk.manus.space/sitemap.xml)

## Map destination update evidence

The public homepage now renders exactly one map action labeled `Open map`, with `target="_blank"`, `rel="noreferrer"`, and the owner-provided destination `https://maps.app.goo.gl/LYx98uWLW8kHdsMv7?g_st=ic`. The previous generated `google.com/maps/search` destination is absent from the public source. Focused map-link tests passed before this evidence was recorded; no map action was submitted or otherwise interacted with during the check.
