# Phase 2 WhatsApp Deployment and Operations Runbook

## Purpose and deployment boundary

Phase 2 adds a **direct Meta WhatsApp Business Platform Cloud API** integration to the existing Cloud Run service. It does not add WhatsApp Web automation, personal-account automation, an external CRM, autonomous appointment booking, autonomous rescheduling, autonomous cancellation, marketing broadcasts, or artificial message status updates.

The deployed service hosts two public webhook routes at `/api/webhooks/whatsapp`. The `GET` endpoint completes Meta’s verification challenge. The `POST` endpoint accepts only payloads carrying a valid Meta HMAC signature over the original request bytes, then stores a deduplicated operational record in PostgreSQL. Meta documents that a valid verification response must return HTTP 200 together with the received `hub.challenge`; otherwise the endpoint is considered unverified. [1] Meta’s WhatsApp webhook overview also describes `messages` as the subscription that provides inbound messages and outgoing-message status updates. [2]

> **Important:** The code is complete without secret values. Do not paste a Meta password, access token, app secret, verification token, or two-factor code into a conversation, repository, issue, or build substitution.

| Component | Phase 2 implementation | Production responsibility |
| --- | --- | --- |
| Inbound customer messages | Meta webhook → Cloud Run → PostgreSQL → protected Admin Inbox | Owner configures Meta callback and subscribes to `messages`. |
| Outbound staff messages | Protected Admin inbox → server-side Graph API client → Meta | Owner provides a production system-user token through Secret Manager. |
| Delivery status | Meta webhook status event updates the matching unique Meta message ID | Owner performs a test-number send and observes the available real status events. |
| Template usage | Template metadata is synchronized server-side; only `approved` entries may be used outside the service window. Declared body placeholders require complete staff-entered text values and are revalidated on the server. | Owner creates and approves required English/Arabic templates in WhatsApp Manager. |
| Patient workflow | Exact normalized-phone links to requests/patients/appointments; staff handles ambiguity | Staff maintains the existing review and approve-and-transfer process. |

## Deployment sequence

Apply the Phase 2 PostgreSQL migrations to an approved target database **before** deploying the Cloud Run revision. Do not run migrations from an application request handler or by exposing database credentials to the browser. The isolated migration history is under `drizzle-pg/` and contains the new WhatsApp operational entities.

| Migration | Purpose |
| --- | --- |
| `0001_phase2_whatsapp_business.sql` | Adds contacts, conversations, messages, templates, webhook receipt records, automation records, safe settings, enums, and non-cascading foreign-key relationships. |
| `0002_phase2_template_identity.sql` | Adds the business-account/template-name/language identity required for idempotent template metadata synchronization. |

The runtime service uses the Phase 1 Cloud SQL socket and `DATABASE_URL` contract. The Cloud Run revision does **not** need the historical MySQL/TiDB source credential and must never be configured with `MYSQL_SOURCE_URL`.

## Secret Manager configuration

The committed `cloudbuild.yaml` mounts the following values from Google Secret Manager into the Cloud Run runtime. The names are intentionally substitutions, so the project owner can change a secret resource name without placing a credential in source control.

| Runtime variable | Default Secret Manager resource name | Value type | Used only by |
| --- | --- | --- | --- |
| `META_APP_ID` | `james-laser-meta-app-id` | Meta application identifier | Server configuration health only. |
| `META_APP_SECRET` | `james-laser-meta-app-secret` | Meta app secret | Webhook HMAC signature verification. |
| `WHATSAPP_ACCESS_TOKEN` | `james-laser-whatsapp-access-token` | Long-lived production system-user token | Server-side Meta Graph API client. |
| `WHATSAPP_PHONE_NUMBER_ID` | `james-laser-whatsapp-phone-number-id` | WhatsApp production phone identifier | Messages API path construction. |
| `WHATSAPP_BUSINESS_ACCOUNT_ID` | `james-laser-whatsapp-business-account-id` | WhatsApp Business Account identifier | Template metadata synchronization. |
| `WHATSAPP_WEBHOOK_VERIFY_TOKEN` | `james-laser-whatsapp-webhook-verify-token` | Owner-generated opaque random string | GET webhook verification comparison. |
| `META_GRAPH_API_VERSION` | `james-laser-meta-graph-api-version` | Current supported Graph API version, such as `vXX.X` | Server-side Graph API URL construction. |

The Cloud Run runtime service account must have **Secret Manager Secret Accessor** for each listed secret resource. The Cloud Build deployer must retain its existing rights to deploy the service, update the revision, and reference the runtime service account. The runtime service account must retain its Cloud SQL client access. The owner should grant only these narrowly scoped roles rather than a broad project-owner role.

## Activation preflight and staging replay

Run `pnpm whatsapp:preflight` from the owner-controlled Cloud Run deployment shell after Secret Manager values are mounted. The command validates only presence and safe shape: it reports required variable names, missing names, and non-sensitive format errors, but never prints any secret value. A non-zero result blocks activation until the configuration is corrected.

The repository also includes `fixtures/whatsapp-inbound-greeting.json` and `pnpm whatsapp:replay`. The replay command is **dry-run by default** and makes no network request. In an owner-controlled staging shell, after replacing the fixture identifiers with a fresh non-clinical test event, run it with `META_APP_SECRET` available only in that shell and add `--confirm-staging` explicitly. Use a staging callback URL, observe the HTTP response, then verify exactly one persisted message, notification, audit outcome, and status transition. Never use the fixture against production without a separate owner approval.

## Owner setup actions

Complete the following in order. Each secret is entered directly in its provider’s secure console, not in a chat message.

| Step | Where | Value type | Expected result |
| --- | --- | --- | --- |
| 1. Create or select the Meta application | Meta for Developers | Owner account action | An application containing the WhatsApp product is available. |
| 2. Connect business assets | Meta Business Portfolio and WhatsApp Manager | Owner account action | The correct WhatsApp Business Account and a verified production business phone are connected. |
| 3. Create Secret Manager values | Google Cloud Console → Security → Secret Manager | Seven values in the table above | Each runtime value exists as a separate secret version; no value is committed to GitHub. |
| 4. Grant runtime access | Google Cloud IAM / each Secret Manager secret | Service-account role assignment | The Cloud Run runtime account can read only the required secret versions. |
| 5. Apply migrations | Approved database administration process | Database change approval | The two Phase 2 migrations are applied successfully to Cloud SQL PostgreSQL. |
| 6. Configure substitutions and deploy the Cloud Run revision | Existing Cloud Build trigger or approved build process | Set `_SERVICE_ACCOUNT`, `_CLOUDSQL_INSTANCE`, `_VITE_PUBLIC_SITE_ORIGIN`, `_OAUTH_SERVER_URL`, and `_VITE_APP_ID`; then submit the validated `main` revision | `james-laser-web` runs the Phase 2 revision with Secret Manager mounts. |
| 7. Set callback and verification token | Meta App Dashboard → WhatsApp → Configuration | Callback: `https://<production-origin>/api/webhooks/whatsapp`; verification token entered directly from Secret Manager | Meta sends the verification `GET`, receives HTTP 200 plus its challenge value, and marks the endpoint verified. |
| 8. Subscribe to webhook fields | Meta App Dashboard → WhatsApp configuration | Subscribe to `messages` | Meta delivers inbound message and status events to Cloud Run. |
| 9. Create approved templates | WhatsApp Manager | English and Arabic operational templates | Templates required outside the customer-service window become Meta-approved and appear after synchronization. |
| 10. Run activation preflight and staging replay | Owner-controlled deployment shell and non-production callback | `pnpm whatsapp:preflight`; dry-run replay first; `--confirm-staging` only for an approved staging URL | Configuration is complete without secret leakage, and retry/idempotency behavior is observed before production traffic. |
| 11. Perform controlled production verification | Owner-authorized WhatsApp test number | Non-clinical test messages only | Incoming, outbound, and available delivery/read statuses are demonstrated without touching a real booking. |

## Webhook verification and status checks

The GET verification implementation compares Meta’s `hub.verify_token` against `WHATSAPP_WEBHOOK_VERIFY_TOKEN` and returns only the supplied challenge on success. Meta’s setup documentation describes this verification request and the required 200/challenge response. [1] The POST implementation is intentionally unauthenticated at the application-session layer but performs a constant-time `x-hub-signature-256` HMAC comparison against `META_APP_SECRET` before any data is persisted.

| Check | Expected result | Failure response |
| --- | --- | --- |
| GET with valid mode, token, and challenge | HTTP 200 with challenge text | Meta marks callback verified. |
| GET with invalid token | 4xx response | Callback remains unverified; no secret detail is returned. |
| POST with invalid or missing signature | HTTP 401 | No contact, message, or notification is created. |
| POST with malformed body | HTTP 400 | No operational record is created. |
| Repeated processed/ignored raw event | HTTP 200, no duplicate customer message or notification | The recorded fingerprint is acknowledged as a safe duplicate. |
| Repeated failed/interrupted raw event | HTTP 200 after a successful retry, with exactly one persisted customer message | The matching receipt is reset for controlled reprocessing; unique Meta message identity prevents duplicate content. |
| Incoming `messages` event | Contact/conversation/message appears in PostgreSQL and the protected Admin Inbox | A generic staff notification is created. |
| `sent`, `delivered`, `read`, or `failed` status | Existing Meta message ID is updated with the actual status and timestamp | Unsupported statuses are ignored safely. |

Meta indicates that it retries webhook deliveries that do not receive HTTP 200. Processed and ignored receipts are therefore acknowledged as duplicates, while failed or interrupted receipts are reprocessed against the same fingerprint. Unique Meta message identity preserves exactly-once message persistence across the controlled retry. [2]

## Required operational templates

The initial Meta template catalog should cover the following operational scenarios in **English and Arabic** where needed: appointment request received, clarification needed, appointment confirmed after staff approval and transfer, appointment reminder, reschedule information, cancellation information, and follow-up. The code does not create marketing campaigns or bulk broadcasts.

Free-form service messages are allowed only while the customer-service window is open. When it is closed, Meta requires a pre-approved template; the server therefore rejects a free-form send outside the tracked window and requires an `approved` template instead. A template with `{{n}}` body placeholders requires exactly `n` text values from staff; the Inbox will not enable submission until every declared value is present, and the server repeats that validation. [3]

## Controlled production verification

Use only an owner-authorized test number. Do not send a test that claims a real customer appointment is confirmed.

| Verification path | Action | Success condition |
| --- | --- | --- |
| Inbound message | Send a simple greeting from the authorized test phone to the business phone. | The `messages` webhook is logged as processed; a contact, conversation, message, and unread count appear in the Admin Inbox. |
| Staff response | Open the protected Admin Inbox and send a neutral free-form response while the service window is open. | Meta returns a message ID; the stored outgoing item remains `sending` until Meta later supplies its real `sent`, `delivered`, `read`, or `failed` webhook status. |
| Closed-window behavior | Use a test conversation whose tracked window is closed. | The free-form action is rejected and an approved template can be selected instead; complete every declared template variable with neutral non-clinical test text. |
| Duplicate delivery | Replay an approved processed test event only in a controlled environment, or observe an actual Meta retry. | The event is safe: no duplicate message or duplicate staff notification occurs. |
| Retry after controlled failure | In a non-production target, force the first authenticated receipt to fail after the receipt record is created, then submit the identical payload. | The same fingerprint is retried and exactly one message, notification, and audit outcome are persisted. |
| Request linking | Submit an authorized test appointment request using the same exact normalized test number. | The existing contact/conversation links to the new patient request, but no appointment is created. |
| Approval and transfer | Perform the normal admin approval flow on a non-clinical test request. | Patient and appointment links appear after the existing explicit transfer succeeds; a WhatsApp message alone never creates the appointment. |
| Reschedule/cancel language | Send a neutral test message asking to change or cancel an appointment. | Staff-review flag/notification is created; the appointment database record is unchanged. |

## Data handling and retention policy

Phase 2 stores original message text, conversation state, delivery status, safe webhook event summaries, and linking/audit information in PostgreSQL. Original content is not overwritten with a translation. The conversation list displays only minimum operational preview information; detailed patient information remains on existing protected patient pages.

Inbound media is intentionally **not downloaded automatically** in Phase 2. The service may retain the Meta media identifier and MIME type as a private operational reference, but it does not publish it or retrieve it to public storage. Before enabling any later media-download feature, the clinic owner must approve a documented retention duration, authorized-purpose policy, protected private-storage path, deletion mechanism, and access-audit process.

No automatic message or attachment deletion job is deployed in this phase because the clinic has not supplied an approved retention period or legal-basis schedule. Before live use, the clinic owner must document the retention period, legal basis, deletion approval process, preservation-hold exceptions, and responsible role. A future retention job must be documented, reversible, auditable, and owner-approved; it must never silently delete activity evidence needed for an active patient request, consent workflow, appointment dispute, or legally required retention period.

## Secret rotation and incident response

Rotate the access token, app secret, or verification token only through Secret Manager. Create a new secret version, grant the existing runtime service account access, deploy a new Cloud Run revision, validate the webhook and a test message, then disable the old version according to the clinic’s incident process. Never log tokens, post them to support channels, or add them to frontend build variables.

If Meta access-token or webhook verification fails, the website’s `/healthz` and PostgreSQL readiness behavior remain independent. The web application should remain available; the protected WhatsApp Settings and Webhook Logs views should be used to investigate the integration-specific condition.

## References

[1]: https://developers.facebook.com/documentation/business-messaging/whatsapp/webhooks/create-webhook-endpoint "Meta WhatsApp Business Platform — Create a webhook endpoint"
[2]: https://developers.facebook.com/documentation/business-messaging/whatsapp/webhooks/overview "Meta WhatsApp Business Platform — Webhooks overview"
[3]: https://developers.facebook.com/documentation/business-messaging/whatsapp/messages/send-messages "Meta WhatsApp Business Platform — Service messages"
