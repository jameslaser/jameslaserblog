# Appointment Duplicate-Reuse Verification

## Baseline and scope

This verification targets published checkpoint `8c785b29` and preserves rollback baseline `41702f9c`. It is limited to in-project, non-destructive checks. No clinic record was inserted, updated, deleted, or migrated, and no infrastructure task was resumed.

## Contract results

| Scenario | Expected behavior | Verification result |
|---|---|---|
| Same MRN, new phone | Reuse the MRN patient file and link the appointment | PASS — `resolveSinglePatientFile` returns the MRN patient ID. |
| Same phone/WhatsApp, new MRN | Reuse the phone patient file and link the appointment | PASS — returns the phone patient ID. |
| Same MRN and same phone | Reuse one existing patient file | PASS — returns the shared patient ID. |
| New MRN and new phone | Make one new-patient decision | PASS — resolver returns no existing patient; the approval transaction is the only path that creates a new file. |
| Divergent MRN and phone | Reject rather than overwrite or relink | PASS — identity guard throws for different patient files. |
| Existing appointment already linked | Preserve the existing patient link | PASS — linked-patient guard returns the existing ID when consistent and rejects relinking. |

## Protected workflow evidence

The protected request approval router returns `existingPatientFound` and `matchedBy` (`mrn`, `whatsapp`, `both`, or `null`). The request workspace presents an Existing Patient Found notice when reuse occurs. The appointment and Patients workspaces rendered successfully during the non-submitting desktop review. Focused validation passed with 46 tests across identity, admin-router, and consent-workspace files, plus TypeScript validation.

## Data and security boundaries

The existing patient profile is preserved when a match is found. The appointment is linked through `appointments.patientId`. Manual appointment creation, manual patient creation, Waiting List arrival, HMS NR011 filtering, public requests, RBAC, authentication, and database architecture remain unchanged. No real-data workflow submission was performed because doing so would change clinic records; the evidence is contract-level and UI-level rather than a live mutation test.
