# Phase 1 Cloud Run and Cloud SQL Deployment Runbook

## Deployment boundary

The repository now provides a Cloud Build configuration that creates a locked-dependency Node 22 container, publishes it to Artifact Registry, and deploys it to Cloud Run. The configuration attaches a designated Cloud SQL for PostgreSQL instance, sets a bounded database pool, and references runtime credentials through Secret Manager. The deployment is intentionally configured with placeholders; it cannot be safely submitted until the project owner supplies the exact Google Cloud project, service account, OAuth settings, final public origin, and Cloud SQL connection name.

Cloud Run verifies that the service identity can access referenced secrets during deployment. For environment-variable secrets, Cloud Run retrieves the value before the instance starts, so a missing or inaccessible secret prevents the instance from starting successfully. [1] The Cloud SQL connection uses the instance connection name and the service account assigned to the Cloud Run service; Cloud SQL documents that the instance connection name is available from the instance overview or `gcloud sql instances describe`. [2]

> **No production submission has been performed.** A production deployment, domain mapping, DNS change, database migration, or secret creation remains an owner-controlled action.

## Repository artifacts

| Artifact | Purpose |
| --- | --- |
| `Dockerfile.cloudrun` | Multi-stage Node 22 image that installs locked dependencies, builds the application, and runs the bundled server as the `node` user on port `8080`. |
| `cloudbuild.yaml` | Builds the tagged Artifact Registry image, attaches Cloud SQL, assigns the runtime identity, supplies non-secret configuration, references Secret Manager values, and publishes the Cloud Run revision. |
| `.dockerignore` | Excludes local modules, `.env` files, build outputs, logs, and workspace artifacts from the Docker build context. |
| `POSTGRESQL_DATA_MIGRATION.md` | Controls the separate source-to-PostgreSQL migration and reconciliation process. |
| `ENVIRONMENT_VARIABLES.md` | Defines the current secret, non-secret, build-time, and migration-only configuration contract. |

## Required owner inputs

| Placeholder or setting | Owner action |
| --- | --- |
| `PROJECT_ID` | Select the intended Google Cloud project. |
| `_REGION` | Confirm the production region. The current default is `me-central1`. |
| `_SERVICE_ACCOUNT` | Create or nominate the Cloud Run runtime service account, for example `james-laser-runtime@PROJECT_ID.iam.gserviceaccount.com`. |
| `_CLOUDSQL_INSTANCE` | Supply the Cloud SQL instance connection name in the form `PROJECT:REGION:INSTANCE`. |
| `_VITE_PUBLIC_SITE_ORIGIN` | Supply the final HTTPS origin. Use the assigned Cloud Run URL temporarily if the custom domain is not yet mapped. |
| `_OAUTH_SERVER_URL` and `_VITE_APP_ID` | Confirm the existing OAuth provider’s production values and allowed callback origin. |
| Optional frontend Forge values | Leave blank unless a public-scoped, browser-authorized Forge endpoint and key are required for the map component. Never pass a server credential as a Vite build argument. |

## IAM and Secret Manager setup

Use a dedicated Cloud Run runtime service account rather than the default compute service account. Grant it the Cloud SQL Client role for the attached instance and Secret Manager Secret Accessor only for the named application secrets. Cloud Build must be able to build to the Artifact Registry repository and deploy the service using the nominated runtime identity. Verify the applicable organization policies before granting roles.

Create the following Secret Manager secrets with one active version each. The secret values are not committed, logged, or embedded in `cloudbuild.yaml`.

| Secret substitution | Runtime environment variable | Content |
| --- | --- | --- |
| `_DATABASE_URL_SECRET` | `DATABASE_URL` | PostgreSQL database URL containing the application database user, password, and database name. The host may be `localhost`; Cloud Run overrides it through `DB_SOCKET_PATH`. |
| `_JWT_SECRET` | `JWT_SECRET` | Strong session-signing secret. |
| `_OWNER_OPEN_ID_SECRET` | `OWNER_OPEN_ID` | Existing owner authorization identifier. |
| `_FORGE_API_URL_SECRET` | `BUILT_IN_FORGE_API_URL` | Server-side storage service endpoint. |
| `_FORGE_API_KEY_SECRET` | `BUILT_IN_FORGE_API_KEY` | Server-side storage credential. |

The Cloud Build defaults identify secret names but contain no secret value. Change a secret name through a Cloud Build substitution or the configuration file only after the owner creates that secret and grants the runtime identity access.

## Database and migration gate

Create a distinct Cloud SQL for PostgreSQL target and apply `drizzle-pg/0000_phase1_postgresql_baseline.sql` only to that empty target. Preserve the existing MySQL/TiDB database as the source of record. Perform the controlled dry run, import, reconciliation, and owner sign-off described in `POSTGRESQL_DATA_MIGRATION.md` before any production service revision uses the PostgreSQL target.

The application’s Cloud Run database pool is intentionally bounded to five connections per container, with a Cloud Run concurrency value of 20 and a maximum of three instances. Adjust these values together only after a Cloud SQL connection-budget review. The runtime attaches the Cloud SQL instance and uses `/cloudsql/PROJECT:REGION:INSTANCE` as `DB_SOCKET_PATH`; the `DATABASE_URL` secret retains the database credential while this path supplies the connection transport.

## Build and deployment sequence

After the owner replaces all placeholder substitutions, create or update a Cloud Build trigger from the protected deployment branch. The trigger should run the repository `cloudbuild.yaml`, use a Git commit SHA tag, and require a review before merge. Cloud Build supports building an image, publishing it, and deploying it to Cloud Run in the same build configuration. [3]

Before traffic is moved, validate the newly deployed revision using its service URL. Confirm `/healthz` returns `200` and `/readyz` returns `200` only after the runtime database is available. Verify both English and Arabic public routes; anonymous `GET` requests must not expose protected request, patient, consent, upload, or admin content. Sign in with the owner account and exercise the required appointment, CMS, consent, audit, and media-link workflows against the PostgreSQL QA target.

| Verification stage | Required result |
| --- | --- |
| Container build | The image builds from the locked `pnpm-lock.yaml` and contains no `.env` files or source secrets. |
| Cloud Run deployment | The revision becomes ready with the dedicated runtime service account and all referenced secrets resolvable. |
| Database readiness | `/readyz` becomes healthy only with a valid PostgreSQL connection through the attached Cloud SQL socket. |
| Smoke test | Public routes resolve; unauthorized admin and storage requests are rejected; authorized owner flows work. |
| Migration reconciliation | All source/target counts match and orphan checks are empty. |
| Cutover | Owner explicitly approves production `DATABASE_URL`, traffic movement, and any custom-domain mapping. |

## Deferred items

WhatsApp migration or activation, HMS CSV import execution, new test patient creation, custom-domain/DNS changes, and the irreversible production data cutover are deliberately deferred. They require separate validated source material or owner authorization.

## References

[1]: https://docs.cloud.google.com/run/docs/configuring/services/secrets "Configure secrets for Cloud Run services"
[2]: https://docs.cloud.google.com/sql/docs/postgres/connect-run "Connect from Cloud Run to Cloud SQL for PostgreSQL"
[3]: https://docs.cloud.google.com/build/docs/deploying-builds/deploy-cloud-run "Deploying to Cloud Run using Cloud Build"
