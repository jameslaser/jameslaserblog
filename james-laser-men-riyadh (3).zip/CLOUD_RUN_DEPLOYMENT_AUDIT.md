# Independent Cloud Run Deployment Audit

**Scope:** Cloud Run/external deployment only. Manus fallback, current MySQL/TiDB database, authentication, governance records, policies, RBAC, audit logs, staff workflows, and DNS remain untouched.

## Repository architecture

The repository is `jameslaser/jameslaserhairremovalfullmanus`, currently on the feature branch `feature/complete-james-laser-system` with the working release at checkpoint `285c73cb`. It is a single full-stack application: React 19 and Vite on the frontend, Express and tRPC on the backend, and Drizzle ORM with the existing MySQL/TiDB database. It is not an SSR application and should deploy as one service rather than splitting frontend and API unnecessarily.

The production contract is `pnpm install && pnpm build` during image build and `pnpm start` at runtime. The active build bundles the frontend and `server/_core/index.ts` into `dist`, and the production server binds the Cloud Run-provided `PORT` on `0.0.0.0`. The active server includes `/healthz`, database-backed `/readyz`, SPA fallback, OAuth callback, tRPC API, storage proxy, public webhook routes, and protected application routes.

The existing container preparation uses `Dockerfile.cloudrun`, a multi-stage Node 22 image with locked pnpm dependencies, a production build, an unprivileged `node` runtime user, and port `8080`. The repository has no Firebase Hosting configuration and no active Railway, Vercel, or Netlify configuration.

## Cloud Build preparation status

`cloudbuild.yaml` has been aligned with the current application runtime without creating or enabling a Cloud Run service. It now removes the paused Cloud SQL attachment and PostgreSQL socket variables and references the existing MySQL/TiDB connection through a Secret Manager placeholder named `james-laser-mysql-url`, exposed only as runtime `MYSQL_URL`. No actual secret value is present in the repository.

The configuration still contains owner-controlled placeholders for the Google Cloud project, service account, production origin, OAuth server, and frontend application ID. The WhatsApp/Meta Secret Manager placeholders remain server-side only. The current Manus deployment and database are not changed by this preparation.

## Authenticated Google Cloud inspection

The browser reached Google Cloud Console while signed in as the clinic owner account. The selected Google Cloud project is **My First Project**, project ID `intense-vault-420023`. Cloud Run Services displayed no existing services and offered only “Deploy container” and “Connect repo”; therefore no Cloud Run service currently serves this project.

The billing page opened in read-only mode but did not expose a linked-account status in the rendered result. No billing activation, payment method, project change, service enablement, Secret Manager operation, or deployment action was attempted.

## Exact deployment boundary

The application artifacts can be prepared for Cloud Run while preserving the existing MySQL/TiDB source. However, an actual Cloud Run deployment still requires owner-controlled Google Cloud actions: confirming the intended project, confirming billing eligibility, selecting or creating the runtime service account, creating the named Secret Manager values, granting the required IAM roles, and authorizing the Cloud Build/Artifact Registry path. The current sandbox has no local `docker`, `gcloud`, or `firebase` executable, so local image build and Cloud Run submission cannot be performed here.

The safest next step is for the owner to confirm that `intense-vault-420023` is the intended Google Cloud project and that its billing/API prerequisites are already satisfied. If Google requests billing activation, payment, organization permission, or account authorization, work must stop at that boundary. No custom-domain DNS change should occur until an external deployment is independently healthy.

## Google Cloud account inspection update

The authenticated Google Cloud Console selected project **My First Project** with project ID `intense-vault-420023`. Cloud Run Services showed no deployed services in that project. The read-only Billing page showed that the project has a linked **My Billing Account 2** marked **Paid account**, with the displayed cost summary at `$0.00`; no billing changes were made. The linked-account status alone does not prove that all required Cloud Run APIs, IAM permissions, Artifact Registry access, or Secret Manager permissions are ready.

## Final artifact validation

The Cloud Run configuration tests and complete regression suite pass: 54 test files and 173 tests passed. The production build also passed. Static checks confirm the configuration contains no Cloud SQL attachment, PostgreSQL URL, or Unix-socket setting and does reference the MySQL/TiDB `MYSQL_URL` Secret Manager placeholder. Local `docker`, `gcloud`, and `firebase` executables are unavailable, so no local image build or external submission was attempted.

The prepared configuration is therefore a safe, non-submitted deployment artifact. It is not evidence that a Cloud Run service exists or that Google Cloud billing, APIs, IAM, Artifact Registry, Secret Manager, OAuth callback settings, or the external TiDB network path are ready.

## Deployment boundary reached in Cloud Console

The authenticated Cloud Run repository deployment flow opened successfully for project `intense-vault-420023`, but Google Cloud displayed a blocking modal: **“Enable billing to keep using Cloud Run”** with a **“Go to Billing”** action. The Cloud Run Services page still showed no service. Although the linked billing page displayed **My Billing Account 2 — Paid account**, Cloud Run requires a valid billing association/verification for this project or account state before the repository deployment flow can continue. No billing action was clicked, no service was created, no build was triggered, and no secret or DNS operation was performed.

The repository connection/deployment flow is therefore stopped at Google’s billing prerequisite boundary, exactly as requested. PostgreSQL/Cloud SQL migration remains paused, the MySQL/TiDB source remains unchanged, and the Manus fallback remains intact.

## Built-in database decision

The owner confirmed that the external service must use the existing built-in database, not PostgreSQL or Cloud SQL. The application’s active production runtime uses MySQL/TiDB and reads `MYSQL_URL`; the Cloud Run preparation now matches that contract. An external Cloud Run service cannot inherit the Manus environment secret automatically, so a deployment would require the owner to place the same existing connection value into a Google Secret Manager secret named by `_MYSQL_URL_SECRET` (currently `james-laser-mysql-url`) or explicitly provide an equivalent secure secret reference. The value must not be committed to GitHub or printed in reports.

The external service also needs network access to the current managed MySQL/TiDB endpoint. This has not been tested from Cloud Run because no service or revision exists. If the provider blocks the connection or requires an allowlist change, work must stop rather than creating Cloud SQL or migrating data.
